---
name: skill-creator
description: Create, edit, and improve Agent Skills for this project. Use this whenever the user wants to make a new skill, turn a workflow or set of repeated instructions into a reusable skill, capture domain knowledge or a procedure the agent should follow on demand, or refine an existing skill. Trigger it even when the user only says things like "make a skill", "save this as a skill", "turn this into a skill", or describes a repeatable task they want the agent to remember how to do later.
---

# Skill Creator

Use this skill to author new Agent Skills and improve existing ones. A skill packages instructions (and optionally scripts, references, and assets) that the agent loads only when a task needs them.

## What a skill is

A skill is a folder with a single required file, SKILL.md, plus optional supporting files. Skills follow the open Agent Skills convention, so a skill written here works in any compatible agent.

Skills exist because of progressive disclosure — the agent should not carry every instruction in context all the time. Loading happens in three levels:

1. Metadata — the name and description from the frontmatter. This is always visible in the agent's skill catalog, so it stays small.
2. Instructions — the full SKILL.md body. Loaded only when the agent decides the skill is relevant and reads the file.
3. Resources — files under scripts, references, and assets. Loaded only when the instructions point at them.

This is why the description matters most: it is the only thing the agent sees before deciding to open the skill. Everything else is paid for only when used.

## Where skills live

Create skills under the project's agent skills directory:

```
.agents/skills/<skill-name>/SKILL.md
```

The folder name must match the name field in the frontmatter exactly. The agent scans .agents/skills on startup, reads each skill's frontmatter, and lists it in the skill catalog — so a skill you create here is available on the next run with no extra wiring.

## Step 1: Capture intent

Before writing, get clear on:

1. What should this skill let the agent do?
2. When should it trigger — what user phrasings or contexts?
3. What is the expected output or end state?

If the current conversation already contains the workflow the user wants to capture (they said "turn this into a skill"), pull the steps, tools, file paths, and corrections out of the history first, then confirm the gaps with the user instead of asking everything from scratch.

## Step 2: Choose the name and write the frontmatter

The frontmatter is a YAML block at the very top of SKILL.md between `---` markers. Two fields are required.

- `name`: lowercase letters, numbers, and hyphens only, max 64 characters, must not start or end with a hyphen, and must match the folder name.
- `description`: one to a few sentences covering both what the skill does and when to use it. This is the primary trigger, so include concrete keywords and situations.

Write the description to trigger reliably. Agents tend to under-trigger skills — to skip them when they would actually help — so make the description a little pushy about when to use it. State the trigger conditions explicitly rather than leaving them implicit.

- Weak: "Build a dashboard to display internal metrics."
- Strong: "Build a dashboard to display internal metrics. Use this whenever the user mentions dashboards, charts, data visualization, internal metrics, or wants to display any kind of company data, even if they don't say the word dashboard."

Optional fields you can add when they apply: license, compatibility (environment or dependency requirements), and metadata (arbitrary key-value pairs). Spec-compliant agents ignore frontmatter keys they don't recognize, so unknown fields are safe but pointless — only add what you'll use.

## Step 3: Write the body

Below the frontmatter, write the instructions in Markdown. Guidance:

- Use the imperative voice — write instructions to the agent that will follow them.
- Explain the why behind important steps. Modern models follow reasoning better than a wall of rigid MUST and NEVER rules; if you find yourself writing those in all caps, try reframing as an explanation instead.
- Keep SKILL.md focused and ideally under about 500 lines. If it grows past that, move detail into reference files and point at them from the body.
- Define exact output formats with a template when the output shape matters.
- Include one or two concrete examples — they communicate intent faster than prose.

## Step 4: Add nested files when they help

Keep SKILL.md as the entry point and push heavier material into sibling folders. The conventional layout is:

```
.agents/skills/<skill-name>/
  SKILL.md
  scripts/
  references/
  assets/
```

- scripts — executable code (Python, Node, Bash) for deterministic or repetitive work. The agent can run a script without loading its full contents into context. If you notice the agent rewriting the same helper across runs, capture it here once.
- references — extra documentation the agent reads only when a task calls for it. Good for long specs, schemas, or per-variant guides. For a large reference (more than ~300 lines), add a short table of contents at the top.
- assets — files used in the output, such as templates, icons, fonts, or lookup tables.

Reference these files from SKILL.md and say when to read each one, for example: "For the AWS variant, read references/aws.md." Keep references one level deep — avoid chains where one file points at another that points at another. When a skill spans several variants or frameworks, organize by variant under references so the agent reads only the relevant file.

## Step 5: Verify

- Confirm the folder name matches the name field.
- Confirm the frontmatter is valid YAML and has a non-empty description.
- Re-read the description as if you were the agent deciding whether to open the skill — would a realistic user request clearly trigger it?
- If the skill bundles a script, make sure SKILL.md says how to run it.

The skill is now in .agents/skills and will appear in the catalog on the next run.

## A complete minimal example

File `.agents/skills/changelog-entry/SKILL.md`:

```markdown
---
name: changelog-entry
description: Add a release note to CHANGELOG.md in this repo's house format. Use whenever the user merges a change, cuts a release, or asks to record a changelog or release note, even if they only describe the change without saying "changelog".
---

# Changelog Entry

Add an entry to CHANGELOG.md under the Unreleased heading.

## Format

Use this exact shape, one bullet per change:

- <type>: <imperative summary> (#<pr-number>)

Where <type> is one of: feat, fix, docs, chore.

## Steps

1. Open CHANGELOG.md and find the "## Unreleased" section. Create it at the top if missing.
2. Add the bullet under the matching type, keeping bullets sorted by type.
3. Keep the summary under ~80 characters and in the imperative ("add", not "added").

## Example

Input: merged PR #214 that fixes a crash when the avatar URL is empty
Output: - fix: guard against empty avatar URL (#214)
```

## Improving an existing skill

When editing a skill rather than creating one:

- Keep the original name and folder unchanged unless the user asks to rename.
- Generalize from feedback. You are usually iterating on a few examples, but the skill must work across many future requests — prefer broader guidance over fixes that only satisfy the example in front of you.
- Keep the prompt lean. Remove instructions that aren't earning their place; extra rules can push the agent toward wasted work.
- When the same helper logic shows up every time the skill runs, move it into a script under scripts so future runs reuse it instead of reinventing it.

## A note on safety

Skills must not contain malware, exploit code, or anything that could compromise a system, and their behavior should match what their description claims. Decline requests to build skills designed to mislead users or to enable unauthorized access or data exfiltration. Ordinary creative or role-play skills are fine.
