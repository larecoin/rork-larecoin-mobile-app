---
name: play-store-metadata
description: Prepare truthful Google Play listing metadata from the app codebase. Read this for Android app names, short descriptions, full descriptions, release notes, localized listing copy, or metadata readiness.
---

# Play Store Metadata

Use this skill to prepare, review, and apply Google Play listing text through typed, project-bound backend operations. Never install a third-party CLI, request credentials, or claim prepared copy was uploaded unless the operation returns a committed `updated` result.

## Before Writing Copy

1. Read the app code and config to determine the real app name, package name, audience, screens, and features.
2. Read `.rork/skills/play-store-connect/SKILL.md` and call `setupGooglePlay` when the work is connected to an existing Play app.
3. Read `.rork/skills/play-store-preflight/SKILL.md` when metadata is part of release readiness.
4. Ask only for facts that cannot be inferred from code, such as regulated claims, official support contacts, or legal URLs.

## Metadata Fields

Prepare one locale at a time unless the user explicitly asks for several. Use BCP-47 locale identifiers such as `en-US`.

- `title`: app name on Google Play, at most 30 characters.
- `shortDescription`: first listing summary, at most 80 characters.
- `fullDescription`: complete description, at most 4000 characters.
- `video`: optional YouTube preview URL.

Count limits before presenting the result.

## Applying Metadata

1. Start from a successful committed Google Play `submissionId` for the current project.
2. Call `listPlayListings` before writing so existing localized values and the preview video are known.
3. Call `updatePlayListing` with the complete title, short description, and full description for one locale.
4. Omit `video` to preserve the current preview, pass `null` to remove it, or pass a YouTube URL to replace it.
5. Use `validateOnly: true` before committing unless the user already explicitly confirmed the exact copy and video change.

Report `validated` as a check only, `unchanged` as no mutation needed, and `updated` as committed. A validation result is not an applied listing.

## Copy Rules

- Ground every claim in the actual app and do not invent features.
- Do not keyword-stuff titles or descriptions.
- Do not repeat the short description as the first sentence of the full description.
- Avoid rankings, awards, download counts, pricing promotions, or performance claims without a verifiable source and policy-safe wording.
- Do not imply endorsement by Google Play, Android, or a competitor.
- For AI, health, finance, kids, UGC, marketplace, or location-heavy apps, include clear scope and safety wording and run preflight.

## Release Notes

Write concise user-visible changes for each locale. Keep first internal-test notes simple and do not imply a production launch. Release notes belong to a build or promotion, not the app-wide listing fields.

## Output

Return structured proposed values per locale, their character counts, the evidence for product claims, and any missing facts. After an apply request, report the exact locale, returned status, and whether the preview video was preserved, removed, or replaced.
