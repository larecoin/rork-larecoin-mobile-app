---
name: play-store-connect
description: Configure Google Play OAuth access and use deterministic
  project-bound Android Publisher operations. Use before any package check,
  build publication, listing text or image update, track promotion, or rollout
  change.
---

# Play Store Connect

Use this skill before any Google Play publishing task. Every provider call must go through a typed Rork backend operation using the current user's server-side OAuth connection.

## Hard Boundaries

Google's public Android Publisher API cannot create a brand-new normal public Play Store app record. The user must first create the package in Play Console and may need an initial manual upload or draft release setup before API automation works.

Do not ask the user to paste a service-account key, OAuth refresh token, access token, or other Google credential in chat. Do not install or invoke a third-party Play Console CLI. Do not write shared publishing credentials into the sandbox.

## Connection And Package Access

1. Call `setupGooglePlay`.
2. If it returns `connected: false`, stop and ask the user to connect Google Play from the project Publish dialog.
3. Call `ensurePlayAppRecord({ packageName, appName })` before the first publish attempt.
4. If the package does not exist, stop and identify the required Play Console app-creation or first-upload step. Do not retry with another credential or tool.


## Internal Testing

1. Call `listPublishablePlayBuilds` and choose the build matching the current `snapshotId`, `sourceHash`, `appPath`, framework, and Play package.
2. If none matches, call `generatePlayAab({ snapshotId, sourceHash, appPath, framework })`, wait, then list again.
3. Call `publishInternalBuild` with the current `snapshotId`, `sourceHash`, `appPath`, `framework`, package name, and release copy.
4. Use `validateOnly: true` before committing unless the user already explicitly requested that exact internal publish.
5. Keep the `submissionId` from a successful non-validation result. It is the project-bound source for later promotion.


Never accept an arbitrary bundle URL, local file path, version code, or package identity in place of a backend build result.

## Listing Metadata

1. Start from a successful committed Google Play `submissionId` for the current project.
2. Call `listPlayListings` before changing a locale so the current listing and preview video are known.
3. Call `updatePlayListing` with the complete title, short description, and full description for one locale.
4. Omit `video` to preserve it, pass `null` to remove it, or pass the intended YouTube URL to replace it.
5. Validate first unless the user already explicitly confirmed the exact localized copy and video change.


The backend resolves the package and OAuth token from the project-bound submission. Never ask the model or user to provide either value.

## Listing Images

1. Start from a successful committed Google Play `submissionId` for the current project.
2. Call `listExistingAssets({ types: ["image"] })` to get exact project image asset UUIDs. Do not pass image URLs or local paths.
3. Call `listPlayListingImages` for the exact locale and image type before any mutation.
4. Call `replacePlayListingImages` with the complete intended slot in display order. Replacement removes every existing image in that slot before uploading the supplied assets.
5. Use `clearPlayListingImages` only when the user explicitly asks to remove every image from that exact slot. Never represent an empty replacement as a clear request.
6. Validate first unless the user already explicitly confirmed the exact locale, image type, asset set, order, and replacement or deletion intent.


The backend accepts only project-owned PNG or JPEG assets and resolves their managed bytes, package, and OAuth token. A replacement can contain up to eight images; `icon`, `featureGraphic`, and `tvBanner` accept one.

## Release Controls

1. Before production promotion, rollout increase, resume, or completion, call `checkAndroidDeveloperVerification` with the successful committed `submissionId`. A halt stays available without this check.
2. Stop when the result has `productionBlocked: true`. Treat `unavailable` as unknown, ask the user whether to proceed without verification, and set `allowUnavailableDeveloperVerification: true` only after explicit confirmation.
3. Call `promotePlayRelease` with a successful committed `submissionId` to move a release to alpha, beta, or production.
4. For staged production, pass `userFraction` as a decimal such as `0.1` for 10%.
5. Call `updatePlayRollout` with the latest committed production `submissionId` to increase, halt, resume, or complete a rollout.
6. Validate first unless the user has explicitly confirmed the exact operation. Confirmation of the release operation is separate from confirmation to proceed while developer verification is unavailable. Reuse the original published `sourceSubmissionId` for the commit; a validation result is not an active release.
7. Never lower an active rollout percentage. Halt it or publish a corrective release instead.


The backend resolves project ownership, package name, source track, version code, and OAuth token. Do not reconstruct or override them in the sandbox.
The current verification operation checks package-name registration only. Do not claim that the app-signing certificate matches; Rork does not yet have an authoritative Play app-signing fingerprint for this call.

## Unsupported Operations

Until a typed backend tool exists, do not claim to create custom tracks, perform rollback, or poll a complete review lifecycle. Prepare the requested content or plan, state the exact automation gap, and stop before mutation.

## User-Facing Reporting

Report the package, track, version code, release status, rollout fraction, and any Play Console manual blocker returned by the typed operation. Never collapse internal testing success into "Android publishing is fully done."

## Related Skills

- `.rork/skills/play-store-publish/SKILL.md` for internal, promotion, and rollout orchestration.
- `.rork/skills/play-store-preflight/SKILL.md` for readiness gates.
- `.rork/skills/play-store-metadata/SKILL.md` for preparing truthful listing text.
- `.rork/skills/play-store-assets/SKILL.md` for preparing screenshots and graphics.


## Available tools

### setupGooglePlay

Check whether the current user has connected Google Play publishing access.
Call this before checking a Play app record or publishing an Android build.

If it returns `connected: false`, this tool's chat card shows a Connect Google Play button; tell the
user to connect from that card, then retry. Do not ask for service account JSON or Google credentials in chat.

```json
{"type":"object","properties":{}}
```

### listPublishablePlayBuilds

List completed signed Play AAB builds for the current project.
Before publishing, match snapshotId, sourceHash, appPath, framework, and package name against the current app.
If no returned build matches the current source, call `generatePlayAab` first.

```json
{"type":"object","properties":{}}
```

### ensurePlayAppRecord

Verify that Android Publisher API can open an edit for an existing Google Play app package.
This does not create a public Play Store app. If Google reports the package is missing,
the user must create the app in Play Console first and then retry.

```json
{"type":"object","properties":{"packageName":{"type":"string","pattern":"^[A-Za-z][A-Za-z0-9_]*(?:\\.[A-Za-z][A-Za-z0-9_]*)+$","description":"Existing Google Play package name, for example com.example.app."},"appName":{"description":"Display name to show in Play Console setup guidance.","type":"string","minLength":1}},"required":["packageName"]}
```

### generatePlayAab

Start a signed Android App Bundle build for Google Play from the current Kotlin app source.
Use when no `listPublishablePlayBuilds` result matches the current snapshotId, sourceHash, appPath, and framework.
Get snapshotId/sourceHash from the current source and appPath/framework from rork.json; wait, then list again.

```json
{"type":"object","properties":{"snapshotId":{"type":"string","minLength":1,"description":"Current project snapshot id to build into a Play AAB."},"sourceHash":{"type":"string","minLength":1,"description":"Current project source hash to build into a Play AAB."},"appPath":{"type":"string","minLength":1,"description":"Current Kotlin app path from rork.json, for example android."},"framework":{"type":"string","const":"kotlin","description":"Current app framework. Play AAB generation supports Kotlin apps."}},"required":["snapshotId","sourceHash","appPath","framework"]}
```

### publishInternalBuild

Publish or validate the current project's signed Play AAB to Google Play internal testing.
The backend resolves the AAB from snapshotId, sourceHash, appPath, and framework; never pass an arbitrary AAB URL.

Call `ensurePlayAppRecord` first. If the package is missing, stop and guide the user through Play Console app creation.

```json
{"type":"object","properties":{"snapshotId":{"type":"string","minLength":1,"description":"Current project snapshot id for the Play AAB."},"sourceHash":{"type":"string","minLength":1,"description":"Current project source hash for the Play AAB."},"appPath":{"type":"string","minLength":1,"description":"Current Kotlin app path from rork.json for the Play AAB."},"framework":{"type":"string","const":"kotlin","description":"Current app framework for the Play AAB."},"packageName":{"type":"string","pattern":"^[A-Za-z][A-Za-z0-9_]*(?:\\.[A-Za-z][A-Za-z0-9_]*)+$","description":"Existing Google Play package name, for example com.example.app."},"releaseName":{"description":"Optional internal release name.","type":"string","minLength":1},"releaseNotes":{"description":"Optional internal release notes.","type":"string","minLength":1},"validateOnly":{"default":false,"description":"Set true to validate the Play edit without committing the release.","type":"boolean"}},"required":["snapshotId","sourceHash","appPath","framework","packageName"]}
```

### checkAndroidDeveloperVerification

Check whether the package from a committed Google Play submission is registered to a verified Android developer.
Call this before production promotion, rollout increase, resume, or completion. The backend resolves the package
from the current project and checks Google's Android Developer ID Status API without exposing the server API key.

Stop when `productionBlocked: true`. Treat `unavailable` as unknown, never as a passed production-readiness check.
Before September 30, 2026, clearly warn about `not_registered` before continuing. This currently checks package-name
registration only; do not claim the app-signing certificate matches until Rork has an authoritative Play signing fingerprint.

```json
{"type":"object","properties":{"sourceSubmissionId":{"type":"string","format":"uuid","pattern":"^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$","description":"Submission ID returned by a successful non-validation Google Play operation for this project."}},"required":["sourceSubmissionId"]}
```

### listPlayListings

List every localized Google Play store listing for an app owned by the current project.
Pass a persisted submission ID from a successful non-validation Google Play operation;
the backend resolves the package and current user's server-side OAuth connection.

Call this before updating listing text so existing locale and video values are preserved deliberately.

```json
{"type":"object","properties":{"sourceSubmissionId":{"type":"string","format":"uuid","pattern":"^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$","description":"Submission ID returned by a successful non-validation Google Play operation for this project."}},"required":["sourceSubmissionId"]}
```

### updatePlayListing

Create or replace one localized Google Play store listing for an app owned by the current project.
Pass the complete title, short description, and full description for the locale. Omit video to preserve
the current preview video, pass null to remove it, or pass a YouTube URL to replace it.

Call listPlayListings first. Use validateOnly to check the edit without committing it.
If the result needs Play Console review, stop and direct the user to createAppUrl instead of reporting the listing updated.

```json
{"type":"object","properties":{"sourceSubmissionId":{"type":"string","format":"uuid","pattern":"^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$","description":"Submission ID returned by a successful non-validation Google Play operation for this project."},"language":{"type":"string","minLength":2,"maxLength":35,"description":"BCP-47 listing locale, for example en-US."},"title":{"type":"string","minLength":1,"maxLength":30,"description":"Localized Play Store title, at most 30 characters."},"shortDescription":{"type":"string","minLength":1,"maxLength":80,"description":"Localized short description, at most 80 characters."},"fullDescription":{"type":"string","minLength":1,"maxLength":4000,"description":"Localized full description, at most 4000 characters."},"video":{"description":"Optional YouTube preview URL. Omit to preserve the current video or pass null to remove it.","anyOf":[{"type":"string","format":"uri"},{"type":"null"}]},"validateOnly":{"default":false,"description":"Set true to validate the listing edit without committing it.","type":"boolean"}},"required":["sourceSubmissionId","language","title","shortDescription","fullDescription"]}
```

### listPlayListingImages

List the current images in one localized Google Play store-listing slot owned by the current project.
Pass a persisted submission ID from a successful non-validation Google Play operation; the backend
resolves the package and current user's server-side OAuth connection.

Call this before replacing or clearing a slot so the existing images and order are known.

```json
{"type":"object","properties":{"sourceSubmissionId":{"type":"string","format":"uuid","pattern":"^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$","description":"Submission ID returned by a successful non-validation Google Play operation for this project."},"language":{"type":"string","minLength":2,"maxLength":35,"description":"BCP-47 listing locale, for example en-US."},"imageType":{"type":"string","enum":["phoneScreenshots","sevenInchScreenshots","tenInchScreenshots","tvScreenshots","wearScreenshots","icon","featureGraphic","tvBanner"],"description":"Android Publisher image slot to read or mutate."}},"required":["sourceSubmissionId","language","imageType"]}
```

### replacePlayListingImages

Replace every image in one localized Google Play store-listing slot with ordered project image assets.
Pass only image UUIDs returned by listExistingAssets or accepted screenshot capture output. The backend
verifies project ownership, reads the managed asset bytes, accepts PNG or JPEG up to 15 MB each, and
preserves the supplied order.

This replaces the complete slot. Call listPlayListingImages first and use validateOnly before committing
unless the user explicitly confirmed the exact assets, order, locale, and image type.
If the result needs Play Console review, stop and direct the user to createAppUrl instead of reporting the images replaced.

```json
{"type":"object","properties":{"sourceSubmissionId":{"type":"string","format":"uuid","pattern":"^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$","description":"Submission ID returned by a successful non-validation Google Play operation for this project."},"language":{"type":"string","minLength":2,"maxLength":35,"description":"BCP-47 listing locale, for example en-US."},"imageType":{"type":"string","enum":["phoneScreenshots","sevenInchScreenshots","tenInchScreenshots","tvScreenshots","wearScreenshots","icon","featureGraphic","tvBanner"],"description":"Android Publisher image slot to read or mutate."},"assetIds":{"minItems":1,"maxItems":8,"type":"array","items":{"type":"string","format":"uuid","pattern":"^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$"},"description":"Ordered project image asset UUIDs from listExistingAssets or accepted screenshot capture output. Google Play displays them in this order."},"validateOnly":{"default":false,"description":"Set true to validate the complete slot replacement without committing it.","type":"boolean"}},"required":["sourceSubmissionId","language","imageType","assetIds"]}
```

### clearPlayListingImages

Delete every image from one localized Google Play store-listing slot owned by the current project.
This is intentionally separate from replacement so an empty asset list can never clear a slot accidentally.

Call listPlayListingImages first. Use this only when the user explicitly asked to clear the exact locale
and image type, and use validateOnly before committing unless that exact deletion is already confirmed.
If the result needs Play Console review, stop and direct the user to createAppUrl instead of reporting the images cleared.

```json
{"type":"object","properties":{"sourceSubmissionId":{"type":"string","format":"uuid","pattern":"^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$","description":"Submission ID returned by a successful non-validation Google Play operation for this project."},"language":{"type":"string","minLength":2,"maxLength":35,"description":"BCP-47 listing locale, for example en-US."},"imageType":{"type":"string","enum":["phoneScreenshots","sevenInchScreenshots","tenInchScreenshots","tvScreenshots","wearScreenshots","icon","featureGraphic","tvBanner"],"description":"Android Publisher image slot to read or mutate."},"validateOnly":{"default":false,"description":"Set true to validate clearing the complete image slot without committing it.","type":"boolean"}},"required":["sourceSubmissionId","language","imageType"]}
```

### promotePlayRelease

Promote a previously published release owned by the current project to alpha, beta, or production.
Pass a persisted submission ID from a successful non-validation publish; the backend resolves the
package, source track, version code, and the current user's server-side Google OAuth connection.

For a staged production rollout, pass userFraction as a decimal between 0 and 1.
Use validateOnly to check the edit without committing it.
If developer verification is unavailable, stop and ask the user before setting allowUnavailableDeveloperVerification.
If the result needs Play Console review, stop and direct the user to createAppUrl instead of reporting a promotion.

```json
{"type":"object","properties":{"sourceSubmissionId":{"type":"string","format":"uuid","pattern":"^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$","description":"Submission ID returned by a successful non-validation Google Play operation for this project."},"validateOnly":{"default":false,"description":"Set true to validate the Play edit without committing the release.","type":"boolean"},"allowUnavailableDeveloperVerification":{"description":"Set true only after the user explicitly confirms proceeding while Android developer verification is unavailable.","type":"boolean"},"targetTrack":{"type":"string","enum":["alpha","beta","production"],"description":"Google Play track to promote the release to."},"userFraction":{"description":"Optional production rollout fraction as a decimal, for example 0.1 for 10%.","type":"number","exclusiveMinimum":0,"exclusiveMaximum":1}},"required":["sourceSubmissionId","targetTrack"]}
```

### updatePlayRollout

Increase, halt, resume, or complete a staged production rollout owned by the current project.
Pass the persisted production submission ID returned by a successful non-validation release-control
result; the backend resolves all package, version, track, and OAuth details.

Use validateOnly to check the edit without committing it. Never lower a rollout fraction.
If developer verification is unavailable, stop and ask the user before setting allowUnavailableDeveloperVerification.
If the result needs Play Console review, stop and direct the user to createAppUrl instead of reporting an updated rollout.

```json
{"type":"object","properties":{"sourceSubmissionId":{"type":"string","format":"uuid","pattern":"^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$","description":"Submission ID returned by a successful non-validation Google Play operation for this project."},"validateOnly":{"default":false,"description":"Set true to validate the Play edit without committing the release.","type":"boolean"},"allowUnavailableDeveloperVerification":{"description":"Set true only after the user explicitly confirms proceeding while Android developer verification is unavailable.","type":"boolean"},"action":{"type":"string","enum":["increase","halt","resume","complete"],"description":"Transition to apply to the production rollout."},"userFraction":{"description":"Required for increase; optional for resume. Use a decimal such as 0.25 for 25%.","type":"number","exclusiveMinimum":0,"exclusiveMaximum":1}},"required":["sourceSubmissionId","action"]}
```
