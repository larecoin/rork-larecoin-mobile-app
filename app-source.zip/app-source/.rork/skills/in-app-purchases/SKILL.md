---
name: in-app-purchases
description: Add and configure in-app purchases with RevenueCat. Use when the
  user asks about subscriptions, paywalls, premium plans, trials, restore
  purchases, or monetization.
aliases:
  - subscription
  - subscriptions
  - paywall
  - premium
  - pro plan
  - trial
  - restore purchases
  - RevenueCat
  - remove ads
  - monetization
---

# In-App Purchases (RevenueCat)

Always use RevenueCat for in-app purchases. Rork is partnered with RevenueCat — their SDK is the only supported path on every platform. Their dashboard is the source of truth for products, entitlements, and offerings.

## Workflow (every platform)

The RevenueCat-side workflow is the same regardless of which platform you're shipping. Use the agent tools for products, entitlements, offerings, packages, and public API keys. Apple's In-App Purchase Key is the one exception because RevenueCat's public API does not expose its credential status.

1. Call `revenueCatDoctor` to see what's already connected/configured, then `connectRevenueCat` if RevenueCat is not connected yet for this project.
2. Call `fetchConfiguration` to inspect existing apps, products, entitlements, and offerings.
3. Find the **Test Store** app. If `fetchConfiguration` reports it is missing, this is the one RevenueCat dashboard exception to the tool-driven workflow: ask the user to create a Test Store app in RevenueCat, then retry `fetchConfiguration`. Find or `createRCApp` the platform-specific store apps your project needs.
4. For every iOS App Store app, have the user configure RevenueCat's **In-App Purchase Key** and confirm the dashboard shows **Valid credentials**. The key is created in App Store Connect under Users and Access > Integrations > In-App Purchase. It is separate from the App Store Connect API key. `createRCApp` cannot configure or verify it through the current public API.
5. Configure products, entitlements, and offerings to match what your paywall will show. Use `createProduct` / `addTestStoreProduct` / `createEntitlement` / `attachProductsToEntitlement` / `createOffering` / `createPackage` / `attachProductsToPackage` as needed.
6. Call `listPublicApiKeys` for each app and set the corresponding `EXPO_PUBLIC_REVENUECAT_*` environment variables. Set env vars **before** writing client code — at least on Swift, generated `Config.swift` only contains properties for env vars that already exist.
7. Implement the client (install SDK, configure, build paywall UI, handle restore). See the platform file.
8. Always include a **Restore Purchases** button — App Store review requires it.


Do not require a sandbox purchase as a release prerequisite. The final App Store review gate validates every machine-observable configuration link, but it must not claim that an unexecuted transaction succeeded.

## Test Store

Test Store is RevenueCat's built-in testing environment. New projects usually have it already, but some projects can be missing it. `createRCApp` cannot create Test Store apps; `rc_billing` is RevenueCat Billing, not Test Store. Missing Test Store setup is the only dashboard-driven exception here: ask the user to create it in RevenueCat, then retry `fetchConfiguration`, add the Test Store products, and use `listPublicApiKeys` to set the development key.

- No App Store Connect / Play Console account needed for development
- Works immediately — no platform review delays
- Products, prices, and descriptions match exactly what's configured in RevenueCat
- Does NOT test StoreKit / Play Billing-specific behavior (grace periods, billing retry, parental approval)
- Requires switching to platform-specific API keys before submission


When adding a product, create it in **every** store the project ships to (Test Store + iOS App Store on Swift; Test Store + iOS App Store + Play Store on RN). Don't add a product to only one store unless the user explicitly asks.

## Files in this skill

The client integration differs per platform — read the file matching the app you're working in:

| File              | Contents                                                                                                                                                  |
| ----------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `react-native.md` | React Native / Expo: `react-native-purchases` package, three stores (Test + iOS + Android), `getRCToken` helper, react-query patterns, paywall UI.        |
| `swift.md`        | Swift: `purchases-ios-spm` SPM dep, two stores (Test + iOS App Store), `Purchases.configure` in `init()`, `StoreViewModel`, `PaywallView`, anti-patterns. |

## Doctor

Call the `revenueCatDoctor` tool to verify the RevenueCat connection and that the required `EXPO_PUBLIC_REVENUECAT_*` env vars are set for the stores this project ships to. Run it before assuming setup is complete — e.g. at the start of any subscription/paywall work, and again after setting API keys.

## Available tools

### revenueCatDoctor

Check RevenueCat setup for this project: whether RevenueCat is connected, the selected project is still valid, and whether the required EXPO_PUBLIC_REVENUECAT_* env keys are set for the stores this workspace ships to (Test Store always; iOS App Store on Swift/RN; Play Store on RN/Kotlin). Call this before implementing subscriptions/paywalls/in-app purchases, and again after setting API keys, so you know what still needs configuring.

```json
{"type":"object","properties":{}}
```

### connectRevenueCat

Connect to RevenueCat to manage in-app purchases. Use this tool when you need to set up or verify the RevenueCat connection for the project.

```json
{"type":"object","properties":{}}
```

### fetchConfiguration

Fetch RevenueCat configuration including apps, products, entitlements, and offerings.

```json
{"type":"object","properties":{}}
```

### createRCApp

Create a new real store app in RevenueCat. This cannot create Test Store apps; if fetchConfiguration reports the Test Store is missing, the user must create it in the RevenueCat dashboard. For App Store apps, this creates the app record only; the user must separately configure RevenueCat's Apple In-App Purchase Key and confirm Valid credentials.

```json
{"type":"object","properties":{"name":{"type":"string","minLength":1,"maxLength":255,"description":"The name of the app"},"type":{"type":"string","enum":["amazon","app_store","mac_app_store","play_store","stripe","rc_billing","roku","paddle"],"description":"The platform type of the app"},"bundleId":{"description":"Bundle ID for App Store/Mac App Store apps","type":"string"},"packageName":{"description":"Package name for Play Store/Amazon apps","type":"string"}},"required":["name","type"]}
```

### deleteRCApp

Delete an app from RevenueCat. Warning: This action cannot be undone.

```json
{"type":"object","properties":{"appId":{"type":"string","description":"The ID of the app to delete"}},"required":["appId"]}
```

### listPublicApiKeys

List public API keys for an app.

```json
{"type":"object","properties":{"appId":{"type":"string","description":"The ID of the app"},"limit":{"type":"number","minimum":1,"maximum":100},"startingAfter":{"type":"string"}},"required":["appId"]}
```

### createEntitlement

Create a new entitlement in RevenueCat.

```json
{"type":"object","properties":{"lookupKey":{"type":"string","minLength":1,"maxLength":200,"description":"The identifier for the entitlement"},"displayName":{"type":"string","minLength":1,"maxLength":1500,"description":"The display name for the entitlement"}},"required":["lookupKey","displayName"]}
```

### attachProductsToEntitlement

Attach products to an entitlement.

```json
{"type":"object","properties":{"entitlementId":{"type":"string","description":"The ID of the entitlement"},"productIds":{"minItems":1,"maxItems":50,"type":"array","items":{"type":"string"},"description":"Array of product IDs"}},"required":["entitlementId","productIds"]}
```

### detachProductsFromEntitlement

Detach products from an entitlement.

```json
{"type":"object","properties":{"entitlementId":{"type":"string","description":"The ID of the entitlement"},"productIds":{"minItems":1,"maxItems":50,"type":"array","items":{"type":"string"},"description":"Array of product IDs"}},"required":["entitlementId","productIds"]}
```

### createProduct

Create a new product in RevenueCat.

```json
{"type":"object","properties":{"storeIdentifier":{"type":"string","minLength":1,"maxLength":200,"description":"The store product identifier"},"appId":{"type":"string","description":"The ID of the app this product belongs to"},"type":{"type":"string","enum":["subscription","one_time","consumable","non_consumable","non_renewing_subscription"]},"displayName":{"type":"string","minLength":1,"maxLength":1500}},"required":["storeIdentifier","appId","type"]}
```

### addTestStoreProduct

Create a Test Store product with pricing in one step.

```json
{"type":"object","properties":{"appId":{"type":"string","description":"The ID of the Test Store app"},"storeIdentifier":{"type":"string","minLength":1,"maxLength":200,"description":"The product identifier"},"displayName":{"type":"string","minLength":1,"maxLength":1500,"description":"Display name for the product"},"type":{"type":"string","enum":["subscription","consumable","non_consumable"]},"subscriptionDuration":{"type":"string","enum":["P1W","P1M","P2M","P3M","P6M","P1Y"]},"prices":{"minItems":1,"type":"array","items":{"type":"object","properties":{"amountMicros":{"type":"number","minimum":0},"currency":{"type":"string","minLength":3,"maxLength":3}},"required":["amountMicros","currency"]}}},"required":["appId","storeIdentifier","displayName","type","prices"]}
```

### deleteProduct

Delete a product from RevenueCat.

```json
{"type":"object","properties":{"productId":{"type":"string","description":"The ID of the product to delete"}},"required":["productId"]}
```

### createOffering

Create a new offering in RevenueCat.

```json
{"type":"object","properties":{"lookupKey":{"type":"string","minLength":1,"maxLength":200,"description":"The identifier for the offering"},"displayName":{"type":"string","minLength":1,"maxLength":1500,"description":"The display name for the offering"},"metadata":{"type":"object","propertyNames":{"type":"string"},"additionalProperties":{}}},"required":["lookupKey","displayName"]}
```

### updateOffering

Update an existing offering in RevenueCat.

```json
{"type":"object","properties":{"offeringId":{"type":"string","description":"The ID of the offering to update"},"displayName":{"type":"string","minLength":1,"maxLength":1500},"isCurrent":{"type":"boolean"},"metadata":{"anyOf":[{"type":"object","propertyNames":{"type":"string"},"additionalProperties":{}},{"type":"null"}]}},"required":["offeringId"]}
```

### createPackage

Create a new package in an offering.

```json
{"type":"object","properties":{"offeringId":{"type":"string","description":"The ID of the offering"},"lookupKey":{"type":"string","minLength":1,"maxLength":200,"description":"The identifier for the package"},"displayName":{"type":"string","minLength":1,"maxLength":1500,"description":"The display name for the package"},"position":{"type":"number","minimum":1}},"required":["offeringId","lookupKey","displayName"]}
```

### updatePackage

Update a package's display name or position.

```json
{"type":"object","properties":{"packageId":{"type":"string","description":"The ID of the package to update"},"displayName":{"type":"string","minLength":1,"maxLength":1500},"position":{"type":"number","minimum":1}},"required":["packageId"]}
```

### deletePackage

Delete a package from an offering.

```json
{"type":"object","properties":{"packageId":{"type":"string","description":"The ID of the package to delete"}},"required":["packageId"]}
```

### attachProductsToPackage

Attach products to a package.

```json
{"type":"object","properties":{"packageId":{"type":"string","description":"The ID of the package"},"products":{"minItems":1,"maxItems":50,"type":"array","items":{"type":"object","properties":{"productId":{"type":"string"},"eligibilityCriteria":{"default":"all","type":"string","enum":["all","google_sdk_lt_6","google_sdk_ge_6"]}},"required":["productId"]}}},"required":["packageId","products"]}
```

### detachProductsFromPackage

Detach products from a package.

```json
{"type":"object","properties":{"packageId":{"type":"string","description":"The ID of the package"},"productIds":{"minItems":1,"maxItems":50,"type":"array","items":{"type":"string"}}},"required":["packageId","productIds"]}
```

### getPackageProducts

Get all products attached to a package.

```json
{"type":"object","properties":{"packageId":{"type":"string","description":"The ID of the package"}},"required":["packageId"]}
```
