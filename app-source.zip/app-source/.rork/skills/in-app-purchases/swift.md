# In-App Purchases — Swift

Read `SKILL.md` first for the RevenueCat-side workflow (apps / products / entitlements / offerings via the agent tools). This file covers only the Swift client integration.

RevenueCat SDK provides server-side receipt validation, cross-platform entitlement management, and a unified API for StoreKit. It handles subscriptions, one-time purchases, and consumables.

**Import:** `import RevenueCat`
**Install:** `swiftInstall({ packages: [{ url: "https://github.com/RevenueCat/purchases-ios-spm.git", version: "5.0.0", products: ["RevenueCat"] }] })`
**Requires:** RevenueCat configuration and environment variables set before writing code.

## Per-platform Setup Order

Steps are sequential — follow this order:

1. Run the RevenueCat workflow from `SKILL.md` (`fetchConfiguration`, ensure Test Store + iOS App Store apps, configure products / entitlements / offerings, `listPublicApiKeys`).
2. **Set environment variables BEFORE writing any Swift code.** `Config.swift` is auto-generated and only includes properties for env vars that exist. Referencing a missing property is a build error.
3. Install the RevenueCat SDK via `swiftInstall` (see above).
4. Add the RevenueCat configuration in the App's `init()`.
5. Build a paywall view that lists packages from the current offering.
6. Add a navigation path to the paywall.
7. Implement restore purchases.
8. Do not create or modify `.entitlements` files for In-App Purchase.

## Environment Variables (two stores)

Swift apps ship to iOS only. You need **two** RevenueCat apps and two env vars:

| Variable                              | Purpose                  | Config.swift Access                          |
| ------------------------------------- | ------------------------ | -------------------------------------------- |
| `EXPO_PUBLIC_REVENUECAT_TEST_API_KEY` | Test Store / Development | `Config.EXPO_PUBLIC_REVENUECAT_TEST_API_KEY` |
| `EXPO_PUBLIC_REVENUECAT_IOS_API_KEY`  | App Store / Production   | `Config.EXPO_PUBLIC_REVENUECAT_IOS_API_KEY`  |

- Do NOT create or edit `Config.swift` manually — it is system-managed.
- In the sandbox, empty-string placeholders for available keys are expected.
- Only TWO stores needed for Swift: **Test Store** + **iOS App Store** (no Android).

## SDK Configuration

Configure once in the App's `init()`. Never configure in `onAppear` or `.task`.

```swift
import RevenueCat

@main
struct MyApp: App {
    init() {
        #if DEBUG
        Purchases.logLevel = .debug
        Purchases.configure(withAPIKey: Config.EXPO_PUBLIC_REVENUECAT_TEST_API_KEY)
        #else
        Purchases.configure(withAPIKey: Config.EXPO_PUBLIC_REVENUECAT_IOS_API_KEY)
        #endif
    }

    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
```

## Store ViewModel

Central place for subscription state. Uses `@Observable` (iOS 17+) and `customerInfoStream` for real-time updates.

```swift
import Observation
import RevenueCat

@Observable
@MainActor
class StoreViewModel {
    var offerings: Offerings?
    var isPremium = false
    var isLoading = false
    var isPurchasing = false
    var error: String?

    init() {
        Task { await listenForUpdates() }
        Task { await fetchOfferings() }
    }

    private func listenForUpdates() async {
        for await info in Purchases.shared.customerInfoStream {
            self.isPremium = info.entitlements["premium"]?.isActive == true
        }
    }

    func fetchOfferings() async {
        isLoading = true
        do {
            offerings = try await Purchases.shared.offerings()
        } catch {
            self.error = error.localizedDescription
        }
        isLoading = false
    }

    func purchase(package: Package) async {
        isPurchasing = true
        do {
            let result = try await Purchases.shared.purchase(package: package)
            if !result.userCancelled {
                isPremium = result.customerInfo.entitlements["premium"]?.isActive == true
            }
        } catch ErrorCode.purchaseCancelledError {
            // StoreKit cancellation — not an error
        } catch ErrorCode.paymentPendingError {
            // Awaiting parental approval or extra auth — not a failure
        } catch {
            self.error = error.localizedDescription
        }
        isPurchasing = false
    }

    func restore() async {
        do {
            let info = try await Purchases.shared.restorePurchases()
            isPremium = info.entitlements["premium"]?.isActive == true
        } catch {
            self.error = error.localizedDescription
        }
    }

    func checkStatus() async {
        do {
            let info = try await Purchases.shared.customerInfo()
            isPremium = info.entitlements["premium"]?.isActive == true
        } catch {
            self.error = error.localizedDescription
        }
    }
}
```

## Paywall View

```swift
import SwiftUI
import RevenueCat

struct PaywallView: View {
    var store: StoreViewModel
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            Group {
                if store.isLoading {
                    ProgressView()
                } else if let current = store.offerings?.current {
                    VStack(spacing: 20) {
                        Text("Unlock Premium")
                            .font(.largeTitle.bold())

                        ForEach(current.availablePackages, id: \.identifier) { package in
                            Button {
                                Task { await store.purchase(package: package) }
                            } label: {
                                VStack(spacing: 4) {
                                    Text(package.storeProduct.localizedTitle)
                                        .font(.headline)
                                    Text(package.storeProduct.localizedPriceString)
                                        .font(.title2.bold())
                                    if let intro = package.storeProduct.introductoryDiscount {
                                        Text("Free for \(intro.subscriptionPeriod.value) \(intro.subscriptionPeriod.unit)")
                                            .font(.caption)
                                            .foregroundStyle(.secondary)
                                    }
                                }
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.accentColor)
                                .foregroundStyle(.white)
                                .clipShape(RoundedRectangle(cornerRadius: 12))
                            }
                            .disabled(store.isPurchasing)
                        }

                        Button("Restore Purchases") {
                            Task { await store.restore() }
                        }
                        .font(.footnote)
                    }
                    .padding()
                } else {
                    ContentUnavailableView("Unable to Load", systemImage: "exclamationmark.triangle")
                }
            }
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Close") { dismiss() }
                }
            }
            .alert("Error", isPresented: .init(
                get: { store.error != nil },
                set: { if !$0 { store.error = nil } }
            )) {
                Button("OK") { store.error = nil }
            } message: {
                Text(store.error ?? "")
            }
            .onChange(of: store.isPremium) { _, isPremium in
                if isPremium { dismiss() }
            }
        }
    }
}
```

## Checking Entitlements

```swift
// One-time check
let info = try await Purchases.shared.customerInfo()
let hasPremium = info.entitlements["premium"]?.isActive == true

// Entitlement details
if let entitlement = info.entitlements["premium"], entitlement.isActive {
    let willRenew = entitlement.willRenew
    let expiresAt = entitlement.expirationDate
    let store = entitlement.store // .appStore, .macAppStore, .rcBilling, etc.
}

// All active entitlements
for (id, entitlement) in info.entitlements.active {
    print("\(id): \(entitlement.productIdentifier)")
}
```

## Xcode Project Setup

Do not represent In-App Purchase with `{AppName}.entitlements` or `CODE_SIGN_ENTITLEMENTS`; RevenueCat setup only needs the SDK/package and purchase code in the project.

## Anti-Patterns

| Anti-Pattern                           | Fix                                                                                                                 |
| -------------------------------------- | ------------------------------------------------------------------------------------------------------------------- |
| Configure in `onAppear` or `.task`     | Configure once in App `init()`                                                                                      |
| Write code before setting env vars     | Set env vars first — `Config.swift` only includes existing vars                                                     |
| Create Android/Play Store app          | Swift projects need only Test Store + iOS App Store                                                                 |
| Hardcode API keys in Swift files       | Use `Config.EXPO_PUBLIC_*` from environment variables                                                               |
| Forget restore purchases button        | Always include — App Store review requirement                                                                       |
| Show error on purchase cancel          | Check `result.userCancelled` AND catch `ErrorCode.purchaseCancelledError` — cancellation can come from either path  |
| Show error on pending payment          | Catch `ErrorCode.paymentPendingError` separately — it means awaiting parental approval or extra auth, not a failure |
| Create a new `StoreViewModel` per view | Share one instance across the app via `@State` in root view                                                         |
| Use `ObservableObject` + `@Published`  | Use `@Observable` macro — no Combine import needed                                                                  |
| Use `@StateObject` / `@ObservedObject` | Use `@State` for ownership, plain property for passing down                                                         |
| `.background(.accentColor)`            | Use `Color.accentColor` explicitly — `.accentColor` is not a member of `ShapeStyle`                                 |
