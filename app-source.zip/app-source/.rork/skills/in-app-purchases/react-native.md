# In-App Purchases — React Native / Expo

Read `SKILL.md` first for the RevenueCat-side workflow (apps / products / entitlements / offerings via the agent tools). This file covers only the client integration.

## SDK

Install:

```bash
bunx expo install react-native-purchases
```

Import: `import Purchases from "react-native-purchases";`

## Environment Variables (three stores)

React Native / Expo apps ship to iOS, Android, and the web preview. You need three RevenueCat apps and three env vars:

| Variable                                 | Used when                            |
| ---------------------------------------- | ------------------------------------ |
| `EXPO_PUBLIC_REVENUECAT_TEST_API_KEY`    | Web preview or `__DEV__` builds      |
| `EXPO_PUBLIC_REVENUECAT_IOS_API_KEY`     | Production iOS App Store builds      |
| `EXPO_PUBLIC_REVENUECAT_ANDROID_API_KEY` | Production Android Play Store builds |

Use a single helper to pick the right key per platform:

```ts
import { Platform } from "react-native";

function getRCToken() {
  if (__DEV__ || Platform.OS === "web") {
    return process.env.EXPO_PUBLIC_REVENUECAT_TEST_API_KEY;
  }
  return Platform.select({
    ios: process.env.EXPO_PUBLIC_REVENUECAT_IOS_API_KEY,
    android: process.env.EXPO_PUBLIC_REVENUECAT_ANDROID_API_KEY,
    default: process.env.EXPO_PUBLIC_REVENUECAT_TEST_API_KEY,
  });
}
```

## Configure at the top of the module

Call `Purchases.configure({ apiKey })` at the top level of a module — **not** inside a `useEffect` or a component. This avoids re-configuring every render.

RevenueCat fully supports the web via the Test Store. Do NOT branch out RevenueCat for web — let the same config and the same UI run there.

## Use react-query for fetching offerings / customer info

Always wrap RevenueCat queries and mutations in `@tanstack/react-query`. Because RevenueCat is configured at the top level (not inside a context provider), you can write the queries outside any provider.

## Paywall UI

Build the paywall UI in React Native — do **not** use RevenueCat's hosted paywalls.

A typical flow:

1. Use `Purchases.getOfferings()` to fetch offerings. Show packages from the `current` offering.
2. On tap, call `Purchases.purchasePackage(pkg)`. Handle user-cancelled and pending-payment branches without showing them as errors.
3. Always include a **Restore Purchases** button that calls `Purchases.restorePurchases()`.
4. Handle success and error UI — never silently swallow a failure.

Before implementing the paywall, call `fetchConfiguration` to confirm the products, entitlements, and offerings actually exist with the names you'll use. Create or rename them via the agent tools if not.

## Checklist

When adding subscriptions to the app, make sure:

1. Run `fetchConfiguration` and verify products, entitlements, and offerings exist.
2. Create or update them via the agent tools (`createProduct`, `createEntitlement`, `createOffering`, `createPackage`, `attachProducts*`) if the configuration is missing or wrong.
3. Show a paywall built in React Native that lists packages from the current offering.
4. Provide a clear path for the user to reach the paywall (button, locked feature, etc.).
5. Handle success, cancel, and error branches explicitly.
6. Include a Restore Purchases button.
7. Add the products to **all three** RevenueCat stores (Test, iOS, Android) and set **all three** env vars unless the user explicitly opts out.
