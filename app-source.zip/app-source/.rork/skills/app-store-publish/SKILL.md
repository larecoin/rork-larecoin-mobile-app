---
name: app-store-publish
description: Orchestrate App Store preparation and submission. Read this when the user asks to prepare, publish, submit, upload, or push a build to the App Store or TestFlight.
aliases:
  - publish my app
  - publish app
  - release my app
  - send to app store
  - submit to app store
  - upload to app store
  - send build
  - send a build
  - TestFlight build
---

## App Store Publish

This skill guides you through the full App Store preparation and submission process. It coordinates multiple specialized skills — read each one as you reach its step.

There are two distinct flows. **You must determine the correct flow before proceeding.**

---

## Determining User Intent

- **"Submit my app to TestFlight"**, **"push/upload/send a build"** in a TestFlight/App Store context, or any message with a structured publish payload (teamId, bundleId, version, platform) → **Flow 1** (TestFlight). Go directly.
- **"Prepare my app for the App Store"**, **"create my App Store listing"**, or similar → **Flow 2** (App Store Prep). Go directly.
- **Ambiguous** ("publish my app", "publish app", "send to App Store", "release my app") → call `askUser` with one focused question:

> "Would you like to send a build to TestFlight for testing, or prepare your full App Store listing (icons, screenshots, metadata) for review?"

Only proceed after `askUser` returns a clear choice. Treat broad publish phrasing as valid publishing intent and use `askUser` to choose the destination when needed.

---

## Inspect Publishing Status

Call `getAppStorePublishingStatus({})` when the user asks about publishing progress, a previous failure, or whether their build completed. Pass a `submissionId` only when the user is referring to a specific submission.

The tool reads the same persisted status as Publishing View. If it reports an active `building` or `submitting` submission, explain the current step instead of starting a duplicate build.

---

## Flow 1: TestFlight Submission

**Use when:** the user wants to test on a real device, share with testers, or submit to TestFlight.
`runChecks` only validates and creates installable artifacts; it does not upload to App Store Connect or TestFlight.

**Steps:**

1. Read `.rork/skills/app-store-connect/SKILL.md` to unlock ASC tools.
2. For Swift projects, move giant static datasets from `.swift` files into bundled resources before publishing.
3. Follow the **"Standard publishing flow"** section in that skill exactly:
   - `setupAsc({ requireAppleSession: true })`
   - `ensureCertificate`
   - `ensureApp`
   - `syncCapabilities`
   - `submitBuild`
4. After a successful build, suggest (do NOT force):
   > "Your app is on TestFlight! Would you also like to prepare your App Store listing? I can generate icons, screenshots, and metadata."

---

## Flow 2: App Store Prep and Submission

**Use when:** the user explicitly wants to prepare for the App Store, create their App Store page, or submit for App Store review.

Work through these steps **sequentially**. Each step involves reading a skill, following its instructions, and completing it before moving on.

### Step 1: Setup App Store Connect

Read `.rork/skills/app-store-connect/SKILL.md` to unlock ASC tools, then:

```
setupAsc({ requireAppleSession: false })
```

This gives you access to the `asc` CLI for metadata and asset management. A full Apple session is not needed yet.

### Step 2: Generate App Icon

Check if the project already has an app icon. If it does, ask the user:

> "You already have an app icon. Would you like to generate a new one, or keep the current icon?"

Only read `.rork/skills/app-store-icons/SKILL.md` and call `generateAppIcon` if the user wants a new icon. Do NOT silently skip this step — always confirm with the user.

### Step 3: Capture Screenshots

Check if the project already has App Store screenshots. If it does, ask the user:

> "You already have App Store screenshots. Would you like to generate new ones, or keep the current set?"

Only read `.rork/skills/app-config/screenshots.md` and call `captureAppScreenshots` if the user wants new screenshots.

### Step 4: Generate Metadata

Before generating App Store metadata, create or confirm the app's public legal and support website:

- Privacy Policy URL: required for all App Store apps
- Support URL: required for all App Store apps
- Marketing URL: use the website home page when available
- Terms of Use / EULA URL: required for subscriptions, in-app purchases, marketplaces, user-generated content, or custom app rules

Do not use a generic Rork template URL when the user does not have their own site. Generate a small project-specific web app with the existing app generation flow:

1. Read `rork.json` and the app files to see whether the project already has a web app.
2. If no web app exists, read `.rork/skills/platforms/SKILL.md` to unlock `createApp`, then call `createApp` with `framework: "web"` and a stable app path such as `web`.
3. If a web app already exists, update that app instead of creating a duplicate.
4. Read `.rork/skills/app-store-publish/legal-website-template.md` and use it as the starting structure.
5. Implement or update these slash routes:

- `/`
- `/support`
- `/privacy`
- `/terms`
- `/privacy-choices` when the app needs data export, deletion, or opt-out handling

Use the existing app code as the source of truth. Audit the codebase and config for:

- app name, bundle identity, and support contact details
- auth, account creation, account deletion, and user profile data
- permissions such as camera, photos, location, microphone, contacts, notifications, and health data
- purchases, subscriptions, ads, affiliate links, and marketplace behavior
- analytics, crash reporting, attribution, push notification, and email providers
- AI features, third-party APIs, uploads, generated content, and user-generated content
- data storage, retention, export, deletion, and opt-out paths visible in the code

If a needed fact is not available, ask the user for the smallest missing detail instead of inventing it.

The generated website should be publishable and useful:

- `/`: app name, short description, support link, privacy link, terms link, and app store readiness copy
- `/support`: contact method, expected response path, app name, platform, and troubleshooting details
- `/privacy`: collected data, purpose, third-party processors, sharing, retention, deletion, export, children policy when relevant, and contact method
- `/terms`: license, acceptable use, subscriptions or purchases, user content rules, AI/content disclaimer when relevant, termination, and contact method
- `/privacy-choices`: clear access, deletion, export, and opt-out instructions when relevant

Run `runChecks({ appPath: "<web app path>" })` for the web app and use the returned hosted URL as the base URL for App Store Connect, such as `/privacy`, `/support`, and `/terms`. This App Store prep flow does not require the separate production web publishing flow as long as `runChecks` returns a public hosted URL.

For apps with subscriptions or in-app purchases, add tappable Terms and Privacy links to the paywall or settings screen before preflight. Use Apple's standard EULA link only when the app does not need custom terms.

Then read `.rork/skills/app-store-metadata/SKILL.md` and follow its instructions to call `generateAppStoreMetadata`. Pass the generated or confirmed website URLs in `legalUrls`. Set `includeLegalLinksInDescription: true` only when subscriptions or in-app purchases are present.

### Step 5: Run Preflight Checks

Before preflight, cover review facts that source scanning and App Store Connect cannot prove:

- Do not require a sandbox purchase as release evidence. Confirm that the paywall and Restore Purchases control are reachable in the release UI, but do not claim a transaction was proven when no transaction was run.
- For iOS subscriptions or in-app purchases, ask the user to open the submitted App Store app in RevenueCat and confirm its **In-App Purchase Key** shows **Valid credentials**. This is a separate Apple key from the App Store Connect API key, and RevenueCat's public API does not expose its validity. Stop before submission when the user cannot confirm it. When the user has confirmed, pass `revenueCatAppStoreCredentialsConfirmed: true` to `submitReview` in Step 9 — without it the server blocks submission with `REVENUECAT_APP_STORE_CREDENTIALS_UNCONFIRMED`.
- Before sending personal data to an external AI provider, obtain explicit consent that names the provider and data categories.
- For user-generated content, provide filtering, reporting, blocking, and a published contact method.
- Request sensitive permissions at the point of use with specific purpose strings, and remove unused capabilities.

Read `.rork/skills/app-store-preflight/SKILL.md` and follow its instructions to call `runPreflight`.

Report the preflight's likely Apple outcome and explain every rejection-risk finding. Recommend fixes, but do not automatically stop submission: model and source findings are advisory, and the user decides whether to proceed. Final submission independently runs deterministic server-side checks against the project-owned build and current App Store Connect state.

### Step 6: Upload Assets to App Store Connect

Upload the generated assets using the `asc` CLI:

- Screenshots: first validate and preview with `asc screenshots validate --path "./screenshots/" --device-type IPHONE_65` and `asc screenshots upload --version-localization "LOC_ID" --path "./screenshots/" --device-type IPHONE_65 --skip-existing --dry-run`, then upload with `--skip-existing`.
- If an upload partially fails, resume from the exact `.asc/reports/screenshots-upload/failures-*.json` artifact with `asc screenshots upload --resume "./.asc/reports/screenshots-upload/failures-123.json"`; do not delete ghost records or combine `--resume` with target selectors.
- Use `--replace --dry-run` and then `--replace --confirm` only when the user explicitly wants every existing screenshot in the target set deleted and replaced.
- Metadata: use `asc apps info edit` for quick single-locale version metadata. For canonical files, subtitle, or multiple locales, follow the `app-store-metadata` skill's pull → edit → validate → dry-run → push flow, preserving unrelated metadata and checking for unintended deletes.
- Legal URLs: pass support and marketing URLs with `asc apps info edit`; write privacy policy and privacy choices URLs to canonical metadata files before `asc metadata push`.

Refer to `.rork/skills/app-store-connect/SKILL.md` for detailed CLI usage.

### Step 7: Ask About Submission

Tell the user their App Store listing is prepared, then ask:

> "Your App Store listing is ready — icons, screenshots, metadata, and preflight checks are all done. Would you like to submit your app for App Store review?"

If the user says **no**, stop here. The listing is prepared and they can submit later.

If the user says **yes**, continue to Step 8.

### Step 8: Check Build Availability

A valid build for the requested version and platform is required for App Store submission. Check if one exists:

```bash
asc builds list \
  --app "APP_ID" \
  --version "VERSION" \
  --platform "PLATFORM" \
  --processing-state "VALID" \
  --sort=-uploadedDate \
  --limit 1
```

Handle the result:

- **VALID build exists** — note its build number, then call:

  ```ts
  resolveReviewSubmission({
    ascAppId: "APP_ID",
    version: "VERSION",
    buildNumber: BUILD_NUMBER,
    platform: "PLATFORM",
  });
  ```

  If it returns `ok`, keep the returned `submissionId` and proceed to Step 9. If it returns
  `not_found`, the build is not linked to a successful Rork submission for this project.
  Ask whether to upload a new build through Flow 1, then use the `submissionId` returned by
  `submitBuild`.

- **Build is PROCESSING** — use one bounded `asc builds wait --build-id "BUILD_ID" --timeout 50s --poll-interval 10s --fail-on-invalid` within Bash's 60-second deadline. If it times out, report that processing is still pending and end the turn. On `VALID`, continue submission; on `FAILED` or `INVALID`, report the failure and stop. Do not poll processing state after a terminal result.
- **No build available** — ask the user: "No build is available for submission. Would you like to submit a new build to TestFlight first?" If yes, switch to Flow 1 (TestFlight Submission) to build and upload, then return here for submission.

Before Step 9, call `runPreflight` in this same assistant turn after a successful
`resolveReviewSubmission` or `submitBuild`. These tools bind the project-owned submission to
the active turn so preflight can refresh its sanitized App Store Connect evidence. Pass the
same `appPath` and `appType`, preserving `buildId` when provided. Do not pass `submissionId`:
`runPreflight` does not accept it. Preflight never attaches products or submits the app, and
an advisory outage does not replace the deterministic server-side submission gate.

A `buildId` label alone does not restore a historical source tree. Exact-submission App Store
Connect evidence and verification of the inspected source are separate: do not claim an old
build was reviewed merely because its identifier was supplied.

### Step 9: Complete Review Details and Submit

Read the App Review details and pre-submission sections in
`.rork/skills/app-store-connect/SKILL.md`. Use the version ID from `asc versions list` to create
or update real review contact details, working demo credentials when login is required,
and substantive notes that lead Apple directly to the core feature and any paywall or
in-app purchases. If any current contact value is missing, call `requestAppReviewContact`
with `existingContact` containing only the exact values returned for that version. Omit
missing fields, never infer values, and wait for the user to confirm the prefilled form before
updating ASC. Use the returned first name, last name, email, and phone instead of asking in
chat prose. Run `asc validate` and fix its errors before continuing.

Before submission:

1. Build the complete app-wide privacy target from source, SDK, server-side, partner, identity-linkage,
   and tracking evidence. Include the privacy-policy URL. Omitted usages are removed.
2. Call `prepareAppStoreCompliance` without `medicalDevice`. Ask the medical question only if Apple returns
   `answer_required`, then prepare again. `true` requires manual App Store Connect completion; `false` lets
   Rork record No. If Apple says it is not required, do not ask.
3. Call `applyAppStoreCompliance` with the same target and exact `planId`, including when Apple already
   matches. The visual confirmation is the required attestation.
4. Submit with the same complete target:

```ts
submitReview({
  submissionId: "PROJECT_OWNED_SUBMISSION_ID",
  compliance: COMPLETE_COMPLIANCE_TARGET,
});
```

The server rechecks Apple and the stored build-bound attestation before mutating review state. On
`compliance_required`, prepare and confirm the returned fresh plan. On `blocked`, fix the listed product
issues. On `reauthentication_required`, reconnect Apple and retry.

For RevenueCat-monetized apps, `blocked` with `REVENUECAT_APP_STORE_CREDENTIALS_UNCONFIRMED` is a
confirmation prompt, not a detected credential problem — RevenueCat's API cannot expose the Apple
In-App Purchase Key, so the server requires a one-time user attestation. Do not re-verify bundle IDs,
API keys, offerings, or entitlements. Ask the user to open the submitted App Store app in RevenueCat
and confirm the bundle ID matches and the In-App Purchase Key shows Valid credentials. Once the user
confirms, retry with the flag set:

```ts
submitReview({
  submissionId: "PROJECT_OWNED_SUBMISSION_ID",
  compliance: COMPLETE_COMPLIANCE_TARGET,
  revenueCatAppStoreCredentialsConfirmed: true,
});
```

For RevenueCat-configured monetized apps, this final gate verifies the submitted bundle's RevenueCat production key, current offering package mapping, entitlement coverage, Apple's Paid Apps Agreement, App Store Connect product state, and review attachment. It does not verify unconfigured or direct-StoreKit commerce, and it does not claim that an unexecuted purchase transaction succeeded.

Tell the user their app has been submitted for review and that Apple review timing varies.

---

## Key Rules

- **Do NOT duplicate skill instructions.** Each step says "Read skill X" — follow those instructions, don't rewrite them here.
- **Steps are sequential.** Screenshots and icons involve user interaction, so do them one at a time.
- **Steps can be skipped.** If the user already has assets or has completed a step, ask before redoing it.
- **Build is separate from prep.** The user might just want to prepare their listing (steps 1–6) without submitting. Always ask before proceeding to submission.
