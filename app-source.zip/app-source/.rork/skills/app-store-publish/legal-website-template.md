# Legal Website Template

Use this as the starting structure for the generated App Store legal/support website. Adapt every section to facts found in the app code and config. Remove sections that do not apply, and ask the user for the smallest missing fact instead of inventing it.

Do not present this as legal advice. The final pages should be clear, app-specific, and ready for the user to review before App Store submission.

## Home Page (`/`)

- App name: `[APP_NAME]`
- Short product summary: `[ONE_OR_TWO_SENTENCES_FROM_CODE]`
- Primary support link: `/support`
- Privacy Policy link: `/privacy`
- Terms of Use link: `/terms`
- Privacy Choices link: `/privacy-choices` when applicable
- App Store readiness note: explain that these pages support publishing, account help, privacy requests, and product support.

## Support (`/support`)

- App name and platform
- Contact email, contact form, or support destination
- What users should include when asking for help:
  - app version
  - device model
  - iOS version
  - account email or user ID when relevant
  - screenshots or error details when relevant
- Billing/subscription help path when the app has purchases
- Account deletion or data request path when the app has accounts
- Expected response path or support owner when known

## Privacy Policy (`/privacy`)

- Effective date
- Who operates the app and how to contact them
- What data the app collects:
  - account/profile data
  - user-created content
  - uploads and generated content
  - purchases/subscriptions
  - analytics, diagnostics, crash reports, attribution, ads, and notifications
  - device permissions such as camera, photos, location, microphone, contacts, health, or notification tokens
- Why each data category is used
- Third-party services and processors found in packages/config
- Whether data is shared, sold, or used for tracking
- Data retention and deletion
- User rights: access, correction, deletion, export, and opt-out where applicable
- Children/privacy age note when the app targets or may be used by children
- International transfer note when third-party cloud services are used
- Changes to the policy
- Contact method

## Terms of Use (`/terms`)

- Effective date
- Acceptance of terms
- License to use the app
- Account responsibilities
- Acceptable use rules
- User content ownership and permissions when the app has user-generated content
- AI-generated content disclaimer when the app uses AI
- Subscription, purchase, trial, renewal, cancellation, and refund language when the app sells anything
- Marketplace, creator, or affiliate terms when applicable
- Prohibited conduct
- Service availability and changes
- Termination
- Disclaimer and limitation of liability
- Governing law placeholder only if the user provides it
- Contact method

## Privacy Choices (`/privacy-choices`)

Use this page when the app has accounts, analytics/ads/tracking, uploads, AI data processing, or region-specific privacy requests.

- Request access to data
- Request deletion
- Request export
- Opt out of marketing emails, analytics, ads tracking, or sale/sharing when applicable
- Revoke app permissions through iOS Settings when relevant
- Contact method and required verification details

## Final Checks

- All legal links are public, tappable, and reachable without login.
- The homepage links to support, privacy, terms, and privacy choices when present.
- App Store metadata uses the same public URLs passed through `legalUrls`.
- Paywalls and settings screens link to Terms and Privacy when the app has subscriptions or in-app purchases.
