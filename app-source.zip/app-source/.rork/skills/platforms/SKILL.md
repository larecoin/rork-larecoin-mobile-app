---
name: platforms
description: Use this skill whenever the user asks to create, scaffold, add, or
  set up an app in the current Rork workspace, including requests like "create
  an iOS app for this website" or adding a native iOS/Swift, Android/Kotlin,
  Expo/React Native, or web app alongside an existing app. This unlocks app
  scaffolding; do not reject app-creation requests just because another app
  already exists. Also use this skill when the user wants to rename, change, or
  claim their published website's URL/subdomain — it unlocks renameWebsiteUrl.
---

### createApp

Create a new app inside the workspace. Writes template files into a subfolder and
creates/updates the root rork.json manifest.

When to call:
- Empty workspace: you MUST call this before writing any code.
- Existing workspace: call when the user asks to add another app (e.g. an iOS app alongside an
  existing web app).

Picking `framework` for the FIRST app:
- Default to the user's selected platform (named in the new-project nudge).
- Override only on clear intent for another platform — by name OR by use:
  iPhone/iPad/App Store/widget → `swift`; Android/Play Store → `kotlin`;
  website/dashboard/"deploy to my domain"/runs in a browser → `web`. Intent need not be the
  exact word ("deploy it to my domain" → `web`); the app's genre alone is not intent (a
  "CS2-style FPS is a PC game" stays on the selected platform).
- createApp rejects the first attempt whose `framework` differs from the selected platform.
  If the user really did ask for the other platform, just call createApp again with the same
  `framework` and it goes through; otherwise switch to the selected platform.
- `react-native` is RETIRED: no new Expo app can be created. It stays valid only inside a
  project that was originally started with React Native, so an existing Expo workspace can
  still be scaffolded; the call is rejected everywhere else. Never pick it for a new app.
- Swift 3D games / RealityKit games → `swift`. Decide orientation from the requested genre,
  camera, and controls before creating the app.
- Use `swiftTemplateProfile: "landscape-3d-game"` when the chosen orientation is landscape:
  explicit landscape/horizontal requests, generic or ambiguous Swift/RealityKit 3D games,
  racing/driving/flight, FPS/TPS/shooters, arena combat, action RPG/open-world/adventure,
  sports/fighting, dual-stick controls, wide tactical maps, or designs that need a wide
  camera view or two-thumb controls.
- Do not use the landscape profile for portrait-first games: endless/lane runners, vertical
  runners/climbers/fallers, one-tap or swipe hypercasual games, idle/merge/tycoon/collection
  games, card/board/puzzle/gacha games, vertical shooters, rhythm lane games, regular apps,
  AR/model viewers, or non-game 3D showcases.

Ask the user for a clear app name/alias, then call this tool with the name and framework.
If a Swift/RealityKit 3D game's orientation is ambiguous, default to landscape and include
`swiftTemplateProfile`; do not stop to ask the user. Omit the profile when the user
explicitly requests portrait/vertical or the prompt clearly matches a portrait-first genre.
The repo folder path is derived automatically from that name, for example `ios-client-demo`,
`android-field-team`, or `web-marketing-site`.

Temporary rollout constraint: only one app per framework can be created right now. If the
project already has an iOS, Android, or Web app, do not create another one of that same
framework yet.

```json
{"type":"object","properties":{"name":{"type":"string","minLength":1,"maxLength":60,"description":"Display name for the app (e.g. 'My Fitness Tracker')"},"framework":{"type":"string","enum":["react-native","swift","kotlin","web"],"description":"Framework to use"},"path":{"description":"Exact app folder path to create. If omitted, the path is derived from the app name.","type":"string","minLength":1,"maxLength":120},"swiftTemplateProfile":{"description":"Swift-only template profile. Use \"landscape-3d-game\" when creating a landscape Swift/RealityKit 3D game.","type":"string","enum":["landscape-3d-game"]}},"required":["name","framework"]}
```

### renameWebsiteUrl

Rename this project's published website URL — the public "<name>.rork.app" subdomain — instantly, with no build or publish step.
The user must approve a confirmation card in chat before the rename applies: the previous URL stops working immediately and the name is released for anyone to claim.
Use this tool instead of editing rork.json's settings.webSlug — that field is no longer read and has no effect.

If the name is reserved or already taken, the error message explains why — relay it to the user and suggest an
alternative (e.g. a hyphenated variant or suffix) rather than retrying the same value.

```json
{"type":"object","properties":{"webSlug":{"type":"string","minLength":5,"maxLength":48,"pattern":"^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$","description":"New public web name for the project's website URL. 5-48 characters: lowercase letters, numbers, and hyphens only; no leading or trailing hyphen."}},"required":["webSlug"]}
```
