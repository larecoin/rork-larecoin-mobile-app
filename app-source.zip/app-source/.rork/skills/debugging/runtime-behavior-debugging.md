# Runtime Behavior Debugging

Use this playbook when an app builds successfully but the user reports that runtime behavior is still wrong, especially with vague feedback like "it doesn't work", "still broken", "the tap does nothing", or "the screen does not change".

This applies across React Native, React web, SwiftUI, and Kotlin apps. A successful build only proves the code compiles; it does not prove the user event reached the app, state changed, the relevant UI is mounted, or side effects and permissions are aligned.

## Core Rule

Classify the failure before editing again. Work from the furthest confirmed point in the flow:

- **Launch/build**: The app installs and opens without crashing.
- **Event delivery**: The tap, notification response, deep link, delegate callback, router event, or async completion fires.
- **State mutation**: The expected React state, store value, observable model, navigation path, permission state, or view model property changes.
- **Render/presentation**: The destination component/view is mounted by the active route, root view, navigator, sheet, modal, full-screen cover, overlay, or conditional branch.
- **Side effects**: Audio, haptics, network calls, logs, notifications, storage writes, or other non-visual effects happen.

If a later checkpoint is confirmed, do not keep rewriting earlier layers. Move forward to the next unproven checkpoint.

## Vague User Feedback

When the user only says the behavior is still broken, ask one focused follow-up if no observable signal exists. Separate the checkpoints:

- Does the app open?
- Does any sound, log, haptic, notification, network call, or other side effect happen?
- Does any screen or visible state change?
- Does a permission prompt appear?

Avoid asking a broad list of questions when one high-signal question can split the next decision.

## Side Effect Works, UI Does Not

If a side effect fires but the UI does not change, the trigger path is at least partially proven. Stop changing the original event handler unless new evidence points there.

Example: if a notification tap starts audio but no call screen appears, notification delivery is already proven. Next inspect:

- Whether the session/call state actually changed in the state source the UI reads.
- Whether the route, root component, or presenting view that owns the UI is currently mounted.
- Whether the target UI is hidden behind another modal, stale route, guard, permission gate, or conditional branch.
- Whether permission state blocks the visible UI even though the side effect started.
- Whether app activation, hydration, or navigation timing caused state to update before the presenter existed.

## Platform Notes

React Native and React web:

- Confirm the handler fires, then inspect the exact state/store value used by the rendered component.
- Check stale closures, missing dependencies, memoized selectors, provider boundaries, route guards, and navigation readiness.
- If state changes but UI does not, inspect component mounting, conditional rendering, memoization, and whether a different store/provider instance is being read.

SwiftUI:

- Confirm state changes on the main actor and that the mounted root view reads the same `@State`, `@Binding`, `@Observable`, environment value, or navigation path.
- Be careful with `sheet` and `fullScreenCover` during launch, app activation, notification taps, or deep links. Presentation state can change before the presenter is mounted.
- For global states that must always make a screen visible, prefer a stable root-level presenter or conditional overlay.

Kotlin and Jetpack Compose:

- Confirm the event updates the `StateFlow`, `MutableState`, navigation state, or view model property observed by the composable.
- Check lifecycle-aware collection, remembered state that should be hoisted, navigation graph ownership, and conditional branches around the destination.

## Stale Assets After a Web Publish

If the user reports an old image or file still showing after a publish and it is a `public/` file (Vite and Expo web both copy `public/` verbatim; imported/`require()`d assets are content-hashed and immune): rename the file, update its references, and republish — only a new URL reaches visitors' caches. Assets that first existed after 2026-08-06 are not affected; investigate other causes. The user's own browser may need one hard refresh.

## Debugging Order

1. Confirm the last checkpoint that definitely works.
2. Search the code path for the next checkpoint only.
3. Add the smallest change that connects the confirmed state to the missing behavior.
4. Build after code changes.
5. If the user reports it is still broken, update the checkpoint model before editing again.

Do not treat repeated "still broken" feedback as permission to rewrite the same layer repeatedly.
