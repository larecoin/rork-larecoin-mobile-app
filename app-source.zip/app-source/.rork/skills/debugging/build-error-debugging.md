# Build Error Debugging

Use this playbook when failures are likely caused by project code rather than infrastructure, especially build, bundle, compile, archive, or App Store build failures.

## React Native, React Web, And TypeScript

Common patterns and what to do first:

- **Unresolved import/module not found**
  - Verify path casing and extension.
  - Confirm the file exists and is exported correctly.
  - If dependency is external, verify it is in `package.json` and installed.
- **TypeScript parse/type error near one file**
  - Fix the first reported error first; many follow-up errors are cascading.
  - Check recently edited JSX/TS syntax, such as missing commas, braces, or closing tags.
- **Runtime-only API used during bundling**
  - Guard platform-specific APIs and avoid unavailable globals at module top level.
- **Metro or Vite cannot resolve asset or alias**
  - Confirm alias/path config and avoid dynamic import paths that the bundler cannot statically analyze.

## Swift Build And Archive

Common patterns and what to do first:

- **`file.swift:<line>:<col>: error:` compiler failures**
  - Start with the first compiler error and ignore later cascades.
  - Check symbol names and access modifiers after recent refactors.
- **Type mismatch / optional handling errors**
  - Add explicit types where inference is ambiguous.
  - Handle optional unwrapping safely with `if let`, `guard let`, optional chaining, or nil coalescing.
- **Missing target member or framework symbol**
  - Verify target membership and imports for moved or new files.
  - Confirm the symbol exists for the selected iOS version and gate with availability when needed.
- **Archive-specific failure after local compile success**
  - Check signing, capabilities, entitlements, and code paths used only in archive builds.

## Kotlin Build And Compose

Common patterns and what to do first:

- **Unresolved reference**
  - Verify imports, Gradle dependencies, and package names.
  - Check whether a composable or class was moved without updating references.
- **Type mismatch or nullability error**
  - Fix the first compiler diagnostic and preserve Kotlin null-safety instead of force-unwrapping.
- **Compose state or lifecycle compile errors**
  - Check `remember`, state hoisting, lifecycle-aware collection, and navigation graph ownership.

## Triage Order

1. Identify the earliest root error in the failing stack or log.
2. Normalize the error signature so repeated incidents can be grouped.
3. Apply the smallest safe code change to remove the root cause.
4. Re-run checks and only then move to the next group of errors.
