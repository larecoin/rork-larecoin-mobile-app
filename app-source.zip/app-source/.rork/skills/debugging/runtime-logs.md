# Runtime Logs

Use this playbook when you need runtime logs, crash evidence, regression evidence, or user-flow traces from a running app.

Fetch logs with the `rork-agent logs <source>` CLI in the bash tool. It prints one log per line, so pipe it to ripgrep, head, or jq to search and filter — you do not read a file.

## Sources

- runtime — logs from the live app (console.log/warn/error, crashes). Newest first.
- backend — Deno hosting logs from Freestyle.
- appstore — App Store build errors.
- ai-gateway — AI model API responses through the gateway (defaults to failures).
- supabase — Supabase logs (edge functions, postgres, auth, realtime); requires a provisioned backend.

All sources are filtered to the current project automatically.

## Flags

- `--limit <n>` — max logs to fetch (1-100, default 50).
- `--errors` — runtime: only error-level logs.
- `--before <id>` — runtime: fetch logs older than this id (page back through history).
- `--after <id>` — runtime: fetch logs newer than this id (refresh).
- `--skip <n>` — backend/appstore/ai-gateway: pagination offset.
- `--since <iso>` / `--until <iso>` — supabase: ISO 8601 time range.
- `--sql <query>` — supabase: custom SQL (defaults to edge_logs).
- `--message-id <id>` — ai-gateway: scope to one assistantMessageId.
- `--json` — emit one JSON object per line instead of formatted text (pipe to jq).

## Reading and searching

Runtime logs are returned newest-first. Each line is `ISO-timestamp LEVEL message`. Search with ripgrep and cap output:

```bash
rork-agent logs runtime --limit 100 | rg -i "error|undefined" | head -20
rork-agent logs runtime --errors                       # error-level only
rork-agent logs runtime --json | jq -r 'select(.level=="error") | .message'
```

Pagination: the CLI prints `(more logs available — page back with --before <id>)` to stderr when there is more history. Fetch the next older page with `rork-agent logs runtime --before <id>`.

## Workflows

- Crash investigation: `rork-agent logs runtime --errors`, then read surrounding context by widening `--limit` or paging with `--before`.
- Regression detection: compare logs across snapshots — runtime lines include the snapshot id in `--json` output.
- User-flow tracing: `rork-agent logs runtime --limit 200 | rg -i "<action keyword>"`.
- Backend/server errors: `rork-agent logs backend`, then apply build-error-debugging.md if it is a deploy/compile failure.
- AI model API errors: `rork-agent logs ai-gateway` (or scope with `--message-id`).

## Instrumenting the app so logs exist

Runtime logs (and the `.log` files paired with the user's screen recordings and screenshots) only contain what the app prints. When building or debugging a feature whose behavior is hard to see from the UI alone (state machines, gestures, network flows, timers), add one-line semantic log statements at the key transitions — `event_name key=value` style lines are easy to rg for later:

- React Native: `if (__DEV__) console.log("checkout_submit", { items });` — the `__DEV__` guard compiles out of release builds, so production bundles stay silent.
- Swift: wrap prints in `#if DEBUG` … `#endif` — debug prints ship in simulator preview builds (where the logs pipeline captures them) but are stripped from release/App Store builds.

Guarded this way, instrumentation costs nothing in production, and a user's next screen recording arrives with logs that already explain what happened. Keep it to meaningful events (user actions, state transitions, error branches), not every render.

Notes:

- runtime logs cover the last several thousand logs from the live app, not sandbox builds.
- A new project with no traffic may return no logs.
