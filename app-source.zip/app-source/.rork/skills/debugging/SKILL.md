---
name: debugging
description: Playbooks and the `rork-agent logs` CLI for investigating runtime
  logs, behavioral runtime failures, App Store build failures, backend issues,
  and Supabase logs. Use this skill when troubleshooting crashes, logs, broken
  app behavior, UI not updating, or deployment problems.
aliases:
  - runtime logs
  - runtime behavior
  - crash logs
  - app logs
  - build logs
  - doesn't work
  - does not work
  - still broken
  - nothing happens
  - button does nothing
  - ui not updating
  - not updating
  - still the same
  - tap does nothing
  - screen does not change
  - app store build failure
  - supabase logs
  - edge function logs
  - investigate error
---

# Debugging Skill

Playbooks plus the `rork-agent logs` CLI for debugging issues in your Rork app.

## Which Playbook To Read

- Behavior is wrong but the app builds and runs: read runtime-behavior-debugging.md before editing again. Use this for vague feedback like "it doesn't work", "still broken", "nothing happens", "button does nothing", "the tap does nothing", "not updating", "still the same", or "the screen does not change".
- Runtime logs, crashes, or user-flow tracing: read runtime-logs.md.
- Build, bundle, compile, archive, or App Store build failures: read build-error-debugging.md.
- Backend, deployment, or Supabase failures: fetch logs with the CLI below, then apply the relevant playbook.


## Fetching logs: `rork-agent logs <source>`

Run in the bash tool. Output is one log per line, so pipe it to rg / head / jq to filter:

```bash
rork-agent logs runtime --errors | rg -i "network"   # app runtime logs, errors only
rork-agent logs backend --limit 100                   # Deno hosting (Freestyle) logs
rork-agent logs appstore                              # App Store build errors
rork-agent logs ai-gateway --message-id <id>          # failed AI model API calls
rork-agent logs supabase --since 2026-01-15T00:00:00Z # Supabase edge/postgres/auth logs
```

Sources:

- runtime — logs from the live app (console output, crashes). Newest first; page back with `--before <id>`.
- backend — Deno hosting logs from Freestyle (deployment logs, server errors).
- appstore — App Store build errors and failure reasons.
- ai-gateway — AI model API responses (OpenAI/Anthropic/Bedrock via the gateway); defaults to failures.
- supabase — Supabase project logs (edge functions, postgres, auth, realtime). Requires a provisioned Supabase backend. Supports `--sql`, `--since`, `--until`.


All sources are scoped to the current project automatically. See runtime-logs.md for the full flag reference and paging workflow.
