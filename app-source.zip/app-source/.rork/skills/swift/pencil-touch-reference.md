---
index: true
description: UITouch force/azimuth, PencilKit, Apple Pencil Pro
---

# Apple Pencil & Touch Input — Drawing Input Pipeline

Complete reference for handling touch/pencil input for drawing apps. Covers raw UITouch, PencilKit, and Apple Pencil Pro.

**Import:** `import UIKit`, `import PencilKit`

---

## UITouch — Low-Level Touch Input

### Touch Properties for Drawing

| Property                              | Type                                       | Range                               | Pencil Only?      | Use Case                     |
| ------------------------------------- | ------------------------------------------ | ----------------------------------- | ----------------- | ---------------------------- |
| `location(in:)`                       | `CGPoint`                                  | View coords                         | No                | Stroke position              |
| `force`                               | `CGFloat`                                  | 0 to `maximumPossibleForce` (~6.67) | No (3D Touch too) | Brush size/opacity           |
| `azimuthAngle(in:)`                   | `CGFloat`                                  | 0 to 2π radians                     | Yes               | Brush rotation (calligraphy) |
| `azimuthUnitVector(in:)`              | `CGVector`                                 | Unit vector                         | Yes               | Directional brush shape      |
| `altitudeAngle`                       | `CGFloat`                                  | 0 (flat) to π/2 (perpendicular)     | Yes               | Shading width (tilt)         |
| `rollAngle`                           | `CGFloat`                                  | -π to π (iPadOS 17.5+, Pencil Pro)  | Pencil Pro only   | Rotate flat/chisel brushes   |
| `type`                                | `.direct` / `.pencil` / `.indirectPointer` | Enum                                | N/A               | Distinguish finger vs pencil |
| `timestamp`                           | `TimeInterval`                             | Seconds                             | No                | Velocity calculation         |
| `estimatedProperties`                 | `UITouch.Properties`                       | OptionSet                           | Yes               | Which values are estimated   |
| `estimatedPropertiesExpectingUpdates` | `UITouch.Properties`                       | OptionSet                           | Yes               | Which will be refined later  |

### Coalesced Touches (Sub-Frame Input — Up to 240Hz)

iPad Pro + Apple Pencil samples at 240Hz, but `touchesMoved` fires at 60-120Hz. `coalescedTouches(for:)` gives you ALL intermediate points:

```swift
override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
    guard let touch = touches.first else { return }

    // Get ALL sub-frame touch samples (critical for smooth strokes)
    let allTouches = event?.coalescedTouches(for: touch) ?? [touch]
    for coalescedTouch in allTouches {
        let point = StrokePoint(
            position: coalescedTouch.location(in: self),
            force: coalescedTouch.force / coalescedTouch.maximumPossibleForce,
            azimuth: coalescedTouch.azimuthAngle(in: self),
            altitude: coalescedTouch.altitudeAngle,
            timestamp: coalescedTouch.timestamp
        )
        currentStroke.append(point)
    }

    // Get predicted future points (reduces perceived latency)
    let predicted = event?.predictedTouches(for: touch) ?? []
    let predictions = predicted.map {
        StrokePoint(
            position: $0.location(in: self),
            force: $0.force / $0.maximumPossibleForce,
            azimuth: $0.azimuthAngle(in: self),
            altitude: $0.altitudeAngle,
            timestamp: $0.timestamp
        )
    }

    renderStroke(committed: currentStroke, predicted: predictions)
}
```

**Key pattern:** Render coalesced points as committed, render predicted points as temporary (erase and re-draw each frame as predictions update).

### Predicted Touches — Latency Compensation

`predictedTouches(for:)` returns estimated future touch positions. Draw them to make strokes feel instant, but discard and re-draw them each frame since they're approximations:

```swift
func renderStroke(committed: [StrokePoint], predicted: [StrokePoint]) {
    // 1. Draw committed points to the permanent stroke texture
    drawPoints(committed, to: committedTexture)

    // 2. Clear the prediction texture from last frame
    clearTexture(predictionTexture)

    // 3. Draw predicted points to the temporary prediction texture
    drawPoints(predicted, to: predictionTexture)

    // 4. Composite: committed + prediction overlaid on screen
    compositeToScreen(committedTexture, predictionTexture)
}
```

### Estimated Properties & Updates

Apple Pencil `force` and `azimuth` values may arrive as estimates initially, then get refined:

```swift
override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
    guard let touch = touches.first else { return }

    if touch.estimatedPropertiesExpectingUpdates.contains(.force) {
        // Force value may be refined in a future touchesEstimatedPropertiesUpdated call
    }
}

override func touchesEstimatedPropertiesUpdated(_ touches: Set<UITouch>) {
    for touch in touches {
        // Update previously stored points with refined values
        let refinedForce = touch.force
        let estimationIndex = touch.estimationUpdateIndex
        // Match estimationIndex to your stored point and update it
    }
}
```

### Velocity Calculation from Timestamps

```swift
func velocity(from p1: StrokePoint, to p2: StrokePoint) -> CGFloat {
    let dx = p2.position.x - p1.position.x
    let dy = p2.position.y - p1.position.y
    let distance = sqrt(dx * dx + dy * dy)
    let dt = p2.timestamp - p1.timestamp
    guard dt > 0 else { return 0 }
    return distance / CGFloat(dt)
}
```

Use velocity for: stroke width variation (fast = thin), opacity variation (fast = light), smoothing strength.

---

## Apple Pencil Pro Features (iOS 17.5+)

### Barrel Roll (rollAngle)

Gyroscope-based rotation around the pencil axis. Enables flat brush rotation like a real calligraphy pen:

```swift
if #available(iOS 17.5, *) {
    let roll = touch.rollAngle  // -π to π radians
    // Map to brush rotation: natural grip = 0
    brushRotation = roll
}
```

### Squeeze Gesture

Detected via `UIPencilInteraction`:

```swift
class CanvasViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        let pencilInteraction = UIPencilInteraction()
        pencilInteraction.delegate = self
        view.addInteraction(pencilInteraction)
    }
}

extension CanvasViewController: UIPencilInteractionDelegate {
    func pencilInteractionDidTap(_ interaction: UIPencilInteraction) {
        // Double-tap: switch between pen and eraser
        toggleTool()
    }

    @available(iOS 17.5, *)
    func pencilInteraction(_ interaction: UIPencilInteraction,
                           didReceiveSqueeze squeeze: UIPencilInteraction.Squeeze) {
        // Squeeze: show/hide tool palette
        showToolPalette()
        // Haptic feedback
        let generator = UIImpactFeedbackGenerator(style: .medium)
        generator.impactOccurred()
    }
}
```

### Hover (iOS 16.1+)

Pencil hover detection before touching the screen:

```swift
let hoverGesture = UIHoverGestureRecognizer(target: self, action: #selector(handleHover))
view.addGestureRecognizer(hoverGesture)

@objc func handleHover(_ gesture: UIHoverGestureRecognizer) {
    let location = gesture.location(in: view)
    switch gesture.state {
    case .began, .changed:
        showBrushPreview(at: location, altitude: gesture.altitudeAngle)
    case .ended, .cancelled:
        hideBrushPreview()
    default: break
    }
}
```

---

## PencilKit — Turnkey Drawing Framework

PencilKit provides a complete drawing canvas with built-in tools, undo, and Apple Pencil support. No Metal required.

### Basic Setup

```swift
import SwiftUI
import PencilKit

struct DrawingCanvas: UIViewRepresentable {
    @Binding var drawing: PKDrawing

    func makeUIView(context: Context) -> PKCanvasView {
        let canvas = PKCanvasView()
        canvas.tool = PKInkingTool(.pen, color: .black, width: 5)
        canvas.drawingPolicy = .anyInput
        canvas.delegate = context.coordinator
        canvas.drawing = drawing
        canvas.backgroundColor = .white
        return canvas
    }

    func updateUIView(_ uiView: PKCanvasView, context: Context) {}

    func makeCoordinator() -> Coordinator { Coordinator(drawing: $drawing) }

    class Coordinator: NSObject, PKCanvasViewDelegate {
        @Binding var drawing: PKDrawing
        init(drawing: Binding<PKDrawing>) { _drawing = drawing }

        func canvasViewDrawingDidChange(_ canvasView: PKCanvasView) {
            drawing = canvasView.drawing
        }
    }
}
```

### Tool Picker

```swift
struct DrawingScreen: View {
    @State private var canvasView = PKCanvasView()
    @State private var toolPicker = PKToolPicker()
    @State private var drawing = PKDrawing()

    var body: some View {
        DrawingCanvas(drawing: $drawing)
            .onAppear {
                toolPicker.setVisible(true, forFirstResponder: canvasView)
                toolPicker.addObserver(canvasView)
                canvasView.becomeFirstResponder()
            }
    }
}
```

### Available Tools

| Tool                 | Class                                        | Notes                         |
| -------------------- | -------------------------------------------- | ----------------------------- |
| Pen                  | `PKInkingTool(.pen, color:, width:)`         | Variable-width ink            |
| Pencil               | `PKInkingTool(.pencil, color:, width:)`      | Textured, tilt-sensitive      |
| Marker               | `PKInkingTool(.marker, color:, width:)`      | Flat chisel tip               |
| Monoline             | `PKInkingTool(.monoline, color:, width:)`    | Constant width (iOS 17+)      |
| Fountain Pen         | `PKInkingTool(.fountainPen, color:, width:)` | Pressure-sensitive (iOS 17+)  |
| Watercolor           | `PKInkingTool(.watercolor, color:, width:)`  | Blending (iOS 17+)            |
| Crayon               | `PKInkingTool(.crayon, color:, width:)`      | Textured, tilt (iOS 17+)      |
| Eraser (bitmap)      | `PKEraserTool(.bitmap)`                      | Erases pixels                 |
| Eraser (vector)      | `PKEraserTool(.vector)`                      | Erases whole strokes          |
| Eraser (fixed width) | `PKEraserTool(.fixedWidthBitmap, width: 30)` | Fixed-size eraser (iOS 16.4+) |
| Lasso                | `PKLassoTool()`                              | Selection tool                |
| Ruler                | via tool picker UI                           | Straight-edge guide           |

### Custom Tools in Tool Picker (iOS 18+)

```swift
let customTool = PKToolPickerCustomItem(configuration: .init(identifier: "spray", name: "Spray"))
customTool.imageProvider = { _ in UIImage(systemName: "sparkles")! }
// Add to tool picker via PKToolPickerCustomItemConfiguration
```

### PKStroke & PKStrokePoint

```swift
let drawing: PKDrawing = canvasView.drawing

for stroke in drawing.strokes {
    let ink = stroke.ink          // PKInk — tool type + color
    let path = stroke.path        // PKStrokePath — array of points
    let transform = stroke.transform  // CGAffineTransform
    let mask = stroke.mask        // PKStrokePath? — eraser mask

    // Iterate points
    path.forEach { point in
        let location = point.location       // CGPoint
        let force = point.force             // CGFloat (0-1)
        let azimuth = point.azimuth         // CGFloat (radians)
        let altitude = point.altitude       // CGFloat (radians)
        let opacity = point.opacity         // CGFloat (0-1)
        let size = point.size               // CGSize
        let timeOffset = point.timeOffset   // TimeInterval
    }
}
```

### Export / Import

```swift
// Export as image
let image = drawing.image(from: drawing.bounds, scale: UIScreen.main.scale)

// Export as data (for persistence)
let data = drawing.dataRepresentation()

// Restore from data
let restored = try PKDrawing(data: data)

// Append drawings
let combined = drawing1.appending(drawing2)

// Transform drawing
let scaled = drawing.transformed(using: CGAffineTransform(scaleX: 2, y: 2))
```

### PencilKit vs Custom Metal Engine

| Feature           | PencilKit                  | Custom Metal           |
| ----------------- | -------------------------- | ---------------------- |
| Setup             | 3 lines of code            | Weeks of work          |
| Layers            | No                         | Yes                    |
| Blend modes       | No                         | Yes (16+)              |
| Custom brushes    | Limited (7 built-in types) | Unlimited              |
| Frame rate        | 60fps                      | 120fps                 |
| Undo/redo         | Built-in                   | Must implement         |
| Apple Pencil Pro  | Auto-supported             | Must implement         |
| Canvas resolution | Limited                    | Any (4K+)              |
| Filters on canvas | No                         | Yes (Core Image / MPS) |
| Export to PSD     | No                         | Yes                    |

**Use PencilKit** for: annotation, note-taking, signing, simple sketching apps.
**Use custom Metal** for: pro drawing, painting, photo editing, anything needing layers or custom brushes.

---

## Viewport Gestures (Pinch/Zoom/Rotate Canvas)

```swift
func setupViewportGestures(on view: UIView) {
    let pinch = UIPinchGestureRecognizer(target: self, action: #selector(handlePinch))
    let rotate = UIRotationGestureRecognizer(target: self, action: #selector(handleRotation))
    let pan = UIPanGestureRecognizer(target: self, action: #selector(handlePan))
    pan.minimumNumberOfTouches = 2
    pan.maximumNumberOfTouches = 2

    [pinch, rotate, pan].forEach {
        $0.delegate = self  // enable simultaneous
        view.addGestureRecognizer($0)
    }
}

func gestureRecognizer(_ g1: UIGestureRecognizer,
                       shouldRecognizeSimultaneouslyWith g2: UIGestureRecognizer) -> Bool {
    return true  // pinch + rotate + pan simultaneously
}
```

The viewport transform is a `simd_float3x3` (2D affine) applied in the vertex shader to convert canvas coords → screen coords. Single-finger touches draw; two-finger gestures navigate.

---

## Permissions

No special permissions needed for touch/pencil input. PencilKit requires no additional entitlements.
