---
index: true
description: AVAudioEngine graph, pitch randomization, adaptive music (vertical layering), audio ducking, sound layering, reverb zones, crossfade
---

# Game Audio — Advanced Building Blocks

Reusable audio techniques beyond basic AVAudioPlayer. Use these to build an audio system tailored to each game. For basic SFX/Music pooling, see `game-core.md`.

---

## AVAudioEngine Graph

The engine graph connects audio nodes: sources → effects → mixer → output. Build graphs tailored to each game — a puzzle game needs minimal nodes, an action game needs many.

### Minimal Setup (SFX + Music)

```swift
class GameAudioEngine {
    private let engine = AVAudioEngine()
    private let sfxMixer = AVAudioMixerNode()
    private let musicMixer = AVAudioMixerNode()

    init() {
        engine.attach(sfxMixer)
        engine.attach(musicMixer)
        engine.connect(sfxMixer, to: engine.mainMixerNode, format: nil)
        engine.connect(musicMixer, to: engine.mainMixerNode, format: nil)

        musicMixer.volume = 0.6
        sfxMixer.volume = 1.0

        try? engine.start()
    }

    func setMusicVolume(_ volume: Float) { musicMixer.volume = volume }
    func setSFXVolume(_ volume: Float) { sfxMixer.volume = volume }
}
```

### Adding Effects (Reverb, EQ)

Attach effect nodes between source and mixer. Mix and match per game.

```swift
// Reverb for environmental depth
let reverb = AVAudioUnitReverb()
reverb.loadFactoryPreset(.cathedral) // .smallRoom, .largeHall, .plate, etc.
reverb.wetDryMix = 30 // 0 = dry, 100 = fully wet
engine.attach(reverb)
engine.connect(sfxMixer, to: reverb, format: nil)
engine.connect(reverb, to: engine.mainMixerNode, format: nil)

// EQ for tone shaping
let eq = AVAudioUnitEQ(numberOfBands: 3)
eq.bands[0].frequency = 80; eq.bands[0].gain = 6; eq.bands[0].bandwidth = 1 // bass boost for impacts
eq.bands[1].frequency = 2000; eq.bands[1].gain = -3; eq.bands[1].bandwidth = 1 // cut mids
eq.bands[2].frequency = 8000; eq.bands[2].gain = 3; eq.bands[2].bandwidth = 1 // sparkle on top
engine.attach(eq)
```

### Playing Sounds Through the Engine

```swift
func playSFX(named name: String) {
    guard let url = Bundle.main.url(forResource: name, withExtension: "mp3"),
          let file = try? AVAudioFile(forReading: url) else { return }

    let player = AVAudioPlayerNode()
    engine.attach(player)
    engine.connect(player, to: sfxMixer, format: file.processingFormat)
    player.scheduleFile(file, at: nil) {
        // Clean up after playback on a background queue
        DispatchQueue.main.async {
            self.engine.detach(player)
        }
    }
    player.play()
}
```

For frequently used sounds, pre-create a pool of `AVAudioPlayerNode` instances and reuse them instead of attach/detach each time.

---

## Pitch Randomization

Repeating the same sound identically can feel robotic. Pitch randomization adds natural variation.

```swift
func playSFXWithVariation(named name: String) {
    guard let url = Bundle.main.url(forResource: name, withExtension: "mp3"),
          let file = try? AVAudioFile(forReading: url) else { return }

    let player = AVAudioPlayerNode()
    let pitch = AVAudioUnitTimePitch()
    pitch.pitch = Float.random(in: -50...50) // cents (100 cents = 1 semitone)

    engine.attach(player)
    engine.attach(pitch)
    engine.connect(player, to: pitch, format: file.processingFormat)
    engine.connect(pitch, to: sfxMixer, format: file.processingFormat)

    player.scheduleFile(file, at: nil) {
        DispatchQueue.main.async {
            self.engine.detach(player)
            self.engine.detach(pitch)
        }
    }
    player.play()
}
```

Wider ranges (~100 cents) suit stylized games; narrower ranges (~30 cents) suit realistic ones. Common candidates: jumps, footsteps, coins, hits.

---

## Adaptive Music (Vertical Layering)

Split music into stems (drums, bass, melody, pads). All play simultaneously, but volume of each stem changes with game state. Transitions are always smooth because stems share tempo and key.

### Setup

```swift
class AdaptiveMusic {
    private let engine: AVAudioEngine
    private var stems: [String: AVAudioPlayerNode] = [:]
    private var stemVolumes: [String: Float] = [:]
    private let mixer = AVAudioMixerNode()

    init(engine: AVAudioEngine) {
        self.engine = engine
        engine.attach(mixer)
        engine.connect(mixer, to: engine.mainMixerNode, format: nil)
    }

    /// Load stems from bundle. All stems must have identical duration and tempo.
    func loadStems(_ names: [String]) {
        for name in names {
            guard let url = Bundle.main.url(forResource: name, withExtension: "mp3"),
                  let file = try? AVAudioFile(forReading: url) else { continue }

            let player = AVAudioPlayerNode()
            engine.attach(player)
            engine.connect(player, to: mixer, format: file.processingFormat)
            player.volume = 0 // start silent
            player.scheduleFile(file, at: nil)
            stems[name] = player
            stemVolumes[name] = 0
        }
    }

    /// Start all stems simultaneously
    func play() {
        let startTime = AVAudioTime(hostTime: mach_absolute_time() + 100_000_000) // slight future sync
        stems.values.forEach { $0.play(at: startTime) }
    }

    /// Fade a stem to target volume over duration
    func setStemVolume(_ name: String, to volume: Float, duration: TimeInterval = 1.0) {
        guard let player = stems[name] else { return }
        stemVolumes[name] = volume

        // Smooth ramp (check for ramp API or do manual interpolation)
        let steps = Int(duration * 60) // 60 updates per second
        let current = player.volume
        for i in 0...steps {
            let t = Float(i) / Float(steps)
            DispatchQueue.main.asyncAfter(deadline: .now() + duration * Double(i) / Double(steps)) {
                player.volume = current + (volume - current) * t
            }
        }
    }
}
```

### Usage Patterns

```swift
// Load stems
music.loadStems(["bgm_drums", "bgm_bass", "bgm_melody", "bgm_pads"])
music.play()

// Exploration — pads only
music.setStemVolume("bgm_pads", to: 0.8)
music.setStemVolume("bgm_melody", to: 0)
music.setStemVolume("bgm_bass", to: 0)
music.setStemVolume("bgm_drums", to: 0)

// Combat detected — add drums and bass
music.setStemVolume("bgm_drums", to: 0.7)
music.setStemVolume("bgm_bass", to: 0.6)

// Boss fight — everything full
music.setStemVolume("bgm_melody", to: 1.0, duration: 2.0)

// Victory — cut drums, leave melody
music.setStemVolume("bgm_drums", to: 0, duration: 0.5)
```

When creating stems with `generateAudio`, generate each stem separately with the same BPM and key. Name them `bgm_level1_drums`, `bgm_level1_bass`, etc.

---

## Audio Ducking

Temporarily lower music/ambient volume so important sounds cut through. Essential for impacts, dialogue, and dramatic moments.

```swift
extension GameAudioEngine {
    /// Duck music for a brief moment (e.g., heavy impact)
    func duckMusic(to volume: Float = 0.2, duration: TimeInterval = 0.5) {
        let original = musicMixer.volume
        musicMixer.volume = volume
        DispatchQueue.main.asyncAfter(deadline: .now() + duration) {
            self.musicMixer.volume = original
        }
    }
}

// On big hit:
audioEngine.duckMusic(to: 0.15, duration: 0.3)
audioEngine.playSFXWithVariation(named: "heavy_impact")
```

For longer ducking (dialogue, cutscenes), use a slower fade and restore on completion.

---

## Sound Layering

Single sounds can feel thin for significant events. Layering multiple sounds adds perceived weight.

```swift
extension GameAudioEngine {
    /// Play multiple sounds simultaneously for a layered effect
    func playLayered(_ names: [String]) {
        for name in names {
            playSFXWithVariation(named: name)
        }
    }
}

// Sword hit — layer a swoosh, a metallic clang, and a bass thud
audioEngine.playLayered(["sfx_swoosh", "sfx_metal_clang", "sfx_bass_thud"])

// Explosion — layer a boom, debris crackle, and a sub-bass rumble
audioEngine.playLayered(["sfx_explosion_boom", "sfx_debris", "sfx_sub_rumble"])

// Coin pickup — layer a chime and a sparkle
audioEngine.playLayered(["sfx_coin_chime", "sfx_sparkle"])
```

Layers commonly serve different roles: body (core sound), transient (initial attack), tail (aftermath). Not all events need every layer.

---

## Crossfade Between Tracks

Smooth transition between two music tracks (level change, menu → gameplay).

```swift
extension GameAudioEngine {
    func crossfade(from current: AVAudioPlayerNode, to next: AVAudioPlayerNode, duration: TimeInterval = 2.0) {
        next.volume = 0
        next.play()

        let steps = Int(duration * 30)
        for i in 0...steps {
            let t = Float(i) / Float(steps)
            DispatchQueue.main.asyncAfter(deadline: .now() + duration * Double(i) / Double(steps)) {
                current.volume = 1.0 - t
                next.volume = t
            }
        }

        DispatchQueue.main.asyncAfter(deadline: .now() + duration) {
            current.stop()
        }
    }
}
```

---

## Reverb Zones

Change reverb settings when the player enters different environments. Makes spaces feel distinct.

```swift
nonisolated enum EnvironmentType {
    case outdoors, cave, smallRoom, underwater

    var preset: AVAudioUnitReverbPreset {
        switch self {
        case .outdoors: .plate
        case .cave: .cathedral
        case .smallRoom: .smallRoom
        case .underwater: .largeHall
        }
    }

    var wetDryMix: Float {
        switch self {
        case .outdoors: 15
        case .cave: 50
        case .smallRoom: 30
        case .underwater: 70
        }
    }
}

extension GameAudioEngine {
    func setEnvironment(_ env: EnvironmentType) {
        reverb.loadFactoryPreset(env.preset)
        reverb.wetDryMix = env.wetDryMix
    }
}
```

Trigger zone changes based on player position or level section. For RealityKit, use `SpatialAudioComponent` and `AmbientAudioComponent` instead — they handle 3D positioning automatically (see `game-3d.md`).

---

## Principles

1. **Sound confirms action** — primary player inputs should produce audio feedback promptly. Silent interactions on important actions feel broken.
2. **Vary repetitive sounds** — pitch randomization on anything that plays more than once per second.
3. **Layer for weight** — single sounds feel thin. 2-3 layers give body to significant events.
4. **Duck for clarity** — lower background audio during important moments so key sounds cut through.
5. **Match the game's world** — reverb, EQ, and music style should reinforce the environment. A cave sounds different from a field.
6. **Silence is a tool** — brief silence before a big moment creates anticipation. Don't fill every moment with sound.
7. **AVAudioPlayer vs AVAudioEngine** — AVAudioPlayer is fine for simple games (< 5 simultaneous sounds). Switch to AVAudioEngine when you need real-time effects, pitch variation, or adaptive music.
