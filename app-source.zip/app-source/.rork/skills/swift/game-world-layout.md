---
index: true
description: World scale, ground plane, scene graph, camera ownership, genre level layouts
---

# 3D World & Level Layout

Scene-level conventions for RealityKit games: units, ground, scene graph, camera ownership, and concrete level layouts per genre. Per-model import correction (orientation, scale, anchors) lives in `game-3d.md` and `game-asset-integration.md` — this doc covers WHERE things go, not how a single model is corrected.

## Units & Scale

RealityKit is metric: **1 unit = 1 meter**. Every `targetHeight`, position, and camera distance below is in meters. Reference sizes:

| Object               | Size                         |
| -------------------- | ---------------------------- |
| Humanoid character   | 1.7–1.9 height               |
| Eye / camera height  | 1.6 (standing), 1.0 (crouch) |
| Car                  | 4.0–4.5 long, 1.4–1.5 tall   |
| Rifle / long weapon  | 0.9–1.1 long                 |
| Pistol               | 0.2–0.25 long                |
| Door                 | 0.9 × 2.1                    |
| Room / corridor      | 3–6 wide, 2.5–3 ceiling      |
| Building floor       | 3 per storey                 |
| Small arena          | 20×20 to 40×40               |
| Useful draw distance | ≤ 100 from the camera        |

Mixing scales is the most common world bug: a 0.3 m "building" next to a 1.8 m character, or a 40 m weapon. Pick sizes from this table and keep ALL world content within ±100 m of the origin — beyond that, floats lose precision and shadows/physics degrade.

## Ground & Vertical Convention

- **The gameplay ground plane is y = 0.** Terrain height offsets are measured from it; water level, floors of the first storey, and road surfaces sit at y = 0 unless the level design says otherwise.
- Floor-standing models placed with `verticalAnchor: .bottom` touch the ground when their **container** sits at y = 0 — the helper grounds the visual inside the container, so do NOT add an extra half-height offset.
- The physics floor must agree with the visual ground: give the floor entity a static collision box whose TOP face is at y = 0, e.g. `floor.position = [0, -0.05, 0]` with `.generateBox(size: [w, 0.1, d])`. A floor mesh at y = 0 with a collision box centered at y = 0 leaves entities half-sunk.
- **Kill-Z**: anything falling below y = −50 is out of the world. Check `position.y < -50` in a system tick and respawn/destroy — physics objects that escape geometry otherwise fall forever and keep simulating.

## Scene Graph & Camera Ownership

Create ONE explicit scene root and group children by lifetime; never rely on `camera.parent` for spawning:

```swift
let sceneRoot = Entity()            // world origin
let environment = Entity()          // static: ground, walls, sky, lights
let actors = Entity()               // player, NPCs, vehicles
let spawned = Entity()              // projectiles, pickups, FX (pooled/recycled)
sceneRoot.addChild(environment); sceneRoot.addChild(actors); sceneRoot.addChild(spawned)
content.add(sceneRoot)
```

Camera ownership — pick ONE driver per game and do not mix:

- **App-written follow/orbit updater** (default): parent the camera under `sceneRoot` and update its position/look-at every frame from the target's transform (smoothed follow or stored yaw/pitch orbit). Use whenever the camera can switch targets, shake independently, or orbit.
- **`CameraFollowSystem` pattern** (`game-3d.md`): the camera is a CHILD of the target entity so the system can find it via `entity.children`, and the system sets its position in world space each frame — the parent transform is overridden, not double-applied. Do not also drive that camera with a second follow/orbit updater.
- **Static parent-under-player chase** (no per-frame driver at all): zero math, but the camera inherits EVERY player rotation — acceptable only when the player never tilts/rolls.
- **First-person**: the camera IS the player's head; the weapon is parented under the camera (see the first-person section of `game-3d.md`). Move the player entity, not the camera.

Camera defaults that read well on a phone: third-person follow distance 5–7, height 2.5–3.5, `lookHeight` ≈ 1; top-down/arena height 12–20 looking down ~60°; FOV 60° (45° for tight corridors).

## Level Layouts by Genre

Concrete numbers to start from — tune to taste, but keep the relationships.

### Endless runner (forward = −Z)

- 3 lanes at x ∈ {−2, 0, +2} (lane width 2). Player container at z = 0, camera behind at [0, 3, 6] looking at [0, 1, 0].
- Spawn obstacles/pickups at z = −60 (beyond fog/draw falloff), recycle once z > +10 behind the camera. Pool them — never create/destroy per spawn.
- Ground is an illusion: scroll 2–3 tiled segments of length 30–60 toward +Z and leapfrog the one behind the camera to the front.
- Difficulty = world speed: start 6–8 m/s, ramp by 0.1–0.2 m/s per second toward a 16–20 cap.

### Racing

- Track width 8–12 (two 3.5 lanes + margins); cars 4.0–4.5 long. Waypoints every 10–20 m drive both AI steering and off-track detection.
- Grid spawn: rows 6 apart along the track direction, 3 lateral offset within a row.
- AI targets the next waypoint with the same steer-toward-direction math the player uses; reset a car to the nearest waypoint when it leaves the track by > 8 or hits kill-Z.
- Chase camera: distance 6–8, height 2.5–3, lookHeight 1 — and lower the FOV slightly at top speed instead of moving the camera further back.

### Arena / top-down combat

- Playfield radius 15–25 with walls ≥ 2 high carrying static collision — visual walls without collision are the #1 escaped-player bug.
- Enemies spawn on a ring 3 inside the walls, never within 8 of the player.
- Camera at height 12–20, pitched ~60° down; in the orbit updater clamp pitch and keep distance fixed.

### First-person range / shooter

- Room: 8–12 wide, 20–40 deep, ceiling 3–4. Eye height 1.6: camera at [0, 1.6, 0] inside the player collision capsule.
- Targets at 8–25 m read well on a phone screen; closer than 5 m they overflow the FOV.
- Hit detection: raycast from the camera along its forward, not from the muzzle — the muzzle offset makes close shots miss visibly.

### Chunked / open world

- Chunk size 30–60. Keep previous/current/next chunks alive; recycle a chunk once the camera is 1.5 chunk-lengths past it.
- Build chunks under their own root entity at the chunk origin so recycling moves ONE transform.

## World-Position Checklist

Before the final build, verify the scene against this list (the planners validate per-model data, not your level layout):

- Every gameplay entity lives under the scene root; nothing was added to `content` ad hoc or parented to the camera by accident.
- All positions within ±100 of the origin; all sizes match the scale table.
- `desiredWorldForward` vectors are horizontal (XZ) — a vertical forward silently skips body-frame correction.
- The physics floor's top face is at y = 0 and every floor-standing container sits at y = 0.
- A kill-Z guard exists for falling entities.
