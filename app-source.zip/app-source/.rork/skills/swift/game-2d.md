---
index: true
description: Physics, tilemaps, parallax, camera, controls, UI overlays
---

# 2D Game Development — SpriteKit + SwiftUI

> Complete 2D game reference: physics, tilemaps, camera, controls, UI overlays. Coordinate system: (0,0) at BOTTOM-LEFT. Prefer SwiftUI overlays for HUD/menus; use SKLabelNode/SKSpriteNode only for in-world text that must track scene coordinates.

Read `game-core.md` first (crash prevention, state machine, save/load, audio, game polish). For deep SpriteKit API: `spritekit-reference.md`. For particles/effects: `spritekit-particles-effects.md`. For assets: `game-asset-integration.md`.

---

## SpriteKit Scene Setup

```swift
import SwiftUI
import SpriteKit

struct GameView: View {
    @State private var scene: GameScene = {
        let scene = GameScene(size: CGSize(width: 390, height: 844)) // adapt to your target device
        scene.scaleMode = .aspectFill
        return scene
    }()

    var body: some View {
        ZStack {
            SpriteView(scene: scene).ignoresSafeArea()
            GameHUDView(gameManager: scene.gameManager)
        }
    }
}

class GameScene: SKScene {
    let gameManager = GameManager()

    override func didMove(to view: SKView) {
        // (0,0) is BOTTOM-LEFT by default (anchorPoint = (0,0))
        // anchorPoint = CGPoint(x: 0.5, y: 0.5) centers origin
        physicsWorld.contactDelegate = self
    }
}
```

Store the scene in `@State` and create it once in the initializer closure, never in `body`.

---

## Sprite Animation

Generated sprites arrive as SINGLE images, not sprite sheets — plan animation accordingly.

**Default: procedural animation of one sprite.** Squash/stretch, bobbing, tilting, and flip cover most 2D game feel without extra assets:

```swift
// Walk bob + lean (runs while moving)
let bob = SKAction.sequence([
    SKAction.moveBy(x: 0, y: 4, duration: 0.12),
    SKAction.moveBy(x: 0, y: -4, duration: 0.12),
])
player.run(SKAction.repeatForever(bob), withKey: "walk")
player.xScale = facingRight ? 1 : -1   // flip instead of a second sprite
// Jump squash/stretch
player.run(SKAction.sequence([
    SKAction.scaleX(to: 0.85, y: 1.15, duration: 0.08),
    SKAction.scaleX(to: 1.0, y: 1.0, duration: 0.12),
]))
```

**Frame animation (when you have several frames).** Generate pose variants as separate images in one batch with a consistent style prompt (`hero_idle`, `hero_walk_1`, `hero_walk_2`), then drive them with `SKAction.animate`:

```swift
let frames = ["hero_walk_1", "hero_walk_2"].map { name -> SKTexture in
    let texture = SKTexture(imageNamed: name)
    texture.filteringMode = .nearest   // pixel art; .linear for smooth styles
    return texture
}
player.run(SKAction.repeatForever(SKAction.animate(with: frames, timePerFrame: 0.15)), withKey: "walk")
// State changes: removeAction(forKey:) the old loop before starting the new one.
```

Use `SKTextureAtlas(named:)` + `textureNamed(_:)` only when frames live in an `.atlas` folder you created; bundled generated images load directly via `SKTexture(imageNamed:)`. Two or three keyframes at 0.12–0.18s per frame read as lively on a phone — do not generate 10-frame cycles; cross-image consistency degrades and the budget is better spent on more characters.

## Physics Bodies & Presets

### Body Creation

```swift
// Rectangle
sprite.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: 50, height: 50))

// Rectangle with offset center
sprite.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: 50, height: 50),
                                   center: CGPoint(x: 0, y: 10))

// Circle
sprite.physicsBody = SKPhysicsBody(circleOfRadius: 25)

// Circle with offset center
sprite.physicsBody = SKPhysicsBody(circleOfRadius: 25, center: CGPoint(x: 0, y: -10))

// From texture (pixel-perfect, expensive — use sparingly)
sprite.physicsBody = SKPhysicsBody(texture: sprite.texture!, size: sprite.texture!.size())

// Polygon (MUST be convex, counter-clockwise winding; keep under 12 vertices)
let path = CGMutablePath()
path.addLines(between: [
    CGPoint(x: -20, y: -30),
    CGPoint(x: 20, y: -30),
    CGPoint(x: 0, y: 30)
])
path.closeSubpath()
sprite.physicsBody = SKPhysicsBody(polygonFrom: path)

// Compound body (combine multiple shapes for complex objects)
let torso = SKPhysicsBody(rectangleOf: CGSize(width: 30, height: 50))
let head = SKPhysicsBody(circleOfRadius: 15, center: CGPoint(x: 0, y: 40))
sprite.physicsBody = SKPhysicsBody(bodies: [torso, head])

// Edge-based (ALWAYS static — never respond to forces)
let boundary = SKPhysicsBody(edgeLoopFrom: frame)
let floor = SKPhysicsBody(edgeFrom: CGPoint(x: 0, y: 100),
                          to: CGPoint(x: 500, y: 100))
let terrain = SKPhysicsBody(edgeChainFrom: terrainPath)
```

### Key Properties

```swift
let body = sprite.physicsBody!
body.isDynamic = true          // false = immovable obstacle
body.affectedByGravity = true  // false for flying enemies, UI elements
body.allowsRotation = true     // false to prevent spinning (platformer characters)
body.friction = 0.3            // 0 = ice, 1 = rubber (default 0.2)
body.restitution = 0.5         // 0 = no bounce, 1 = perfect bounce (default 0.2)
body.mass = 1.0                // set mass OR density, the other derives automatically
body.density = 1.0
body.linearDamping = 0.1       // 0 = none, 1 = heavy (default 0.1)
body.angularDamping = 0.1
body.velocity = CGVector(dx: 200, dy: 0)     // pixels/sec (read/write)
body.angularVelocity = 2.0                    // radians/sec
```

### Common Presets

| Preset               | Shape                        | Key Settings                                                     |
| -------------------- | ---------------------------- | ---------------------------------------------------------------- |
| Bouncy ball          | `circleOfRadius: 15`         | restitution 0.9, friction 0.1, linearDamping 0.1                 |
| Heavy crate          | `rectangleOf: crate.size`    | mass 5.0, friction 0.8, restitution 0.1                          |
| Static platform      | `rectangleOf: platform.size` | isDynamic false                                                  |
| Platformer character | `rectangleOf: (30, 60)`      | allowsRotation false, friction 0, restitution 0, linearDamping 0 |
| Bullet               | `circleOfRadius: 4`          | affectedByGravity false, mass 0.01, linearDamping 0              |

---

## Collision Categories & Contact Delegate

```swift
nonisolated struct PhysicsCategory {
    static let none:       UInt32 = 0
    static let player:     UInt32 = 0b1         // 1
    static let enemy:      UInt32 = 0b10        // 2
    static let projectile: UInt32 = 0b100       // 4
    static let ground:     UInt32 = 0b1000      // 8
    static let wall:       UInt32 = 0b10000     // 16
    static let collectible:UInt32 = 0b100000    // 32
    static let trigger:    UInt32 = 0b1000000   // 64
    static let all:        UInt32 = UInt32.max
}
```

### The 3-Mask System

| Mask                 | Purpose                                                                | Default      |
| -------------------- | ---------------------------------------------------------------------- | ------------ |
| `categoryBitMask`    | "I am a \_\_\_"                                                        | `0xFFFFFFFF` |
| `contactTestBitMask` | "Notify me when I touch \_\_\_" (delegate fires, NO physical response) | `0`          |
| `collisionBitMask`   | "Physically bounce off \_\_\_" (applies forces, NO delegate call)      | `0xFFFFFFFF` |

Contact fires when `(bodyA.contactTestBitMask & bodyB.categoryBitMask) != 0` OR vice versa.
Collision fires when `(bodyA.collisionBitMask & bodyB.categoryBitMask) != 0`.

```swift
// Player: bounces off walls/ground, notified on enemy/collectible touch
player.physicsBody?.categoryBitMask = PhysicsCategory.player
player.physicsBody?.contactTestBitMask = PhysicsCategory.enemy | PhysicsCategory.collectible
player.physicsBody?.collisionBitMask = PhysicsCategory.wall | PhysicsCategory.ground

// Enemy: bounces off walls and player, notified when hit by projectile
enemy.physicsBody?.categoryBitMask = PhysicsCategory.enemy
enemy.physicsBody?.contactTestBitMask = PhysicsCategory.projectile
enemy.physicsBody?.collisionBitMask = PhysicsCategory.wall | PhysicsCategory.player

// Projectile: passes through everything, notifies on enemy hit
bullet.physicsBody?.categoryBitMask = PhysicsCategory.projectile
bullet.physicsBody?.contactTestBitMask = PhysicsCategory.enemy
bullet.physicsBody?.collisionBitMask = PhysicsCategory.none

// Collectible: no physical collision, just contact detection
coin.physicsBody?.categoryBitMask = PhysicsCategory.collectible
coin.physicsBody?.contactTestBitMask = PhysicsCategory.player
coin.physicsBody?.collisionBitMask = PhysicsCategory.none
coin.physicsBody?.isDynamic = false

// Invisible trigger zone
zone.physicsBody?.categoryBitMask = PhysicsCategory.trigger
zone.physicsBody?.contactTestBitMask = PhysicsCategory.player
zone.physicsBody?.collisionBitMask = PhysicsCategory.none
zone.physicsBody?.isDynamic = false
```

### Contact Delegate with Sorted-Bodies Pattern

```swift
class GameScene: SKScene, SKPhysicsContactDelegate {
    var nodesToRemove: Set<SKNode> = []

    override func didMove(to view: SKView) {
        physicsWorld.contactDelegate = self
    }

    nonisolated func didBegin(_ contact: SKPhysicsContact) {
        Task { @MainActor in
            let (first, second) = contact.bodyA.categoryBitMask <= contact.bodyB.categoryBitMask
                ? (contact.bodyA, contact.bodyB)
                : (contact.bodyB, contact.bodyA)

            guard let nodeA = first.node, let nodeB = second.node else { return }

            switch (first.categoryBitMask, second.categoryBitMask) {
            case (PhysicsCategory.player, PhysicsCategory.enemy):
                handlePlayerHitEnemy(player: nodeA, enemy: nodeB)
            case (PhysicsCategory.player, PhysicsCategory.collectible):
                handlePlayerGotPickup(player: nodeA, pickup: nodeB)
            case (PhysicsCategory.enemy, PhysicsCategory.projectile):
                handleBulletHitEnemy(enemy: nodeA, bullet: nodeB)
                nodesToRemove.insert(nodeB)
            default:
                break
            }
        }
    }

    // CRITICAL: queue removals, process in update() — never removeFromParent() in didBegin
    override func update(_ currentTime: TimeInterval) {
        for node in nodesToRemove {
            node.removeFromParent()
        }
        nodesToRemove.removeAll()
    }
}
```

Guard `enemy.parent != nil` before modifying health to handle duplicate contacts in the same physics frame.

---

## Forces, Impulses, Movement

```swift
let body = sprite.physicsBody!
body.applyForce(CGVector(dx: 0, dy: 100))   // continuous — apply every frame in update()
body.applyImpulse(CGVector(dx: 0, dy: 50))  // instant — one-time (jumps, knockback)
body.applyTorque(0.5)                        // continuous rotation
body.applyAngularImpulse(0.5)               // instant spin
body.velocity = CGVector(dx: 300, dy: body.velocity.dy) // direct set, bypasses physics
```

### Practical Patterns

```swift
// Jump (only when grounded)
func jump() {
    guard let body = player.physicsBody, isOnGround else { return }
    body.applyImpulse(CGVector(dx: 0, dy: 60))
    isOnGround = false
}

// Variable-height jump (release to cut short)
func jumpRelease() {
    guard let body = player.physicsBody, body.velocity.dy > 0 else { return }
    body.velocity = CGVector(dx: body.velocity.dx, dy: body.velocity.dy * 0.4)
}

// Horizontal movement with speed cap
override func update(_ currentTime: TimeInterval) {
    guard let body = player.physicsBody else { return }
    let maxSpeed: CGFloat = 300
    if moveDirection != 0 {
        body.applyForce(CGVector(dx: moveDirection * 600, dy: 0))
    }
    if abs(body.velocity.dx) > maxSpeed {
        body.velocity.dx = maxSpeed * (body.velocity.dx > 0 ? 1 : -1)
    }
}
```

Gravity presets: `-9.8` (Earth, default), `0` (space), `-20` (heavy platformer), `(dx: 2, dy: -9.8)` (wind). Set via `physicsWorld.gravity`.

---

## Joints

All joints connect two physics bodies. Both must exist before creating the joint.

| Joint                   | Use Case                                           |
| ----------------------- | -------------------------------------------------- |
| `SKPhysicsJointPin`     | Rotation around anchor (hinges, pendulums, wheels) |
| `SKPhysicsJointSpring`  | Elastic connection (rubber bands, suspension)      |
| `SKPhysicsJointFixed`   | Rigid bond (gluing pieces together)                |
| `SKPhysicsJointSliding` | Movement along an axis (pistons, rails, elevators) |
| `SKPhysicsJointLimit`   | Maximum distance constraint (chains, tethers)      |

```swift
// Pin joint (most common) — hinges, pendulums, wheels
let pin = SKPhysicsJointPin.joint(withBodyA: nodeA.physicsBody!,
                                   bodyB: nodeB.physicsBody!,
                                   anchor: nodeA.position)
pin.shouldEnableLimits = true
pin.lowerAngleLimit = -.pi / 4
pin.upperAngleLimit = .pi / 4
pin.frictionTorque = 0.2
physicsWorld.add(pin)

// Remove: physicsWorld.remove(joint)
```

Signatures for other joints:

```swift
SKPhysicsJointSpring.joint(withBodyA:bodyB:anchorA:anchorB:) // .frequency, .damping
SKPhysicsJointFixed.joint(withBodyA:bodyB:anchor:)
SKPhysicsJointSliding.joint(withBodyA:bodyB:anchor:axis:)    // .shouldEnableLimits, .lowerDistanceLimit, .upperDistanceLimit
SKPhysicsJointLimit.joint(withBodyA:bodyB:anchorA:anchorB:)  // .maxLength
```

---

## Camera Patterns

```swift
class GameScene: SKScene {
    let cameraNode = SKCameraNode()

    override func didMove(to view: SKView) {
        camera = cameraNode
        addChild(cameraNode)
    }

    // Smooth follow with lerp
    override func update(_ currentTime: TimeInterval) {
        let lerpFactor: CGFloat = 0.1
        let target = player.position
        let dx = (target.x - cameraNode.position.x) * lerpFactor
        let dy = (target.y - cameraNode.position.y) * lerpFactor
        cameraNode.position.x += dx
        cameraNode.position.y += dy
    }

    // Zoom
    func setZoom(_ scale: CGFloat) {
        cameraNode.xScale = scale
        cameraNode.yScale = scale
        // scale < 1 = zoom in, scale > 1 = zoom out
    }
}
```

Nodes added as children of `cameraNode` stay fixed on screen (useful for debug labels; prefer SwiftUI overlays for actual HUD).

### Camera Boundaries

Clamp camera position so it never shows outside the level bounds.

```swift
func clampCamera(levelSize: CGSize, viewSize: CGSize) {
    let scaledWidth = viewSize.width * cameraNode.xScale
    let scaledHeight = viewSize.height * cameraNode.yScale
    let halfW = scaledWidth / 2
    let halfH = scaledHeight / 2

    let minX = halfW
    let maxX = levelSize.width - halfW
    let minY = halfH
    let maxY = levelSize.height - halfH

    cameraNode.position.x = max(minX, min(cameraNode.position.x, maxX))
    cameraNode.position.y = max(minY, min(cameraNode.position.y, maxY))
}

// Call AFTER updating camera position in update():
// clampCamera(levelSize: CGSize(width: 3000, height: 1000), viewSize: view!.bounds.size)
```

For levels smaller than the screen in one dimension, center the camera on that axis instead of clamping.

---

## Touch Handling

```swift
override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
    guard let touch = touches.first else { return }
    let location = touch.location(in: self)
    let tappedNodes = nodes(at: location) // hit testing
    for node in tappedNodes {
        if node.name == "enemy" { handleEnemyTap(node) }
    }
}

override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) { /* drag */ }
override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) { /* release */ }
```

---

## Tilemap + Level Loading

Row 0 of the array is the top of the screen; `.reversed()` maps it to SpriteKit's bottom-up row order.

```swift
// 0 = empty, 1 = grass, 2 = dirt
let levelData: [[Int]] = [
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],  // top of screen
    [1, 1, 0, 0, 0, 0, 0, 0, 1, 1],
    [2, 2, 1, 0, 0, 0, 0, 1, 2, 2],
    [2, 2, 2, 2, 2, 2, 2, 2, 2, 2],  // bottom of screen
]

func buildLevel(from data: [[Int]], tileMap: SKTileMapNode, groups: [SKTileGroup]) {
    for (row, rowData) in data.reversed().enumerated() {
        for (col, tileIndex) in rowData.enumerated() {
            guard tileIndex > 0, tileIndex <= groups.count else { continue }
            tileMap.setTileGroup(groups[tileIndex - 1], forColumn: col, row: row)
        }
    }
}
```

### Per-Tile Physics Bodies

```swift
func addPhysicsToTiles(tileMap: SKTileMapNode) {
    let tileSize = tileMap.tileSize
    for col in 0..<tileMap.numberOfColumns {
        for row in 0..<tileMap.numberOfRows {
            guard tileMap.tileGroup(atColumn: col, row: row) != nil else { continue }
            let tileCenter = tileMap.centerOfTile(atColumn: col, row: row)
            let node = SKNode()
            node.position = tileCenter
            node.physicsBody = SKPhysicsBody(rectangleOf: tileSize)
            node.physicsBody?.isDynamic = false
            node.physicsBody?.categoryBitMask = PhysicsCategory.wall
            node.physicsBody?.collisionBitMask = PhysicsCategory.player | PhysicsCategory.enemy
            node.physicsBody?.contactTestBitMask = PhysicsCategory.player
            tileMap.addChild(node)
        }
    }
}
```

### Touch to Tile Coordinates

Convert touch position to tile indices: `let col = tileMap.tileColumnIndex(fromPosition: touch.location(in: tileMap))` and `tileMap.tileRowIndex(fromPosition:)`. Use `tileMap.tileGroup(atColumn:row:)` to read, `tileMap.setTileGroup(_:forColumn:row:)` to write.

---

## Parallax & Infinite Scrolling

### ParallaxBackground

Multiple background layers move at different speeds relative to the camera.

```swift
class ParallaxBackground {
    struct Layer {
        let node: SKSpriteNode
        let speed: CGFloat // 0.0 = static, 1.0 = moves with camera
    }

    private var layers: [Layer] = []

    func addLayer(imageNamed name: String, zPosition: CGFloat, speed: CGFloat, scene: SKScene) {
        let node = SKSpriteNode(imageNamed: name)
        node.zPosition = zPosition
        node.position = CGPoint(x: scene.size.width / 2, y: scene.size.height / 2)
        scene.addChild(node)
        layers.append(Layer(node: node, speed: speed))
    }

    // Each layer compensates by (1 - speed) since SKCameraNode shifts the viewport
    func update(cameraPosition: CGPoint) {
        for layer in layers {
            layer.node.position.x = cameraPosition.x * (1.0 - layer.speed)
            layer.node.position.y = cameraPosition.y * (1.0 - layer.speed)
        }
    }
}

// Add layers with increasing speed: bg_sky(0.1), bg_mountains(0.3), bg_trees(0.6)
// Call parallax.update(cameraPosition: cameraNode.position) in update()
```

### InfiniteBackground

Tiles two copies of a texture side by side and wraps when one scrolls off-screen.

```swift
class InfiniteBackground {
    private let nodeA: SKSpriteNode
    private let nodeB: SKSpriteNode
    private let scrollSpeed: CGFloat

    init(imageNamed name: String, scrollSpeed: CGFloat, scene: SKScene) {
        self.scrollSpeed = scrollSpeed
        nodeA = SKSpriteNode(imageNamed: name)
        nodeB = SKSpriteNode(imageNamed: name)
        nodeA.zPosition = -10
        nodeB.zPosition = -10
        nodeA.position = CGPoint(x: scene.size.width / 2, y: scene.size.height / 2)
        nodeB.position = CGPoint(x: scene.size.width / 2 + nodeA.size.width, y: scene.size.height / 2)
        scene.addChild(nodeA)
        scene.addChild(nodeB)
    }

    func update(deltaTime: TimeInterval) {
        let offset = scrollSpeed * CGFloat(deltaTime)
        nodeA.position.x -= offset
        nodeB.position.x -= offset

        if nodeA.position.x + nodeA.size.width / 2 < 0 {
            nodeA.position.x = nodeB.position.x + nodeB.size.width
        }
        if nodeB.position.x + nodeB.size.width / 2 < 0 {
            nodeB.position.x = nodeA.position.x + nodeA.size.width
        }
    }
}
```

---

## UI Overlays

Prefer SwiftUI overlays over `SpriteView` for HUD and menus. Use SKLabelNode/SKSpriteNode for in-world text that must track scene coordinates (damage numbers above enemies, item labels).
Use `.allowsHitTesting(false)` on non-interactive HUD elements so touches pass through to SpriteKit.

For animated menus, transitions, floating text, health bars, and polish techniques: see `game-ui-patterns.md`. The examples below show structural layout patterns — adapt visuals and animations to match each game's identity.

### GameHUDView

```swift
struct GameHUDView: View {
    let gameManager: GameManager

    var body: some View {
        VStack {
            HStack {
                Label("\(gameManager.score)", systemImage: "star.fill")
                    .font(.title2.bold())
                    .foregroundStyle(.yellow)
                Spacer()
                HStack(spacing: 4) {
                    ForEach(0..<gameManager.lives, id: \.self) { _ in
                        Image(systemName: "heart.fill")
                            .foregroundStyle(.red)
                    }
                }
            }
            .padding(.horizontal)
            Spacer()
        }
        .allowsHitTesting(false)
    }
}
```

### MainMenuView

```swift
struct MainMenuView: View {
    let onPlay: () -> Void
    let onSettings: () -> Void

    var body: some View {
        VStack(spacing: 24) {
            Text("GAME TITLE")
                .font(.system(size: 48, weight: .black))
                .foregroundStyle(.white)
                .shadow(color: .black, radius: 4, y: 2)

            Spacer()

            VStack(spacing: 16) {
                MenuButton(title: "Play", systemImage: "play.fill", action: onPlay)
                MenuButton(title: "Settings", systemImage: "gearshape.fill", action: onSettings)
            }
            .padding(.bottom, 80)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(.black.opacity(0.6))
    }
}

struct MenuButton: View {
    let title: String
    let systemImage: String
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Label(title, systemImage: systemImage)
                .font(.title2.bold())
                .frame(width: 220, height: 56)
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16))
        }
        .buttonStyle(.plain)
    }
}
```

### PauseMenuView

```swift
struct PauseMenuView: View {
    let onResume: () -> Void
    let onRestart: () -> Void
    let onQuit: () -> Void

    var body: some View {
        VStack(spacing: 20) {
            Text("PAUSED")
                .font(.largeTitle.bold())
                .foregroundStyle(.white)

            VStack(spacing: 12) {
                MenuButton(title: "Resume", systemImage: "play.fill", action: onResume)
                MenuButton(title: "Restart", systemImage: "arrow.counterclockwise", action: onRestart)
                MenuButton(title: "Quit", systemImage: "xmark", action: onQuit)
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(.black.opacity(0.7))
    }
}
```

### GameOverView

```swift
struct GameOverView: View {
    let score: Int
    let highScore: Int
    let isNewHighScore: Bool
    let onRetry: () -> Void
    let onMenu: () -> Void

    var body: some View {
        VStack(spacing: 24) {
            Text("GAME OVER")
                .font(.system(size: 40, weight: .black))
                .foregroundStyle(.white)

            if isNewHighScore {
                Text("NEW HIGH SCORE!")
                    .font(.title3.bold())
                    .foregroundStyle(.yellow)
            }

            VStack(spacing: 8) {
                Text("Score: \(score)")
                    .font(.title.bold())
                Text("Best: \(highScore)")
                    .font(.title3)
                    .foregroundStyle(.secondary)
            }
            .foregroundStyle(.white)

            VStack(spacing: 12) {
                MenuButton(title: "Retry", systemImage: "arrow.counterclockwise", action: onRetry)
                MenuButton(title: "Menu", systemImage: "house.fill", action: onMenu)
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(.black.opacity(0.8))
    }
}
```

### HealthBar

```swift
struct HealthBar: View {
    let current: Int
    let max: Int

    private var percentage: Double {
        guard max > 0 else { return 0 }
        return Double(current) / Double(max)
    }

    private var barColor: Color {
        if percentage > 0.5 { return .green }
        if percentage > 0.25 { return .yellow }
        return .red
    }

    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .leading) {
                Capsule().fill(.gray.opacity(0.3))
                Capsule()
                    .fill(barColor)
                    .frame(width: geo.size.width * percentage)
                    .animation(.easeInOut(duration: 0.3), value: current)
            }
        }
        .frame(height: 12)
    }
}
```

### VirtualJoystick (Floating)

Floating joystick: base appears where the thumb touches. More ergonomic than fixed — no need to look at the joystick.

```swift
struct VirtualJoystick: View {
    @Binding var direction: CGVector
    let radius: CGFloat = 50
    let deadZone: CGFloat = 0.15 // ignore input below 15% of radius

    @State private var knobOffset: CGSize = .zero
    @State private var basePosition: CGPoint = .zero
    @State private var isDragging = false

    var body: some View {
        GeometryReader { geo in
            ZStack {
                if isDragging {
                    // Base — appears at touch start
                    Circle()
                        .fill(.ultraThinMaterial)
                        .frame(width: radius * 2, height: radius * 2)
                        .position(basePosition)

                    // Knob
                    Circle()
                        .fill(.white.opacity(0.8))
                        .frame(width: 40, height: 40)
                        .position(
                            x: basePosition.x + knobOffset.width,
                            y: basePosition.y + knobOffset.height
                        )
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .contentShape(Rectangle())
            .gesture(
                DragGesture(minimumDistance: 0)
                    .onChanged { value in
                        if !isDragging {
                            basePosition = value.startLocation
                            isDragging = true
                        }
                        let dx = value.location.x - basePosition.x
                        let dy = value.location.y - basePosition.y
                        let distance = sqrt(dx * dx + dy * dy)
                        let clamped = min(distance, radius)

                        if distance > 0 {
                            knobOffset = CGSize(
                                width: dx / distance * clamped,
                                height: dy / distance * clamped
                            )
                        }

                        // Normalize to -1...1 with dead zone
                        let normalized = clamped / radius
                        if normalized < deadZone {
                            direction = .zero
                        } else {
                            let adjusted = (normalized - deadZone) / (1 - deadZone)
                            direction = CGVector(
                                dx: (dx / distance) * adjusted,
                                dy: -(dy / distance) * adjusted // flip Y for SpriteKit
                            )
                        }
                    }
                    .onEnded { _ in
                        isDragging = false
                        knobOffset = .zero
                        direction = .zero
                    }
            )
        }
    }
}
```

### ActionButton

```swift
struct ActionButton: View {
    let label: String
    var size: CGFloat = 60
    let onPress: () -> Void
    var onRelease: () -> Void = {}

    var body: some View {
        Text(label)
            .font(.title2.bold())
            .frame(width: size, height: size)
            .background(.ultraThinMaterial, in: Circle())
            .simultaneousGesture(
                DragGesture(minimumDistance: 0)
                    .onChanged { _ in onPress() }
                    .onEnded { _ in onRelease() }
            )
    }
}
```

### GameControlsOverlay

```swift
struct GameControlsOverlay: View {
    var onJump: () -> Void
    var onAttack: () -> Void
    @Binding var joystickDirection: CGVector

    var body: some View {
        HStack {
            VirtualJoystick(direction: $joystickDirection)
                .padding(.leading, 30)
                .padding(.bottom, 30)
            Spacer()
            VStack(spacing: 12) {
                ActionButton(label: "B", onPress: onJump)
                ActionButton(label: "A", onPress: onAttack)
            }
            .padding(.trailing, 30)
            .padding(.bottom, 30)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottom)
    }
}
```

### Timer Display

```swift
struct GameTimerView: View {
    let remainingSeconds: Int

    private var minutes: Int { remainingSeconds / 60 }
    private var seconds: Int { remainingSeconds % 60 }
    private var isLow: Bool { remainingSeconds <= 10 }

    var body: some View {
        Text(String(format: "%d:%02d", minutes, seconds))
            .font(.title.monospacedDigit().bold())
            .foregroundStyle(isLow ? .red : .white)
            .contentTransition(.numericText())
            .animation(.default, value: remainingSeconds)
    }
}
```

### Score Popup

```swift
struct ScorePopup: View {
    let points: Int
    let id: UUID
    @State private var offset: CGFloat = 0
    @State private var opacity: Double = 1

    var body: some View {
        Text("+\(points)")
            .font(.title3.bold())
            .foregroundStyle(.yellow)
            .offset(y: offset)
            .opacity(opacity)
            .task {
                withAnimation(.easeOut(duration: 1.0)) {
                    offset = -60
                    opacity = 0
                }
            }
    }
}

// Wrap multiple popups in a ZStack with ForEach(popups, id: \.id)
```

---

## Custom Easing Curves

SpriteKit has only 4 built-in timing modes. These custom curves give bounce, elastic, and overshoot feel.

```swift
extension SKAction {
    /// Bounce ease-out — overshoots target then settles
    static func bounceMove(to target: CGPoint, duration: TimeInterval) -> SKAction {
        .customAction(withDuration: duration) { node, elapsed in
            let t = elapsed / CGFloat(duration)
            // Attempt: Quadratic bounce formula
            let bounce: CGFloat = t < 0.5
                ? 2 * t * t
                : -1 + (4 - 2 * t) * t + sin(t * .pi) * 0.15
            let startX = node.userData?["startX"] as? CGFloat ?? node.position.x
            let startY = node.userData?["startY"] as? CGFloat ?? node.position.y
            if elapsed == 0 {
                node.userData = node.userData ?? NSMutableDictionary()
                node.userData?["startX"] = node.position.x
                node.userData?["startY"] = node.position.y
            }
            node.position = CGPoint(
                x: startX + (target.x - startX) * bounce,
                y: startY + (target.y - startY) * bounce
            )
        }
    }

    /// Elastic scale — overshoots then oscillates to rest
    static func elasticScale(to target: CGFloat, duration: TimeInterval) -> SKAction {
        .customAction(withDuration: duration) { node, elapsed in
            let t = elapsed / CGFloat(duration)
            let elastic = pow(2, -10 * t) * sin((t - 0.075) * (2 * .pi) / 0.3) + 1
            let start: CGFloat = 1.0
            let value = start + (target - start) * elastic
            node.setScale(value)
        }
    }

    /// Overshoot — goes past target then returns (back-ease-out)
    static func overshootMove(by delta: CGVector, duration: TimeInterval, overshoot: CGFloat = 1.7) -> SKAction {
        .customAction(withDuration: duration) { node, elapsed in
            let t = elapsed / CGFloat(duration) - 1
            let s = overshoot
            let ease = t * t * ((s + 1) * t + s) + 1
            if elapsed == 0 {
                node.userData = node.userData ?? NSMutableDictionary()
                node.userData?["easeStartX"] = node.position.x
                node.userData?["easeStartY"] = node.position.y
            }
            let startX = node.userData?["easeStartX"] as? CGFloat ?? node.position.x
            let startY = node.userData?["easeStartY"] as? CGFloat ?? node.position.y
            node.position = CGPoint(x: startX + delta.dx * ease, y: startY + delta.dy * ease)
        }
    }
}
```

---

## Particles & Effects

Key SKEmitterNode properties: `particleBirthRate`, `particleLifetime`, `particleSpeed`/`particleSpeedRange`, `emissionAngle`/`emissionAngleRange`, `particleScale`/`particleScaleSpeed`, `particleAlphaSpeed`, `particleColor`, `particleColorBlendFactor`, `particleTexture`.

```swift
func makeFire() -> SKEmitterNode {
    let e = SKEmitterNode()
    e.particleBirthRate = 200; e.particleLifetime = 0.8; e.particleSpeed = 60
    e.emissionAngle = .pi / 2; e.emissionAngleRange = .pi / 8
    e.particleScale = 0.4; e.particleScaleSpeed = -0.3; e.particleAlphaSpeed = -1.0
    e.particleColor = .orange; e.particleColorBlendFactor = 1.0
    return e
}

func makeSmoke() -> SKEmitterNode {
    let e = SKEmitterNode()
    e.particleBirthRate = 40; e.particleLifetime = 3.0; e.particleSpeed = 20
    e.emissionAngle = .pi / 2; e.emissionAngleRange = .pi / 6
    e.particleScale = 0.5; e.particleScaleSpeed = 0.3; e.particleAlphaSpeed = -0.3
    e.particleColor = .gray; e.particleColorBlendFactor = 1.0
    return e
}

func makeSparkle() -> SKEmitterNode {
    let e = SKEmitterNode()
    e.particleBirthRate = 60; e.particleLifetime = 0.6; e.particleSpeed = 100
    e.emissionAngleRange = .pi * 2
    e.particleScale = 0.2; e.particleScaleSpeed = -0.3; e.particleAlphaSpeed = -1.5
    e.particleColor = .yellow; e.particleColorBlendFactor = 1.0
    return e
}
```

### Screen Shake

```swift
func shakeCamera(duration: TimeInterval = 0.3, intensity: CGFloat = 8) {
    guard let camera = camera else { return }
    let originalPos = camera.position
    let shakeCount = Int(duration / 0.03)
    var actions: [SKAction] = []
    for _ in 0..<shakeCount {
        let dx = CGFloat.random(in: -intensity...intensity)
        let dy = CGFloat.random(in: -intensity...intensity)
        actions.append(.moveBy(x: dx, y: dy, duration: 0.03))
    }
    actions.append(.move(to: originalPos, duration: 0.03))
    camera.run(.sequence(actions))
}
```

### Slow Motion

Set both `scene.speed` and `physicsWorld.speed` to the same value (e.g. `0.3` for slow-mo, `1.0` for normal).

See `spritekit-particles-effects.md` for complete particle recipes and GLSL shaders.

---

## Field Nodes

Fields apply forces to bodies within their region. Bodies opt in via `fieldBitMask`.

| Field                                             | Effect                                    |
| ------------------------------------------------- | ----------------------------------------- |
| `linearGravityField(withVector:)`                 | Constant directional force (wind)         |
| `radialGravityField()`                            | Attract/repel from center                 |
| `dragField()`                                     | Slows objects (water, mud)                |
| `turbulenceField(withSmoothness:animationSpeed:)` | Semi-random swirling                      |
| `noiseField(withSmoothness:animationSpeed:)`      | Random forces (leaves, debris)            |
| `springField()`                                   | Pulls toward center (magnet)              |
| `vortexField()`                                   | Rotational force (whirlpool)              |
| `electricField()`                                 | Affects bodies by their `charge` property |
| `magneticField()`                                 | Magnetic force                            |

```swift
// Black hole effect
let blackHole = SKFieldNode.radialGravityField()
blackHole.strength = 10.0
blackHole.falloff = 2.0
blackHole.position = CGPoint(x: 200, y: 400)
blackHole.region = SKRegion(radius: 300)
addChild(blackHole)
```

Target specific bodies via `fieldBitMask`: set the field's `categoryBitMask` and matching `fieldBitMask` on bodies that should be affected. Set `fieldBitMask = 0` to disable all field interaction on a body.

---

## Raycasting

```swift
physicsWorld.enumerateBodies(alongRayStart: start, end: end) { body, point, normal, stop in
    if body.categoryBitMask & PhysicsCategory.enemy != 0 {
        self.spawnHitEffect(at: point)
        stop.pointee = true // stop at first hit
    }
}

// Tap detection
if let body = physicsWorld.body(at: tapLocation), let node = body.node {
    handleTap(on: node)
}
```

### Line-of-Sight Check

```swift
func hasLineOfSight(from source: CGPoint, to target: CGPoint) -> Bool {
    var blocked = false
    physicsWorld.enumerateBodies(alongRayStart: source, end: target) { body, _, _, stop in
        if body.categoryBitMask & PhysicsCategory.wall != 0 {
            blocked = true
            stop.pointee = true
        }
    }
    return !blocked
}
```

---

## Common Gotchas

- **Edge bodies are ALWAYS static** -- `isDynamic = true` has no effect on them. Use a volume body with `isDynamic = false` for a static body that participates in collisions.
- **`contactTestBitMask` defaults to `0`** -- no contacts fire until you set it. Forgetting this is the #1 reason `didBegin` never triggers.
- **`collisionBitMask` defaults to `0xFFFFFFFF`** -- everything collides with everything. Always set it explicitly, especially for projectiles and sensors.
- **Never `removeFromParent()` inside `didBegin`** -- queue removals in a `Set<SKNode>` and process them in `update()`.
- **Don't set `position` directly on physics bodies in `update()`** -- it fights the physics engine and causes jitter. Use `velocity` or `applyForce`/`applyImpulse`.
- **Use explicit size for `physicsBody`**, not `sprite.frame` -- frame may be zero if the texture hasn't loaded yet.
- **`[weak self]` in `repeatForever` actions** -- SKAction closures can capture the scene strongly, preventing deallocation.
- **`texture.filteringMode = .nearest` for pixel art** -- default `.linear` blurs pixel art when scaled.
- **Always set `physicsWorld.contactDelegate = self`** -- without it, contacts are detected but `didBegin`/`didEnd` never fire.
- **Force vs impulse** -- `applyForce` in a touch handler barely moves anything (applied for one frame). Use `applyImpulse` for one-shot pushes, or apply force continuously in `update()`.
