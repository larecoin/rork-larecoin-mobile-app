---
index: true
description: Location permissions, accuracy, async API, geocoding, geofencing
---

# Core Location — User Location & Geocoding

Core Location provides the user's geographic position, heading, and altitude. Also converts between coordinates and human-readable addresses.

**Import:** `import CoreLocation`

---

## CLLocationManager Setup

```swift
import CoreLocation

@Observable
class LocationService: NSObject, CLLocationManagerDelegate {
    let manager = CLLocationManager()
    var location: CLLocation?
    var authorizationStatus: CLAuthorizationStatus = .notDetermined

    override init() {
        super.init()
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyKilometer
    }

    func requestPermission() {
        manager.requestWhenInUseAuthorization()
    }

    func requestLocation() {
        manager.requestLocation() // one-shot, battery-friendly
    }

    func startContinuousUpdates() {
        manager.startUpdatingLocation()
    }

    func stopContinuousUpdates() {
        manager.stopUpdatingLocation()
    }

    // Delegate methods
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        location = locations.last
    }

    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        authorizationStatus = manager.authorizationStatus
        if manager.authorizationStatus == .authorizedWhenInUse || manager.authorizationStatus == .authorizedAlways {
            requestLocation()
        }
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        // Handle error
    }
}
```

## Permission Flow

### Authorization Levels

| Level                  | Description                     | Use Case                               |
| ---------------------- | ------------------------------- | -------------------------------------- |
| `.authorizedWhenInUse` | Only while app is in foreground | Weather, maps, navigation              |
| `.authorizedAlways`    | Background access too           | Geofencing, background weather updates |
| `.denied`              | User denied                     | Show settings prompt                   |
| `.restricted`          | Parental controls               | Cannot request                         |
| `.notDetermined`       | Not yet asked                   | Call `requestWhenInUseAuthorization()` |

### Requesting Permission

```swift
// When In Use (most apps)
manager.requestWhenInUseAuthorization()

// Always (background features)
manager.requestAlwaysAuthorization()
```

### Info.plist Keys

```
INFOPLIST_KEY_NSLocationWhenInUseUsageDescription = "Show weather for your location";
INFOPLIST_KEY_NSLocationAlwaysUsageDescription = "Update weather in background";
```

### Handling Denied Permission

```swift
func openSettings() {
    if let url = URL(string: UIApplication.openSettingsURLString) {
        UIApplication.shared.open(url)
    }
}
```

## Accuracy Levels

| Constant                               | Accuracy | Battery   | Use Case            |
| -------------------------------------- | -------- | --------- | ------------------- |
| `kCLLocationAccuracyBestForNavigation` | ~1m      | Very High | Turn-by-turn nav    |
| `kCLLocationAccuracyBest`              | ~5m      | High      | Precise location    |
| `kCLLocationAccuracyNearestTenMeters`  | ~10m     | Medium    | Walking directions  |
| `kCLLocationAccuracyHundredMeters`     | ~100m    | Low       | City-level features |
| `kCLLocationAccuracyKilometer`         | ~1km     | Very Low  | Weather apps        |
| `kCLLocationAccuracyThreeKilometers`   | ~3km     | Minimal   | Regional content    |
| `kCLLocationAccuracyReduced`           | ~5km     | Minimal   | Approximate only    |

For weather apps, `kCLLocationAccuracyKilometer` is sufficient and battery-friendly.

## One-Shot Location

```swift
// Best for weather apps — gets location once, stops GPS
manager.requestLocation()
```

This calls `didUpdateLocations` once with the best available location, then stops. Much more battery-efficient than `startUpdatingLocation()`.

## iOS 17+ Async API (CLLocationUpdate)

```swift
import CoreLocation

func getLocation() async throws -> CLLocation {
    let updates = CLLocationUpdate.liveUpdates()
    for try await update in updates {
        if let location = update.location {
            return location
        }
    }
    throw LocationError.noLocation
}
```

## iOS 18+ CLServiceSession

```swift
let session = CLServiceSession(authorization: .whenInUse)
// Session keeps location services active while it exists
// Automatically handles authorization state
// Dealloc session to stop
```

## Geocoding

### Reverse Geocoding (coordinates → address)

```swift
let geocoder = CLGeocoder()

func getPlaceName(for location: CLLocation) async throws -> String {
    let placemarks = try await geocoder.reverseGeocodeLocation(location)
    guard let placemark = placemarks.first else { return "Unknown" }

    let city = placemark.locality              // "San Francisco"
    let state = placemark.administrativeArea   // "CA"
    let country = placemark.country            // "United States"
    let zip = placemark.postalCode             // "94102"

    return city ?? state ?? country ?? "Unknown"
}
```

### Forward Geocoding (address → coordinates)

```swift
func getCoordinates(for address: String) async throws -> CLLocationCoordinate2D? {
    let placemarks = try await geocoder.geocodeAddressString(address)
    return placemarks.first?.location?.coordinate
}
```

### CLPlacemark Properties

| Property             | Type          | Example             |
| -------------------- | ------------- | ------------------- |
| `name`               | `String?`     | "Apple Park"        |
| `locality`           | `String?`     | "San Francisco"     |
| `subLocality`        | `String?`     | "Mission District"  |
| `administrativeArea` | `String?`     | "CA"                |
| `country`            | `String?`     | "United States"     |
| `isoCountryCode`     | `String?`     | "US"                |
| `postalCode`         | `String?`     | "94102"             |
| `timeZone`           | `TimeZone?`   | America/Los_Angeles |
| `location`           | `CLLocation?` | coordinates         |
| `inlandWater`        | `String?`     | "Lake Tahoe"        |
| `ocean`              | `String?`     | "Pacific Ocean"     |

## Region Monitoring (Geofencing)

```swift
let region = CLCircularRegion(center: coordinate, radius: 500, identifier: "home")
region.notifyOnEntry = true
region.notifyOnExit = true
manager.startMonitoring(for: region)

func locationManager(_ manager: CLLocationManager, didEnterRegion region: CLRegion) {
    // User entered region
}

func locationManager(_ manager: CLLocationManager, didExitRegion region: CLRegion) {
    // User left region
}
```

## Significant Location Changes (Battery Efficient Background)

```swift
// Only triggers on ~500m+ movements, uses cell towers not GPS
manager.startMonitoringSignificantLocationChanges()

// Don't forget to stop
manager.stopMonitoringSignificantLocationChanges()
```

Requires `Always` authorization for background delivery.

## Distance Calculation

```swift
let locationA = CLLocation(latitude: 37.7749, longitude: -122.4194)
let locationB = CLLocation(latitude: 34.0522, longitude: -118.2437)
let distance = locationA.distance(from: locationB) // meters
let km = distance / 1000
let miles = distance / 1609.34
```
