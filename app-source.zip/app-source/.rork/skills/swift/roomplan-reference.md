---
index: true
description: Room scanning UI, CapturedRoom data, USDZ export
---

# RoomPlan — Room Scanning

Scans indoor rooms using camera + LiDAR to produce **parametric 3D models** with walls, doors, windows, furniture detection, dimensions, and room classification. Exports to USD/USDZ.

**Requires:** LiDAR device (iPhone 12 Pro+, iPad Pro 2020+), iOS 16+, camera permission.

---

## Two Integration Methods

### RoomCaptureView (Turnkey UI)

Built-in coaching UI, scan progress visualization (white line animations), dollhouse preview, VoiceOver support (iOS 17+).

```swift
import RoomPlan

struct RoomScanView: UIViewControllerRepresentable {
    func makeUIViewController(context: Context) -> RoomCaptureViewController {
        RoomCaptureViewController()
    }
    func updateUIViewController(_ uiViewController: RoomCaptureViewController, context: Context) {}
}

class RoomCaptureViewController: UIViewController, RoomCaptureViewDelegate {
    private var roomCaptureView: RoomCaptureView!
    private var finalRoom: CapturedRoom?

    override func viewDidLoad() {
        super.viewDidLoad()
        roomCaptureView = RoomCaptureView(frame: view.bounds)
        roomCaptureView.captureSession.delegate = self
        roomCaptureView.delegate = self
        view.addSubview(roomCaptureView)

        roomCaptureView.captureSession.run(configuration: .init())
    }

    func stopScan() {
        roomCaptureView.captureSession.stop()
    }

    func captureView(shouldPresent roomDataForProcessing: CapturedRoomData, error: Error?) -> Bool {
        return true
    }

    func captureView(didPresent processedResult: CapturedRoom, error: Error?) {
        finalRoom = processedResult
    }

    func exportUSDZ() throws -> URL {
        guard let room = finalRoom else { throw NSError(domain: "RoomPlan", code: 1) }
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("room.usdz")
        try room.export(to: url)
        return url
    }
}
```

### RoomCaptureSession (Custom UI)

Full control — you handle visualization, guidance, and processing.

```swift
import RoomPlan

class RoomScanner: NSObject, RoomCaptureSessionDelegate {
    let session = RoomCaptureSession()
    private var scanData: CapturedRoomData?
    var currentRoom: CapturedRoom?

    func startScan() {
        session.delegate = self
        session.run(configuration: .init())
    }

    func stopScan() {
        session.stop()
    }

    // Real-time room updates during scanning
    func captureSession(_ session: RoomCaptureSession, didUpdate room: CapturedRoom) {
        currentRoom = room
        // Update your custom visualization here
    }

    // Scanning guidance
    func captureSession(_ session: RoomCaptureSession, didProvide instruction: RoomCaptureSession.Instruction) {
        switch instruction {
        case .moveCloseToWall: break   // user too far
        case .moveAwayFromWall: break  // user too close
        case .slowDown: break          // scanning too fast
        case .turnOnLight: break       // insufficient lighting
        case .lowTexture: break        // surface lacks visual features
        case .normal: break            // scanning proceeding well
        @unknown default: break
        }
    }

    // Final data after scan ends
    func captureSession(_ session: RoomCaptureSession, didEndWith data: CapturedRoomData, error: Error?) {
        scanData = data
        Task {
            let builder = RoomBuilder(options: [.beautifyObjects])
            currentRoom = try await builder.capturedRoom(from: data)
        }
    }
}
```

---

## Custom ARSession (iOS 17+)

Pass your own ARSession to combine RoomPlan with other ARKit features (scene geometry, plane detection, high-quality image capture, existing AR anchors).

```swift
// Init with custom ARSession
let roomSession = RoomCaptureSession(arSession: myExistingARSession)
roomSession.run(configuration: .init())

// Stop WITHOUT pausing the underlying ARSession
roomSession.stop(pauseARSession: false)
// ARSession keeps running — reuse for another scan or other AR features
```

Use cases:

- Combine RoomPlan results with ARKit scene geometry and plane detection
- Capture high-quality images alongside scan (real estate listings)
- Integrate with an existing AR experience without disrupting ARAnchors

---

## CapturedRoom Data Structure

```
CapturedRoom
├── walls: [Surface]
├── doors: [Surface]
├── windows: [Surface]
├── openings: [Surface]       — passages without doors
├── floors: [Surface]         — polygon shape (iOS 17+)
├── objects: [Object]         — detected furniture
├── sections: [Section]       — room area labels (iOS 17+)
```

### Surface

| Property           | Type                                              | Notes                                             |
| ------------------ | ------------------------------------------------- | ------------------------------------------------- |
| `identifier`       | `UUID`                                            | Stable across StructureBuilder merges             |
| `category`         | `.wall`, `.door`, `.window`, `.opening`, `.floor` |                                                   |
| `dimensions`       | `SIMD3<Float>`                                    | Width, height, thickness in meters                |
| `transform`        | `simd_float4x4`                                   | Position and orientation in 3D                    |
| `confidence`       | `.low`, `.medium`, `.high`                        |                                                   |
| `curve`            | `Curve?`                                          | For curved walls                                  |
| `polygonCorners`   | `[SIMD3<Float>]`                                  | Non-rectangular walls (slanted, beamed) — iOS 17+ |
| `parentIdentifier` | `UUID?`                                           | e.g. window → parent wall — iOS 17+               |

### Object

| Property           | Type                          | Notes                                              |
| ------------------ | ----------------------------- | -------------------------------------------------- |
| `identifier`       | `UUID`                        | Stable across StructureBuilder merges              |
| `category`         | `Category`                    | See categories below                               |
| `dimensions`       | `SIMD3<Float>`                | Bounding box (width, height, depth) in meters      |
| `transform`        | `simd_float4x4`               | Position and orientation                           |
| `confidence`       | `.low`, `.medium`, `.high`    |                                                    |
| `attributes`       | `[any CapturedRoomAttribute]` | Shape variants — iOS 17+                           |
| `parentIdentifier` | `UUID?`                       | e.g. chair → table, dishwasher → storage — iOS 17+ |

### Section (iOS 17+)

Describes room area type:

```swift
room.sections  // [CapturedRoom.Section]
// section.label: .livingRoom, .bedroom, .bathroom, .kitchen, .diningRoom
// section.center: SIMD3<Float>
```

---

## Object Categories

All cases of `CapturedRoom.Object.Category`:

| Category        | Notes                                                         |
| --------------- | ------------------------------------------------------------- |
| `.table`        | Dining, desk, coffee                                          |
| `.chair`        | Attributes distinguish stool, dining, office (iOS 17+)        |
| `.sofa`         | Attributes: single-seat, L-shaped, straight (iOS 17+)         |
| `.bed`          |                                                               |
| `.storage`      | Cabinets, shelving, wardrobes                                 |
| `.television`   |                                                               |
| `.fireplace`    |                                                               |
| `.bathtub`      |                                                               |
| `.toilet`       |                                                               |
| `.sink`         | Kitchen and bathroom — parent carved into rendering (iOS 17+) |
| `.washerDryer`  |                                                               |
| `.stove`        |                                                               |
| `.oven`         | Parent carved into rendering (iOS 17+)                        |
| `.dishwasher`   | Parent carved into rendering (iOS 17+)                        |
| `.refrigerator` |                                                               |
| `.stairs`       |                                                               |

### Object Attributes (iOS 17+)

Objects have a polymorphic `attributes: [any CapturedRoomAttribute]` array that provides finer classification within a category. For example:

- **Chair**: stool vs dining chair vs office chair
- **Sofa**: single-seat vs L-shaped vs straight

Use `category.supportedCombinations` to discover valid attribute sets:

```swift
for category in CapturedRoom.Object.Category.allCases {
    for attributes in category.supportedCombinations {
        // Each `attributes` is a valid combination for this category
    }
}
```

---

## iOS 17 Enhancements Summary

- **Custom ARSession** — pass your own ARSession, keep it alive after scan stops
- **MultiRoom** — StructureBuilder merges multiple scans into one structure
- **Sections** — room type labels (livingRoom, bedroom, bathroom, kitchen, diningRoom)
- **Polygon walls/floors** — non-rectangular shapes (slanted, beamed walls)
- **Curved walls** — now rendered in final result (previously data-only)
- **Object attributes** — finer classification within categories
- **Parent identifiers** — window → wall, chair → table, dishwasher → storage
- **Recessed elements** — dishwashers, ovens, sinks carved into parent storage/wall
- **VoiceOver** — audio feedback for scanning guidance
- **ModelProvider** — replace bounding boxes with custom 3D models on export
- **Mapping metadata** — bridge USDZ node names to CapturedRoom UUIDs

---

## MultiRoom (iOS 17+)

Merge multiple room scans into a single `CapturedStructure`.

### Approach 1: Continuous ARSession

Keep ARSession alive between scans so all rooms share the same coordinate system.

```swift
let roomSession = RoomCaptureSession()

// Scan room 1
roomSession.run(configuration: .init())
// ... user scans ...
roomSession.stop(pauseARSession: false)  // keep ARSession alive

// Scan room 2 (same coordinate system)
roomSession.run(configuration: .init())
// ... user scans ...
roomSession.stop()  // finally pause ARSession
```

### Approach 2: ARWorldMap Relocalization

For scans taken at different times (e.g. next day). Save the world map, reload it later.

```swift
// After first scan — save world map
roomSession.arSession.getCurrentWorldMap { worldMap, error in
    let data = try NSKeyedArchiver.archivedData(withRootObject: worldMap!, requiringSecureCoding: true)
    try data.write(to: savedMapURL)
}

// Before second scan — relocalize
let data = try Data(contentsOf: savedMapURL)
let worldMap = try NSKeyedUnarchiver.unarchivedObject(ofClass: ARWorldMap.self, from: data)
let config = ARWorldTrackingConfiguration()
config.initialWorldMap = worldMap
roomSession.arSession.run(config)
// Wait for relocalization to complete, then start second scan
```

### Merging with StructureBuilder

```swift
let structureBuilder = StructureBuilder(options: [.beautifyObjects])

var capturedRoomArray: [CapturedRoom] = []
// ... add rooms from individual scans ...

let structure = try await structureBuilder.capturedStructure(from: capturedRoomArray)

// CapturedStructure properties:
structure.rooms      // [CapturedRoom] — individual rooms within the structure
structure.walls      // [Surface] — merged, shared walls resolved
structure.doors      // [Surface]
structure.windows    // [Surface]
structure.openings   // [Surface]
structure.objects    // [Object]
structure.floors     // [Surface]
structure.sections   // [Section]

try structure.export(to: outputURL)
```

**Identifier behavior:** Wall, window, door, opening, and object IDs remain stable across merge. Room and floor IDs change.

**Limits:** Best for single-floor residential, 1-4 bedrooms, up to ~186 m² (2000 sq ft). Good lighting (50+ lux).

---

## Export

### Basic USDZ Export

```swift
try capturedRoom.export(to: url)
// Parametric USDZ with bounding boxes for furniture
```

### Export with Metadata Mapping (iOS 17+)

Creates a dictionary bridging USDZ node names → CapturedRoom element UUIDs, so you can look up dimensions/attributes from the USDZ.

```swift
try capturedRoom.export(to: modelURL, metadataURL: mappingURL)
// mappingURL: encoded dictionary of String → UUID
```

### Export with Custom 3D Models (iOS 17+)

Replace object bounding boxes with actual 3D models using `ModelProvider`.

```swift
// Build a ModelProvider from category → model URL mappings
var modelProvider = CapturedRoom.ModelProvider()

// Map a category to a model
try modelProvider.setModelFileURL(sofaModelURL, for: .sofa)

// Map a specific attribute combination to a model
try modelProvider.setModelFileURL(lShapedSofaURL, for: attributes)

// Export with models replacing bounding boxes
try capturedRoom.export(to: outputURL, modelProvider: modelProvider, exportOptions: .model)
```

### USDExportOptions

| Option            | Result                                                     |
| ----------------- | ---------------------------------------------------------- |
| `.mesh` (default) | Parametric mesh — bounding boxes for objects               |
| `.model`          | Custom 3D models from ModelProvider replace bounding boxes |

### CapturedStructure Export

```swift
try structure.export(
    to: outputURL,
    metadataURL: mappingURL,       // optional
    modelProvider: modelProvider,   // optional
    exportOptions: .model          // optional, default .mesh
)
```

---

## Scanning Best Practices

- **Lighting:** 50+ lux — well-lit rooms, avoid very dark spaces
- **Distance:** Arm's length from walls
- **Speed:** Move slowly and steadily
- **Technique:** Point camera at bottom edges of walls to establish floor-wall boundaries
- **Coverage:** Walk the entire perimeter, scan all walls
- **Environment:** Keep room static during scan (no moving people/pets)
- **Size:** Best for rooms up to ~9×9 meters, scan under 10 minutes
- **MultiRoom:** Single-floor residential, up to ~186 m² total

## Limitations & Gotchas

- **Not centimeter-perfect** — treat output as parametric/approximate, allow user correction for design/estimation apps
- **Mirrors and glass** — reflective/transparent surfaces degrade or confuse the LiDAR mesh
- **Very dark surfaces** — absorb LiDAR, produce gaps in mesh
- **High ceilings** — may not be fully captured if beyond LiDAR range (~5m)
- **Thermals/battery** — avoid repeated scans or single scans over ~5 minutes to prevent thermal throttling
- **Moving objects** — people, pets, or objects moving during scan cause artifacts
- **Outdoor spaces** — RoomPlan is designed for interior rooms only, not outdoor or very large spaces
- **No re-seed** — `RoomCaptureView` cannot be pre-populated with a previous `CapturedRoom` to skip scanning

---

## Complete SwiftUI Example

```swift
import SwiftUI
import RoomPlan

struct RoomScannerView: View {
    @State private var isScanning = false
    @State private var scannedRoom: CapturedRoom?
    @State private var showShareSheet = false
    @State private var exportedURL: URL?

    var body: some View {
        ZStack {
            if isScanning {
                RoomScanRepresentable(
                    isScanning: $isScanning,
                    scannedRoom: $scannedRoom
                )
                .edgesIgnoringSafeArea(.all)

                VStack {
                    Spacer()
                    Button("Done Scanning") {
                        isScanning = false
                    }
                    .buttonStyle(.borderedProminent)
                    .padding(.bottom, 40)
                }
            } else if scannedRoom != nil {
                VStack(spacing: 20) {
                    Image(systemName: "checkmark.circle.fill")
                        .font(.system(size: 60))
                        .foregroundStyle(.green)
                    Text("Room Scanned")
                        .font(.title2.bold())
                    Text("\(scannedRoom!.walls.count) walls, \(scannedRoom!.objects.count) objects detected")
                        .foregroundStyle(.secondary)

                    Button("Export USDZ") {
                        exportRoom()
                    }
                    .buttonStyle(.borderedProminent)

                    Button("Scan Again") {
                        scannedRoom = nil
                        isScanning = true
                    }
                }
            } else {
                VStack(spacing: 20) {
                    Image(systemName: "camera.metering.matrix")
                        .font(.system(size: 60))
                        .foregroundStyle(.blue)
                    Text("Room Scanner")
                        .font(.title.bold())
                    Button("Start Scanning") {
                        isScanning = true
                    }
                    .buttonStyle(.borderedProminent)
                }
            }
        }
        .sheet(isPresented: $showShareSheet) {
            if let url = exportedURL {
                ShareLink(item: url)
            }
        }
    }

    private func exportRoom() {
        guard let room = scannedRoom else { return }
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("scanned_room.usdz")
        do {
            try room.export(to: url)
            exportedURL = url
            showShareSheet = true
        } catch {
            print("Export failed: \(error)")
        }
    }
}

struct RoomScanRepresentable: UIViewControllerRepresentable {
    @Binding var isScanning: Bool
    @Binding var scannedRoom: CapturedRoom?

    func makeUIViewController(context: Context) -> RoomScanController {
        let controller = RoomScanController()
        controller.delegate = context.coordinator
        return controller
    }

    func updateUIViewController(_ controller: RoomScanController, context: Context) {
        if !isScanning {
            controller.stopScan()
        }
    }

    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }

    class Coordinator: NSObject, RoomScanControllerDelegate {
        let parent: RoomScanRepresentable
        init(_ parent: RoomScanRepresentable) { self.parent = parent }

        func didFinishScan(room: CapturedRoom) {
            parent.scannedRoom = room
        }
    }
}

protocol RoomScanControllerDelegate: AnyObject {
    func didFinishScan(room: CapturedRoom)
}

class RoomScanController: UIViewController, RoomCaptureViewDelegate {
    private var captureView: RoomCaptureView!
    weak var delegate: RoomScanControllerDelegate?

    override func viewDidLoad() {
        super.viewDidLoad()
        captureView = RoomCaptureView(frame: view.bounds)
        captureView.delegate = self
        captureView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        view.addSubview(captureView)
        captureView.captureSession.run(configuration: .init())
    }

    func stopScan() {
        captureView.captureSession.stop()
    }

    func captureView(shouldPresent roomDataForProcessing: CapturedRoomData, error: Error?) -> Bool {
        return true
    }

    func captureView(didPresent processedResult: CapturedRoom, error: Error?) {
        delegate?.didFinishScan(room: processedResult)
    }
}
```

### Accessing Scan Results

```swift
let room: CapturedRoom = ...

// Room dimensions from walls
for wall in room.walls {
    let width = wall.dimensions.x   // meters
    let height = wall.dimensions.y
    print("Wall: \(width)m × \(height)m")
}

// Furniture
for object in room.objects {
    print("\(object.category): \(object.dimensions.x)m × \(object.dimensions.y)m × \(object.dimensions.z)m")
    print("  Position: \(object.transform.columns.3)")
    print("  Confidence: \(object.confidence)")
}

// Room sections (iOS 17+)
for section in room.sections {
    print("Area: \(section.label)")  // .livingRoom, .bedroom, etc.
}

// Parent relationships (iOS 17+)
for object in room.objects {
    if let parentID = object.parentIdentifier {
        // e.g. chair belongs to table, dishwasher belongs to storage
    }
}
```
