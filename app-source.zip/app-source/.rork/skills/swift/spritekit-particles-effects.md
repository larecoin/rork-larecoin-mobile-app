---
index: true
description: SKEmitterNode, GLSL shaders, SKEffectNode filters, 2D lighting, screen shake
---

# SpriteKit Particles & Effects — Emitters, Shaders, Lighting

SKEmitterNode, custom GLSL shaders, SKEffectNode filters, 2D lighting.

---

## SKEmitterNode — Programmatic Creation

Keep total active particles under 30K across all emitters (`birthRate × lifetime` = active count per emitter).

The recipes below are starting points — tune colors, speeds, birth rates, and sizes to match your game's art style.

```swift
func makeFireEmitter() -> SKEmitterNode {
    let emitter = SKEmitterNode()
    emitter.particleBirthRate = 200
    emitter.particleLifetime = 1.5
    emitter.particleLifetimeRange = 0.5
    emitter.particleSpeed = 50
    emitter.particleSpeedRange = 20
    emitter.emissionAngle = .pi / 2
    emitter.emissionAngleRange = .pi / 6
    emitter.particleSize = CGSize(width: 8, height: 8)
    emitter.particleScaleSpeed = -0.5
    emitter.particleAlphaSpeed = -0.5
    emitter.particleColor = .orange
    emitter.particleColorBlendFactor = 1.0
    emitter.particleColorSequence = nil // clear so color works
    emitter.particleBlendMode = .add
    return emitter
}
```

### Color Sequences

```swift
// Gradient from yellow -> orange -> red -> transparent
let colors: [UIColor] = [.yellow, .orange, .red, UIColor.red.withAlphaComponent(0)]
let locations: [NSNumber] = [0.0, 0.3, 0.7, 1.0]
emitter.particleColorSequence = SKKeyframeSequence(
    keyframeValues: colors,
    times: locations
)
```

## Common Game Effects

### Smoke

```swift
func makeSmokeEmitter() -> SKEmitterNode {
    let e = SKEmitterNode()
    e.particleBirthRate = 40
    e.particleLifetime = 3.0
    e.particleLifetimeRange = 1.0
    e.particleSpeed = 20
    e.particleSpeedRange = 10
    e.emissionAngle = .pi / 2
    e.emissionAngleRange = .pi / 8
    e.particleSize = CGSize(width: 16, height: 16)
    e.particleScaleSpeed = 0.5
    e.particleAlphaSpeed = -0.3
    e.particleColor = .gray
    e.particleColorBlendFactor = 1.0
    e.particleBlendMode = .alpha
    return e
}
```

### Explosion (Burst)

```swift
func makeExplosionEmitter() -> SKEmitterNode {
    let e = SKEmitterNode()
    e.particleBirthRate = 0 // controlled via burst pattern
    e.numParticlesToEmit = 0
    e.particleLifetime = 0.8
    e.particleLifetimeRange = 0.3
    e.particleSpeed = 200
    e.particleSpeedRange = 80
    e.emissionAngleRange = .pi * 2 // all directions
    e.particleSize = CGSize(width: 6, height: 6)
    e.particleScaleSpeed = -1.0
    e.particleAlphaSpeed = -1.0
    e.particleColor = .yellow
    e.particleColorBlendFactor = 1.0
    e.particleBlendMode = .add
    return e
}

func explode(at position: CGPoint) {
    let emitter = makeExplosionEmitter()
    emitter.position = position
    addChild(emitter)
    emitter.run(.sequence([
        .run { emitter.particleBirthRate = 500 },
        .wait(forDuration: 0.1),
        .run { emitter.particleBirthRate = 0 },
        .wait(forDuration: 2.0),
        .removeFromParent()
    ]))
}
```

### Sparkle / Magic

```swift
func makeSparkleEmitter() -> SKEmitterNode {
    let e = SKEmitterNode()
    e.particleBirthRate = 60
    e.particleLifetime = 1.0
    e.particleLifetimeRange = 0.5
    e.particleSpeed = 30
    e.particleSpeedRange = 20
    e.emissionAngleRange = .pi * 2
    e.particleSize = CGSize(width: 4, height: 4)
    e.particleScaleSpeed = -0.8
    e.particleAlphaSpeed = -0.8
    e.particleColor = .cyan
    e.particleColorBlendFactor = 1.0
    e.particleBlendMode = .add
    e.yAcceleration = 20
    return e
}
```

### Rain

```swift
func makeRainEmitter(sceneWidth: CGFloat, sceneHeight: CGFloat) -> SKEmitterNode {
    let e = SKEmitterNode()
    e.particleBirthRate = 300
    e.particleLifetime = 1.5
    e.particleSpeed = 400
    e.particleSpeedRange = 50
    e.emissionAngle = -.pi / 2 // downward
    e.emissionAngleRange = .pi / 30
    e.particleSize = CGSize(width: 1, height: 12)
    e.particleColor = UIColor(white: 0.8, alpha: 0.6)
    e.particleColorBlendFactor = 1.0
    e.particleBlendMode = .alpha
    e.particlePositionRange = CGVector(dx: sceneWidth, dy: 0)
    e.position = CGPoint(x: sceneWidth / 2, y: sceneHeight) // top of scene
    return e
}
```

### Snow

```swift
func makeSnowEmitter(sceneWidth: CGFloat) -> SKEmitterNode {
    let e = SKEmitterNode()
    e.particleBirthRate = 50
    e.particleLifetime = 8.0
    e.particleSpeed = 30
    e.particleSpeedRange = 20
    e.emissionAngle = -.pi / 2
    e.emissionAngleRange = .pi / 4
    e.particleSize = CGSize(width: 6, height: 6)
    e.particleScaleRange = 0.5
    e.particleColor = .white
    e.particleColorBlendFactor = 1.0
    e.particleAlphaRange = 0.3
    e.particleBlendMode = .alpha
    e.particlePositionRange = CGVector(dx: sceneWidth, dy: 0)
    e.xAcceleration = 5 // gentle wind drift
    return e
}
```

### Trail (Attached to Moving Node)

```swift
func makeTrailEmitter() -> SKEmitterNode {
    let e = SKEmitterNode()
    e.particleBirthRate = 100
    e.particleLifetime = 0.5
    e.particleLifetimeRange = 0.2
    e.particleSpeed = 0
    e.particleSize = CGSize(width: 6, height: 6)
    e.particleScaleSpeed = -1.5
    e.particleAlphaSpeed = -2.0
    e.particleColor = .cyan
    e.particleColorBlendFactor = 1.0
    e.particleBlendMode = .add
    return e
}

// targetNode keeps particles in world space so they don't follow the node
let trail = makeTrailEmitter()
trail.targetNode = scene
movingNode.addChild(trail)
```

### Dust on Landing

```swift
func spawnLandingDust(at position: CGPoint) {
    let e = SKEmitterNode()
    e.particleBirthRate = 0
    e.particleLifetime = 0.6
    e.particleSpeed = 40
    e.particleSpeedRange = 20
    e.emissionAngle = .pi / 2
    e.emissionAngleRange = .pi / 3
    e.particleSize = CGSize(width: 4, height: 4)
    e.particleScaleSpeed = 0.3
    e.particleAlphaSpeed = -1.5
    e.particleColor = UIColor(white: 0.7, alpha: 1)
    e.particleColorBlendFactor = 1.0
    e.particleBlendMode = .alpha
    e.position = position
    addChild(e)
    e.run(.sequence([
        .run { e.particleBirthRate = 200 },
        .wait(forDuration: 0.05),
        .run { e.particleBirthRate = 0 },
        .wait(forDuration: 1.0),
        .removeFromParent()
    ]))
}
```

### Coin Pickup Sparkle

```swift
func spawnCoinPickup(at position: CGPoint) {
    let e = SKEmitterNode()
    e.particleBirthRate = 0
    e.particleLifetime = 0.6
    e.particleSpeed = 80
    e.particleSpeedRange = 40
    e.emissionAngleRange = .pi * 2
    e.particleSize = CGSize(width: 4, height: 4)
    e.particleScaleSpeed = -1.0
    e.particleAlphaSpeed = -1.5
    e.particleColor = .yellow
    e.particleColorBlendFactor = 1.0
    e.particleBlendMode = .add
    e.yAcceleration = -50
    e.position = position
    addChild(e)
    e.run(.sequence([
        .run { e.particleBirthRate = 300 },
        .wait(forDuration: 0.08),
        .run { e.particleBirthRate = 0 },
        .wait(forDuration: 1.0),
        .removeFromParent()
    ]))
}
```

## SKShader — Custom GLSL on Nodes

### Glow Pulse

```swift
let glowShader = SKShader(source: """
void main() {
    vec4 color = texture2D(u_texture, v_tex_coord);
    float pulse = (sin(u_time * 3.0) + 1.0) * 0.5;
    gl_FragColor = color + vec4(pulse * 0.3, pulse * 0.2, 0.0, 0.0) * color.a;
}
""")
sprite.shader = glowShader
```

### Dissolve Effect

```swift
let dissolveShader = SKShader(source: """
void main() {
    vec4 color = texture2D(u_texture, v_tex_coord);
    float noise = fract(sin(dot(v_tex_coord, vec2(12.9898, 78.233))) * 43758.5453);
    if (noise < u_progress) { discard; }
    // Edge glow near dissolve boundary
    float edge = smoothstep(u_progress - 0.05, u_progress, noise);
    vec4 edgeColor = vec4(1.0, 0.5, 0.0, 1.0) * (1.0 - edge) * color.a;
    gl_FragColor = color * edge + edgeColor;
}
""")
dissolveShader.uniforms = [SKUniform(name: "u_progress", float: 0.0)]
sprite.shader = dissolveShader

// Animate dissolution in update loop:
// dissolveShader.uniformNamed("u_progress")?.floatValue = progress (0.0 -> 1.0)
```

### Flash White (Hit Feedback)

```swift
let flashShader = SKShader(source: """
void main() {
    vec4 color = texture2D(u_texture, v_tex_coord);
    gl_FragColor = mix(color, vec4(1.0, 1.0, 1.0, color.a), u_flash);
}
""")
flashShader.uniforms = [SKUniform(name: "u_flash", float: 0.0)]
sprite.shader = flashShader

func flashHit() {
    sprite.run(.sequence([
        .run { flashShader.uniformNamed("u_flash")?.floatValue = 1.0 },
        .wait(forDuration: 0.05),
        .run { flashShader.uniformNamed("u_flash")?.floatValue = 0.0 }
    ]))
}
```

### Built-in Uniforms

| Uniform         | Type      | Description                               |
| --------------- | --------- | ----------------------------------------- |
| `u_time`        | float     | seconds since shader attached             |
| `u_texture`     | sampler2D | node's texture                            |
| `v_tex_coord`   | vec2      | texture coordinate (0-1)                  |
| `u_path_length` | float     | shape node path length (SKShapeNode only) |

## SKEffectNode — Core Image Filters

```swift
let effectNode = SKEffectNode()
effectNode.filter = CIFilter(name: "CIGaussianBlur", parameters: ["inputRadius": 5.0])
effectNode.shouldEnableEffects = true
effectNode.shouldRasterize = true // cache the result for performance
effectNode.addChild(backgroundNode)
addChild(effectNode)
```

### Common Filters for Games

```swift
// Pixelate (retro look)
effectNode.filter = CIFilter(name: "CIPixellate", parameters: ["inputScale": 8.0])

// Color invert (damage flash on whole scene)
effectNode.filter = CIFilter(name: "CIColorInvert")

// Bloom / glow
effectNode.filter = CIFilter(name: "CIBloom", parameters: [
    "inputRadius": 10.0,
    "inputIntensity": 0.8
])

// Vignette
effectNode.filter = CIFilter(name: "CIVignette", parameters: [
    "inputRadius": 2.0,
    "inputIntensity": 1.0
])
```

### Toggle Effects at Runtime

```swift
// Wrap the whole scene content in an effect node for post-processing
let worldNode = SKEffectNode()
worldNode.shouldRasterize = false // don't cache — content changes each frame
worldNode.shouldEnableEffects = false // off by default

func enableSlowMotionEffect() {
    worldNode.filter = CIFilter(name: "CIMotionBlur", parameters: [
        "inputRadius": 10.0,
        "inputAngle": 0.0
    ])
    worldNode.shouldEnableEffects = true
}
```

## 2D Lighting — SKLightNode

```swift
let torchLight = SKLightNode()
torchLight.categoryBitMask = 1
torchLight.falloff = 1.5
torchLight.ambientColor = UIColor(white: 0.1, alpha: 1)
torchLight.lightColor = .orange
torchLight.position = CGPoint(x: 100, y: 200)
addChild(torchLight)

// Make sprites respond to light
sprite.lightingBitMask = 1    // affected by lights with matching bit
sprite.shadowCastBitMask = 1  // casts shadows from these lights
sprite.shadowedBitMask = 1    // receives shadows cast by other nodes
```

### Multiple Light Categories

```swift
// Player torch — category 1
let playerLight = SKLightNode()
playerLight.categoryBitMask = 0b0001
playerLight.falloff = 1.0
playerLight.lightColor = .yellow

// Enemy glow — category 2
let enemyLight = SKLightNode()
enemyLight.categoryBitMask = 0b0010
enemyLight.falloff = 2.0
enemyLight.lightColor = .red

// Environment responds to both
wall.lightingBitMask = 0b0011
wall.shadowCastBitMask = 0b0011

// Player only responds to enemy lights (sees danger)
player.lightingBitMask = 0b0010
```

### Flickering Light

```swift
func makeFlickeringLight() -> SKLightNode {
    let light = SKLightNode()
    light.categoryBitMask = 1
    light.falloff = 1.5
    light.lightColor = .orange

    let flicker = SKAction.repeatForever(.sequence([
        .run { light.falloff = CGFloat.random(in: 1.2...1.8) },
        .wait(forDuration: 0.1, withRange: 0.05)
    ]))
    light.run(flicker)
    return light
}
```

## Screen Shake

```swift
func shakeCamera(duration: TimeInterval = 0.3, intensity: CGFloat = 10) {
    guard let camera else { return }
    let shakes = Int(duration / 0.04)
    var actions: [SKAction] = []
    for _ in 0..<shakes {
        let dx = CGFloat.random(in: -intensity...intensity)
        let dy = CGFloat.random(in: -intensity...intensity)
        actions.append(.moveBy(x: dx, y: dy, duration: 0.02))
        actions.append(.moveBy(x: -dx, y: -dy, duration: 0.02))
    }
    camera.run(.sequence(actions))
}
```

### Directional Shake (e.g. hit from left)

```swift
func directionalShake(angle: CGFloat, intensity: CGFloat = 15) {
    guard let camera else { return }
    let dx = cos(angle) * intensity
    let dy = sin(angle) * intensity
    camera.run(.sequence([
        .moveBy(x: dx, y: dy, duration: 0.03),
        .moveBy(x: -dx * 1.5, y: -dy * 1.5, duration: 0.03),
        .moveBy(x: dx * 0.8, y: dy * 0.8, duration: 0.03),
        .moveBy(x: -dx * 0.3, y: -dy * 0.3, duration: 0.03),
        .move(to: .zero, duration: 0.05)
    ]))
}
```

## Slow Motion / Time Scale

```swift
// Slow the entire scene
scene.speed = 0.3           // actions run at 30% speed
scene.physicsWorld.speed = 0.3 // physics at 30% speed

// Restore
func restoreNormalSpeed() {
    let restore = SKAction.customAction(withDuration: 0.5) { node, elapsed in
        let progress = elapsed / 0.5
        let speed = 0.3 + (1.0 - 0.3) * progress
        self.speed = speed
        self.physicsWorld.speed = speed
    }
    run(restore)
}
```

---

## More Shader Recipes

### CRT / Retro TV

Scanlines + slight curvature + color fringing. Apply to an `SKEffectNode` wrapping game content for a retro look.

```swift
let crtShader = SKShader(source: """
void main() {
    vec2 uv = v_tex_coord;

    // Barrel distortion (screen curvature)
    vec2 center = uv - 0.5;
    float dist = dot(center, center);
    uv = uv + center * dist * 0.1;

    // Scanlines
    float scanline = sin(uv.y * 800.0) * 0.04;

    // Color fringing (chromatic aberration)
    float r = texture2D(u_texture, uv + vec2(0.002, 0.0)).r;
    float g = texture2D(u_texture, uv).g;
    float b = texture2D(u_texture, uv - vec2(0.002, 0.0)).b;

    gl_FragColor = vec4(r - scanline, g - scanline, b - scanline, 1.0);
}
""")
effectNode.shader = crtShader
```

### Chromatic Aberration

RGB channel offset on impact. Pass `u_strength` (0 = off, 0.01 = subtle, 0.03 = heavy).

```swift
let aberrationShader = SKShader(source: """
void main() {
    vec2 uv = v_tex_coord;
    vec2 dir = normalize(uv - 0.5); // radial direction from center
    float r = texture2D(u_texture, uv + dir * u_strength).r;
    float g = texture2D(u_texture, uv).g;
    float b = texture2D(u_texture, uv - dir * u_strength).b;
    float a = texture2D(u_texture, uv).a;
    gl_FragColor = vec4(r, g, b, a);
}
""")
aberrationShader.uniforms = [SKUniform(name: "u_strength", float: 0.01)]
effectNode.shader = aberrationShader

// On impact: ramp strength up then back to 0
// aberrationShader.uniformNamed("u_strength")?.floatValue = 0.03
// Then animate back to 0 over 0.2s via SKAction.customAction
```

### Water Reflection (2D)

Wavy distortion of texture — use on a sprite placed below the "waterline" showing a flipped copy of the scene.

```swift
let waterShader = SKShader(source: """
void main() {
    vec2 uv = v_tex_coord;
    // Horizontal wave distortion
    uv.x += sin(uv.y * 20.0 + u_time * 2.0) * 0.01;
    // Vertical ripple
    uv.y += sin(uv.x * 15.0 + u_time * 3.0) * 0.005;
    vec4 color = texture2D(u_texture, uv);
    // Tint blue + reduce opacity for underwater feel
    color.rgb = mix(color.rgb, vec3(0.2, 0.4, 0.7), 0.3);
    color.a *= 0.6;
    gl_FragColor = color;
}
""")
reflectionSprite.shader = waterShader
```

### Heat Distortion / Haze

Warps the area behind a heat source (fire, engine exhaust, desert).

```swift
let heatShader = SKShader(source: """
void main() {
    vec2 uv = v_tex_coord;
    float distort = sin(uv.y * 30.0 + u_time * 4.0) * u_strength;
    uv.x += distort;
    gl_FragColor = texture2D(u_texture, uv);
}
""")
heatShader.uniforms = [SKUniform(name: "u_strength", float: 0.008)]
heatEffectNode.shader = heatShader
```

### Pixelation

Reduce resolution for retro transitions or damage effects. Lower `u_pixels` = more pixelated.

```swift
let pixelShader = SKShader(source: """
void main() {
    float pixels = u_pixels;
    vec2 uv = floor(v_tex_coord * pixels) / pixels;
    gl_FragColor = texture2D(u_texture, uv);
}
""")
pixelShader.uniforms = [SKUniform(name: "u_pixels", float: 64.0)]
sprite.shader = pixelShader

// Animate: decrease u_pixels from 256 → 8 for pixelation transition
```

### Vignette

Darken screen edges for focus or mood. Apply to a full-screen `SKEffectNode`.

```swift
let vignetteShader = SKShader(source: """
void main() {
    vec2 uv = v_tex_coord;
    vec4 color = texture2D(u_texture, uv);
    float dist = distance(uv, vec2(0.5, 0.5));
    float vignette = smoothstep(0.5, 0.2, dist); // dark edges, bright center
    color.rgb *= vignette;
    gl_FragColor = color;
}
""")
effectNode.shader = vignetteShader
```

---

## Day/Night Cycle

Animate light color and ambient over time. Combine with sky color gradient for full effect. The color values below are an Earth-like example — replace them to match your game's atmosphere.

### Light Color Animation

```swift
struct DayNightCycle {
    /// Returns light color and ambient color for a given time of day (0...1, where 0 = midnight, 0.5 = noon)
    static func colors(for time: Float) -> (light: UIColor, ambient: UIColor, intensity: CGFloat) {
        switch time {
        case 0.0..<0.25: // Night → Dawn
            let t = CGFloat(time / 0.25)
            return (
                light: UIColor(red: 0.2 + 0.6 * t, green: 0.2 + 0.4 * t, blue: 0.4 + 0.2 * t, alpha: 1),
                ambient: UIColor(red: 0.05 + 0.15 * t, green: 0.05 + 0.1 * t, blue: 0.1 + 0.1 * t, alpha: 1),
                intensity: 0.3 + 0.5 * t
            )
        case 0.25..<0.5: // Dawn → Noon
            let t = CGFloat((time - 0.25) / 0.25)
            return (
                light: UIColor(red: 0.8 + 0.2 * t, green: 0.6 + 0.35 * t, blue: 0.6 + 0.3 * t, alpha: 1),
                ambient: UIColor(red: 0.2 + 0.1 * t, green: 0.15 + 0.15 * t, blue: 0.2 + 0.05 * t, alpha: 1),
                intensity: 0.8 + 0.2 * t
            )
        case 0.5..<0.75: // Noon → Dusk
            let t = CGFloat((time - 0.5) / 0.25)
            return (
                light: UIColor(red: 1.0 - 0.2 * t, green: 0.95 - 0.5 * t, blue: 0.9 - 0.5 * t, alpha: 1),
                ambient: UIColor(red: 0.3 - 0.1 * t, green: 0.3 - 0.15 * t, blue: 0.25 - 0.05 * t, alpha: 1),
                intensity: 1.0 - 0.3 * t
            )
        default: // Dusk → Night
            let t = CGFloat((time - 0.75) / 0.25)
            return (
                light: UIColor(red: 0.8 - 0.6 * t, green: 0.45 - 0.25 * t, blue: 0.4, alpha: 1),
                ambient: UIColor(red: 0.2 - 0.15 * t, green: 0.15 - 0.1 * t, blue: 0.2 - 0.1 * t, alpha: 1),
                intensity: 0.7 - 0.4 * t
            )
        }
    }
}
```

### Apply in SpriteKit Update Loop

```swift
// In GameScene
var dayTime: Float = 0.25 // start at dawn
let dayDuration: TimeInterval = 120 // full cycle in seconds

override func update(_ currentTime: TimeInterval) {
    let dt = /* clamped delta time */
    dayTime += Float(dt / dayDuration)
    if dayTime > 1 { dayTime -= 1 }

    let (lightColor, ambientColor, intensity) = DayNightCycle.colors(for: dayTime)

    // Update SKLightNode
    sunLight.lightColor = lightColor
    sunLight.ambientColor = ambientColor
    sunLight.falloff = 1.0 / CGFloat(intensity)

    // Update sky gradient background
    skyGradientNode.color = ambientColor
}
```

Combine with weather particles (rain at 0.6–0.8, fog at night) for atmospheric variation. Use `dayTime` to control enemy spawn rates, NPC behavior, or music stems.

---

## Related Skills

- **spritekit-reference.md** — Core SpriteKit nodes and actions
- **game-2d.md** — Physics contact events that trigger particle effects
- **game-core.md** — GameManager, entity protocols
