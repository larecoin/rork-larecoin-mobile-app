---
index: true
description: Session configs, plane detection, raycasting, scene reconstruction
---

# ARKit — The Sensing Layer

ARKit understands the real world through the device camera and sensors. It does NOT render anything — pair it with RealityKit for visuals.

---

## Session Configurations (pick one per session)

| Configuration                       | What It Does                                                                 | Hardware Required                  |
| ----------------------------------- | ---------------------------------------------------------------------------- | ---------------------------------- |
| `ARWorldTrackingConfiguration`      | 6DOF tracking, plane detection, image/object detection, scene reconstruction | Any ARKit device (A9+)             |
| `ARFaceTrackingConfiguration`       | Front camera face tracking, 50+ blend shapes                                 | TrueDepth camera (iPhone X+)       |
| `ARBodyTrackingConfiguration`       | Full body pose estimation via rear camera                                    | A12+ chip                          |
| `ARGeoTrackingConfiguration`        | GPS + AR for location-anchored content                                       | iPhone with GPS + supported cities |
| `ARPositionalTrackingConfiguration` | Position-only (no scene understanding)                                       | A12+                               |

## Plane Detection

```swift
let config = ARWorldTrackingConfiguration()
config.planeDetection = [.horizontal, .vertical]
arView.session.run(config)
```

- Detects **horizontal** surfaces (floors, tables, countertops)
- Detects **vertical** surfaces (walls)
- **Slanted** surfaces are visionOS-only via `PlaneDetectionProvider` (NOT available on iOS `ARWorldTrackingConfiguration`)
- Returns `ARPlaneAnchor` with extent, center, alignment, geometry, classification
- Plane classifications: `.wall`, `.floor`, `.ceiling`, `.table`, `.seat`, `.door`, `.window`, `.none`
- Works on ALL ARKit devices (A9+), no LiDAR required (but LiDAR makes it instant)

**Practical for code generation:** YES — fundamental building block. Place objects on tables, floors, walls.

## Ray Casting (Hit Testing)

```swift
if let query = arView.raycastQuery(from: tapLocation, allowing: .existingPlaneGeometry, alignment: .horizontal) {
    let results = arView.session.raycast(query)
    if let result = results.first {
        // result.worldTransform gives 3D position
    }
}
```

- Converts 2D screen tap → 3D world position
- `.allowing` parameter: `.existingPlaneGeometry`, `.estimatedPlane`, `.existingPlaneInfinite`
- `.alignment`: `.horizontal`, `.vertical`, `.any`
- **Tracked ray casts** continue refining position over time
- Legacy `hitTest(_:types:)` is deprecated

**Practical for code generation:** YES — essential for any "tap to place" interaction.

## Scene Reconstruction (LiDAR Mesh)

```swift
config.sceneReconstruction = .meshWithClassification
```

- Creates a **triangle mesh** of the entire physical environment in real-time
- Generates `ARMeshAnchor` objects, each containing a portion of the mesh
- **Mesh classifications:** `floor`, `wall`, `ceiling`, `table`, `seat`, `door`, `window`, `none`
- Enables:
  - **Object occlusion** — virtual objects hidden behind real ones
  - **Physics interactions** — virtual ball bouncing off real wall
  - **Precise raycasting** against actual geometry (not just planes)

**Requires:** LiDAR-equipped device (iPhone 12 Pro+, iPad Pro 2020+)

## Depth API (Per-Pixel Depth)

```swift
let config = ARWorldTrackingConfiguration()
if ARWorldTrackingConfiguration.supportsFrameSemantics(.sceneDepth) {
    config.frameSemantics.insert(.sceneDepth)
    // Or use .smoothedSceneDepth for temporally filtered depth
    config.frameSemantics.insert(.smoothedSceneDepth)
}
arView.session.run(config)
```

Access depth data from each frame:

```swift
func session(_ session: ARSession, didUpdate frame: ARFrame) {
    guard let depthData = frame.sceneDepth else { return }
    let depthMap = depthData.depthMap  // CVPixelBuffer — Float32 per pixel, in meters
    let confidenceMap = depthData.confidenceMap  // CVPixelBuffer — ARConfidenceLevel per pixel

    let width = CVPixelBufferGetWidth(depthMap)
    let height = CVPixelBufferGetHeight(depthMap)

    CVPixelBufferLockBaseAddress(depthMap, .readOnly)
    let baseAddress = CVPixelBufferGetBaseAddress(depthMap)!
    let buffer = baseAddress.assumingMemoryBound(to: Float32.self)
    let centerDepth = buffer[height / 2 * width + width / 2]  // depth at center pixel in meters
    CVPixelBufferUnlockBaseAddress(depthMap, .readOnly)
}
```

- `sceneDepth` — raw LiDAR depth, updates with each frame
- `smoothedSceneDepth` — temporally filtered, less noisy
- Depth map resolution is lower than camera image (e.g. 256×192)
- Each pixel value = distance in meters to real-world geometry
- `confidenceMap` provides `.low`, `.medium`, `.high` per pixel

**Requires:** LiDAR device. Always check `supportsFrameSemantics` before enabling.

## People Occlusion

```swift
let config = ARWorldTrackingConfiguration()
if ARWorldTrackingConfiguration.supportsFrameSemantics(.personSegmentationWithDepth) {
    config.frameSemantics.insert(.personSegmentationWithDepth)
}
```

- A person walks in front of a virtual object → the person correctly blocks it
- `.personSegmentation` — mask only (no depth)
- `.personSegmentationWithDepth` — mask + depth for correct occlusion ordering

**Requires:** A12+ chip

## Face Tracking

```swift
let config = ARFaceTrackingConfiguration()
config.isLightEstimationEnabled = true
arView.session.run(config)
```

- Detects face position, orientation (6DOF)
- **52 blend shape coefficients** — tracks individual muscle movements:
  - Eyes: `eyeBlinkLeft/Right`, `eyeLookUp/Down/In/Out`, `eyeWideLeft/Right`, `eyeSquintLeft/Right`
  - Mouth: `mouthSmileLeft/Right`, `mouthClose`, `mouthFunnel`, `mouthPucker`, `jawOpen`, `tongueOut`
  - Brows: `browDownLeft/Right`, `browInnerUp`, `browOuterUpLeft/Right`
  - Cheeks, nose, jaw movements
- **Face mesh geometry** — 1220 vertices triangle mesh conforming to face shape
- **Light estimation** — uses face as light probe, provides directional light + spherical harmonics
- Supports up to 3 simultaneous faces (ARKit 4+, A12+)

**Requires:** TrueDepth camera (iPhone X and later)

**Practical for code generation:** YES — great for selfie filters, face effects, avatar animation.

### Blend Shape Reader Example

```swift
class FaceTrackingCoordinator: NSObject, ARSessionDelegate {
    func session(_ session: ARSession, didUpdate anchors: [ARAnchor]) {
        for anchor in anchors {
            guard let faceAnchor = anchor as? ARFaceAnchor else { continue }

            let blendShapes = faceAnchor.blendShapes
            let smileLeft = blendShapes[.mouthSmileLeft]?.floatValue ?? 0
            let smileRight = blendShapes[.mouthSmileRight]?.floatValue ?? 0
            let isSmiling = (smileLeft + smileRight) / 2 > 0.5

            let eyeBlinkLeft = blendShapes[.eyeBlinkLeft]?.floatValue ?? 0
            let eyeBlinkRight = blendShapes[.eyeBlinkRight]?.floatValue ?? 0
            let isWinking = eyeBlinkLeft > 0.8 && eyeBlinkRight < 0.3

            let jawOpen = blendShapes[.jawOpen]?.floatValue ?? 0
            let isMouthOpen = jawOpen > 0.5
        }
    }
}
```

## Image Detection & Tracking

```swift
config.detectionImages = referenceImages  // Set<ARReferenceImage>
config.maximumNumberOfTrackedImages = 4
```

- **Image Detection:** Recognizes pre-registered 2D images (posters, cards, product packaging)
- **Image Tracking:** Continuously tracks moving images in real-time
- Can detect up to **100 images** simultaneously (ARKit 6)
- Provides position, orientation, physical size estimation
- Use cases: AR business cards, museum guides, product recognition

**Practical for code generation:** YES — works on all ARKit devices. No LiDAR needed. Requires reference images in asset catalog.

## Object Detection

```swift
config.detectionObjects = referenceObjects  // Set<ARReferenceObject>
```

- Recognizes pre-scanned 3D objects in the environment
- Objects must be pre-scanned using Apple's scanning app to create `ARReferenceObject`
- Returns position and orientation of recognized object

**Practical for code generation:** LIMITED — requires pre-scanned reference objects which can't be generated at build time.

## Body Tracking (Motion Capture)

```swift
let config = ARBodyTrackingConfiguration()
// Returns ARBodyAnchor with skeleton:
// - 91 joints (hip as root)
// - 3D joint positions relative to hip
// - Includes hands, feet, spine, head, ears (ARKit 6+)
```

- Full 2D and 3D body pose estimation via rear camera
- Skeleton with **91 joints** including fingers, spine segments
- Hip joint is the root — other joints defined relative to it
- Can drive a rigged 3D character in real-time
- **Person segmentation**: separates person from background (`.personSegmentation`, `.personSegmentationWithDepth`)
- **People occlusion**: virtual objects correctly pass behind/in front of people

**Requires:** A12+ chip

## Light Estimation

```swift
config.isLightEstimationEnabled = true  // default: true
// Access via: frame.lightEstimate
// - ambientIntensity: lumens
// - ambientColorTemperature: Kelvin
```

- Estimates ambient light intensity and color temperature
- RealityKit uses this automatically for environment-based lighting
- Face tracking provides even richer directional light data

**Practical for code generation:** YES — automatic in RealityKit. Improves realism with zero effort.

## World Map Persistence

```swift
// Save
arView.session.getCurrentWorldMap { worldMap, error in
    guard let map = worldMap else { return }
    let data = try NSKeyedArchiver.archivedData(withRootObject: map, requiringSecureCoding: true)
    try data.write(to: savedMapURL)
}

// Restore
let data = try Data(contentsOf: savedMapURL)
let worldMap = try NSKeyedUnarchiver.unarchivedObject(ofClass: ARWorldMap.self, from: data)
let config = ARWorldTrackingConfiguration()
config.initialWorldMap = worldMap
arView.session.run(config)
```

- Save and restore AR sessions (persistent AR)
- Place content that stays in the same physical spot across app launches

**Practical for code generation:** ADVANCED — useful for persistent experiences but adds complexity.

## Collaborative AR (Multiuser)

Multiple devices see the same AR content aligned to the same physical space.

```swift
// Enable collaboration on world tracking
let config = ARWorldTrackingConfiguration()
config.isCollaborationEnabled = true
arView.session.run(config)
```

ARKit periodically outputs `CollaborationData` you must send to peers. Networking is on you (typically MultipeerConnectivity).

```swift
// Send — in ARSessionDelegate
func session(_ session: ARSession, didOutputCollaborationData data: ARSession.CollaborationData) {
    // Serialize and send to all peers
    guard let encoded = try? NSKeyedArchiver.archivedData(
        withRootObject: data, requiringSecureCoding: true
    ) else { return }
    try? mcSession.send(encoded, toPeers: mcSession.connectedPeers,
                        with: data.priority == .critical ? .reliable : .unreliable)
}

// Receive — when data arrives from peer
func receivedData(_ data: Data) {
    guard let collaborationData = try? NSKeyedUnarchiver.unarchivedObject(
        ofClass: ARSession.CollaborationData.self, from: data
    ) else { return }
    arView.session.update(with: collaborationData)
}
```

Two priority levels:

- **Critical** — periodic, must be sent reliably (world mapping data)
- **Optional** — nearly every frame, can be sent unreliably (device pose)

**Practical for code generation:** ADVANCED — requires networking infrastructure (MultipeerConnectivity or custom server).

## Geo Tracking (Location Anchors)

Anchor content to real-world GPS coordinates.

```swift
// Check availability first
ARGeoTrackingConfiguration.checkAvailability { available, error in
    guard available else { return }

    let config = ARGeoTrackingConfiguration()
    arView.session.run(config)

    let coordinate = CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194)
    let geoAnchor = ARGeoAnchor(name: "My Pin", coordinate: coordinate)
    arView.session.add(anchor: geoAnchor)
}
```

- Anchors content to latitude/longitude/altitude
- Uses Apple Maps visual localization data for precision
- **Region-dependent** — only works in supported cities (check availability)
- Requires A12+ chip + GPS

**Practical for code generation:** LIMITED — region-dependent, complex setup, needs fallbacks.

## Coaching Overlay

```swift
let coachingOverlay = ARCoachingOverlayView()
coachingOverlay.session = arView.session
coachingOverlay.goal = .horizontalPlane  // .verticalPlane, .anyPlane, .tracking
coachingOverlay.activatesAutomatically = true
arView.addSubview(coachingOverlay)
```

- Built-in UI guidance for users during AR setup
- Shows animated instructions: "Move your device slowly", "Point at a surface"
- Automatically appears/disappears based on tracking quality

**Practical for code generation:** YES — highly recommended for all AR apps. Zero-effort UX.

## ARSession Delegate

```swift
class SessionDelegate: NSObject, ARSessionDelegate {
    func session(_ session: ARSession, didAdd anchors: [ARAnchor]) {
        for anchor in anchors {
            if let planeAnchor = anchor as? ARPlaneAnchor {
                // Handle detected plane
            }
            if let imageAnchor = anchor as? ARImageAnchor {
                // Handle detected image
            }
            if let faceAnchor = anchor as? ARFaceAnchor {
                // Handle face — access blendShapes, geometry
            }
        }
    }

    func session(_ session: ARSession, didUpdate anchors: [ARAnchor]) {
        // Anchors refined over time
    }

    func session(_ session: ARSession, didRemove anchors: [ARAnchor]) {
        // Clean up removed anchors
    }
}
```

## Permissions

Camera permission is required. Add to `project.pbxproj`:

```
INFOPLIST_KEY_NSCameraUsageDescription = "AR experiences need camera access";
```

For Location Anchors, also add:

```
INFOPLIST_KEY_NSLocationWhenInUseUsageDescription = "Place AR content at real-world locations";
```
