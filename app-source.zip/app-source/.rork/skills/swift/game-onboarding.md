---
index: true
description: "Tutorial building blocks: highlight overlay, contextual hints, typewriter text, arrow pointers, step-by-step tutorial, first-time detection"
---

# Game Onboarding — Tutorial Building Blocks

Reusable primitives for teaching game mechanics. Players tend to skip text and learn through interaction. These building blocks work with both SpriteKit and SwiftUI overlays.

---

## Highlight Overlay

Darken the entire screen except one element. Draws attention to a specific area (a button, an enemy, a power-up).

### SwiftUI (for menus, HUD elements)

```swift
struct HighlightOverlay: View {
    let targetFrame: CGRect // frame of the element to highlight
    let hint: String

    var body: some View {
        ZStack {
            // Darken everything
            Color.black.opacity(0.6)
                .ignoresSafeArea()
                // Cut out the highlight area
                .reverseMask {
                    RoundedRectangle(cornerRadius: 12)
                        .frame(width: targetFrame.width + 16, height: targetFrame.height + 16)
                        .position(x: targetFrame.midX, y: targetFrame.midY)
                }

            // Hint text below the cutout
            Text(hint)
                .font(.body.bold())
                .foregroundStyle(.white)
                .position(x: targetFrame.midX, y: targetFrame.maxY + 40)
        }
        .allowsHitTesting(false)
    }
}

// Helper for reverse masking
extension View {
    func reverseMask<Mask: View>(@ViewBuilder _ mask: () -> Mask) -> some View {
        self.mask(
            ZStack {
                Rectangle()
                mask().blendMode(.destinationOut)
            }
            .compositingGroup()
        )
    }
}
```

### SpriteKit (for in-game elements)

Use `SKCropNode` with an inverted mask — the mask defines what's VISIBLE, so fill the screen and cut a hole.

```swift
func showHighlight(around target: SKNode, in scene: SKScene) {
    let overlay = SKCropNode()
    overlay.zPosition = 1000
    overlay.name = "tutorialHighlight"

    // Dark background covering the whole scene
    let background = SKSpriteNode(color: UIColor(white: 0, alpha: 0.6), size: scene.size)
    background.position = CGPoint(x: scene.size.width / 2, y: scene.size.height / 2)
    overlay.addChild(background)

    // Mask: SKShapeNode with a hole cut out via even-odd fill rule
    let holeSize = CGSize(width: target.frame.width + 20, height: target.frame.height + 20)
    let path = CGMutablePath()
    path.addRect(CGRect(origin: .zero, size: scene.size)) // outer rect
    path.addRoundedRect(in: CGRect(
        x: target.position.x - holeSize.width / 2,
        y: target.position.y - holeSize.height / 2,
        width: holeSize.width, height: holeSize.height
    ), cornerWidth: 10, cornerHeight: 10) // inner cutout

    let maskShape = SKShapeNode(path: path, centered: false)
    maskShape.fillColor = .white
    maskShape.strokeColor = .clear
    // Even-odd fill: outer rect is filled, inner rounded rect is cut out
    overlay.maskNode = maskShape

    scene.addChild(overlay)
}

func removeHighlight(from scene: SKScene) {
    scene.childNode(withName: "tutorialHighlight")?.removeFromParent()
}
```

---

## Contextual Hint

Show a hint when the player seems stuck. Hints triggered by inactivity or repeated failure tend to feel more contextual than fixed timers.

```swift
@Observable
class HintManager {
    var currentHint: String?
    private var inactivityTimer: Task<Void, Never>?
    private var failureCount = 0

    /// Call on every player action to reset the inactivity timer
    func playerActed() {
        failureCount = 0
        dismissHint()
        resetInactivityTimer()
    }

    /// Call when the player fails an objective
    func playerFailed(hint: String, threshold: Int = 3) {
        failureCount += 1
        if failureCount >= threshold {
            showHint(hint)
        }
    }

    /// Start a timer — if no action within `seconds`, show hint
    func watchForInactivity(seconds: TimeInterval = 5, hint: String) {
        resetInactivityTimer()
        inactivityTimer = Task { @MainActor in
            try? await Task.sleep(for: .seconds(seconds))
            guard !Task.isCancelled else { return }
            showHint(hint)
        }
    }

    private func showHint(_ hint: String) {
        withAnimation(.smooth) { currentHint = hint }
    }

    func dismissHint() {
        inactivityTimer?.cancel()
        if currentHint != nil {
            withAnimation(.smooth) { currentHint = nil }
        }
    }
}
```

Display in SwiftUI:

```swift
// Overlay on game view
if let hint = hintManager.currentHint {
    Text(hint)
        .font(.callout.bold())
        .padding(.horizontal, 16)
        .padding(.vertical, 10)
        .background(.ultraThinMaterial, in: Capsule())
        .transition(.move(edge: .bottom).combined(with: .opacity))
        .onTapGesture { hintManager.dismissHint() }
}
```

---

## Typewriter Text

Text that appears character by character. Use for story moments, NPC dialogue, level introductions.

```swift
struct TypewriterText: View {
    let fullText: String
    let speed: TimeInterval // seconds per character
    @State private var visibleCount = 0
    @State private var timer: Task<Void, Never>?

    var body: some View {
        Text(fullText.prefix(visibleCount))
            .onAppear { startTyping() }
            .onDisappear { timer?.cancel() }
            .onTapGesture { revealAll() }
    }

    private func startTyping() {
        visibleCount = 0
        timer = Task { @MainActor in
            for i in 1...fullText.count {
                try? await Task.sleep(for: .seconds(speed))
                guard !Task.isCancelled else { return }
                visibleCount = i
            }
        }
    }

    private func revealAll() {
        timer?.cancel()
        visibleCount = fullText.count
    }
}

// Usage:
TypewriterText(fullText: "Tap the glowing orb to begin...", speed: 0.04)
    .font(.title3)
    .foregroundStyle(.white)
```

Tap to skip is important — players who've seen the text before don't want to wait.

---

## Arrow Pointer

Animated arrow pointing at a target. Use sparingly — only when the player needs to find something.

### SpriteKit

```swift
func showArrow(at position: CGPoint, in scene: SKScene) {
    let arrow = SKSpriteNode(imageNamed: "arrow_down") // or use an SF Symbol rendered to texture
    arrow.name = "tutorialArrow"
    arrow.position = CGPoint(x: position.x, y: position.y + 40)
    arrow.zPosition = 999

    // Bounce animation
    let bounce = SKAction.sequence([
        .moveBy(x: 0, y: -10, duration: 0.4),
        .moveBy(x: 0, y: 10, duration: 0.4)
    ])
    bounce.timingMode = .easeInEaseOut
    arrow.run(.repeatForever(bounce))

    scene.addChild(arrow)
}

func removeArrow(from scene: SKScene) {
    guard let arrow = scene.childNode(withName: "tutorialArrow") else { return }
    arrow.run(.sequence([.fadeOut(withDuration: 0.2), .removeFromParent()]))
}
```

### SwiftUI

```swift
struct BouncingArrow: View {
    @State private var offset: CGFloat = 0

    var body: some View {
        Image(systemName: "arrowtriangle.down.fill")
            .font(.title)
            .foregroundStyle(.yellow)
            .offset(y: offset)
            .onAppear {
                withAnimation(.easeInOut(duration: 0.5).repeatForever(autoreverses: true)) {
                    offset = 10
                }
            }
    }
}
```

---

## Step-by-Step Tutorial

For games with multiple mechanics, introduce one at a time. Each step blocks until the player completes the action.

```swift
@Observable
class TutorialManager {
    var currentStep: TutorialStep?
    var isComplete = false
    private var steps: [TutorialStep] = []
    private var stepIndex = 0

    func start(steps: [TutorialStep]) {
        self.steps = steps
        stepIndex = 0
        isComplete = false
        advanceToCurrentStep()
    }

    /// Call when the player completes the current step's required action
    func completeCurrentStep() {
        stepIndex += 1
        if stepIndex >= steps.count {
            currentStep = nil
            isComplete = true
        } else {
            advanceToCurrentStep()
        }
    }

    private func advanceToCurrentStep() {
        guard stepIndex < steps.count else { return }
        currentStep = steps[stepIndex]
    }
}

struct TutorialStep {
    let id: String
    let hint: String                   // text to display
    let highlightElement: String?      // name of element to highlight (optional)
    let requiredAction: String         // what the player must do (for game logic to check)
}
```

Usage in game logic:

```swift
// Define tutorial
let tutorial = [
    TutorialStep(id: "move", hint: "Drag to move", highlightElement: "joystick", requiredAction: "move"),
    TutorialStep(id: "jump", hint: "Tap to jump", highlightElement: "jumpButton", requiredAction: "jump"),
    TutorialStep(id: "collect", hint: "Grab the coin!", highlightElement: nil, requiredAction: "collectCoin"),
]
tutorialManager.start(steps: tutorial)

// In game event handlers:
if tutorialManager.currentStep?.requiredAction == "jump" && playerJumped {
    tutorialManager.completeCurrentStep()
}
```

---

## First-Time Detection

Only show tutorial on first play. Use `@AppStorage` for persistence.

```swift
struct GameView: View {
    @AppStorage("hasCompletedTutorial") private var hasCompletedTutorial = false
    @State private var tutorialManager = TutorialManager()

    var body: some View {
        ZStack {
            GameContentView(tutorialManager: tutorialManager)

            if !hasCompletedTutorial, let step = tutorialManager.currentStep {
                TutorialOverlay(step: step)
            }
        }
        .onAppear {
            if !hasCompletedTutorial {
                tutorialManager.start(steps: introTutorial)
            }
        }
        .onChange(of: tutorialManager.isComplete) { _, complete in
            if complete { hasCompletedTutorial = true }
        }
    }
}
```

---

## Observations

1. **Learn by doing** — Tutorials that let players practice mechanics tend to be more effective than text explanations.
2. **Shorter hints stick** — Concise hints are easier to absorb. Showing through interaction often works better than telling.
3. **Context-sensitive triggers** — Hints shown in response to struggle feel helpful. Hints on fixed timers can feel nagging.
4. **Skippable** — Returning players appreciate being able to dismiss or skip tutorials.
5. **Focused steps** — Introducing one mechanic per step reduces cognitive load. Multiple concepts at once can overwhelm.
6. **Celebrate progress** — Positive feedback (sound + haptic + visual) on completing a tutorial step reinforces learning.
