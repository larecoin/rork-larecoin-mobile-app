---
index: true
description: State sync, host architecture, latency handling
---

# Game Multiplayer Patterns — Networking, State Sync, Architecture

Real-time and turn-based multiplayer architecture, state synchronization, data encoding.

---

## Real-Time Match Setup

See `game-center-reference.md` for match setup (GKMatchRequest, GKMatchDelegate, GKMatchmakerViewController). This file focuses on what happens after the match is established — message protocols, state sync, and architecture.

## Game Message Protocol

```swift
nonisolated enum GameMessage: Codable {
    case playerMove(playerId: String, x: Float, y: Float, vx: Float, vy: Float)
    case playerAction(playerId: String, action: PlayerAction)
    case gameEvent(event: GameEvent)
    case stateSync(state: GameState)
    case ping(timestamp: TimeInterval)
    case pong(timestamp: TimeInterval)
}

nonisolated enum PlayerAction: String, Codable {
    case jump, attack, useItem, die, respawn
}

nonisolated enum GameEvent: Codable {
    case scoreChanged(playerId: String, score: Int)
    case objectSpawned(id: String, type: String, x: Float, y: Float)
    case objectDestroyed(id: String)
    case gameOver(winnerId: String?)
}

nonisolated struct GameState: Codable {
    var players: [PlayerState]
    var objects: [ObjectState]
    var score: [String: Int]
    var timeRemaining: TimeInterval
}

nonisolated struct PlayerState: Codable {
    var id: String
    var x, y: Float
    var vx, vy: Float
    var health: Int
    var isAlive: Bool
}

nonisolated struct ObjectState: Codable {
    var id: String
    var type: String
    var x, y: Float
}
```

## Sending and Receiving

```swift
extension MultiplayerManager {
    func send(_ message: GameMessage, reliable: Bool = true) throws {
        guard let match else { return }
        let data = try JSONEncoder().encode(message)
        try match.sendData(toAllPlayers: data, with: reliable ? .reliable : .unreliable)
    }

    func send(_ message: GameMessage, to player: GKPlayer, reliable: Bool = true) throws {
        guard let match else { return }
        let data = try JSONEncoder().encode(message)
        try match.send(data, to: [player], dataMode: reliable ? .reliable : .unreliable)
    }

    func decode(_ data: Data) -> GameMessage? {
        try? JSONDecoder().decode(GameMessage.self, from: data)
    }
}
```

### When to Use Reliable vs Unreliable

| Data Type              | Mode          | Why                                   |
| ---------------------- | ------------- | ------------------------------------- |
| Position updates       | `.unreliable` | High frequency, stale data is useless |
| Actions (jump, attack) | `.reliable`   | Must not be lost                      |
| Score changes          | `.reliable`   | Must be consistent                    |
| State sync             | `.reliable`   | Authoritative snapshot                |
| Ping/pong              | `.unreliable` | Latency measurement                   |

## State Sync Patterns

### Pattern 1: Full State Sync (Simple)

Host sends complete state at fixed interval. High bandwidth, but trivial to implement.

```swift
class HostGameLoop {
    var state = GameState(players: [], objects: [], score: [:], timeRemaining: 60)
    let multiplayer: MultiplayerManager
    var syncTimer: Timer?

    init(multiplayer: MultiplayerManager) {
        self.multiplayer = multiplayer
    }

    func startSyncing() {
        syncTimer = Timer.scheduledTimer(withTimeInterval: 1.0 / 20.0, repeats: true) { [weak self] _ in
            guard let self else { return }
            try? self.multiplayer.send(.stateSync(state: self.state), reliable: false)
        }
    }

    func processInput(from playerId: String, message: GameMessage) {
        switch message {
        case .playerMove(_, let x, let y, let vx, let vy):
            if let idx = state.players.firstIndex(where: { $0.id == playerId }) {
                state.players[idx].x = x
                state.players[idx].y = y
                state.players[idx].vx = vx
                state.players[idx].vy = vy
            }
        case .playerAction(_, let action):
            applyAction(playerId: playerId, action: action)
        default: break
        }
    }

    func applyAction(playerId: String, action: PlayerAction) {}
}
```

### Pattern 2: Delta Updates (Efficient)

Only send what changed since last sync.

```swift
nonisolated struct StateDelta: Codable {
    var updatedPlayers: [PlayerState]?
    var removedPlayerIds: [String]?
    var updatedObjects: [ObjectState]?
    var removedObjectIds: [String]?
    var scoreChanges: [String: Int]?
}

func computeDelta(old: GameState, new: GameState) -> StateDelta {
    var delta = StateDelta()

    let changedPlayers = new.players.filter { np in
        guard let op = old.players.first(where: { $0.id == np.id }) else { return true }
        return op.x != np.x || op.y != np.y || op.health != np.health
    }
    if !changedPlayers.isEmpty { delta.updatedPlayers = changedPlayers }

    let removed = old.players.filter { op in !new.players.contains(where: { $0.id == op.id }) }
    if !removed.isEmpty { delta.removedPlayerIds = removed.map(\.id) }

    return delta
}
```

### Pattern 3: Input Sync (Competitive)

Each client sends inputs. All clients simulate locally using the same inputs. Deterministic simulation required.

```swift
nonisolated struct FrameInput: Codable {
    let frame: UInt64
    let playerId: String
    let moveX: Float
    let moveY: Float
    let actions: [PlayerAction]
}

class DeterministicSimulation {
    var currentFrame: UInt64 = 0
    var inputBuffer: [UInt64: [FrameInput]] = [:]

    func addInput(_ input: FrameInput) {
        inputBuffer[input.frame, default: []].append(input)
    }

    func canAdvance(playerCount: Int) -> Bool {
        guard let inputs = inputBuffer[currentFrame + 1] else { return false }
        return inputs.count == playerCount
    }

    func advanceFrame(state: inout GameState) {
        currentFrame += 1
        guard let inputs = inputBuffer[currentFrame] else { return }
        for input in inputs.sorted(by: { $0.playerId < $1.playerId }) {
            applyInput(input, to: &state)
        }
        inputBuffer.removeValue(forKey: currentFrame - 60) // keep 1s history
    }

    func applyInput(_ input: FrameInput, to state: inout GameState) {
        guard let idx = state.players.firstIndex(where: { $0.id == input.playerId }) else { return }
        state.players[idx].x += input.moveX
        state.players[idx].y += input.moveY
    }
}
```

## Host-Based Architecture

```swift
class GameHost {
    let multiplayer: MultiplayerManager
    var state = GameState(players: [], objects: [], score: [:], timeRemaining: 0)
    let localPlayerId: String

    init(multiplayer: MultiplayerManager, localPlayerId: String) {
        self.multiplayer = multiplayer
        self.localPlayerId = localPlayerId
        multiplayer.onReceive = { [weak self] data, player in
            guard let msg = self?.multiplayer.decode(data) else { return }
            self?.processInput(from: player.gamePlayerID, message: msg)
        }
    }

    func processInput(from playerId: String, message: GameMessage) {
        switch message {
        case .playerMove(_, let x, let y, let vx, let vy):
            // Validate: reject teleporting, speed hacks
            if let idx = state.players.firstIndex(where: { $0.id == playerId }) {
                let maxSpeed: Float = 10
                let dx = x - state.players[idx].x
                let dy = y - state.players[idx].y
                guard sqrt(dx*dx + dy*dy) < maxSpeed else { return } // anti-cheat
                state.players[idx].x = x
                state.players[idx].y = y
                state.players[idx].vx = vx
                state.players[idx].vy = vy
            }
        case .playerAction(_, let action):
            handleAction(playerId: playerId, action: action)
        default: break
        }
    }

    func broadcastState() {
        try? multiplayer.send(.stateSync(state: state), reliable: false)
    }

    func handleAction(playerId: String, action: PlayerAction) {}
}
```

### Host Election

```swift
func electHost(players: [GKPlayer]) -> GKPlayer {
    // Deterministic: lowest gamePlayerID is host
    players.sorted(by: { $0.gamePlayerID < $1.gamePlayerID }).first!
}

var isHost: Bool {
    guard let match = multiplayer.match else { return false }
    let allPlayers = [GKLocalPlayer.local] + match.players
    return electHost(players: allPlayers).gamePlayerID == GKLocalPlayer.local.gamePlayerID
}
```

## Turn-Based Match

```swift
class TurnBasedGame: NSObject, GKLocalPlayerListener {
    var currentMatch: GKTurnBasedMatch?

    func createMatch() {
        let request = GKMatchRequest()
        request.minPlayers = 2
        request.maxPlayers = 4
        GKTurnBasedMatch.find(for: request) { [weak self] match, error in
            self?.currentMatch = match
        }
    }

    func player(_ player: GKPlayer, receivedTurnEventFor match: GKTurnBasedMatch, didBecomeActive: Bool) {
        currentMatch = match
        guard let data = match.matchData, !data.isEmpty else { return }
        if let state = try? JSONDecoder().decode(TurnState.self, from: data) {
            handleTurn(state: state, isMyTurn: didBecomeActive)
        }
    }

    func takeTurn(state: TurnState) async throws {
        guard let match = currentMatch else { return }
        let data = try JSONEncoder().encode(state)
        let nextParticipants = match.participants.filter { $0 != match.currentParticipant }
        try await match.endTurn(
            withNextParticipants: nextParticipants,
            turnTimeout: GKTurnTimeoutDefault,
            match: data
        )
    }

    func endGame(state: TurnState, winnerId: String?) async throws {
        guard let match = currentMatch else { return }
        let data = try JSONEncoder().encode(state)
        for participant in match.participants {
            participant.matchOutcome = participant.player?.gamePlayerID == winnerId ? .won : .lost
        }
        try await match.endMatchInTurn(withMatch: data)
    }

    func handleTurn(state: TurnState, isMyTurn: Bool) {}
}

nonisolated struct TurnState: Codable {
    var board: [[Int]]
    var currentPlayerIndex: Int
    var moveHistory: [Move]
    var scores: [String: Int]
}

nonisolated struct Move: Codable {
    let playerId: String
    let fromX, fromY, toX, toY: Int
}
```

## Latency Handling

### Interpolation

Smoothly move remote players between received positions instead of snapping.

```swift
struct RemotePlayerState {
    var currentPosition: CGPoint
    var targetPosition: CGPoint
    var velocity: CGVector
    var lastUpdateTime: TimeInterval

    mutating func update(dt: TimeInterval) {
        let lerpSpeed: CGFloat = 10.0
        let t = min(1.0, CGFloat(dt) * lerpSpeed)
        currentPosition.x += (targetPosition.x - currentPosition.x) * t
        currentPosition.y += (targetPosition.y - currentPosition.y) * t
    }

    mutating func receiveUpdate(x: Float, y: Float, vx: Float, vy: Float, time: TimeInterval) {
        targetPosition = CGPoint(x: CGFloat(x), y: CGFloat(y))
        velocity = CGVector(dx: CGFloat(vx), dy: CGFloat(vy))
        lastUpdateTime = time
    }
}
```

### Client-Side Prediction

Apply local inputs immediately, reconcile when server confirms.

```swift
struct PredictedState {
    var position: CGPoint
    var inputSequence: UInt64
}

class PredictingClient {
    var pendingInputs: [FrameInput] = []
    var localState: PlayerState

    init(localState: PlayerState) { self.localState = localState }

    func applyLocalInput(_ input: FrameInput) {
        localState.x += input.moveX
        localState.y += input.moveY
        pendingInputs.append(input)
    }

    func reconcile(serverState: PlayerState, lastProcessedFrame: UInt64) {
        localState = serverState
        pendingInputs.removeAll { $0.frame <= lastProcessedFrame }
        // Re-apply unacknowledged inputs
        for input in pendingInputs {
            localState.x += input.moveX
            localState.y += input.moveY
        }
    }
}
```

## Disconnect Handling

```swift
extension MultiplayerManager {
    func handlePlayerDisconnected(_ player: GKPlayer) {
        // Option 1: AI takeover
        replaceWithAI(playerId: player.gamePlayerID)

        // Option 2: Pause and wait for reconnect
        // Option 3: End game
    }

    func replaceWithAI(playerId: String) {
        // Mark player as AI-controlled in game state
        // AI logic runs on host
    }
}

// Reconnection with GKMatch isn't supported — for short sessions, just end the game.
// For longer sessions, use your own server with WebSocket reconnection.
```

## Compact Binary Encoding (Performance)

For high-frequency messages, JSON is wasteful. Use raw bytes.

```swift
struct CompactPosition {
    let playerId: UInt8
    let x: Float
    let y: Float
    let vx: Float16
    let vy: Float16

    func encode() -> Data {
        var data = Data(capacity: 13)
        data.append(playerId)
        withUnsafeBytes(of: x) { data.append(contentsOf: $0) }
        withUnsafeBytes(of: y) { data.append(contentsOf: $0) }
        withUnsafeBytes(of: vx) { data.append(contentsOf: $0) }
        withUnsafeBytes(of: vy) { data.append(contentsOf: $0) }
        return data
    }

    static func decode(_ data: Data) -> CompactPosition? {
        guard data.count >= 13 else { return nil }
        return data.withUnsafeBytes { buf in
            CompactPosition(
                playerId: buf.load(fromByteOffset: 0, as: UInt8.self),
                x: buf.loadUnaligned(fromByteOffset: 1, as: Float.self),
                y: buf.loadUnaligned(fromByteOffset: 5, as: Float.self),
                vx: buf.loadUnaligned(fromByteOffset: 9, as: Float16.self),
                vy: buf.loadUnaligned(fromByteOffset: 11, as: Float16.self)
            )
        }
    }
}
```

## Voice Chat with SharePlay (iOS 18+)

`GKVoiceChat` is deprecated. On iOS 18+, `GKMatchmakerViewController` automatically shows a SharePlay button — no custom code needed for most games.

For custom voice chat integration:

```swift
import GroupActivities

struct GameGroupActivity: GroupActivity {
    static let activityIdentifier = "com.example.game.play"
    var metadata: GroupActivityMetadata {
        var meta = GroupActivityMetadata()
        meta.title = "Play Together"
        meta.type = .generic
        return meta
    }
}
```

---

## Related Skills

- **game-center-reference.md** — Game Center matchmaking that creates GKMatch
- **game-core.md** — GameManager state machine for multiplayer game states
