---
index: true
description: Audio graph, playback, recording, effects, tone generation
---

# AVAudioEngine — The Audio Processing Graph

AVAudioEngine is Apple's high-level API for real-time audio processing. It manages a graph of audio nodes for recording, playback, mixing, effects, and synthesis. Use it when you need more control than AVAudioPlayer/AVAudioRecorder provide.

**Import:** `import AVFAudio` (or `import AVFoundation`)

---

## Core Architecture: Audio Node Graph

```
AVAudioEngine
├── inputNode      — microphone (read-only, always exists)
├── outputNode     — speaker (read-only, always exists)
├── mainMixerNode  — final mix point before output
└── [your nodes]   — player, mixer, effect, source nodes
```

Nodes connect via `engine.connect(nodeA, to: nodeB, format: format)`. Audio flows left-to-right through the graph.

## Setting Up the Engine

```swift
import AVFoundation

class AudioEngine {
    let engine = AVAudioEngine()

    func setup() throws {
        let audioSession = AVAudioSession.sharedInstance()
        try audioSession.setCategory(.playAndRecord, mode: .default, options: [.defaultToSpeaker])
        try audioSession.setActive(true)

        engine.prepare()
        try engine.start()
    }

    func stop() {
        engine.stop()
    }
}
```

## Playing Audio Files

```swift
let playerNode = AVAudioPlayerNode()
engine.attach(playerNode)
engine.connect(playerNode, to: engine.mainMixerNode, format: nil)

let audioFile = try AVAudioFile(forReading: fileURL)
playerNode.scheduleFile(audioFile, at: nil)

try engine.start()
playerNode.play()
```

### Scheduling Options

```swift
// Play entire file
playerNode.scheduleFile(audioFile, at: nil, completionHandler: nil)

// Play a segment (offset + frame count)
playerNode.scheduleSegment(audioFile, startingFrame: 0, frameCount: 44100, at: nil)

// Play a buffer (for looping / generated audio)
let buffer = AVAudioPCMBuffer(pcmFormat: audioFile.processingFormat, frameCapacity: AVAudioFrameCount(audioFile.length))!
try audioFile.read(into: buffer)
playerNode.scheduleBuffer(buffer, at: nil, options: .loops)

// Play at a specific time
let futureTime = AVAudioTime(sampleTime: AVAudioFramePosition(engine.outputNode.lastRenderTime!.sampleTime + 44100),
                              atRate: 44100)
playerNode.scheduleFile(audioFile, at: futureTime)
```

## Recording from Microphone

```swift
let inputNode = engine.inputNode
let inputFormat = inputNode.outputFormat(forBus: 0)

inputNode.installTap(onBus: 0, bufferSize: 1024, format: inputFormat) { buffer, time in
    // Process audio buffer in real-time
    // buffer.floatChannelData contains raw samples
}

try engine.start()

// To stop recording
inputNode.removeTap(onBus: 0)
```

### Writing to File

```swift
let outputFile = try AVAudioFile(forWriting: fileURL,
                                  settings: [
                                      AVFormatIDKey: Int(kAudioFormatMPEG4AAC),
                                      AVSampleRateKey: 44100,
                                      AVNumberOfChannelsKey: 1,
                                      AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue
                                  ])

inputNode.installTap(onBus: 0, bufferSize: 4096, format: inputFormat) { buffer, time in
    try? outputFile.write(from: buffer)
}
```

## Built-in Effect Nodes

| Node                    | What It Does                     | Key Properties                                             |
| ----------------------- | -------------------------------- | ---------------------------------------------------------- |
| `AVAudioUnitReverb`     | Room/hall reverb                 | `wetDryMix` (0-100), `loadFactoryPreset(.largeHall)`       |
| `AVAudioUnitDelay`      | Echo/delay effect                | `delayTime` (0-2s), `feedback` (-100 to 100%), `wetDryMix` |
| `AVAudioUnitDistortion` | Distortion/overdrive             | `wetDryMix`, `loadFactoryPreset(.drumsBitBrush)`           |
| `AVAudioUnitEQ`         | Parametric equalizer             | `bands[n].frequency`, `.gain`, `.bandwidth`, `.filterType` |
| `AVAudioUnitTimePitch`  | Pitch shift without speed change | `pitch` (cents, ±2400), `rate` (0.03125-32x)               |
| `AVAudioUnitVarispeed`  | Speed change (affects pitch)     | `rate` (0.25-4x)                                           |

### Chaining Effects

```swift
let reverb = AVAudioUnitReverb()
reverb.loadFactoryPreset(.largeHall)
reverb.wetDryMix = 40

let delay = AVAudioUnitDelay()
delay.delayTime = 0.3
delay.feedback = 50
delay.wetDryMix = 30

let eq = AVAudioUnitEQ(numberOfBands: 2)
eq.bands[0].filterType = .lowPass
eq.bands[0].frequency = 8000
eq.bands[1].filterType = .highPass
eq.bands[1].frequency = 200

engine.attach(playerNode)
engine.attach(reverb)
engine.attach(delay)
engine.attach(eq)

// Chain: player → EQ → delay → reverb → output
engine.connect(playerNode, to: eq, format: nil)
engine.connect(eq, to: delay, format: nil)
engine.connect(delay, to: reverb, format: nil)
engine.connect(reverb, to: engine.mainMixerNode, format: nil)
```

### Reverb Factory Presets

`.smallRoom`, `.mediumRoom`, `.largeRoom`, `.mediumHall`, `.largeHall`, `.plate`, `.mediumChamber`, `.largeChamber`, `.cathedral`, `.largeRoom2`, `.mediumHall2`, `.mediumHall3`, `.largeHall2`

### Distortion Factory Presets

`.drumsBitBrush`, `.drumsBufferBeats`, `.drumsLoFi`, `.multiBrokenSpeaker`, `.multiCellphoneConcert`, `.multiDecimated1` thru `4`, `.multiDistortedFunk`, `.multiDistortedCubed`, `.multiDistortedSquared`, `.multiEcho1` thru `2`, `.multiEchoTight1` thru `2`, `.multiEverythingIsBroken`, `.multiSpeechAlienChatter`, `.multiSpeechCosmicInterference`, `.multiSpeechGoldenPi`, `.multiSpeechRadioTower`, `.multiSpeechWaves`, `.speechAlienChatter`, `.speechCosmicInterference`, `.speechGoldenPi`, `.speechRadioTower`, `.speechWaves`

## Mixing Multiple Audio Sources

```swift
let mixer = AVAudioMixerNode()
engine.attach(mixer)

let player1 = AVAudioPlayerNode()
let player2 = AVAudioPlayerNode()
engine.attach(player1)
engine.attach(player2)

engine.connect(player1, to: mixer, format: nil)
engine.connect(player2, to: mixer, format: nil)
engine.connect(mixer, to: engine.mainMixerNode, format: nil)

// Per-player volume control
player1.volume = 0.8
player2.volume = 0.5

// Per-player pan (-1 left, 0 center, 1 right)
player1.pan = -0.5
player2.pan = 0.5
```

## Generating Audio Programmatically (AVAudioSourceNode)

```swift
let sampleRate: Double = 44100
var phase: Double = 0
let frequency: Double = 440 // A4

let sourceNode = AVAudioSourceNode { _, _, frameCount, audioBufferList in
    let bufferList = UnsafeMutableAudioBufferListPointer(audioBufferList)
    let phaseIncrement = 2.0 * .pi * frequency / sampleRate

    for frame in 0..<Int(frameCount) {
        let sample = Float(sin(phase))
        phase += phaseIncrement
        if phase >= 2.0 * .pi { phase -= 2.0 * .pi }

        for buffer in bufferList {
            let buf = UnsafeMutableBufferPointer<Float>(buffer)
            buf[frame] = sample
        }
    }
    return noErr
}

engine.attach(sourceNode)
engine.connect(sourceNode, to: engine.mainMixerNode, format: nil)
```

**Critical:** Inside the render callback, do NOT allocate memory, perform file I/O, take locks, or interact with Swift/ObjC runtimes. Pre-compute everything you can outside the callback.

## Tapping Audio for Analysis

```swift
let format = engine.mainMixerNode.outputFormat(forBus: 0)
engine.mainMixerNode.installTap(onBus: 0, bufferSize: 1024, format: format) { buffer, time in
    guard let channelData = buffer.floatChannelData else { return }
    let frames = Int(buffer.frameLength)

    // RMS level
    var sum: Float = 0
    for i in 0..<frames {
        sum += channelData[0][i] * channelData[0][i]
    }
    let rms = sqrt(sum / Float(frames))
    let db = 20 * log10(rms)
}
```

## Audio Session Categories

| Category         | Behavior                                               |
| ---------------- | ------------------------------------------------------ |
| `.playback`      | Audio plays even in silent mode, interrupts other apps |
| `.record`        | Recording only, silences other audio                   |
| `.playAndRecord` | Simultaneous play and record (voice chat, music apps)  |
| `.ambient`       | Mixes with other apps, silenced by ring switch         |
| `.soloAmbient`   | Default. Silences other apps, silenced by ring switch  |
| `.multiRoute`    | Route audio to multiple outputs simultaneously         |

### Common Options

```swift
try session.setCategory(.playAndRecord, mode: .default, options: [
    .defaultToSpeaker,       // route playback to speaker (not earpiece)
    .allowBluetooth,         // enable Bluetooth headsets
    .allowBluetoothA2DP,     // enable high-quality Bluetooth audio
    .mixWithOthers,          // don't interrupt other apps
])
```

### Audio Session Modes

| Mode              | Use Case                                    |
| ----------------- | ------------------------------------------- |
| `.default`        | General audio                               |
| `.measurement`    | Minimal signal processing for analysis apps |
| `.gameChat`       | Voice chat in games                         |
| `.voiceChat`      | VoIP/voice communication                    |
| `.videoRecording` | Video recording with audio                  |
| `.moviePlayback`  | Movie/video playback                        |
| `.spokenAudio`    | Podcasts, audiobooks (ducks other audio)    |

## Handling Interruptions

```swift
NotificationCenter.default.addObserver(
    forName: AVAudioSession.interruptionNotification,
    object: nil, queue: .main
) { notification in
    guard let info = notification.userInfo,
          let typeValue = info[AVAudioSessionInterruptionTypeKey] as? UInt,
          let type = AVAudioSession.InterruptionType(rawValue: typeValue) else { return }

    switch type {
    case .began:
        // Pause playback
        break
    case .ended:
        guard let optionsValue = info[AVAudioSessionInterruptionOptionKey] as? UInt else { return }
        let options = AVAudioSession.InterruptionOptions(rawValue: optionsValue)
        if options.contains(.shouldResume) {
            try? AVAudioSession.sharedInstance().setActive(true)
            // Resume playback
        }
    @unknown default: break
    }
}
```

## Route Change Handling

```swift
NotificationCenter.default.addObserver(
    forName: AVAudioSession.routeChangeNotification,
    object: nil, queue: .main
) { notification in
    guard let info = notification.userInfo,
          let reasonValue = info[AVAudioSessionRouteChangeReasonKey] as? UInt,
          let reason = AVAudioSession.RouteChangeReason(rawValue: reasonValue) else { return }

    if reason == .oldDeviceUnavailable {
        // Headphones unplugged — pause playback (Apple HIG)
    }
}
```

## Permissions

Microphone access required for recording. Add to `project.pbxproj`:

```
INFOPLIST_KEY_NSMicrophoneUsageDescription = "Record audio for your music";
```
