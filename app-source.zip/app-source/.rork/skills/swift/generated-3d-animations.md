# Wiring Generated Meshy Animations into Swift

This is the reference for wiring `*-anim-*.usdz` files that the agent has already bundled into the Swift app's `Resources/`. The animation tools (`generate3DHumanoid` / `append3DAnimations` + `waitTask`) print the exact `resourceName` strings to use. Copy those strings verbatim; never re-derive them from display names.

## Where the Resource Names Come From

The `generate3DHumanoid` / `append3DAnimations` waitTask result lists "Animation resources bundled into Resources/" — each entry has `resourceName`, `fileName`, and `displayName`. `listExistingAssets` with `types: ["3d-model"]` re-lists animations for models that were generated earlier.

Resource names look like `persian_prince_adventurer-anim-casual-walk` (lowercase, hyphens, `-anim-` separator). Do not convert to camelCase, snake_case, or strip suffixes.

## The Animation Player Pattern (write it yourself)

**CRITICAL contract for generated Meshy USDZs:** every accepted animation is a separate FULL animated model entity. Do not extract the `AnimationResource` and try to play it on the base model — that can silently no-op. Play the clip only on the entity that owns it, hide the base visual while a clip is active, and restore the base visual when no clip is requested.

Write one small player type in app code (adapt as needed) and create one instance per generated model container. App code owns the gameplay enum and the mapping from state to exact resource names; the player owns the fragile mechanics: hiding/restoring the base visual, stopping stale loops, and restoring the latest requested loop after one-shot animations.

```swift
import RealityKit

/// Swaps generated Meshy animation entities under a model container.
/// Assumes the placement contract from .rork/skills/swift/game-asset-integration.md:
/// container → runtime child ("generated_model_runtime") → normalized base visual.
@MainActor
final class GeneratedModelAnimationPlayer {
    private let container: Entity
    private var templates: [String: Entity] = [:]
    private var activeAnimation: Entity?
    private var baseVisual: Entity?
    private var currentLoop: String?
    private var oneShotRestoreTask: Task<Void, Never>?

    init(container: Entity) {
        self.container = container
    }

    private var runtime: Entity {
        container.findEntity(named: "generated_model_runtime") ?? container
    }

    func preload(_ resourceNames: [String]) async {
        if baseVisual == nil { baseVisual = runtime.children.first }
        for name in resourceNames where templates[name] == nil {
            templates[name] = try? await Entity(named: name)
        }
    }

    /// Passing nil stops generated playback and restores the base visual — use
    /// it for states without a bundled clip so stale walk/run loops never stick.
    func setLoop(_ resourceName: String?) {
        currentLoop = resourceName
        oneShotRestoreTask?.cancel()
        play(resourceName, looping: true)
    }

    func playOnce(_ resourceName: String?, restoreAfter duration: Duration = .milliseconds(650)) {
        guard let resourceName else { return }
        play(resourceName, looping: false)
        oneShotRestoreTask?.cancel()
        oneShotRestoreTask = Task { [weak self] in
            try? await Task.sleep(for: duration)
            guard let self, !Task.isCancelled else { return }
            self.play(self.currentLoop, looping: true)
        }
    }

    func stop() {
        currentLoop = nil
        oneShotRestoreTask?.cancel()
        play(nil, looping: false)
    }

    private func play(_ resourceName: String?, looping: Bool) {
        activeAnimation?.removeFromParent()
        activeAnimation = nil
        baseVisual?.isEnabled = true
        guard let resourceName, let template = templates[resourceName] else { return }

        let animated = template.clone(recursive: true)
        // Copy the base visual's normalization (scale / orientation / centering)
        // so the animated entity replaces it in exactly the same pose.
        if let base = baseVisual {
            animated.transform = base.transform
            base.isEnabled = false
        }
        runtime.addChild(animated)
        if let animation = animated.availableAnimations.first {
            animated.playAnimation(looping ? animation.repeat() : animation, transitionDuration: 0.2)
        }
        activeAnimation = animated
    }
}
```

Pitfalls the pattern exists to prevent: a helper that extracts `AnimationResource` and calls `playAnimation(...)` on the base model silently fails for generated Meshy outputs; a helper that plays one clip on every descendant overwrites placement transforms and can flip the character; loading every animation as a separate always-attached entity and toggling `isEnabled` per frame is expensive and causes pops.

## Pattern A: Single Ambient Loop

Use this when one model has one ambient animation and no state machine.

```swift
import Observation
import RealityKit
import SwiftUI

@MainActor
@Observable
final class HeroScene {
    private(set) var heroContainer: Entity?
    private var animationPlayer: GeneratedModelAnimationPlayer?

    func makeHero(in content: any RealityViewContentProtocol) async {
        // Build the container per the placement recipe in game-asset-integration.md.
        let hero = await makeHeroContainer()
        content.add(hero)
        heroContainer = hero

        let player = GeneratedModelAnimationPlayer(container: hero)
        await player.preload([
            "persian_prince_adventurer-anim-casual-walk"
        ])
        player.setLoop("persian_prince_adventurer-anim-casual-walk")
        animationPlayer = player
    }
}

struct HeroView: View {
    @State private var scene = HeroScene()

    var body: some View {
        RealityView { content in
            await scene.makeHero(in: content)
        }
    }
}
```

Notes on the `RealityView` parameter type:

- iOS uses `inout RealityViewCameraContent` or generic `<C: RealityViewContentProtocol>`. There is no type called `RealityViewContent` on iOS (only visionOS).
- The example above takes `any RealityViewContentProtocol` so it works on iOS and visionOS unchanged.

## Pattern B: Gameplay State Machine

Use this when a humanoid switches among idle / walk / run / attack / jump based on velocity, input, or AI state. The holder maps your enum to exact resource-name strings; the player handles playback mechanics.

```swift
import Foundation
import Observation
import RealityKit
import simd

enum HeroMoveState {
    case idle, walk, run, jump, fall
}

@MainActor
@Observable
final class HeroAnimator {
    private let player: GeneratedModelAnimationPlayer
    private let loopResources: [HeroMoveState: String]
    private let attackResourceName: String?
    private var currentLoopState: HeroMoveState?

    init(
        container: Entity,
        loopResources: [HeroMoveState: String],
        attackResourceName: String? = nil
    ) {
        player = GeneratedModelAnimationPlayer(container: container)
        self.loopResources = loopResources
        self.attackResourceName = attackResourceName
    }

    func preload() async {
        let resourceNames = Array(loopResources.values) + [attackResourceName].compactMap { $0 }
        await player.preload(resourceNames)
        setLoop(.idle)
    }

    func setLoop(_ state: HeroMoveState) {
        guard state != currentLoopState else { return }
        currentLoopState = state
        player.setLoop(loopResources[state])
    }

    func updateFromJoystick(_ joystick: SIMD2<Float>, isGrounded: Bool, verticalVelocity: Float) {
        if !isGrounded {
            setLoop(verticalVelocity > 0 ? .jump : .fall)
            return
        }

        let intensity = simd_length(joystick)
        if intensity > 0.75, loopResources[.run] != nil {
            setLoop(.run)
        } else if intensity > 0.08 {
            setLoop(.walk)
        } else {
            setLoop(.idle)
        }
    }

    func playAttack() {
        player.playOnce(attackResourceName, restoreAfter: .milliseconds(650))
    }

    func stop() {
        currentLoopState = nil
        player.stop()
    }
}
```

Construction at scene setup:

```swift
let heroAnimator = HeroAnimator(
    container: heroContainer,
    loopResources: [
        // Include only keys whose resourceName appeared in the waitTask output.
        // If idle was not generated, setLoop(.idle) will call player.setLoop(nil)
        // and the base visual will be restored instead of leaving walk/run stuck.
        .walk: "persian_prince_adventurer-anim-casual-walk",
        .run: "persian_prince_adventurer-anim-run-fast",
    ],
    attackResourceName: nil
)
await heroAnimator.preload()
```

Driving from a RealityKit system:

```swift
nonisolated struct HeroAnimationSystem: System {
    static let query = EntityQuery(where: .has(PlayerComponent.self))
    init(scene: Scene) {}

    func update(context: SceneUpdateContext) {
        for entity in context.entities(matching: Self.query, updatingSystemWhen: .rendering) {
            Task { @MainActor in
                guard let animator = entity.components[HeroAnimatorComponent.self]?.animator else { return }
                let velocity = entity.components[PhysicsMotionComponent.self]?.linearVelocity ?? .zero
                let speed = simd_length(SIMD2<Float>(velocity.x, velocity.z))
                animator.setLoop(speed > 3.0 ? .run : speed > 0.5 ? .walk : .idle)
            }
        }
    }
}

struct HeroAnimatorComponent: Component {
    let animator: HeroAnimator
}
```

## Adding an Animation to an Existing Game

When an animation waitTask reports a manual animation integration request, the new USDZ file is only the asset. Patch the gameplay code before replying that the move works.

Use the requested behavior to update all relevant app layers:

- Input: add or reuse the gesture/control, such as swipe down for slide or a button for attack.
- State: add the enum case, component field, and timer/window for one-shot moves.
- Animation: preload the exact `resourceName`, then call `playOnce(...)` for one-shot moves or `setLoop(...)` for persistent states.
- Mechanics: update hitbox, collision, movement, scoring, or obstacle logic when the new behavior changes gameplay.

For example, a slide in an endless runner should not only add `"runner-anim-slide"`. It should also detect the slide gesture, set an `isSliding` or `slideTimer` state for the intended duration, trigger `player.playOnce("runner-anim-slide", restoreAfter: ...)`, and adjust collision only while the slide window is active.

## Camera and Facing

Choose the camera/control pattern from the requested genre before wiring joystick math; do not add right-side camera drag, crosshair aim, or two-thumb shooter controls unless the user request or genre calls for them.

- SwiftUI `DragGesture.translation` has Y positive **downward** — negate the Y component when building joystick state so joystick Y is positive for visual up/forward. Never store `translation.height` directly as joystick Y, and never pass raw drag signs as a movement vector.
- Convert the joystick vector into a **world XZ direction** appropriate to the camera pattern: for fixed-world or runner cameras screen-up always maps to the same world direction; for free-orbit third-person rotate the joystick vector by the stored camera yaw; for lock-behind chase cameras derive movement from the game's chase/vehicle/character rules.
- Use the SAME world direction for movement and for facing. Rotate the model container's yaw to face that direction with `simd_quatf(angle: atan2(direction.x, direction.z), axis: [0, 1, 0])`-style math — keep this gameplay yaw on the **container**, never on the normalized visual (its one-time orientation correction must not be overwritten). When the entity has `CharacterControllerComponent`, rotate a dedicated facing node (the runtime child) instead of the physics root, so left/right/back input turns the visible humanoid instead of sliding the run animation sideways.
- Third-person humanoids usually turn to face left/right/back input rather than strafe sideways; only wire strafe/aim controls when the user explicitly asks.
- From `System.update`, wrap synchronous entity mutations in `MainActor.assumeIsolated { ... }`; use `Task { @MainActor in ... }` only for async holder calls where a one-frame delay is acceptable.
- Do not derive the camera direction with `entity.orientation.act(SIMD3<Float>(0, 0, 1))`; that ignores the model's corrected rest-forward axis and puts the camera in front of some generated characters.

## Checklist

- Every `resourceName` string in Swift source appears verbatim in an animation waitTask or `listExistingAssets` output.
- One animation player instance per generated model container that requires Meshy animations.
- For states without listed animation resources, call `player.setLoop(nil)` through your state mapper.
- For manual animation additions, do not stop at bundling the USDZ. Patch the requested input/state/gameplay behavior and only then report completion.
- For joystick-driven humanoids, use strong joystick intensity for run if a run resource exists; do not require a separate run button unless requested.
- From `System.update`, wrap synchronous generated-model entity mutations in `MainActor.assumeIsolated { ... }`.
- `RealityView` content parameter is `inout RealityViewCameraContent` or `<C: RealityViewContentProtocol>` / `any RealityViewContentProtocol`; never use the visionOS-only `RealityViewContent`.
