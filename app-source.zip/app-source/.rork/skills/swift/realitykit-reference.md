---
index: true
description: ECS architecture, RealityView, materials, physics, animations, USDZ; advanced animation (IK, blend shapes)
---

# RealityKit — The Rendering Layer

RealityKit is Apple's high-level 3D engine using an Entity-Component-System (ECS) architecture. Handles rendering, physics, audio, and animations. SceneKit is officially soft-deprecated as of WWDC25 (critical-bug-only fixes, no new features) — use RealityKit for all new projects.

---

## Core Architecture: Entity-Component System (ECS)

```
Entity (container)
├── TransformComponent  — position, rotation, scale in 3D space
├── ModelComponent     — mesh + materials = visible object
├── CollisionComponent — physics collision shape
├── PhysicsBodyComponent — mass, forces, physics simulation
└── Custom components   — your own behaviors
```

**Key entity types:**

- `Entity` — base container, invisible by default
- `ModelEntity` — has a mesh and materials (visible)
- `AnchorEntity` — attaches to real-world anchor (plane, image, face, etc.)

## Setting Up a 3D Scene

### RealityView (SwiftUI — primary API)

The `make` closure runs once; the `update` closure reruns when SwiftUI state changes.

```swift
import SwiftUI
import RealityKit

struct My3DView: View {
    @State private var scale: Float = 1.0

    var body: some View {
        RealityView { content in
            let sphere = ModelEntity(
                mesh: .generateSphere(radius: 0.1),
                materials: [SimpleMaterial(color: .blue, isMetallic: true)]
            )
            sphere.name = "sphere"
            content.add(sphere)
        } update: { content in
            if let sphere = content.entities.first(where: { $0.name == "sphere" }) {
                sphere.transform.scale = SIMD3<Float>(repeating: scale)
            }
        }
    }
}
```

- `content.add(entity)` / `content.remove(entity)` to manage scene
- `update` closure is NOT frame-based — only fires when referenced `@State` changes
- Supports `placeholder:` for loading states and `attachments:` for SwiftUI overlays on entities

## Programmatic 3D Shapes (No USDZ Required)

```swift
// Box
let box = MeshResource.generateBox(size: 0.1, cornerRadius: 0.005)

// Sphere
let sphere = MeshResource.generateSphere(radius: 0.05)

// Plane (flat rectangle)
let plane = MeshResource.generatePlane(width: 0.2, depth: 0.2)

// 3D Text
let text = MeshResource.generateText("Hello AR",
    extrusionDepth: 0.01,
    font: .systemFont(ofSize: 0.05),
    containerFrame: .zero,
    alignment: .center,
    lineBreakMode: .byWordWrapping)

// Create visible entity
let material = SimpleMaterial(color: .blue, roughness: 0.3, isMetallic: true)
let entity = ModelEntity(mesh: box, materials: [material])
```

**Available generators:** `generateBox`, `generateSphere`, `generatePlane`, `generateText`, `generateCylinder`, `generateCone`
**NOT available built-in:** pyramid, torus (need USDZ or custom mesh)

## Custom/Procedural Meshes (RealityKit 2+)

```swift
var descr = MeshDescriptor(name: "customMesh")
descr.positions = MeshBuffer([
    SIMD3<Float>(0, 0, 0),
    SIMD3<Float>(1, 0, 0),
    SIMD3<Float>(0.5, 1, 0)
])
descr.primitives = .triangles([0, 1, 2])
descr.normals = MeshBuffer([...])
descr.textureCoordinates = MeshBuffer([...])

let mesh = try MeshResource.generate(from: [descr])
let entity = ModelEntity(mesh: mesh, materials: [SimpleMaterial(color: .orange, isMetallic: false)])
```

## Materials

See `realitykit-materials.md` for full reference: PBR channels, TextureResource loading, tiling, CustomMaterial Metal shaders, and material starting points (gold, glass, lava, ice, fabric).

## Anchoring (AR — Connecting Virtual to Real)

For AR apps, use `AnchorEntity` to attach content to real-world surfaces. See `arkit-reference.md` for full AR setup.

```swift
// In RealityView make closure:
let anchor = AnchorEntity(.plane(.horizontal, classification: .table, minimumBounds: [0.2, 0.2]))
anchor.addChild(myModelEntity)
content.add(anchor)
```

## Gestures & Interaction

```swift
// Tap on entity
RealityView { content in
    entity.generateCollisionShapes(recursive: true)
    content.add(entity)
}
.gesture(
    SpatialTapGesture()
        .targetedToAnyEntity()
        .onEnded { value in
            let tapped = value.entity
        }
)

// Drag entity
.gesture(
    DragGesture()
        .targetedToAnyEntity()
        .onChanged { value in
            let entity = value.entity
            let newPos = value.convert(value.location3D, from: .local, to: .scene)
            entity.position = newPos
        }
)
```

### ManipulationComponent (visionOS only — WWDC25)

Higher-level natural interaction — combined move/rotate/scale with one or two hands.

```swift
let entity = ModelEntity(mesh: .generateBox(size: 0.2),
                         materials: [SimpleMaterial(color: .orange, isMetallic: true)])
ManipulationComponent.configureEntity(entity,
    collisionShapes: [.generateBox(width: 0.2, height: 0.2, depth: 0.2)])
content.add(entity)
```

Customizable behaviors:

- `releaseBehavior` — reset to original transform or stay
- `dynamics.translationBehavior` — enable/disable movement
- `dynamics.primaryRotationBehavior` — single-hand rotation
- `dynamics.scalingBehavior` — pinch-to-scale
- `dynamics.inertia` — momentum after release

## Physics

```swift
// Static body (doesn't move, but others collide with it)
let floor = ModelEntity(mesh: .generatePlane(width: 2, depth: 2))
floor.physicsBody = PhysicsBodyComponent(massProperties: .default, material: .default, mode: .static)
floor.generateCollisionShapes(recursive: true)

// Dynamic body (affected by gravity and forces)
let ball = ModelEntity(mesh: .generateSphere(radius: 0.05),
                       materials: [SimpleMaterial(color: .red, isMetallic: false)])
ball.physicsBody = PhysicsBodyComponent(massProperties: .default, material: .default, mode: .dynamic)
ball.generateCollisionShapes(recursive: true)
ball.position = [0, 1, 0]  // Drop from 1 meter
```

**Physics body modes:**

- `.dynamic` — affected by gravity and forces, interacts with other bodies
- `.static` — immovable, other bodies collide with it
- `.kinematic` — controlled programmatically, still interacts with dynamic bodies

### Collision Detection

Store subscription in `@State` to keep it alive:

```swift
@State private var collisionSub: EventSubscription?

RealityView { content in
    // ... setup entities ...
    collisionSub = content.subscribe(to: CollisionEvents.Began.self) { event in
        let entityA = event.entityA
        let entityB = event.entityB
    }
}
// Also available: CollisionEvents.Updated, CollisionEvents.Ended
```

## Animations

```swift
// Simple transform animation
var transform = entity.transform
transform.translation = SIMD3<Float>(0, 0.5, 0)
entity.move(to: transform, relativeTo: entity.parent, duration: 2.0, timingFunction: .easeInOut)

// Orbit / rotation
let rotation = Transform(rotation: simd_quatf(angle: .pi * 2, axis: [0, 1, 0]))
entity.move(to: rotation, relativeTo: entity, duration: 3.0)
```

### Playing USDZ Animations

```swift
// Entity(named:) is async — prefer over synchronous Entity.load(named:) which blocks main thread
let entity = try await Entity(named: "animated_character")
for anim in entity.availableAnimations {
    entity.playAnimation(anim.repeat(duration: .infinity),
                         transitionDuration: 0.5,
                         startsPaused: false)
}

// Listen for animation completion (in RealityView make closure)
let subscription = content.subscribe(to: AnimationEvents.PlaybackCompleted.self, on: entity) { event in
    // Animation finished
}
```

## Loading USDZ Models

### From app bundle

```swift
let entity = try await Entity(named: "toy_car.usdz")
anchor.addChild(entity)
```

### From a remote URL (fallback when bundling is not available)

> **Note:** For 3D models generated via `generate3DAsset` / `generate3DHumanoid` + `waitTask`, assets are auto-bundled into the project. Use `Entity(named: "model_name")` instead — it loads from the bundle with no download needed. See `game-asset-integration.md` for bundled patterns. This download recipe below is only for apps that load 3D models from remote URLs without bundling.

`Entity(contentsOf:)` only accepts local `file://` URLs — remote `https://` URLs crash at runtime. Download first, using ETag to avoid redundant downloads:

```swift
func downloadModel(from url: URL) async throws -> URL {
    let cache = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0]
    let local = cache.appendingPathComponent(url.lastPathComponent)
    let etagFile = local.appendingPathExtension("etag")

    var request = URLRequest(url: url)
    request.cachePolicy = .reloadIgnoringLocalCacheData
    if let etag = try? String(contentsOf: etagFile, encoding: .utf8),
       FileManager.default.fileExists(atPath: local.path) {
        request.addValue(etag, forHTTPHeaderField: "If-None-Match")
    }

    let (temp, response) = try await URLSession.shared.download(for: request)
    guard let http = response as? HTTPURLResponse else { throw URLError(.badServerResponse) }

    if http.statusCode == 304 { return local }
    guard (200...299).contains(http.statusCode) else { throw URLError(.badServerResponse) }

    try? FileManager.default.removeItem(at: local)
    try FileManager.default.moveItem(at: temp, to: local)
    if let etag = http.value(forHTTPHeaderField: "ETag") {
        try? etag.write(to: etagFile, atomically: true, encoding: .utf8)
    }
    return local
}
```

Use `if let ... = try? await` in RealityView (never bare `try await` — errors are silently swallowed). Always add a `placeholder:`:

```swift
RealityView { content in
    if let localURL = try? await downloadModel(from: remoteURL),
       let entity = try? await Entity(contentsOf: localURL) {
        content.add(entity)
    }
} placeholder: {
    ProgressView()
}
```

## Video Textures

```swift
guard let url = Bundle.main.url(forResource: "video", withExtension: "mp4") else { return }
let player = AVPlayer(url: url)
let videoMaterial = VideoMaterial(avPlayer: player)
let screen = ModelEntity(mesh: .generatePlane(width: 0.8, height: 0.45), materials: [videoMaterial])
player.play()
```

## Spatial Audio

```swift
let audioSource = Entity()
audioSource.spatialAudio = SpatialAudioComponent(gain: -5)

let resource = try AudioFileResource.load(
    named: "ambient_rain",
    configuration: .init(shouldLoop: true)
)
audioSource.playAudio(resource)
anchor.addChild(audioSource)

// Ambient (non-directional) audio
let ambientSource = Entity()
ambientSource.ambientAudio = AmbientAudioComponent()
let ambientResource = try AudioFileResource.load(named: "background_music")
ambientSource.playAudio(ambientResource)
```

## Custom ECS System

```swift
nonisolated struct FloatingSystem: System {
    static let query = EntityQuery(where: .has(FloatingComponent.self))

    init(scene: Scene) {}

    func update(context: SceneUpdateContext) {
        for entity in context.entities(matching: Self.query, updatingSystemWhen: .rendering) {
            var transform = entity.transform
            transform.translation.y += sin(Float(Date().timeIntervalSince1970)) * 0.001
            entity.transform = transform
        }
    }
}

nonisolated struct FloatingComponent: Component {}

// Register in RealityView make closure
FloatingSystem.registerSystem()
FloatingComponent.registerComponent()
```

### Game Loop System Pattern

For game logic that needs to run every frame (movement, AI, spawning):

```swift
nonisolated struct GameLoopSystem: System {
    static let query = EntityQuery(where: .has(GameStateComponent.self))

    init(scene: Scene) {}

    func update(context: SceneUpdateContext) {
        let dt = min(Float(context.deltaTime), 1.0 / 30.0) // clamp deltaTime
        for entity in context.entities(matching: Self.query, updatingSystemWhen: .rendering) {
            guard var state = entity.components[GameStateComponent.self] else { continue }
            state.elapsedTime += dt
            // Game logic: spawn enemies, update score, check win conditions
            entity.components[GameStateComponent.self] = state
        }
    }
}

nonisolated struct GameStateComponent: Component {
    var score: Int = 0
    var elapsedTime: Float = 0
    var isRunning: Bool = true
}
```

Without `updatingSystemWhen: .rendering`, systems stall after ~20 frames on visionOS. Always clamp `deltaTime`.

## Scene Understanding (LiDAR — AR only)

Enable the LiDAR mesh so virtual objects interact with real geometry. Requires LiDAR device. See `arkit-reference.md` for full AR setup.

## EnvironmentBlendingComponent (visionOS — WWDC25)

Controls how virtual objects blend with the real-world environment for more natural integration (visionOS only).

```swift
entity.components.set(EnvironmentBlendingComponent())
```

## MeshInstancesComponent (iOS 26+ / visionOS 26+ — WWDC25)

Efficient rendering of many repeated objects (e.g. forest of trees, array of furniture). Instead of one draw call per entity, instances share geometry.

```swift
let mesh = MeshResource.generateBox(size: 0.05)
let material = SimpleMaterial(color: .green, isMetallic: false)
let prototype = ModelEntity(mesh: mesh, materials: [material])

// Create instance transforms
var instances: [MeshInstancesComponent.Instance] = []
for i in 0..<100 {
    let transform = Transform(translation: SIMD3<Float>(Float(i % 10) * 0.1, 0, Float(i / 10) * 0.1))
    instances.append(.init(transform: transform.matrix))
}
prototype.components.set(MeshInstancesComponent(instances: instances))
```

Big performance win for repeated geometry — use instead of duplicating entities.

## Scene Events (Render Loop)

```swift
@State private var updateSub: EventSubscription?

RealityView { content in
    updateSub = content.subscribe(to: SceneEvents.Update.self) { event in
        let deltaTime = event.deltaTime
        // Per-frame logic (prefer a custom System for game loops)
    }
}
```

## Custom Metal Shaders

```swift
let device = MTLCreateSystemDefaultDevice()!
let library = device.makeDefaultLibrary()!
let surfaceShader = CustomMaterial.SurfaceShader(named: "mySurfaceShader", in: library)
let geometryModifier = CustomMaterial.GeometryModifier(named: "myGeometryModifier", in: library)

var material = try CustomMaterial(
    surfaceShader: surfaceShader,
    geometryModifier: geometryModifier,
    lightingModel: .lit
)
// Pass data: only 4-component vector or texture
material.custom.value = [1.0, 0.5, 0.0, 1.0]
```

Metal shader file (`.metal`):

```metal
#include <metal_stdlib>
#include <RealityKit/RealityKit.h>
using namespace metal;

[[visible]]
void mySurfaceShader(realitykit::surface_parameters params) {
    half3 color = half3(params.uniforms().custom_parameter()[0],
                        params.uniforms().custom_parameter()[1],
                        params.uniforms().custom_parameter()[2]);
    params.surface().set_base_color(color);
    params.surface().set_roughness(0.3);
    params.surface().set_metallic(0.9);
}

[[visible]]
void myGeometryModifier(realitykit::geometry_parameters params) {
    float3 offset = params.geometry().normal() * 0.01;
    params.geometry().set_model_position_offset(offset);
}
```

## Advanced Animation (from Game Characters Reference)

### Animation Blending

#### BlendTreeAnimation

Smoothly merge two animations based on weight (e.g. walk ↔ run based on speed):

```swift
let walkAnim = // ... loaded animation definition
let runAnim = // ... loaded animation definition

let blendTree = BlendTreeAnimation<JointTransforms>(
    blend(
        BlendTreeSourceNode(source: walkAnim, name: "walk", weight: .value(0.7)),  // 70% walk
        BlendTreeSourceNode(source: runAnim, name: "run", weight: .value(0.3)),    // 30% run
        name: "walkRun"
    ),
    name: "locomotion"
)

let animView = AnimationView(source: blendTree, delay: 0, speed: 1.0)
let resource = try AnimationResource.generate(with: animView)
character.playAnimation(resource.repeat(duration: .infinity))
```

#### FromToByAnimation (Procedural)

```swift
var targetTransform = entity.transform
targetTransform.translation.y += 0.5  // move up
targetTransform.rotation = simd_quatf(angle: .pi, axis: [0, 1, 0])  // rotate 180°

let anim = FromToByAnimation(
    to: targetTransform,
    duration: 1.0,
    timing: .easeInOut,
    bindTarget: .transform
)
let resource = try AnimationResource.generate(with: anim)
entity.playAnimation(resource)
```

#### OrbitAnimation

```swift
let orbit = OrbitAnimation(
    duration: 5.0,
    axis: [0, 1, 0],          // orbit around Y
    startTransform: entity.transform,
    bindTarget: .transform
)
let resource = try AnimationResource.generate(with: orbit)
entity.playAnimation(resource.repeat(duration: .infinity))
```

---

### Animation Layering

Play animations on separate layers — locomotion + upper-body can play simultaneously:

```swift
// Layer 0 (default): full-body walk
let walkController = character.playAnimation(
    walkAnim.repeat(duration: .infinity),
    transitionDuration: 0.3,
    startsPaused: false
)

// Layer 1: upper-body aim overlay
let aimController = character.playAnimation(
    aimAnim.repeat(duration: .infinity),
    transitionDuration: 0.2,
    separateAnimatedValue: true  // puts on separate layer
)
aimController.blendFactor = 0.8  // 80% aim influence over walk
```

---

### Inverse Kinematics (IK) — iOS 18+ / visionOS 2+

Procedurally move a character's limb to a target position. The solver calculates intermediate joint positions (e.g. move hand → elbow adjusts automatically).

```swift
// Step 1: Create IK rig from the entity's skeleton
guard let meshResource = character.components[ModelComponent.self]?.mesh else { return }
let skeleton = meshResource.contents.skeletons[0]

var ikRig = try IKRig(for: skeleton)
ikRig.maxIterations = 10

// Step 2: Define constraints (which joints to control)
// .point = position only, .orient = rotation only, .parent = both
ikRig.constraints = [
    .point(named: "left_hand_constraint", on: "left_hand_joint")
]

// Step 3: Create IKResource and IKComponent
let ikResource = try IKResource(rig: ikRig)
var ikComponent = IKComponent(resource: ikResource)
character.components.set(ikComponent)

// Step 4: Update target each frame in a System
func update(context: SceneUpdateContext) {
    guard var ikComponent = character.components[IKComponent.self] else { return }

    // Set target position for the hand
    ikComponent.solvers[0].constraints["left_hand_constraint"]?.target.translation = targetWorldPos

    // Blend between animation and IK:
    // 0.0 = animation fully controls the joint
    // 1.0 = IK fully controls the joint
    ikComponent.solvers[0].constraints["left_hand_constraint"]?.animationOverrideWeight.position = 1.0

    character.components[IKComponent.self] = ikComponent
}
```

**Use cases:** Reaching for objects, aiming weapons, foot placement on uneven terrain, looking at targets.

---

### Blend Shapes (Morph Targets) — iOS 18+ / visionOS 2+

Deform a mesh between predefined shapes. Common for facial expressions, damage states.

```swift
guard let meshResource = entity.components[ModelComponent.self]?.mesh else { return }

// Create mapping from mesh
let mapping = BlendShapeWeightsMapping(meshResource: meshResource)

// Create weights component and attach to entity
let weightsComponent = BlendShapeWeightsComponent(weightsMapping: mapping)
entity.components.set(weightsComponent)

// Set blend shape weights (indices match blend target order in the USDZ file)
// e.g. index 0 = "smile", index 1 = "blink_left" — depends on your model
entity.components[BlendShapeWeightsComponent.self]!.weightSets[0].weights[0] = 0.8   // "smile"
entity.components[BlendShapeWeightsComponent.self]!.weightSets[0].weights[1] = 1.0   // "blink_left"
```

#### Animating Blend Shapes Over Time

```swift
// In a System update — smoothly animate blend shape each frame
func update(context: SceneUpdateContext) {
    let t = Float(Date().timeIntervalSince1970)
    let pulseWeight = (sin(t * 3.0) + 1.0) / 2.0

    // Update weight at index 0 (e.g. "glow" blend target)
    entity.components[BlendShapeWeightsComponent.self]?.weightSets[0].weights[0] = pulseWeight
}
```

---

### Skeletal Poses (Direct Bone Control) — iOS 18+ / visionOS 2+

Directly set bone transforms for procedural animation (head tracking, aim direction).

```swift
guard var skeletal = entity.components[SkeletalPosesComponent.self],
      var pose = skeletal.poses.default else { return }

// Override a specific joint's rotation (e.g. head look-at)
if var jointTransform = pose["head_joint"] {
    let lookRotation = simd_quatf(/* calculate look-at rotation */)
    jointTransform.rotation = lookRotation
    pose["head_joint"] = jointTransform
}

skeletal.poses.default = pose
entity.components[SkeletalPosesComponent.self] = skeletal
```

**Tip:** For head-look or aim-direction, IK with `animationOverrideWeight` is usually better than direct skeletal poses because it handles the full joint chain naturally.

---

### AnimationLibraryComponent

Store multiple named animations on an entity for easy access:

```swift
var library = AnimationLibraryComponent()
library.animations["idle"] = idleAnimResource
library.animations["walk"] = walkAnimResource
library.animations["run"] = runAnimResource
library.animations["attack"] = attackAnimResource
entity.components.set(library)

// Later — play by name
if let library = entity.components[AnimationLibraryComponent.self],
   let walkAnim = library.animations["walk"] {
    entity.playAnimation(walkAnim.repeat(duration: .infinity), transitionDuration: 0.3)
}
```
