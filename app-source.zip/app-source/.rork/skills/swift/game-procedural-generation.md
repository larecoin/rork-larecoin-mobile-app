---
index: true
description: Noise terrain, caves, dungeons, loot tables
---

# Procedural Generation — Noise, Terrain, Dungeons, Loot

GKNoise for terrain, cellular automata caves, BSP dungeons, weighted random loot.

---

## GKNoise — Terrain Generation

```swift
import GameplayKit

let source = GKPerlinNoiseSource(
    frequency: 0.5,
    octaveCount: 6,
    persistence: 0.5,
    lacunarity: 2.0,
    seed: 42
)
let noise = GKNoise(source)

let map = GKNoiseMap(noise,
    size: vector_double2(20, 15),
    origin: vector_double2(0, 0),
    sampleCount: vector_int2(200, 150),
    seamless: false)

// Sample: map.value(at: vector_int2(x, y)) returns Float in -1...1
```

### Map Noise to Tile Types

```swift
enum TileType: Int {
    case deepWater, water, sand, grass, forest, mountain, snow
}

// Threshold values shape the world balance — tune per biome design
func tileType(for value: Float) -> TileType {
    switch value {
    case ..<(-0.4): return .deepWater
    case -0.4..<(-0.1): return .water
    case -0.1..<0.05: return .sand
    case 0.05..<0.3: return .grass
    case 0.3..<0.6: return .forest
    case 0.6..<0.8: return .mountain
    default: return .snow
    }
}

func generateTerrain(width: Int, height: Int, seed: Int32) -> [[TileType]] {
    let source = GKPerlinNoiseSource(
        frequency: 0.5, octaveCount: 6,
        persistence: 0.5, lacunarity: 2.0, seed: seed
    )
    let map = GKNoiseMap(
        GKNoise(source),
        size: vector_double2(Double(width) / 10, Double(height) / 10),
        origin: vector_double2(0, 0),
        sampleCount: vector_int2(Int32(width), Int32(height)),
        seamless: false
    )
    return (0..<height).map { y in
        (0..<width).map { x in
            tileType(for: map.value(at: vector_int2(Int32(x), Int32(y))))
        }
    }
}
```

## Noise Sources Reference

| Source                      | Use Case                            |
| --------------------------- | ----------------------------------- |
| `GKPerlinNoiseSource`       | Natural terrain, heightmaps         |
| `GKRidgedNoiseSource`       | Sharp ridges, mountain ranges       |
| `GKBillowNoiseSource`       | Soft billowy clouds, rolling hills  |
| `GKVoronoiNoiseSource`      | Cell-like patterns, islands, biomes |
| `GKCylindersNoiseSource`    | Concentric ring patterns            |
| `GKSpheresNoiseSource`      | 3D spherical noise                  |
| `GKCheckerboardNoiseSource` | Regular grid patterns               |

## Noise Operations — Combining Noises

```swift
let elevation = GKNoise(GKPerlinNoiseSource(
    frequency: 0.3, octaveCount: 6, persistence: 0.5, lacunarity: 2.0, seed: 1
))
let moisture = GKNoise(GKPerlinNoiseSource(
    frequency: 0.5, octaveCount: 4, persistence: 0.5, lacunarity: 2.0, seed: 2
))

// Built-in operations
elevation.raiseToPower(2)      // sharpen peaks
elevation.clamp(lowerBound: -1, upperBound: 1)

// Combine two noise fields
let combined = GKNoise(source)
combined.add(elevation)        // add values
// Also: .multiply(_:), .minimum(_:), .maximum(_:), .displaceX(with:y:z:)

// Use both maps for biome determination
func biome(elevation: Float, moisture: Float) -> String {
    if elevation < -0.2 { return "ocean" }
    if elevation < 0.0 { return moisture > 0 ? "swamp" : "beach" }
    if elevation < 0.4 { return moisture > 0.2 ? "forest" : "grassland" }
    if elevation < 0.7 { return moisture > 0.3 ? "taiga" : "mountain" }
    return "snow_peak"
}
```

### Island Shape with Radial Falloff

```swift
func generateIsland(width: Int, height: Int, seed: Int32) -> [[TileType]] {
    let source = GKPerlinNoiseSource(
        frequency: 0.4, octaveCount: 6,
        persistence: 0.5, lacunarity: 2.0, seed: seed
    )
    let map = GKNoiseMap(
        GKNoise(source),
        size: vector_double2(10, 10),
        origin: vector_double2(0, 0),
        sampleCount: vector_int2(Int32(width), Int32(height)),
        seamless: false
    )
    let cx = Float(width) / 2, cy = Float(height) / 2
    let maxDist = sqrt(cx * cx + cy * cy)

    return (0..<height).map { y in
        (0..<width).map { x in
            let noise = map.value(at: vector_int2(Int32(x), Int32(y)))
            let dx = Float(x) - cx, dy = Float(y) - cy
            let dist = sqrt(dx * dx + dy * dy) / maxDist
            let falloff = 1.0 - pow(dist * 1.5, 2) // circular falloff
            tileType(for: noise + falloff - 0.3)
        }
    }
}
```

## Cellular Automata — Cave Generation

```swift
func generateCave(width: Int, height: Int, fillPercent: Float, iterations: Int, seed: Int) -> [[Bool]] {
    let random = GKMersenneTwisterRandomSource(seed: UInt64(seed))
    // true = wall, false = open
    let threshold = Int(fillPercent * 100)
    var grid = (0..<height).map { _ in
        (0..<width).map { _ in random.nextInt(upperBound: 100) < threshold }
    }

    for _ in 0..<iterations {
        var next = grid
        for y in 0..<height {
            for x in 0..<width {
                let walls = countWallNeighbors(grid, x: x, y: y, w: width, h: height)
                if y == 0 || y == height - 1 || x == 0 || x == width - 1 {
                    next[y][x] = true // border is always wall
                } else {
                    next[y][x] = walls >= 5
                }
            }
        }
        grid = next
    }
    return grid
}

func countWallNeighbors(_ grid: [[Bool]], x: Int, y: Int, w: Int, h: Int) -> Int {
    var count = 0
    for dy in -1...1 {
        for dx in -1...1 {
            if dx == 0 && dy == 0 { continue }
            let nx = x + dx, ny = y + dy
            if nx < 0 || nx >= w || ny < 0 || ny >= h {
                count += 1 // out of bounds = wall
            } else if grid[ny][nx] {
                count += 1
            }
        }
    }
    return count
}
```

### Flood Fill — Remove Disconnected Regions

```swift
func largestOpenRegion(in grid: [[Bool]], width: Int, height: Int) -> Set<Int> {
    var visited = Set<Int>()
    var largestRegion = Set<Int>()

    func floodFill(x: Int, y: Int) -> Set<Int> {
        var region = Set<Int>()
        var stack = [(x, y)]
        while let (cx, cy) = stack.popLast() {
            let idx = cy * width + cx
            guard cx >= 0, cx < width, cy >= 0, cy < height,
                  !visited.contains(idx), !grid[cy][cx] else { continue }
            visited.insert(idx)
            region.insert(idx)
            stack.append(contentsOf: [(cx+1,cy),(cx-1,cy),(cx,cy+1),(cx,cy-1)])
        }
        return region
    }

    for y in 0..<height {
        for x in 0..<width {
            let idx = y * width + x
            if !grid[y][x] && !visited.contains(idx) {
                let region = floodFill(x: x, y: y)
                if region.count > largestRegion.count { largestRegion = region }
            }
        }
    }
    return largestRegion
}
```

## BSP Dungeon Generation

```swift
struct Room {
    var x, y, width, height: Int
    var center: (Int, Int) { (x + width / 2, y + height / 2) }
}

struct BSPNode {
    var x, y, width, height: Int
    var left: Int? // index into nodes array
    var right: Int?
    var room: Room?
}

func generateDungeon(width: Int, height: Int, minRoom: Int, seed: Int) -> ([[Int]], [Room]) {
    // 0 = wall, 1 = floor, 2 = corridor
    var grid = Array(repeating: Array(repeating: 0, count: width), count: height)
    let rng = GKMersenneTwisterRandomSource(seed: UInt64(seed))
    var nodes: [BSPNode] = [BSPNode(x: 1, y: 1, width: width - 2, height: height - 2)]
    var rooms: [Room] = []

    // Split
    func split(index: Int, depth: Int) {
        guard depth > 0 else { return }
        let node = nodes[index]
        let horizontal = node.width < node.height
            ? true
            : node.width > node.height ? false : rng.nextBool()

        let size = horizontal ? node.height : node.width
        guard size >= minRoom * 2 + 2 else { return }

        let splitAt = minRoom + rng.nextInt(upperBound: size - minRoom * 2)

        let leftIdx = nodes.count
        let rightIdx = nodes.count + 1

        if horizontal {
            nodes.append(BSPNode(x: node.x, y: node.y, width: node.width, height: splitAt))
            nodes.append(BSPNode(x: node.x, y: node.y + splitAt, width: node.width, height: node.height - splitAt))
        } else {
            nodes.append(BSPNode(x: node.x, y: node.y, width: splitAt, height: node.height))
            nodes.append(BSPNode(x: node.x + splitAt, y: node.y, width: node.width - splitAt, height: node.height))
        }

        nodes[index].left = leftIdx
        nodes[index].right = rightIdx
        split(index: leftIdx, depth: depth - 1)
        split(index: rightIdx, depth: depth - 1)
    }

    split(index: 0, depth: 4)

    // Create rooms in leaf nodes
    for i in 0..<nodes.count {
        guard nodes[i].left == nil && nodes[i].right == nil else { continue }
        let n = nodes[i]
        let rw = minRoom + rng.nextInt(upperBound: max(1, n.width - minRoom))
        let rh = minRoom + rng.nextInt(upperBound: max(1, n.height - minRoom))
        let rx = n.x + rng.nextInt(upperBound: max(1, n.width - rw))
        let ry = n.y + rng.nextInt(upperBound: max(1, n.height - rh))
        let room = Room(x: rx, y: ry, width: rw, height: rh)
        nodes[i].room = room
        rooms.append(room)
        for dy in 0..<rh { for dx in 0..<rw { grid[ry + dy][rx + dx] = 1 } }
    }

    // Connect rooms with corridors
    for i in 1..<rooms.count {
        let (ax, ay) = rooms[i - 1].center
        let (bx, by) = rooms[i].center
        for x in min(ax, bx)...max(ax, bx) { grid[ay][x] = grid[ay][x] == 0 ? 2 : grid[ay][x] }
        for y in min(ay, by)...max(ay, by) { grid[y][bx] = grid[y][bx] == 0 ? 2 : grid[y][bx] }
    }

    return (grid, rooms)
}
```

## Weighted Loot Tables

```swift
struct LootEntry {
    let item: String
    let weight: Int
}

let commonLoot: [LootEntry] = [
    LootEntry(item: "gold_coin", weight: 50),
    LootEntry(item: "health_potion", weight: 25),
    LootEntry(item: "iron_sword", weight: 15),
    LootEntry(item: "diamond", weight: 5),
    LootEntry(item: "legendary_armor", weight: 1),
]

func rollLoot(from table: [LootEntry], using rng: GKRandomSource) -> String {
    let total = table.reduce(0) { $0 + $1.weight }
    var roll = rng.nextInt(upperBound: total)
    for entry in table {
        roll -= entry.weight
        if roll < 0 { return entry.item }
    }
    return table.last!.item
}

// Roll multiple with no duplicates
func rollUniqueLoot(count: Int, from table: [LootEntry], using rng: GKRandomSource) -> [String] {
    var remaining = table
    var results: [String] = []
    for _ in 0..<min(count, remaining.count) {
        let item = rollLoot(from: remaining, using: rng)
        results.append(item)
        remaining.removeAll { $0.item == item }
    }
    return results
}
```

### Tiered Loot by Difficulty

```swift
struct LootTable {
    let entries: [LootEntry]

    static func forDifficulty(_ level: Int) -> LootTable {
        switch level {
        case 0..<5:
            return LootTable(entries: [
                LootEntry(item: "wooden_sword", weight: 40),
                LootEntry(item: "leather_armor", weight: 30),
                LootEntry(item: "small_potion", weight: 30),
            ])
        case 5..<10:
            return LootTable(entries: [
                LootEntry(item: "iron_sword", weight: 30),
                LootEntry(item: "chain_armor", weight: 25),
                LootEntry(item: "medium_potion", weight: 25),
                LootEntry(item: "fire_scroll", weight: 15),
                LootEntry(item: "rare_gem", weight: 5),
            ])
        default:
            return LootTable(entries: [
                LootEntry(item: "diamond_sword", weight: 20),
                LootEntry(item: "plate_armor", weight: 15),
                LootEntry(item: "large_potion", weight: 20),
                LootEntry(item: "legendary_staff", weight: 5),
                LootEntry(item: "dragon_egg", weight: 1),
            ])
        }
    }
}
```

## Wave Spawning — Progressive Difficulty

```swift
struct EnemySpawn {
    let type: String
    let count: Int
}

struct Wave {
    let enemies: [EnemySpawn]
    let spawnDelay: TimeInterval // delay between each enemy
}

func generateWaves(count: Int, seed: Int) -> [Wave] {
    let rng = GKMersenneTwisterRandomSource(seed: UInt64(seed))
    return (0..<count).map { wave in
        let difficulty = wave + 1
        var enemies: [EnemySpawn] = [EnemySpawn(type: "basic", count: 2 + difficulty)]
        if difficulty >= 3 { enemies.append(EnemySpawn(type: "fast", count: difficulty / 2)) }
        if difficulty >= 5 { enemies.append(EnemySpawn(type: "tank", count: max(1, difficulty / 4))) }
        if difficulty >= 8 { enemies.append(EnemySpawn(type: "boss", count: 1)) }
        let delay = max(0.3, 2.0 - Double(difficulty) * 0.15)
        return Wave(enemies: enemies, spawnDelay: delay)
    }
}
```

## Infinite Level Generation with Chunks

```swift
struct Chunk {
    let x: Int // chunk coordinate
    var tiles: [[TileType]]
}

class InfiniteWorld {
    let chunkSize = 32
    let seed: Int
    var loadedChunks: [Int: Chunk] = [:] // keyed by chunk x

    init(seed: Int) { self.seed = seed }

    func chunkAt(x: Int) -> Chunk {
        if let existing = loadedChunks[x] { return existing }
        let chunkSeed = seed &+ x &* 7919 // deterministic per-chunk seed
        let source = GKPerlinNoiseSource(
            frequency: 0.5, octaveCount: 4,
            persistence: 0.5, lacunarity: 2.0,
            seed: Int32(chunkSeed)
        )
        let map = GKNoiseMap(
            GKNoise(source),
            size: vector_double2(3.2, 3.2),
            origin: vector_double2(Double(x) * 3.2, 0),
            sampleCount: vector_int2(Int32(chunkSize), Int32(chunkSize)),
            seamless: false
        )
        let tiles = (0..<chunkSize).map { y in
            (0..<chunkSize).map { col in
                tileType(for: map.value(at: vector_int2(Int32(col), Int32(y))))
            }
        }
        let chunk = Chunk(x: x, tiles: tiles)
        loadedChunks[x] = chunk
        return chunk
    }

    func unloadDistantChunks(playerChunkX: Int, radius: Int = 3) {
        loadedChunks = loadedChunks.filter { abs($0.key - playerChunkX) <= radius }
    }
}
```

## Seed-Based Reproducibility

Always use `GKMersenneTwisterRandomSource` with an explicit seed. Never use `arc4random` or `.random(in:)` for procedural content — those are non-deterministic.

```swift
let seed: UInt64 = 12345
let rng = GKMersenneTwisterRandomSource(seed: seed)

// Distributions built on top of deterministic source
let d6 = GKRandomDistribution(randomSource: rng, lowestValue: 1, highestValue: 6)
let gaussian = GKGaussianDistribution(randomSource: rng, lowestValue: 0, highestValue: 100)
let shuffled = GKShuffledDistribution(randomSource: rng, lowestValue: 0, highestValue: 51) // deck of cards
```

---

## Related Skills

- **game-2d.md** — Applying generated terrain to SKTileMapNode
- **gameplaykit-ai.md** — GKRandomSource and GKNoise used here
- **game-core.md** — Genre guide, GameManager, entity protocols
