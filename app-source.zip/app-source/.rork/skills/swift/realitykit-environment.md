---
index: true
description: Terrain from heightmaps, skybox/IBL, fog, water, portals
---

# RealityKit Environment — Terrain, Skybox, Water, Fog

How to build 3D game worlds: terrain from heightmaps, skyboxes, environment lighting, water surfaces, fog, and portals. RealityKit has NO built-in terrain or water systems — build them from primitives using the patterns below. For materials and shaders: `realitykit-materials.md`. For procedural noise: `game-procedural-generation.md`. For performance: `game-performance-reference.md`.

---

## Terrain from Heightmap (MeshDescriptor)

Generate a terrain mesh by sampling a heightmap (noise function or image). This creates a one-time static mesh — use for level geometry that does not change at runtime.

### Heightmap to Mesh

```swift
/// Generate a terrain mesh from a 2D array of height values.
/// - Parameters:
///   - heights: 2D grid of Y values (rows × columns)
///   - gridSize: world-space size of the terrain (width × depth)
/// - Returns: MeshResource ready to use with a ModelEntity
func generateTerrainMesh(heights: [[Float]], gridSize: SIMD2<Float>) throws -> MeshResource {
    let rows = heights.count
    let cols = heights[0].count
    guard rows >= 2, cols >= 2 else { fatalError("Grid must be at least 2×2") }

    let cellWidth = gridSize.x / Float(cols - 1)
    let cellDepth = gridSize.y / Float(rows - 1)

    // Vertices
    var positions: [SIMD3<Float>] = []
    var uvs: [SIMD2<Float>] = []
    positions.reserveCapacity(rows * cols)
    uvs.reserveCapacity(rows * cols)

    for row in 0..<rows {
        for col in 0..<cols {
            let x = Float(col) * cellWidth - gridSize.x / 2
            let z = Float(row) * cellDepth - gridSize.y / 2
            let y = heights[row][col]
            positions.append(SIMD3<Float>(x, y, z))
            uvs.append(SIMD2<Float>(Float(col) / Float(cols - 1), Float(row) / Float(rows - 1)))
        }
    }

    // Indices (two triangles per grid cell)
    var indices: [UInt32] = []
    indices.reserveCapacity((rows - 1) * (cols - 1) * 6)

    for row in 0..<(rows - 1) {
        for col in 0..<(cols - 1) {
            let topLeft = UInt32(row * cols + col)
            let topRight = topLeft + 1
            let bottomLeft = UInt32((row + 1) * cols + col)
            let bottomRight = bottomLeft + 1

            indices.append(contentsOf: [topLeft, bottomLeft, topRight])
            indices.append(contentsOf: [topRight, bottomLeft, bottomRight])
        }
    }

    // Normals (smooth — average of adjacent face normals)
    var normals = [SIMD3<Float>](repeating: .zero, count: positions.count)
    for i in stride(from: 0, to: indices.count, by: 3) {
        let i0 = Int(indices[i]), i1 = Int(indices[i + 1]), i2 = Int(indices[i + 2])
        let edge1 = positions[i1] - positions[i0]
        let edge2 = positions[i2] - positions[i0]
        let faceNormal = normalize(cross(edge1, edge2))
        normals[i0] += faceNormal
        normals[i1] += faceNormal
        normals[i2] += faceNormal
    }
    normals = normals.map { normalize($0) }

    // Build mesh
    var descriptor = MeshDescriptor(name: "terrain")
    descriptor.positions = MeshBuffer(positions)
    descriptor.normals = MeshBuffer(normals)
    descriptor.textureCoordinates = MeshBuffer(uvs)
    descriptor.primitives = .triangles(indices)

    return try MeshResource.generate(from: [descriptor])
}
```

### Using with GKNoise (Procedural Terrain)

Combine with GameplayKit noise (covered in `game-procedural-generation.md`):

```swift
import GameplayKit

func generateNoiseHeightmap(rows: Int, cols: Int, scale: Float, amplitude: Float) -> [[Float]] {
    let source = GKPerlinNoiseSource(
        frequency: 2.0, octaveCount: 6, persistence: 0.5,
        lacunarity: 2.0, seed: 42
    )
    let noise = GKNoise(source)
    let map = GKNoiseMap(noise,
        size: vector_double2(Double(scale), Double(scale)),
        origin: .zero,
        sampleCount: vector_int2(Int32(cols), Int32(rows)),
        seamless: false
    )

    var heights: [[Float]] = []
    for row in 0..<rows {
        var rowValues: [Float] = []
        for col in 0..<cols {
            let value = map.value(at: vector_int2(Int32(col), Int32(row)))
            rowValues.append(value * amplitude)
        }
        heights.append(rowValues)
    }
    return heights
}

// Usage
let heights = generateNoiseHeightmap(rows: 64, cols: 64, scale: 10, amplitude: 3.0)
let terrainMesh = try generateTerrainMesh(heights: heights, gridSize: [40, 40])

var terrainMaterial = PhysicallyBasedMaterial()
let grassTex = try await TextureResource(named: "grass")
terrainMaterial.baseColor = .init(tint: .white, texture: .init(grassTex))
// Tile texture across terrain
terrainMaterial.textureCoordinateTransform = .init(scale: SIMD2<Float>(8, 8), rotation: 0, offset: .zero)
terrainMaterial.roughness = .init(floatLiteral: 0.9)

let terrain = ModelEntity(mesh: terrainMesh, materials: [terrainMaterial])
terrain.generateCollisionShapes(recursive: false)
terrain.components.set(PhysicsBodyComponent(massProperties: .default, material: nil, mode: .static))
```

### Grid Resolution Guide

| Terrain Size           | Grid Resolution | Triangles | Use Case               |
| ---------------------- | --------------- | --------- | ---------------------- |
| Small arena (20×20m)   | 32×32           | ~2K       | Fighting, racing track |
| Medium level (50×50m)  | 64×64           | ~8K       | Adventure, exploration |
| Large world (100×100m) | 128×128         | ~32K      | Open world — needs LOD |

Higher resolution = more detail but more triangles. For large terrains, split into chunks and disable distant ones with `isEnabled = false`.

---

## Dynamic Terrain (LowLevelMesh + LowLevelTexture)

For terrain that changes at runtime (digging, explosions, deformation), use `LowLevelMesh` with a heightmap stored in `LowLevelTexture`. Apple's recommended approach — see `game-performance-reference.md` for LowLevelMesh basics.

### Architecture

1. Create a dense subdivided plane via `LowLevelMesh` (pre-allocate vertices)
2. Store heightmap in `LowLevelTexture` (`.r32Float` format)
3. Each frame: update heightmap on GPU via Metal compute → geometry modifier reads heightmap → displaces vertices
4. Compute normals analytically in the geometry modifier from neighboring height samples

### Geometry Modifier for Terrain Displacement

```metal
#include <metal_stdlib>
#include <RealityKit/RealityKit.h>
using namespace metal;

[[visible]]
void terrainDisplacement(realitykit::geometry_parameters params) {
    float2 uv = params.geometry().uv0();

    // Sample heightmap from custom texture
    constexpr sampler s(address::clamp_to_edge, filter::linear);
    float height = params.textures().custom().sample(s, uv).r;

    // Displace vertex along Y
    float3 offset = float3(0, height, 0);
    params.geometry().set_model_position_offset(offset);

    // Compute normal from heightmap gradient (central differences)
    float texelSize = 1.0 / 256.0; // match your texture resolution
    float hL = params.textures().custom().sample(s, uv + float2(-texelSize, 0)).r;
    float hR = params.textures().custom().sample(s, uv + float2(texelSize, 0)).r;
    float hD = params.textures().custom().sample(s, uv + float2(0, -texelSize)).r;
    float hU = params.textures().custom().sample(s, uv + float2(0, texelSize)).r;

    float3 normal = normalize(float3(hL - hR, 2.0 * texelSize, hD - hU));
    params.geometry().set_normal(normal);
}
```

---

## Skybox & Environment

Non-AR RealityKit scenes default to a black void. You need an explicit skybox and environment lighting.

### Skybox Sphere (Simple — No HDR Required)

Create a large inverted sphere with an `UnlitMaterial`:

```swift
// Gradient sky via a generated image or a sky texture
let skyTexture = try await TextureResource(named: "sky_gradient")
var skyMat = UnlitMaterial()
skyMat.color = .init(tint: .white, texture: .init(skyTexture))
skyMat.faceCulling = .front // render inside of sphere

let skyDome = ModelEntity(mesh: .generateSphere(radius: 500), materials: [skyMat])
skyDome.scale = .init(repeating: -1) // invert normals
content.add(skyDome)
```

### Environment Resource (HDR — Realistic Lighting + Skybox)

`EnvironmentResource` provides both skybox visuals AND image-based lighting (IBL).

```swift
// From an HDR file in the bundle (equirectangular .hdr or .exr)
let env = try await EnvironmentResource(named: "studio_hdr")

// IBL lighting — makes all objects receive ambient light from the environment
let lightEntity = Entity()
lightEntity.components.set(ImageBasedLightComponent(source: .single(env)))
content.add(lightEntity)

// Each entity that should receive IBL needs this:
modelEntity.components.set(ImageBasedLightReceiverComponent(imageBasedLight: lightEntity))
```

**Note:** `EnvironmentResource` contains both lighting data and a cubemap skybox. For the skybox visual, use the simple sphere approach (above) with a separate sky texture, or load an equirectangular image (below).

### From Equirectangular Image at Runtime

```swift
guard let url = Bundle.main.url(forResource: "panorama", withExtension: "hdr") else { return }
if let source = CGImageSourceCreateWithURL(url as CFURL, nil),
   let image = CGImageSourceCreateImageAtIndex(source, 0, nil) {
    let cube = try await TextureResource(
        cubeFromEquirectangular: image, quality: .normal,
        options: .init(semantic: .hdrColor)
    )
    let env = try await EnvironmentResource(cube: cube, options: .init())
    // Use env for skybox + IBL as above
}
```

### Solid Color Background (Quick)

For stylized games that don't need a skybox:

```swift
// SwiftUI background behind RealityView
ZStack {
    LinearGradient(colors: [.blue, .cyan], startPoint: .top, endPoint: .bottom)
        .ignoresSafeArea()
    RealityView { content in
        // scene content...
    }
}
```

---

## Lighting Setup for Game Worlds

Every non-AR 3D scene needs manual lighting. Combine directional (sun) + ambient (IBL or fill light).

### Outdoor Lighting Example

Tune intensity, color, and shadow distance to match your scene's mood and scale.

```swift
// Sun — directional light with shadows
let sun = Entity()
var sunLight = DirectionalLightComponent()
sunLight.intensity = 12000
sunLight.color = .init(red: 1.0, green: 0.95, blue: 0.8, alpha: 1) // warm sunlight
var shadow = DirectionalLightComponent.Shadow()
shadow.maximumDistance = 20
shadow.depthBias = 1.0
sunLight.shadow = shadow
sun.components.set(sunLight)
sun.look(at: .zero, from: [5, 10, 5], relativeTo: nil) // ~45° angle
content.add(sun)

// Ambient fill — IBL from EnvironmentResource (see above)
// OR a dim point light above scene center as fallback
let fill = Entity()
var fillLight = PointLightComponent()
fillLight.intensity = 200000
fillLight.color = .init(red: 0.6, green: 0.7, blue: 1.0, alpha: 1) // cool sky fill
fillLight.attenuationRadius = 30
fill.components.set(fillLight)
fill.position = [0, 15, 0]
content.add(fill)
```

### Indoor Lighting Example

```swift
// Dim directional as ambient
let ambient = Entity()
var ambLight = DirectionalLightComponent()
ambLight.intensity = 2000
ambient.components.set(ambLight)
ambient.look(at: .zero, from: [0, 10, 0], relativeTo: nil)
content.add(ambient)

// Torches — point lights (max 8 total)
func addTorch(at position: SIMD3<Float>, parent: Entity) {
    let torch = Entity()
    var light = PointLightComponent()
    light.intensity = 500000
    light.color = .orange
    light.attenuationRadius = 8
    torch.components.set(light)
    torch.position = position
    parent.addChild(torch)
}
```

---

## Fog (Surface Shader)

No built-in fog system. Implement distance-based fog in a `CustomMaterial` surface shader. Apply this material to objects that need fog.

```metal
constexpr sampler textureSampler(address::repeat, filter::linear);

[[visible]]
void fogSurface(realitykit::surface_parameters params) {
    float2 uv = params.geometry().uv0();
    uv.y = 1.0 - uv.y;

    // Sample base texture
    half4 texColor = params.textures().base_color().sample(textureSampler, uv);
    half3 baseColor = texColor.rgb;

    // Fog parameters from custom.value
    float fogStart = params.uniforms().custom_parameter()[0];    // e.g. 5.0
    float fogEnd = params.uniforms().custom_parameter()[1];      // e.g. 30.0
    half3 fogColor = half3(params.uniforms().custom_parameter()[2],
                           params.uniforms().custom_parameter()[2],
                           params.uniforms().custom_parameter()[2]); // e.g. 0.7 for gray

    // Distance from camera
    float dist = length(params.geometry().world_position());
    float fogFactor = saturate((dist - fogStart) / (fogEnd - fogStart));

    half3 finalColor = mix(baseColor, fogColor, half(fogFactor));
    params.surface().set_base_color(finalColor);
    params.surface().set_roughness(0.8);
}
```

### Simple Fog Without Shaders

For simpler games, use `OpacityComponent` based on distance from camera in an ECS System:

```swift
nonisolated struct FogSystem: System {
    static let query = EntityQuery(where: .has(FoggableComponent.self))
    init(scene: Scene) {}

    func update(context: SceneUpdateContext) {
        guard let camera = context.scene.findEntity(named: "camera") else { return }
        let camPos = camera.position(relativeTo: nil)

        for entity in context.entities(matching: Self.query, updatingSystemWhen: .rendering) {
            let dist = distance(entity.position(relativeTo: nil), camPos)
            let fog = simd_clamp((dist - 10) / 30, 0, 1) // fade from 10m to 40m
            entity.components.set(OpacityComponent(opacity: 1.0 - Float(fog)))
        }
    }
}

nonisolated struct FoggableComponent: Component {}
```

---

## Water Surface

Build water from a subdivided plane with a geometry modifier (waves) and surface shader (color + transparency).

### Setup

```swift
// Dense plane for wave detail (40×40 subdivisions)
let waterMesh = try generateTerrainMesh(
    heights: Array(repeating: Array(repeating: Float(0), count: 40), count: 40),
    gridSize: [20, 20]
)

let device = MTLCreateSystemDefaultDevice()!
let library = device.makeDefaultLibrary()!
var waterMaterial = try CustomMaterial(
    surfaceShader: .init(named: "waterSurface", in: library),
    geometryModifier: .init(named: "waterWaves", in: library),
    lightingModel: .lit
)
waterMaterial.blending = .transparent(opacity: 1.0)
waterMaterial.faceCulling = .none // visible from below too
waterMaterial.custom.value = [0, 0.3, 0, 0] // [time (updated each frame), waveHeight, 0, 0]

let water = ModelEntity(mesh: waterMesh, materials: [waterMaterial])
water.position.y = 0 // water level
```

### Wave Geometry Modifier

```metal
[[visible]]
void waterWaves(realitykit::geometry_parameters params) {
    float time = params.uniforms().time();
    float waveHeight = params.uniforms().custom_parameter()[1];
    float3 pos = params.geometry().model_position();

    // Multi-frequency sine waves
    float wave1 = sin(pos.x * 2.0 + time * 1.5) * waveHeight;
    float wave2 = sin(pos.z * 3.0 + time * 2.0) * waveHeight * 0.5;
    float wave3 = sin((pos.x + pos.z) * 1.5 + time * 1.0) * waveHeight * 0.3;
    float height = wave1 + wave2 + wave3;

    params.geometry().set_model_position_offset(float3(0, height, 0));

    // Analytical normal from wave derivatives
    float dx = cos(pos.x * 2.0 + time * 1.5) * 2.0 * waveHeight
             + cos((pos.x + pos.z) * 1.5 + time * 1.0) * 1.5 * waveHeight * 0.3;
    float dz = cos(pos.z * 3.0 + time * 2.0) * 3.0 * waveHeight * 0.5
             + cos((pos.x + pos.z) * 1.5 + time * 1.0) * 1.5 * waveHeight * 0.3;
    float3 normal = normalize(float3(-dx, 1.0, -dz));
    params.geometry().set_normal(normal);
}
```

### Water Surface Shader

```metal
[[visible]]
void waterSurface(realitykit::surface_parameters params) {
    float3 worldPos = float3(params.geometry().world_position());
    float3 normal = float3(params.geometry().normal());
    float time = params.uniforms().time();

    // Fresnel — more reflective at shallow angles
    float3 viewDir = normalize(worldPos);
    float fresnel = pow(1.0 - saturate(abs(dot(normal, viewDir))), 3.0);

    // Deep water color gradient
    half3 shallowColor = half3(0.1, 0.5, 0.5);
    half3 deepColor = half3(0.0, 0.15, 0.3);
    half3 waterColor = mix(deepColor, shallowColor, half(fresnel));

    // Foam at wave peaks
    float height = params.geometry().model_position().y;
    float foam = smoothstep(0.15, 0.25, height);
    waterColor = mix(waterColor, half3(0.9, 0.95, 1.0), half(foam * 0.6));

    params.surface().set_base_color(waterColor);
    params.surface().set_roughness(half(mix(0.05, 0.3, fresnel)));
    params.surface().set_metallic(0.0);
    params.surface().set_opacity(half(mix(0.6, 0.95, fresnel)));
    params.surface().set_specular(0.8);
}
```

---

## PortalComponent (iOS 18+)

Creates a window into a separate 3D world. Objects in the portal world are only visible through the portal surface.

```swift
// 1. Create portal world content
let portalWorld = Entity()
portalWorld.components.set(WorldComponent())

// Add content to portal world (only visible through portal)
let alienTerrain = ModelEntity(mesh: .generatePlane(width: 10, depth: 10),
                                materials: [SimpleMaterial(color: .purple, isMetallic: false)])
portalWorld.addChild(alienTerrain)

let alienSky = ModelEntity(mesh: .generateSphere(radius: 50),
                            materials: [UnlitMaterial(color: .init(red: 0.1, green: 0, blue: 0.2, alpha: 1))])
alienSky.scale = .init(repeating: -1)
portalWorld.addChild(alienSky)

content.add(portalWorld)

// 2. Create portal surface (a flat plane acts as the "window")
let portalMesh = MeshResource.generatePlane(width: 2, height: 3)
let portalFrame = ModelEntity(mesh: portalMesh, materials: [PortalMaterial()])
portalFrame.components.set(PortalComponent(target: portalWorld))
portalFrame.position = [0, 1.5, -3]
content.add(portalFrame)
```

**Use cases:** Dimensional rifts, level transitions, "peek into another world" effects, magic mirrors.

**Limitation:** The portal world has its own coordinate space. Objects can cross through the portal with `PortalCrossingComponent` but this is complex for games — simpler to use portals as visual effects and teleport entities programmatically.
