---
index: true
description: Audio recorder, sound pad, level meter, ShazamKit recipes
---

# Audio Patterns, Recipes & Practical Guidance

---

## What's Practical for Code Generation

### Highly Practical (pure Swift, no external assets)

| Feature                                     | Why                                    | Complexity  |
| ------------------------------------------- | -------------------------------------- | ----------- |
| AVAudioEngine setup + playback              | Core audio graph, no assets needed     | Low         |
| Record from microphone                      | AVAudioRecorder or engine tap          | Low         |
| Built-in effects (reverb, delay, EQ, pitch) | One-line factory presets               | Low         |
| Generate tones/sounds programmatically      | AVAudioSourceNode + sine waves         | Medium      |
| Audio metering / level visualization        | RMS calculation, simple UI             | Medium      |
| Sound classification (built-in model)       | SoundAnalysis + microphone tap         | Medium      |
| Music recognition (Shazam)                  | ShazamKit simplified API (iOS 17+)     | Low         |
| Speech-to-text transcription                | Speech framework                       | Medium      |
| System/accessibility speech fallback        | AVSpeechSynthesizer                    | Low         |
| FFT spectrum visualization                  | Accelerate + SwiftUI Charts            | Medium-High |
| Audio session management                    | Category, interruptions, route changes | Low         |
| Multi-track mixing                          | Multiple player nodes → mixer          | Medium      |

### Possible But Requires Assets or Hardware

| Feature                     | Limitation                                           |
| --------------------------- | ---------------------------------------------------- |
| Playing audio files         | Need bundled or remote audio files                   |
| MIDI controller input       | Requires physical MIDI device                        |
| Custom sound classification | Requires trained CoreML model                        |
| Custom ShazamKit catalog    | Requires pre-recorded reference audio                |
| AUv3 plugin hosting         | Complex setup, requires understanding of Audio Units |

---

## Complete Recipe: Play Audio from URL (with local caching)

> **Note:** For game audio generated via `generateAudio` + `waitTask`, assets are auto-bundled into the project. Use `Bundle.main.url(forResource: "asset_name", withExtension: "mp3")` + `AVAudioPlayer(contentsOf:)` instead. See `game-asset-integration.md` for bundled patterns. This URL-caching recipe below is for apps that stream audio from remote URLs without bundling.

Use ElevenLabs for natural text-to-speech, narration, voiceovers, character voices, and dialogue. Use `generateAudio` with `type: "voice"` or `type: "dialogue"` when the spoken lines are project assets, and use the ElevenLabs proxy when text is generated dynamically at runtime. Do not use AVSpeechSynthesizer for user-facing natural voice unless the user explicitly asks for offline, on-device, system accessibility, or placeholder speech.

Use this pattern to play generated audio (music, SFX, voice) from remote URLs. Downloads the file once to the Caches directory, then plays locally with zero latency on subsequent plays.

```swift
import SwiftUI
import AVFoundation

@MainActor
@Observable
class AudioManager {
    private var player: AVAudioPlayer?
    var isPlaying = false

    func play(urlString: String, loop: Bool = false) {
        stop()
        guard let url = URL(string: urlString) else { return }
        Task {
            let localURL = try await cachedAudio(from: url)
            try? AVAudioSession.sharedInstance().setCategory(.playback)
            try? AVAudioSession.sharedInstance().setActive(true)
            player = try AVAudioPlayer(contentsOf: localURL)
            player?.numberOfLoops = loop ? -1 : 0
            player?.play()
            isPlaying = true
        }
    }

    func stop() {
        player?.stop()
        player = nil
        isPlaying = false
    }

    private func cachedAudio(from url: URL) async throws -> URL {
        let cacheDir = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0]
        let localURL = cacheDir.appendingPathComponent(url.lastPathComponent)
        if FileManager.default.fileExists(atPath: localURL.path) { return localURL }
        let (tempURL, _) = try await URLSession.shared.download(from: url)
        try? FileManager.default.removeItem(at: localURL)
        try FileManager.default.moveItem(at: tempURL, to: localURL)
        return localURL
    }
}

// Usage:
// @State private var music = AudioManager()
// @State private var sfx = AudioManager()
//
// music.play(urlString: "https://rork.app/pa/{projectId}/battle_theme", loop: true)
// sfx.play(urlString: "https://rork.app/pa/{projectId}/explosion")
```

Use separate `AudioManager` instances for layered audio (e.g. background music + SFX).

---

### Not Practical for Code Generation

| Feature                                | Why                                          |
| -------------------------------------- | -------------------------------------------- |
| Full DAW / sequencer                   | Massive scope, needs custom DSP              |
| Custom Audio Unit (AUv3) plugin        | Requires C++ kernel, app extension structure |
| Real-time pitch correction (auto-tune) | Needs complex DSP algorithms                 |
| Professional-grade mixing/mastering    | Requires deep audio engineering knowledge    |
| MIDI file read/write                   | Complex binary format, use MIDIKit library   |

---

## Complete Recipe: Audio Recorder with Playback

```swift
import SwiftUI
import AVFoundation

struct AudioRecorderView: View {
    @State private var recorder = AudioRecorderModel()

    var body: some View {
        VStack(spacing: 24) {
            // Recording indicator
            Circle()
                .fill(recorder.isRecording ? Color.red : Color.gray.opacity(0.3))
                .frame(width: 20, height: 20)
                .animation(.easeInOut(duration: 0.5).repeatForever(), value: recorder.isRecording)

            Text(recorder.isRecording ? "Recording..." : (recorder.hasRecording ? "Recording ready" : "Tap to record"))
                .font(.headline)

            HStack(spacing: 32) {
                Button(action: {
                    if recorder.isRecording {
                        recorder.stopRecording()
                    } else {
                        recorder.startRecording()
                    }
                }) {
                    Image(systemName: recorder.isRecording ? "stop.circle.fill" : "record.circle")
                        .font(.system(size: 64))
                        .foregroundStyle(recorder.isRecording ? .red : .primary)
                }

                if recorder.hasRecording {
                    Button(action: {
                        if recorder.isPlaying {
                            recorder.stopPlaying()
                        } else {
                            recorder.startPlaying()
                        }
                    }) {
                        Image(systemName: recorder.isPlaying ? "stop.fill" : "play.fill")
                            .font(.system(size: 48))
                            .foregroundStyle(.blue)
                    }
                }
            }
        }
        .padding()
    }
}

@MainActor
@Observable
class AudioRecorderModel: NSObject, AVAudioRecorderDelegate, AVAudioPlayerDelegate {
    var isRecording = false
    var isPlaying = false
    var hasRecording = false

    private var audioRecorder: AVAudioRecorder?
    private var audioPlayer: AVAudioPlayer?

    private var recordingURL: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("recording.m4a")
    }

    func startRecording() {
        let session = AVAudioSession.sharedInstance()
        do {
            try session.setCategory(.playAndRecord, mode: .default, options: [.defaultToSpeaker])
            try session.setActive(true)
        } catch {
            return
        }

        let settings: [String: Any] = [
            AVFormatIDKey: Int(kAudioFormatMPEG4AAC),
            AVSampleRateKey: 44100,
            AVNumberOfChannelsKey: 1,
            AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue
        ]

        do {
            audioRecorder = try AVAudioRecorder(url: recordingURL, settings: settings)
            audioRecorder?.delegate = self
            audioRecorder?.record()
            isRecording = true
        } catch {
            return
        }
    }

    func stopRecording() {
        audioRecorder?.stop()
        isRecording = false
        hasRecording = true
    }

    func startPlaying() {
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: recordingURL)
            audioPlayer?.delegate = self
            audioPlayer?.play()
            isPlaying = true
        } catch {
            return
        }
    }

    func stopPlaying() {
        audioPlayer?.stop()
        isPlaying = false
    }

    nonisolated func audioRecorderDidFinishRecording(_ recorder: AVAudioRecorder, successfully flag: Bool) {
        Task { @MainActor in
            isRecording = false
            hasRecording = flag
        }
    }

    nonisolated func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        Task { @MainActor in
            isPlaying = false
        }
    }
}
```

---

## Complete Recipe: Sound Pad (Tap to Play Sounds)

```swift
import SwiftUI
import AVFoundation

struct SoundPadView: View {
    @State private var audioEngine = SoundPadEngine()

    let padColors: [Color] = [.red, .orange, .yellow, .green, .blue, .purple, .pink, .indigo,
                               .mint, .teal, .cyan, .brown]
    let frequencies: [Double] = [262, 294, 330, 349, 392, 440, 494, 523,
                                  587, 659, 698, 784]
    let noteNames = ["C4", "D4", "E4", "F4", "G4", "A4", "B4", "C5",
                     "D5", "E5", "F5", "G5"]

    var body: some View {
        LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 8), count: 4), spacing: 8) {
            ForEach(0..<12, id: \.self) { index in
                Button {
                    audioEngine.playTone(frequency: frequencies[index], duration: 0.3)
                } label: {
                    VStack {
                        Text(noteNames[index])
                            .font(.headline)
                            .foregroundStyle(.white)
                    }
                    .frame(maxWidth: .infinity, minHeight: 80)
                    .background(padColors[index].gradient)
                    .clipShape(RoundedRectangle(cornerRadius: 12))
                }
            }
        }
        .padding()
        .onAppear { audioEngine.setup() }
    }
}

class SoundPadEngine {
    private let engine = AVAudioEngine()
    private let sampleRate: Double = 44100

    func setup() {
        do {
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.playback, mode: .default)
            try session.setActive(true)
            engine.prepare()
            try engine.start()
        } catch {
            return
        }
    }

    func playTone(frequency: Double, duration: Double) {
        var phase: Double = 0
        let phaseIncrement = 2.0 * .pi * frequency / sampleRate
        let totalFrames = Int(sampleRate * duration)
        var currentFrame = 0

        let sourceNode = AVAudioSourceNode { _, _, frameCount, audioBufferList in
            let bufferList = UnsafeMutableAudioBufferListPointer(audioBufferList)
            let framesToRender = Int(frameCount)

            for frame in 0..<framesToRender {
                let progress = Double(currentFrame) / Double(totalFrames)
                let envelope = progress < 0.01 ? progress / 0.01 : // attack
                               progress > 0.7 ? (1.0 - progress) / 0.3 : 1.0 // release

                let sample = Float(sin(phase) * envelope)
                phase += phaseIncrement
                if phase >= 2.0 * .pi { phase -= 2.0 * .pi }
                currentFrame += 1

                for buffer in bufferList {
                    let buf = UnsafeMutableBufferPointer<Float>(buffer)
                    buf[frame] = currentFrame > totalFrames ? 0 : sample
                }
            }
            return noErr
        }

        engine.attach(sourceNode)
        engine.connect(sourceNode, to: engine.mainMixerNode, format: nil)

        // Clean up after duration
        DispatchQueue.main.asyncAfter(deadline: .now() + duration + 0.1) { [weak self] in
            self?.engine.detach(sourceNode)
        }
    }
}
```

---

## Complete Recipe: Live Audio Level Meter

```swift
import SwiftUI
import AVFoundation
import Accelerate

struct AudioLevelView: View {
    @State private var monitor = AudioLevelMonitor()

    var body: some View {
        VStack(spacing: 16) {
            Text("Audio Level")
                .font(.headline)

            GeometryReader { geometry in
                let level = CGFloat(max(0, min(1, (monitor.decibels + 60) / 60)))
                let barColor: Color = level > 0.8 ? .red : level > 0.6 ? .orange : .green

                RoundedRectangle(cornerRadius: 4)
                    .fill(barColor.gradient)
                    .frame(width: geometry.size.width * level, height: 24)
                    .animation(.linear(duration: 0.05), value: level)
            }
            .frame(height: 24)

            Text(String(format: "%.1f dB", monitor.decibels))
                .font(.caption.monospaced())

            Button(monitor.isMonitoring ? "Stop" : "Start") {
                if monitor.isMonitoring {
                    monitor.stop()
                } else {
                    monitor.start()
                }
            }
            .buttonStyle(.borderedProminent)
        }
        .padding()
    }
}

@MainActor
@Observable
class AudioLevelMonitor {
    var decibels: Float = -60
    var isMonitoring = false

    private let engine = AVAudioEngine()

    func start() {
        do {
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.record, mode: .measurement)
            try session.setActive(true)
        } catch {
            return
        }

        let inputNode = engine.inputNode
        let format = inputNode.outputFormat(forBus: 0)

        inputNode.installTap(onBus: 0, bufferSize: 1024, format: format) { [weak self] buffer, _ in
            guard let channelData = buffer.floatChannelData else { return }
            let frameCount = Int(buffer.frameLength)

            var rms: Float = 0
            vDSP_rmsqv(channelData[0], 1, &rms, vDSP_Length(frameCount))

            let db = rms > 0 ? 20 * log10(rms) : -160

            Task { @MainActor [weak self] in
                self?.decibels = db
            }
        }

        do {
            try engine.start()
            isMonitoring = true
        } catch {
            return
        }
    }

    func stop() {
        engine.inputNode.removeTap(onBus: 0)
        engine.stop()
        isMonitoring = false
        decibels = -60
    }
}
```

---

## Complete Recipe: Music Recognizer (ShazamKit)

```swift
import SwiftUI
import ShazamKit

struct ShazamView: View {
    @State private var recognizer = ShazamRecognizer()

    var body: some View {
        VStack(spacing: 20) {
            if let match = recognizer.matchedSong {
                VStack(spacing: 12) {
                    AsyncImage(url: match.artworkURL) { image in
                        image.resizable().aspectRatio(contentMode: .fit)
                    } placeholder: {
                        RoundedRectangle(cornerRadius: 12)
                            .fill(.gray.opacity(0.2))
                    }
                    .frame(width: 200, height: 200)
                    .clipShape(RoundedRectangle(cornerRadius: 12))

                    Text(match.title ?? "Unknown")
                        .font(.title2.bold())
                    Text(match.artist ?? "Unknown Artist")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
            }

            Button {
                Task { await recognizer.match() }
            } label: {
                Image(systemName: "shazam.logo.fill")
                    .font(.system(size: 64))
                    .foregroundStyle(.blue)
            }
            .disabled(recognizer.isListening)

            if recognizer.isListening {
                ProgressView("Listening...")
            }
        }
        .padding()
    }
}

@MainActor
@Observable
class ShazamRecognizer {
    var matchedSong: SHMediaItem?
    var isListening = false

    private let session = SHManagedSession()

    func match() async {
        isListening = true
        defer { isListening = false }

        let result = await session.result()
        switch result {
        case .match(let match):
            matchedSong = match.mediaItems.first
        case .noMatch:
            matchedSong = nil
        case .error:
            matchedSong = nil
        }
    }
}
```

---

## Key Imports Reference

```swift
import AVFoundation    // AVAudioEngine, AVAudioPlayer, AVAudioRecorder, AVAudioSession
import AVFAudio        // Same as AVFoundation for audio (more targeted import)
import CoreMIDI        // MIDI device communication
import CoreAudioKit    // Bluetooth MIDI UI (CABTMIDICentralViewController)
import SoundAnalysis   // ML-based sound classification
import ShazamKit       // Music recognition
import Speech          // Speech recognition (SFSpeechRecognizer)
import Accelerate      // vDSP, FFT, signal processing
```

---

## Permissions Reference

| Permission         | Key                                                 | Example Value                       |
| ------------------ | --------------------------------------------------- | ----------------------------------- |
| Microphone         | `INFOPLIST_KEY_NSMicrophoneUsageDescription`        | "Record audio for your music"       |
| Speech Recognition | `INFOPLIST_KEY_NSSpeechRecognitionUsageDescription` | "Transcribe your recordings"        |
| Bluetooth          | `INFOPLIST_KEY_NSBluetoothAlwaysUsageDescription`   | "Connect to Bluetooth MIDI devices" |

---

## Audio Format Reference

| Format         | Constant                    | Quality      | File Size | Use Case                      |
| -------------- | --------------------------- | ------------ | --------- | ----------------------------- |
| AAC            | `kAudioFormatMPEG4AAC`      | High         | Small     | General recording, streaming  |
| Apple Lossless | `kAudioFormatAppleLossless` | Lossless     | Medium    | High-quality archival         |
| Linear PCM     | `kAudioFormatLinearPCM`     | Uncompressed | Large     | Real-time processing, editing |
| MP3            | `kAudioFormatMPEGLayer3`    | Good         | Small     | Playback only (no recording)  |

### Common Recording Settings

```swift
// High quality voice recording
let voiceSettings: [String: Any] = [
    AVFormatIDKey: Int(kAudioFormatMPEG4AAC),
    AVSampleRateKey: 44100,
    AVNumberOfChannelsKey: 1,
    AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue
]

// Music quality recording
let musicSettings: [String: Any] = [
    AVFormatIDKey: Int(kAudioFormatAppleLossless),
    AVSampleRateKey: 48000,
    AVNumberOfChannelsKey: 2,
    AVEncoderAudioQualityKey: AVAudioQuality.max.rawValue
]

// Uncompressed for processing
let processingSettings: [String: Any] = [
    AVFormatIDKey: Int(kAudioFormatLinearPCM),
    AVSampleRateKey: 44100,
    AVNumberOfChannelsKey: 1,
    AVLinearPCMBitDepthKey: 16,
    AVLinearPCMIsFloatKey: false
]
```
