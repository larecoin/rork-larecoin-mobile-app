---
index: true
description: "SpriteKit API: SKScene lifecycle, nodes, SKAction, textures, transitions"
---

# SpriteKit — 2D Game Engine Reference

Core SpriteKit APIs: scene setup, nodes, actions, textures, camera, SwiftUI integration.

---

## SwiftUI Integration

```swift
import SpriteKit
import SwiftUI

struct GameView: View {
    var body: some View {
        SpriteView(scene: makeScene(), options: [.allowsTransparency])
            .ignoresSafeArea()
    }

    func makeScene() -> SKScene {
        let scene = GameScene(size: CGSize(width: 390, height: 844))
        scene.scaleMode = .aspectFill
        return scene
    }
}
```

### SpriteView Options

```swift
// All available options — combine with array syntax
SpriteView(
    scene: scene,
    options: [
        .allowsTransparency,       // transparent background (see through to SwiftUI views behind)
        .ignoresSiblingOrder,       // GPU sorts by zPosition only — better performance
        .shouldCullNonVisibleNodes  // skip rendering nodes outside visible bounds
    ]
)

// ❌ WRONG — wrapping SKView in UIViewRepresentable
struct GameViewWrapper: UIViewRepresentable {
    func makeUIView(context: Context) -> SKView { SKView() }
    // ...
}

// ✅ CORRECT — SpriteView handles lifecycle, pausing, and memory correctly
SpriteView(scene: scene)
```

### Transparent Background

```swift
// Required for .allowsTransparency to work
class GameScene: SKScene {
    override func didMove(to view: SKView) {
        backgroundColor = .clear
        view.allowsTransparency = true
    }
}
```

---

## Scene Lifecycle

```swift
class GameScene: SKScene {
    private var lastUpdateTime: TimeInterval = 0

    override func didMove(to view: SKView) {
        // Called once when scene is presented — setup here
        physicsWorld.gravity = CGVector(dx: 0, dy: -9.8)
        physicsWorld.contactDelegate = self
    }

    override func update(_ currentTime: TimeInterval) {
        // Called every frame BEFORE actions and physics
        let deltaTime: TimeInterval
        if lastUpdateTime == 0 {
            deltaTime = 0
        } else {
            deltaTime = currentTime - lastUpdateTime
        }
        lastUpdateTime = currentTime

        // Clamp to prevent teleporting after app backgrounding
        let dt = min(deltaTime, 1.0 / 30.0)
        updateGameLogic(dt: dt)
    }

    override func didEvaluateActions() {
        // After all SKActions processed — resolve action-based state
    }

    override func didSimulatePhysics() {
        // After physics step — clamp positions, update camera
    }

    override func didApplyConstraints() {
        // After SKConstraint evaluation
    }

    override func didFinishUpdate() {
        // Last callback before rendering — final adjustments
    }
}
```

---

## Node Types

### SKSpriteNode

```swift
// From color
let block = SKSpriteNode(color: .red, size: CGSize(width: 50, height: 50))

// From image in asset catalog
let player = SKSpriteNode(imageNamed: "player_idle")
player.size = CGSize(width: 64, height: 64)

// From texture
let texture = SKTexture(imageNamed: "enemy")
let enemy = SKSpriteNode(texture: texture, size: CGSize(width: 48, height: 48))
```

### SKShapeNode

```swift
// Circle
let circle = SKShapeNode(circleOfRadius: 30)
circle.fillColor = .blue
circle.strokeColor = .white
circle.lineWidth = 2

// Rectangle
let rect = SKShapeNode(rectOf: CGSize(width: 100, height: 50), cornerRadius: 8)
rect.fillColor = .green

// Custom path
let path = CGMutablePath()
path.move(to: CGPoint(x: 0, y: 50))
path.addLine(to: CGPoint(x: -40, y: -25))
path.addLine(to: CGPoint(x: 40, y: -25))
path.closeSubpath()
let triangle = SKShapeNode(path: path)
triangle.fillColor = .yellow

// Line
let line = SKShapeNode()
let linePath = CGMutablePath()
linePath.move(to: CGPoint(x: 0, y: 0))
linePath.addLine(to: CGPoint(x: 200, y: 100))
line.path = linePath
line.strokeColor = .white
line.lineWidth = 3
```

### SKLabelNode

```swift
let label = SKLabelNode(text: "Score: 0")
label.fontName = "AvenirNext-Bold"
label.fontSize = 24
label.fontColor = .white
label.horizontalAlignmentMode = .left
label.verticalAlignmentMode = .top

// Multiline text
label.numberOfLines = 0
label.preferredMaxLayoutWidth = 200
label.text = "Game Over\nTap to restart"
```

### SKEmitterNode

```swift
// Load from .sks file created in Xcode Particle Editor
if let emitter = SKEmitterNode(fileNamed: "Fire.sks") {
    emitter.position = player.position
    addChild(emitter)
}

// Programmatic emitter
let sparks = SKEmitterNode()
sparks.particleTexture = SKTexture(imageNamed: "spark")
sparks.particleBirthRate = 100
sparks.particleLifetime = 1.0
sparks.particleSpeed = 200
sparks.particleSpeedRange = 50
sparks.emissionAngle = .pi / 2
sparks.emissionAngleRange = .pi / 4
sparks.particleScale = 0.3
sparks.particleScaleRange = 0.1
sparks.particleAlphaSpeed = -1.0  // fade out over lifetime
sparks.particleColor = .orange
sparks.particleColorBlendFactor = 1.0
```

### SKCropNode

```swift
// Masking — only shows child content where mask is opaque
let cropNode = SKCropNode()
let maskShape = SKShapeNode(circleOfRadius: 100)
maskShape.fillColor = .white
cropNode.maskNode = maskShape

let background = SKSpriteNode(imageNamed: "photo")
cropNode.addChild(background)
addChild(cropNode)
```

### SKEffectNode

```swift
// Apply Core Image filter to children
let effectNode = SKEffectNode()
effectNode.shouldRasterize = true  // cache result for performance
let blur = CIFilter(name: "CIGaussianBlur", parameters: ["inputRadius": 5.0])
effectNode.filter = blur

let content = SKSpriteNode(imageNamed: "background")
effectNode.addChild(content)
addChild(effectNode)
```

### SKVideoNode

```swift
import AVFoundation

guard let videoURL = Bundle.main.url(forResource: "intro", withExtension: "mp4") else { return }
let videoNode = SKVideoNode(url: videoURL)
videoNode.position = CGPoint(x: frame.midX, y: frame.midY)
videoNode.xScale = 0.5
videoNode.yScale = 0.5
addChild(videoNode)
videoNode.play()
```

---

## Node Hierarchy & Positioning

```swift
// Adding and removing
parentNode.addChild(childNode)
childNode.removeFromParent()
parentNode.removeAllChildren()

// Finding nodes by name
let enemy = childNode(withName: "enemy1")

// Recursive search with // prefix
enumerateChildNodes(withName: "//enemy*") { node, stop in
    // finds all nodes whose name starts with "enemy" at any depth
}

// Name patterns:
// "enemy"       — direct children named "enemy"
// "//enemy"     — any descendant named "enemy"
// "//enemy*"    — any descendant with name starting with "enemy"
// "parent/child" — child named "child" under direct child named "parent"
```

### zPosition Layering

```swift
// SpriteKit renders back-to-front by zPosition
let background = SKSpriteNode(imageNamed: "bg")
background.zPosition = -10

let gameLayer = SKNode()
gameLayer.zPosition = 0

let uiLayer = SKNode()
uiLayer.zPosition = 10

let particles = SKEmitterNode(fileNamed: "Rain.sks")!
particles.zPosition = 5  // between game and UI
```

### Transform Properties

```swift
node.position = CGPoint(x: 100, y: 200)  // in parent's coordinate space
node.zRotation = .pi / 4                  // radians, counterclockwise
node.setScale(2.0)                        // uniform scale
node.xScale = 1.5                         // horizontal stretch
node.yScale = -1.0                        // flip vertically
node.alpha = 0.5                          // transparency
node.isHidden = true                      // skip rendering entirely
```

### Coordinate Conversion

```swift
// Convert point between coordinate spaces
let worldPos = childNode.convert(CGPoint.zero, to: scene!)
let localPos = scene!.convert(worldPos, to: parentNode)

// Get node position in scene coordinates
let scenePosition = node.convert(.zero, to: scene!)
```

---

## Textures & Atlases

```swift
// Single texture from asset catalog
let texture = SKTexture(imageNamed: "hero")

// Texture atlas (sprite sheet) — group images in .atlas folder in Xcode
let atlas = SKTextureAtlas(named: "Characters")
let heroTexture = atlas.textureNamed("hero_idle")

// Preload atlas to avoid frame hitches
SKTextureAtlas.preloadTextureAtlases([atlas]) {
    // textures ready — start game
}

// Preload single atlas
atlas.preload {
    // ready
}
```

### Texture Filtering

```swift
// ❌ WRONG — pixel art looks blurry
let texture = SKTexture(imageNamed: "pixel_character")
// default filteringMode is .linear

// ✅ CORRECT — crisp pixels for pixel art
let texture = SKTexture(imageNamed: "pixel_character")
texture.filteringMode = .nearest
```

### Loading Textures from URL

```swift
func loadTexture(from url: URL) async throws -> SKTexture {
    let (data, _) = try await URLSession.shared.data(from: url)
    guard let image = UIImage(data: data) else { throw URLError(.badServerResponse) }
    return SKTexture(image: image)
}

// Usage
Task {
    let texture = try await loadTexture(from: spriteURL)
    let sprite = SKSpriteNode(texture: texture, size: CGSize(width: 64, height: 64))
    texture.filteringMode = .nearest
    addChild(sprite)
}
```

---

## SKAction System

### Movement

```swift
let moveRight = SKAction.move(by: CGVector(dx: 200, dy: 0), duration: 1.0)
let moveTo = SKAction.move(to: CGPoint(x: 300, y: 400), duration: 0.5)
let moveX = SKAction.moveTo(x: 100, duration: 0.3)
let moveY = SKAction.moveTo(y: 500, duration: 0.3)
```

### Rotation & Scale

```swift
let spin = SKAction.rotate(byAngle: .pi * 2, duration: 1.0)
let rotateTo = SKAction.rotate(toAngle: .pi / 4, duration: 0.5)
let scaleUp = SKAction.scale(to: 2.0, duration: 0.3)
let scaleBounce = SKAction.scale(by: 1.2, duration: 0.1)
```

### Fade

```swift
let fadeIn = SKAction.fadeIn(withDuration: 0.5)
let fadeOut = SKAction.fadeOut(withDuration: 0.5)
let fadeHalf = SKAction.fadeAlpha(to: 0.5, duration: 0.3)
```

### Timing

```swift
let wait = SKAction.wait(forDuration: 1.0)
let randomWait = SKAction.wait(forDuration: 2.0, withRange: 1.0)  // 1.5–2.5s
```

### Composition

```swift
// Run in order
let sequence = SKAction.sequence([moveRight, wait, fadeOut, .removeFromParent()])

// Run simultaneously
let group = SKAction.group([spin, scaleUp, fadeHalf])

// Repeat
let repeatThree = SKAction.repeat(spin, count: 3)
let forever = SKAction.repeatForever(sequence)
```

### Code Actions

```swift
let runBlock = SKAction.run {
    self.score += 1
    self.scoreLabel.text = "Score: \(self.score)"
}

let custom = SKAction.customAction(withDuration: 2.0) { node, elapsedTime in
    // elapsedTime goes from 0 to 2.0
    let progress = elapsedTime / 2.0
    node.alpha = CGFloat(1.0 - progress)
}
```

### Sprite Animation

```swift
let frames = [SKTexture(imageNamed: "explosion_1"),
              SKTexture(imageNamed: "explosion_2"),
              SKTexture(imageNamed: "explosion_3")]
let animate = SKAction.animate(with: frames, timePerFrame: 0.1)
```

### Sound

```swift
let sound = SKAction.playSoundFileNamed("coin.wav", waitForCompletion: false)
node.run(.sequence([sound, .removeFromParent()]))
```

### Timing Modes

```swift
let action = SKAction.move(by: CGVector(dx: 200, dy: 0), duration: 1.0)
action.timingMode = .easeIn       // slow start, fast end
action.timingMode = .easeOut      // fast start, slow end
action.timingMode = .easeInEaseOut // slow start and end
action.timingMode = .linear       // constant speed (default)
```

### Named Actions

```swift
// Run with a key — can check/remove by key later
player.run(.repeatForever(walkAnimation), withKey: "walking")

// Stop specific action
player.removeAction(forKey: "walking")

// Check if action is running
if player.action(forKey: "walking") != nil {
    // still walking
}

// Remove all actions
player.removeAllActions()
```

### Practical Example — Character Jump

```swift
let jumpUp = SKAction.moveBy(x: 0, y: 100, duration: 0.3)
jumpUp.timingMode = .easeOut
let jumpDown = SKAction.moveBy(x: 0, y: -100, duration: 0.3)
jumpDown.timingMode = .easeIn
let squash = SKAction.scaleY(to: 0.8, duration: 0.05)
let stretch = SKAction.scaleY(to: 1.0, duration: 0.05)
let jump = SKAction.sequence([squash, stretch, jumpUp, jumpDown, squash, stretch])
player.run(jump)
```

### Practical Example — Spawn Loop

```swift
let spawnEnemy = SKAction.run { [weak self] in
    self?.createEnemy()
}
let waitBetween = SKAction.wait(forDuration: 2.0, withRange: 1.0)
let spawnLoop = SKAction.sequence([spawnEnemy, waitBetween])
run(.repeatForever(spawnLoop), withKey: "spawning")
```

---

## Sprite Animation (Frame-by-Frame)

```swift
let walkFrames = (1...6).map { SKTexture(imageNamed: "player_walk_\($0)") }
walkFrames.forEach { $0.filteringMode = .nearest }
let walkAction = SKAction.animate(with: walkFrames, timePerFrame: 0.1)
player.run(.repeatForever(walkAction), withKey: "walking")

// Stop walking — reset to idle frame
player.removeAction(forKey: "walking")
player.texture = walkFrames[0]
```

### Animation State Machine

```swift
enum AnimationState {
    case idle, walking, jumping, attacking
}

class AnimatedCharacter: SKSpriteNode {
    private var currentAnimation: AnimationState = .idle

    private let idleFrames = (1...4).map { SKTexture(imageNamed: "idle_\($0)") }
    private let walkFrames = (1...6).map { SKTexture(imageNamed: "walk_\($0)") }
    private let jumpFrames = (1...3).map { SKTexture(imageNamed: "jump_\($0)") }

    func setAnimation(_ state: AnimationState) {
        guard state != currentAnimation else { return }
        currentAnimation = state
        removeAction(forKey: "animation")

        let frames: [SKTexture]
        let timePerFrame: TimeInterval
        let repeats: Bool

        switch state {
        case .idle:
            frames = idleFrames
            timePerFrame = 0.2
            repeats = true
        case .walking:
            frames = walkFrames
            timePerFrame = 0.1
            repeats = true
        case .jumping:
            frames = jumpFrames
            timePerFrame = 0.15
            repeats = false
        case .attacking:
            frames = []
            timePerFrame = 0
            repeats = false
        }

        guard !frames.isEmpty else { return }
        let animate = SKAction.animate(with: frames, timePerFrame: timePerFrame)
        let action = repeats ? SKAction.repeatForever(animate) : animate
        run(action, withKey: "animation")
    }
}
```

---

## Camera

See `game-2d.md` for camera patterns (smooth follow, zoom, boundaries). Additional SpriteKit-specific API:

```swift
// SKConstraint-based follow (alternative to manual lerp)
let follow = SKConstraint.distance(SKRange(constantValue: 0), to: playerNode)

// Constrain camera within level bounds
let xRange = SKRange(lowerLimit: size.width / 2, upperLimit: levelWidth - size.width / 2)
let yRange = SKRange(lowerLimit: size.height / 2, upperLimit: levelHeight - size.height / 2)
cam.constraints = [follow, SKConstraint.positionX(xRange, y: yRange)]

// Animated zoom
let zoomIn = SKAction.scale(to: 0.5, duration: 0.3)
zoomIn.timingMode = .easeInEaseOut
cam.run(zoomIn)
```

---

## Touch Handling

### Scene-Level

See `game-2d.md` for touch handling patterns (scene-level, hit testing, drag). SpriteKit-specific: override `isUserInteractionEnabled` on individual nodes for per-node touch handling.

```swift
class InteractiveSprite: SKSpriteNode {
    override var isUserInteractionEnabled: Bool {
        get { true }
        set { }
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        run(.scale(to: 1.2, duration: 0.1))
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        run(.scale(to: 1.0, duration: 0.1))
    }
}
```

---

## Scene Transitions

```swift
let nextScene = Level2Scene(size: size)
nextScene.scaleMode = .aspectFill
let transition = SKTransition.fade(withDuration: 0.5)
view?.presentScene(nextScene, transition: transition)
```

### Transition Types

```swift
SKTransition.fade(withDuration: 1.0)
SKTransition.fade(with: .black, duration: 1.0)
SKTransition.crossFade(withDuration: 0.5)
SKTransition.flipHorizontal(withDuration: 0.5)
SKTransition.flipVertical(withDuration: 0.5)
SKTransition.doorway(withDuration: 1.0)
SKTransition.doorsOpenHorizontal(withDuration: 1.0)
SKTransition.doorsOpenVertical(withDuration: 1.0)
SKTransition.doorsCloseHorizontal(withDuration: 1.0)
SKTransition.doorsCloseVertical(withDuration: 1.0)
SKTransition.push(with: .left, duration: 0.5)
SKTransition.reveal(with: .down, duration: 0.5)
SKTransition.moveIn(with: .right, duration: 0.5)
```

### Passing Data Between Scenes

```swift
class Level2Scene: SKScene {
    var score: Int = 0
    var playerLives: Int = 3
}

// When transitioning
let nextScene = Level2Scene(size: size)
nextScene.scaleMode = .aspectFill
nextScene.score = currentScore
nextScene.playerLives = lives
view?.presentScene(nextScene, transition: .crossFade(withDuration: 0.5))
```

---

## Physics (2D)

See `game-2d.md` for complete physics reference: body types, collision categories (3-mask system), contact delegate with sorted-bodies pattern, forces/impulses, joints, and physics tuning presets in `game-core.md`.

---

## Tilemap (SKTileMapNode)

```swift
// Programmatic tilemap
let tileSet = SKTileSet(named: "GroundTiles")!
let tileMap = SKTileMapNode(
    tileSet: tileSet,
    columns: 20,
    rows: 15,
    tileSize: CGSize(width: 32, height: 32)
)

// Fill with a specific tile group
if let grassGroup = tileSet.tileGroups.first(where: { $0.name == "Grass" }) {
    tileMap.fill(with: grassGroup)
}

// Set individual tiles
if let dirtGroup = tileSet.tileGroups.first(where: { $0.name == "Dirt" }) {
    tileMap.setTileGroup(dirtGroup, forColumn: 5, row: 3)
}

tileMap.enableAutomapping = true  // auto-pick correct edge/corner variants
addChild(tileMap)
```

---

## Complete Mini-Game — Tap-to-Pop

```swift
import SpriteKit
import SwiftUI

struct BubbleGameView: View {
    var body: some View {
        SpriteView(scene: BubbleScene(size: CGSize(width: 390, height: 844)),
                   options: [.ignoresSiblingOrder])
            .ignoresSafeArea()
    }
}

class BubbleScene: SKScene {
    private var score = 0
    private var scoreLabel: SKLabelNode!
    private var lastUpdateTime: TimeInterval = 0
    private var spawnTimer: TimeInterval = 0

    override func didMove(to view: SKView) {
        backgroundColor = SKColor(red: 0.05, green: 0.05, blue: 0.15, alpha: 1.0)
        scaleMode = .aspectFill

        let cam = SKCameraNode()
        addChild(cam)
        camera = cam

        scoreLabel = SKLabelNode(text: "Score: 0")
        scoreLabel.fontName = "AvenirNext-Bold"
        scoreLabel.fontSize = 28
        scoreLabel.fontColor = .white
        scoreLabel.position = CGPoint(x: 0, y: size.height / 2 - 80)
        scoreLabel.zPosition = 100
        cam.addChild(scoreLabel)
    }

    override func update(_ currentTime: TimeInterval) {
        let dt: TimeInterval
        if lastUpdateTime == 0 { dt = 0 } else { dt = currentTime - lastUpdateTime }
        lastUpdateTime = currentTime
        spawnTimer += min(dt, 1.0 / 30.0)

        if spawnTimer > 0.8 {
            spawnTimer = 0
            spawnBubble()
        }
    }

    private func spawnBubble() {
        let radius = CGFloat.random(in: 20...50)
        let bubble = SKShapeNode(circleOfRadius: radius)
        bubble.fillColor = UIColor(
            hue: CGFloat.random(in: 0...1),
            saturation: 0.7,
            brightness: 0.9,
            alpha: 0.8
        )
        bubble.strokeColor = .clear
        bubble.name = "bubble"

        let x = CGFloat.random(in: -size.width / 2 + radius ... size.width / 2 - radius)
        bubble.position = CGPoint(x: x, y: -size.height / 2 - radius)

        let floatUp = SKAction.moveBy(x: 0, y: size.height + radius * 2 + 100, duration: Double.random(in: 3...6))
        let wobble = SKAction.sequence([
            .moveBy(x: 20, y: 0, duration: 0.5),
            .moveBy(x: -20, y: 0, duration: 0.5)
        ])
        let drift = SKAction.group([floatUp, .repeatForever(wobble)])
        bubble.run(.sequence([drift, .removeFromParent()]))
        addChild(bubble)
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else { return }
        let location = touch.location(in: self)
        let tapped = nodes(at: location)

        for node in tapped where node.name == "bubble" {
            score += 1
            scoreLabel.text = "Score: \(score)"

            let pop = SKAction.group([
                .scale(to: 1.5, duration: 0.1),
                .fadeOut(withDuration: 0.1)
            ])
            node.name = nil  // prevent double-tap
            node.run(.sequence([pop, .removeFromParent()]))
        }
    }
}
```

---

## Key Gotchas

### Coordinate System

```swift
// ❌ WRONG assumption — UIKit coordinates
// "top of screen is y = 0, bottom is y = height"

// ✅ CORRECT — SpriteKit has (0,0) at BOTTOM-LEFT
// y increases upward, x increases rightward
// anchorPoint (0,0) = bottom-left of scene
```

### anchorPoint

```swift
// SKSpriteNode.anchorPoint defaults to (0.5, 0.5) — center of sprite
// SKScene.anchorPoint defaults to (0, 0) — bottom-left corner

// ❌ WRONG — placing sprite at bottom-left but it's offset by half its size
let sprite = SKSpriteNode(color: .red, size: CGSize(width: 100, height: 100))
sprite.position = .zero  // center of sprite is at (0,0), not the corner

// ✅ CORRECT — set anchorPoint to bottom-left if you want position = corner
sprite.anchorPoint = CGPoint(x: 0, y: 0)
sprite.position = .zero
```

### scaleMode

```swift
// .aspectFill — scales to fill the view, clips excess (most common for games)
scene.scaleMode = .aspectFill

// .aspectFit — scales to fit inside view, may show letterboxing bars
scene.scaleMode = .aspectFit

// .fill — each axis scaled independently to fill the view (may distort content)
scene.scaleMode = .fill

// .resizeFill — scene is NOT scaled; scene dimensions are automatically resized to match the view
scene.scaleMode = .resizeFill
```

### Pixel Art Rendering

```swift
// ❌ WRONG — pixel art looks blurry and smeared
let sprite = SKSpriteNode(imageNamed: "pixel_hero")

// ✅ CORRECT — set .nearest on EVERY texture used in pixel art games
let texture = SKTexture(imageNamed: "pixel_hero")
texture.filteringMode = .nearest
let sprite = SKSpriteNode(texture: texture)

// For atlas frames too
let frames = (1...4).map { i -> SKTexture in
    let tex = SKTexture(imageNamed: "walk_\(i)")
    tex.filteringMode = .nearest
    return tex
}
```

### Memory — Remove Nodes Properly

```swift
// ❌ WRONG — hiding nodes that will never be shown again wastes memory
enemy.isHidden = true

// ✅ CORRECT — remove from parent when done
enemy.removeFromParent()

// For emitters — set numParticlesToEmit so they stop and auto-remove
let explosion = SKEmitterNode(fileNamed: "Explosion.sks")!
explosion.numParticlesToEmit = 50  // stops after 50 particles
explosion.run(.sequence([
    .wait(forDuration: 2.0),
    .removeFromParent()
]))
```

### Action Retain Cycles

```swift
// ❌ WRONG — strong reference to self in repeatForever action
run(.repeatForever(.run {
    self.spawnEnemy()  // retains self forever
}))

// ✅ CORRECT — use [weak self]
run(.repeatForever(.sequence([
    .run { [weak self] in self?.spawnEnemy() },
    .wait(forDuration: 1.0)
])))
```
