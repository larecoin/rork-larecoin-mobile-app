---
index: true
description: CIFilter catalog, filter chaining, custom CIKernel in Metal
---

# Core Image — GPU-Accelerated Image Processing

Core Image provides 200+ built-in filters for image processing, plus the ability to write custom pixel shaders via Metal. All operations are GPU-accelerated when using a Metal-backed `CIContext`.

**Import:** `import CoreImage`, `import CoreImage.CIFilterBuiltins`

---

## Core Architecture

```
CIImage (immutable, lazy — no pixels yet)
  │
  ▼
CIFilter (transform: blur, color adjust, distortion, etc.)
  │
  ▼
CIImage (output — still lazy, describes the operation graph)
  │
  ▼
CIContext.render() → MTLTexture / CGImage / CVPixelBuffer (pixels materialize)
```

Core Image is **lazy**: filters don't execute until you render. This means chaining 10 filters costs almost the same as 1 — the entire chain is fused into a single GPU pass.

## Setting Up CIContext with Metal

```swift
import CoreImage
import CoreImage.CIFilterBuiltins
import Metal

let device = MTLCreateSystemDefaultDevice()!
let ciContext = CIContext(mtlDevice: device, options: [
    .workingColorSpace: CGColorSpace(name: CGColorSpace.displayP3)!,
    .outputPremultiplied: true,
    .cacheIntermediates: false  // save memory for large images
])
```

**Reuse the CIContext** — creating one is expensive. Create once, use everywhere.

## Using Built-In Filters (Modern API)

Always import `CoreImage.CIFilterBuiltins` for the type-safe API:

```swift
import CoreImage.CIFilterBuiltins

let inputImage = CIImage(image: uiImage)!

// Gaussian Blur
let blur = CIFilter.gaussianBlur()
blur.inputImage = inputImage
blur.radius = 10
let blurred = blur.outputImage!

// Sepia Tone
let sepia = CIFilter.sepiaTone()
sepia.inputImage = inputImage
sepia.intensity = 0.8
let sepiaResult = sepia.outputImage!

// Color Controls (brightness, contrast, saturation)
let colorControls = CIFilter.colorControls()
colorControls.inputImage = inputImage
colorControls.brightness = 0.1
colorControls.contrast = 1.2
colorControls.saturation = 1.5
let adjusted = colorControls.outputImage!
```

## Chaining Filters

```swift
let result = CIImage(image: original)!
    .applyingFilter("CIColorControls", parameters: [
        "inputBrightness": 0.1,
        "inputContrast": 1.2
    ])
    .applyingFilter("CIGaussianBlur", parameters: [
        "inputRadius": 5
    ])
    .applyingFilter("CIVignette", parameters: [
        "inputRadius": 2,
        "inputIntensity": 1.0
    ])
// Still lazy — no GPU work until render
```

## Rendering Output

```swift
// To CGImage (for UIImage / display)
let cgImage = ciContext.createCGImage(ciImage, from: ciImage.extent)!
let uiImage = UIImage(cgImage: cgImage)

// To MTLTexture (for Metal pipeline)
let commandBuffer = commandQueue.makeCommandBuffer()!
ciContext.render(ciImage, to: metalTexture, commandBuffer: commandBuffer,
                bounds: ciImage.extent, colorSpace: CGColorSpace(name: CGColorSpace.sRGB)!)
commandBuffer.commit()

// To CVPixelBuffer (for video / Core ML)
ciContext.render(ciImage, to: pixelBuffer)
```

## Built-In Filter Categories

### Blur

| Filter                          | Key Parameters     | Notes                     |
| ------------------------------- | ------------------ | ------------------------- |
| `CIFilter.gaussianBlur()`       | `radius` (0-100)   | Standard blur             |
| `CIFilter.boxBlur()`            | `radius`           | Fast, blocky              |
| `CIFilter.discBlur()`           | `radius`           | Circular blur             |
| `CIFilter.motionBlur()`         | `radius`, `angle`  | Directional               |
| `CIFilter.zoomBlur()`           | `center`, `amount` | Radial zoom               |
| `CIFilter.maskedVariableBlur()` | `mask`, `radius`   | Blur varies by mask image |

### Color Adjustment

| Filter                             | Key Parameters                                           | Notes                 |
| ---------------------------------- | -------------------------------------------------------- | --------------------- |
| `CIFilter.colorControls()`         | `brightness`, `contrast`, `saturation`                   | Basic adjust          |
| `CIFilter.exposureAdjust()`        | `ev` (-10 to 10)                                         | Exposure compensation |
| `CIFilter.gammaAdjust()`           | `power`                                                  | Gamma correction      |
| `CIFilter.hueAdjust()`             | `angle` (radians)                                        | Rotate color hue      |
| `CIFilter.temperatureAndTint()`    | `neutral`, `targetNeutral` (CIVector)                    | White balance         |
| `CIFilter.vibrance()`              | `amount` (-1 to 1)                                       | Boost muted colors    |
| `CIFilter.whitePointAdjust()`      | `color` (CIColor)                                        | Set white point       |
| `CIFilter.highlightShadowAdjust()` | `highlightAmount`, `shadowAmount`                        | Highlight/shadow      |
| `CIFilter.toneCurve()`             | `point0`-`point4` (CIVector)                             | Custom tone curve     |
| `CIFilter.colorMatrix()`           | `rVector`, `gVector`, `bVector`, `aVector`, `biasVector` | Full color matrix     |

### Color Effect

| Filter                           | Key Parameters                             | Notes                     |
| -------------------------------- | ------------------------------------------ | ------------------------- |
| `CIFilter.sepiaTone()`           | `intensity` (0-1)                          | Classic sepia             |
| `CIFilter.photoEffectMono()`     | —                                          | B&W                       |
| `CIFilter.photoEffectNoir()`     | —                                          | High-contrast B&W         |
| `CIFilter.photoEffectChrome()`   | —                                          | Vivid colors              |
| `CIFilter.photoEffectFade()`     | —                                          | Faded vintage             |
| `CIFilter.photoEffectInstant()`  | —                                          | Polaroid style            |
| `CIFilter.photoEffectProcess()`  | —                                          | Cool tone                 |
| `CIFilter.photoEffectTonal()`    | —                                          | Flat B&W                  |
| `CIFilter.photoEffectTransfer()` | —                                          | Warm tone                 |
| `CIFilter.colorInvert()`         | —                                          | Negate colors             |
| `CIFilter.colorPosterize()`      | `levels` (2-30)                            | Reduce color levels       |
| `CIFilter.falseColor()`          | `color0`, `color1`                         | Map luminance to 2 colors |
| `CIFilter.colorMonochrome()`     | `color`, `intensity`                       | Monochrome tint           |
| `CIFilter.vignette()`            | `radius`, `intensity`                      | Dark edges                |
| `CIFilter.vignetteEffect()`      | `center`, `radius`, `intensity`, `falloff` | Positioned vignette       |

### Distortion

| Filter                              | Key Parameters                    | Notes            |
| ----------------------------------- | --------------------------------- | ---------------- |
| `CIFilter.bumpDistortion()`         | `center`, `radius`, `scale`       | Bump/dent        |
| `CIFilter.twirlDistortion()`        | `center`, `radius`, `angle`       | Swirl            |
| `CIFilter.pinchDistortion()`        | `center`, `radius`, `scale`       | Pinch            |
| `CIFilter.holeDistortion()`         | `center`, `radius`                | Black hole       |
| `CIFilter.circleSplashDistortion()` | `center`, `radius`                | Circle splash    |
| `CIFilter.glassDistortion()`        | `textureImage`, `center`, `scale` | Glass refraction |

### Stylize

| Filter                   | Key Parameters                                                           | Notes             |
| ------------------------ | ------------------------------------------------------------------------ | ----------------- |
| `CIFilter.bloom()`       | `radius`, `intensity`                                                    | Soft glow         |
| `CIFilter.gloom()`       | `radius`, `intensity`                                                    | Dark glow         |
| `CIFilter.pixellate()`   | `scale`                                                                  | Mosaic            |
| `CIFilter.crystallize()` | `radius`                                                                 | Crystal mosaic    |
| `CIFilter.pointillize()` | `radius`                                                                 | Pointillism       |
| `CIFilter.comicEffect()` | —                                                                        | Comic book style  |
| `CIFilter.edges()`       | `intensity`                                                              | Edge detection    |
| `CIFilter.edgeWork()`    | `radius`                                                                 | Woodcut/linocut   |
| `CIFilter.lineOverlay()` | `nrNoiseLevel`, `nrSharpness`, `edgeIntensity`, `threshold`, `contrast`  | Line drawing      |
| `CIFilter.spotLight()`   | `lightPosition`, `lightPointsAt`, `brightness`, `concentration`, `color` | Spot light effect |

### Compositing (Blend Modes as Filters)

| Filter                             | Equivalent Blend Mode     |
| ---------------------------------- | ------------------------- |
| `CIFilter.multiplyCompositing()`   | Multiply                  |
| `CIFilter.screenBlendMode()`       | Screen                    |
| `CIFilter.overlayBlendMode()`      | Overlay                   |
| `CIFilter.darkenBlendMode()`       | Darken                    |
| `CIFilter.lightenBlendMode()`      | Lighten                   |
| `CIFilter.colorDodgeBlendMode()`   | Color Dodge               |
| `CIFilter.colorBurnBlendMode()`    | Color Burn                |
| `CIFilter.softLightBlendMode()`    | Soft Light                |
| `CIFilter.hardLightBlendMode()`    | Hard Light                |
| `CIFilter.differenceBlendMode()`   | Difference                |
| `CIFilter.exclusionBlendMode()`    | Exclusion                 |
| `CIFilter.hueBlendMode()`          | Hue                       |
| `CIFilter.saturationBlendMode()`   | Saturation                |
| `CIFilter.colorBlendMode()`        | Color                     |
| `CIFilter.luminosityBlendMode()`   | Luminosity                |
| `CIFilter.sourceOverCompositing()` | Normal (Porter-Duff over) |
| `CIFilter.sourceAtopCompositing()` | Source atop               |
| `CIFilter.additionCompositing()`   | Add                       |

Usage:

```swift
let blend = CIFilter.multiplyCompositing()
blend.inputImage = topLayer     // foreground
blend.backgroundImage = bottomLayer  // background
let result = blend.outputImage!
```

### Generators (Create Images from Nothing)

| Filter                               | Output               |
| ------------------------------------ | -------------------- |
| `CIFilter.checkerboardGenerator()`   | Checkerboard pattern |
| `CIFilter.stripesGenerator()`        | Stripe pattern       |
| `CIFilter.randomGenerator()`         | Random noise         |
| `CIFilter.gaussianGradient()`        | Radial gradient      |
| `CIFilter.linearGradient()`          | Linear gradient      |
| `CIFilter.radialGradient()`          | Radial gradient      |
| `CIFilter.qrCodeGenerator()`         | QR code from data    |
| `CIFilter.aztecCodeGenerator()`      | Aztec barcode        |
| `CIFilter.code128BarcodeGenerator()` | Code 128 barcode     |
| `CIFilter.starShineGenerator()`      | Star/lens flare      |
| `CIFilter.sunbeamsGenerator()`       | Light ray beams      |

---

## Custom CIKernel in Metal

Write custom per-pixel processing in Metal Shading Language.

### Step 1: Create a `.metal` File

The file must include Core Image headers and use specific function signatures:

```metal
// CustomFilters.metal
#include <CoreImage/CoreImage.h>

extern "C" {
    // CIColorKernel — operates on color only (no position needed)
    float4 thresholdFilter(coreimage::sample_t pixel, float threshold) {
        float luma = dot(pixel.rgb, float3(0.2126, 0.7152, 0.0722));
        return luma > threshold ? float4(1.0) : float4(0.0, 0.0, 0.0, 1.0);
    }

    // CIKernel — has access to position and can sample at arbitrary coordinates
    float4 pixelShift(coreimage::sampler src, float2 offset, coreimage::destination dest) {
        float2 pos = dest.coord() + offset;
        return src.sample(src.transform(pos));
    }

    // CIWarpKernel — returns position only (for geometric distortion)
    float2 rippleWarp(float2 center, float radius, float amplitude,
                      coreimage::destination dest) {
        float2 pos = dest.coord();
        float dist = distance(pos, center);
        if (dist < radius) {
            float angle = (1.0 - dist / radius) * amplitude;
            float2 offset = float2(sin(angle), cos(angle)) * dist * 0.1;
            return pos + offset;
        }
        return pos;
    }
}
```

### Step 2: Build Settings

Add `-fcikernel` to **Other Metal Compiler Flags** and link the compiled `.ci.metallib`:

1. Build Settings → **Other Metal Compiler Flags**: add `-fcikernel`
2. Build Settings → **User-Defined** → add `MTLLINKER_FLAGS` = `-cikernel`

### Step 3: Load and Use from Swift

```swift
class ThresholdFilter: CIFilter {
    var inputImage: CIImage?
    var threshold: Float = 0.5

    private static var kernel: CIColorKernel? = {
        guard let url = Bundle.main.url(forResource: "default", withExtension: "ci.metallib"),
              let data = try? Data(contentsOf: url) else { return nil }
        return try? CIColorKernel(functionName: "thresholdFilter", fromMetalLibraryData: data)
    }()

    override var outputImage: CIImage? {
        guard let input = inputImage, let kernel = Self.kernel else { return nil }
        return kernel.apply(extent: input.extent, arguments: [input, threshold])
    }
}

// Usage
let filter = ThresholdFilter()
filter.inputImage = ciImage
filter.threshold = 0.4
let result = filter.outputImage!
```

### Kernel Types

| Type            | Signature                                       | Access                | Use Case                           |
| --------------- | ----------------------------------------------- | --------------------- | ---------------------------------- |
| `CIColorKernel` | `float4 fn(sample_t pixel, ...)`                | Current pixel only    | Color adjustments                  |
| `CIWarpKernel`  | `float2 fn(..., destination dest)`              | Returns new position  | Distortion effects                 |
| `CIKernel`      | `float4 fn(sampler src, ..., destination dest)` | Any pixel via sampler | Blur, convolution, neighbor access |

---

## Metal Performance Shaders (MPS) — Optimized GPU Filters

MPS provides Apple-tuned GPU kernels that are faster than equivalent CIFilter for many operations. No shader code needed.

```swift
import MetalPerformanceShaders

let device = MTLCreateSystemDefaultDevice()!
let commandQueue = device.makeCommandQueue()!
```

### Image Filters

```swift
let commandBuffer = commandQueue.makeCommandBuffer()!

// Gaussian Blur (faster than CIGaussianBlur for large radii)
let blur = MPSImageGaussianBlur(device: device, sigma: 10)
blur.encode(commandBuffer: commandBuffer, sourceTexture: inputTexture, destinationTexture: outputTexture)

// Lanczos Scale (high-quality resize)
let scale = MPSImageLanczosScale(device: device)
var scaleTransform = MPSScaleTransform(scaleX: 0.5, scaleY: 0.5, translateX: 0, translateY: 0)
withUnsafePointer(to: &scaleTransform) { scale.scaleTransform = $0 }
scale.encode(commandBuffer: commandBuffer, sourceTexture: inputTexture, destinationTexture: outputTexture)

// Sobel Edge Detection
let sobel = MPSImageSobel(device: device)
sobel.encode(commandBuffer: commandBuffer, sourceTexture: inputTexture, destinationTexture: outputTexture)

// Threshold (binary)
let threshold = MPSImageThresholdBinary(device: device, thresholdValue: 0.5, maximumValue: 1.0, linearGrayColorTransform: nil)
threshold.encode(commandBuffer: commandBuffer, sourceTexture: inputTexture, destinationTexture: outputTexture)

// Histogram
var histogramInfo = MPSImageHistogramInfo(
    numberOfHistogramEntries: 256,
    histogramForAlpha: false,
    minPixelValue: vector_float4(0, 0, 0, 0),
    maxPixelValue: vector_float4(1, 1, 1, 1)
)
let histogram = MPSImageHistogram(device: device, histogramInfo: &histogramInfo)
let histogramBuffer = device.makeBuffer(length: histogram.histogramSize(forSourceFormat: .rgba8Unorm))!
histogram.encode(to: commandBuffer, sourceTexture: inputTexture, histogram: histogramBuffer, histogramOffset: 0)

// Morphology (dilate/erode for selection expansion)
let dilate = MPSImageAreaMax(device: device, kernelWidth: 5, kernelHeight: 5)
let erode = MPSImageAreaMin(device: device, kernelWidth: 5, kernelHeight: 5)

// Median filter (noise reduction preserving edges)
let median = MPSImageMedian(device: device, kernelDiameter: 5)

// Transpose (flip)
let transpose = MPSImageTranspose(device: device)

commandBuffer.commit()
```

### MPS vs CIFilter When to Use Which

| Operation      | Use MPS When                | Use CIFilter When              |
| -------------- | --------------------------- | ------------------------------ |
| Blur           | Large radius, real-time     | Part of a filter chain         |
| Resize         | Quality matters, thumbnails | Combined with other transforms |
| Edge detection | Standalone operation        | Combined with other effects    |
| Histogram      | Need raw histogram data     | Don't need raw data            |
| Color adjust   | N/A (no MPS equivalent)     | Always use CIFilter            |
| Custom effect  | N/A                         | Always use CIKernel            |
| Compositing    | N/A                         | Always use CIFilter blend      |

**Rule of thumb:** Use MPS for single, performance-critical image operations on MTLTextures. Use CIFilter for multi-step processing pipelines and color adjustments.

---

## Practical Patterns

### Photo Filter App (CIFilter Chain)

```swift
@MainActor
@Observable
class PhotoFilterModel {
    var filteredImage: UIImage?

    private let ciContext = CIContext(mtlDevice: MTLCreateSystemDefaultDevice()!)

    func applyFilters(to image: UIImage, brightness: Float, contrast: Float,
                      saturation: Float, blurRadius: Float) {
        guard let ciImage = CIImage(image: image) else { return }

        var result = ciImage

        // Color controls
        let colorFilter = CIFilter.colorControls()
        colorFilter.inputImage = result
        colorFilter.brightness = brightness
        colorFilter.contrast = contrast
        colorFilter.saturation = saturation
        result = colorFilter.outputImage!

        // Blur
        if blurRadius > 0 {
            let blur = CIFilter.gaussianBlur()
            blur.inputImage = result
            blur.radius = blurRadius
            result = blur.outputImage!.cropped(to: ciImage.extent)
        }

        // Render
        guard let cgImage = ciContext.createCGImage(result, from: ciImage.extent) else { return }
        filteredImage = UIImage(cgImage: cgImage)
    }
}
```

### Real-Time Camera Filter

```swift
import AVFoundation

// In AVCaptureVideoDataOutputSampleBufferDelegate:
func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer,
                   from connection: AVCaptureConnection) {
    guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
    let ciImage = CIImage(cvPixelBuffer: pixelBuffer)

    let filter = CIFilter.sepiaTone()
    filter.inputImage = ciImage
    filter.intensity = 0.8

    guard let output = filter.outputImage else { return }
    ciContext.render(output, to: pixelBuffer)
    // Display pixelBuffer in Metal view
}
```
