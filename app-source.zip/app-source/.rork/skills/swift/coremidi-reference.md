---
index: true
description: MIDI setup, device discovery, events, virtual endpoints
---

# CoreMIDI — MIDI Communication

CoreMIDI provides communication with MIDI devices (keyboards, drum pads, controllers, synthesizers) over USB, Bluetooth, and network. It's a C-based framework with Swift bridging.

**Import:** `import CoreMIDI`

---

## Core Concepts

```
MIDI Client (your app)
├── Input Port   — receives messages FROM devices
├── Output Port  — sends messages TO devices
└── Virtual Endpoints — make your app appear as a MIDI device
```

**Key types:**

- `MIDIClientRef` — your app's MIDI identity
- `MIDIPortRef` — a port for sending or receiving
- `MIDIEndpointRef` — a specific MIDI source or destination
- `MIDIDeviceRef` — a physical MIDI device
- `MIDIEntityRef` — a logical grouping within a device

## Setting Up a MIDI Client

```swift
import CoreMIDI

class MIDIManager {
    var client: MIDIClientRef = 0
    var inputPort: MIDIPortRef = 0
    var outputPort: MIDIPortRef = 0

    func setup() throws {
        var status = MIDIClientCreateWithBlock("MyApp" as CFString, &client) { notification in
            let messageID = notification.pointee.messageID
            switch messageID {
            case .msgSetupChanged:
                // MIDI configuration changed (device connected/disconnected)
                break
            case .msgObjectAdded:
                // New MIDI object added
                break
            case .msgObjectRemoved:
                // MIDI object removed
                break
            default: break
            }
        }
        guard status == noErr else { throw MIDIError.clientCreationFailed }

        // Create input port (receives MIDI from external devices)
        status = MIDIInputPortCreateWithProtocol(
            client,
            "Input" as CFString,
            ._1_0,
            &inputPort
        ) { [weak self] eventList, _ in
            self?.handleMIDIEvents(eventList)
        }
        guard status == noErr else { throw MIDIError.inputPortFailed }

        // Create output port (sends MIDI to external devices)
        status = MIDIOutputPortCreate(client, "Output" as CFString, &outputPort)
        guard status == noErr else { throw MIDIError.outputPortFailed }
    }

    enum MIDIError: Error {
        case clientCreationFailed, inputPortFailed, outputPortFailed
    }
}
```

## Discovering MIDI Devices

```swift
func getAvailableSources() -> [(name: String, endpoint: MIDIEndpointRef)] {
    var sources: [(String, MIDIEndpointRef)] = []
    let sourceCount = MIDIGetNumberOfSources()

    for i in 0..<sourceCount {
        let endpoint = MIDIGetSource(i)
        var name: Unmanaged<CFString>?
        MIDIObjectGetStringProperty(endpoint, kMIDIPropertyName, &name)
        let deviceName = (name?.takeRetainedValue() as String?) ?? "Unknown"
        sources.append((deviceName, endpoint))
    }
    return sources
}

func getAvailableDestinations() -> [(name: String, endpoint: MIDIEndpointRef)] {
    var destinations: [(String, MIDIEndpointRef)] = []
    let destCount = MIDIGetNumberOfDestinations()

    for i in 0..<destCount {
        let endpoint = MIDIGetDestination(i)
        var name: Unmanaged<CFString>?
        MIDIObjectGetStringProperty(endpoint, kMIDIPropertyName, &name)
        let deviceName = (name?.takeRetainedValue() as String?) ?? "Unknown"
        destinations.append((deviceName, endpoint))
    }
    return destinations
}
```

## Connecting to a Source (Receiving MIDI)

```swift
func connectToSource(_ source: MIDIEndpointRef) {
    MIDIPortConnectSource(inputPort, source, nil)
}

func disconnectFromSource(_ source: MIDIEndpointRef) {
    MIDIPortDisconnectSource(inputPort, source)
}
```

## Handling Incoming MIDI Events

```swift
func handleMIDIEvents(_ eventListPtr: UnsafePointer<MIDIEventList>) {
    let eventList = eventListPtr.pointee
    var packet = eventList.packet

    // Modern iteration using unsafeSequence (iOS 15+)
    eventListPtr.unsafeSequence().forEach { packet in
        packet.pointee.wordSequence().forEach { word in
            let messageType = (word >> 28) & 0xF

            // Only handle MIDI 1.0 Channel Voice Messages (message type 0x2)
            guard messageType == 0x2 else { return }

            let status = (word >> 20) & 0xF
            let channel = (word >> 16) & 0xF

            switch status {
            case 0x9: // Note On
                let note = (word >> 8) & 0x7F
                let velocity = word & 0x7F
                if velocity > 0 {
                    noteOn(note: UInt8(note), velocity: UInt8(velocity), channel: UInt8(channel))
                } else {
                    noteOff(note: UInt8(note), channel: UInt8(channel))
                }
            case 0x8: // Note Off
                let note = (word >> 8) & 0x7F
                noteOff(note: UInt8(note), channel: UInt8(channel))
            case 0xB: // Control Change
                let controller = (word >> 8) & 0x7F
                let value = word & 0x7F
                controlChange(controller: UInt8(controller), value: UInt8(value), channel: UInt8(channel))
            case 0xE: // Pitch Bend
                let lsb = (word >> 8) & 0x7F
                let msb = word & 0x7F
                let bendValue = Int(msb << 7 | lsb) - 8192 // -8192 to 8191
                pitchBend(value: bendValue, channel: UInt8(channel))
            default: break
            }
        }
    }
}

func noteOn(note: UInt8, velocity: UInt8, channel: UInt8) {
    // Handle note on — trigger sound, light up UI, etc.
}

func noteOff(note: UInt8, channel: UInt8) {
    // Handle note off — stop sound, dim UI, etc.
}

func controlChange(controller: UInt8, value: UInt8, channel: UInt8) {
    // Handle CC messages — knobs, faders, mod wheel, etc.
}

func pitchBend(value: Int, channel: UInt8) {
    // Handle pitch bend wheel
}
```

## Sending MIDI Messages

```swift
func sendNoteOn(note: UInt8, velocity: UInt8, channel: UInt8, to destination: MIDIEndpointRef) {
    var packet = MIDIEventList()
    var packetPtr = MIDIEventListInit(&packet, ._1_0)

    let noteOnWord: UInt32 = UInt32(0x20900000)
        | (UInt32(channel) << 16)
        | (UInt32(note) << 8)
        | UInt32(velocity)

    packetPtr = MIDIEventListAdd(&packet, MemoryLayout<MIDIEventList>.size, packetPtr, 0, 1, [noteOnWord])
    MIDISendEventList(outputPort, destination, &packet)
}

func sendNoteOff(note: UInt8, channel: UInt8, to destination: MIDIEndpointRef) {
    var packet = MIDIEventList()
    var packetPtr = MIDIEventListInit(&packet, ._1_0)

    let noteOffWord: UInt32 = UInt32(0x20800000)
        | (UInt32(channel) << 16)
        | (UInt32(note) << 8)

    packetPtr = MIDIEventListAdd(&packet, MemoryLayout<MIDIEventList>.size, packetPtr, 0, 1, [noteOffWord])
    MIDISendEventList(outputPort, destination, &packet)
}

func sendControlChange(controller: UInt8, value: UInt8, channel: UInt8, to destination: MIDIEndpointRef) {
    var packet = MIDIEventList()
    var packetPtr = MIDIEventListInit(&packet, ._1_0)

    let ccWord: UInt32 = UInt32(0x20B00000)
        | (UInt32(channel) << 16)
        | (UInt32(controller) << 8)
        | UInt32(value)

    packetPtr = MIDIEventListAdd(&packet, MemoryLayout<MIDIEventList>.size, packetPtr, 0, 1, [ccWord])
    MIDISendEventList(outputPort, destination, &packet)
}
```

## MIDI Note Numbers

| Note | MIDI # | Note          | MIDI # | Note | MIDI # |
| ---- | ------ | ------------- | ------ | ---- | ------ |
| C-1  | 0      | C3            | 48     | C5   | 72     |
| C0   | 12     | C4 (Middle C) | 60     | C6   | 84     |
| C1   | 24     | A4 (440Hz)    | 69     | C7   | 96     |
| C2   | 36     | C#4           | 61     | C8   | 108    |

## Common Control Change Numbers

| CC # | Name             | Typical Use           |
| ---- | ---------------- | --------------------- |
| 1    | Modulation Wheel | Vibrato, filter sweep |
| 7    | Volume           | Channel volume        |
| 10   | Pan              | Stereo position       |
| 11   | Expression       | Dynamic volume        |
| 64   | Sustain Pedal    | On (≥64) / Off (<64)  |
| 74   | Filter Cutoff    | Synthesizer filter    |
| 91   | Reverb Send      | Effect level          |
| 93   | Chorus Send      | Effect level          |
| 120  | All Sound Off    | Emergency silence     |
| 123  | All Notes Off    | Release all notes     |

## Virtual MIDI Endpoints

Make your app appear as a MIDI source or destination to other apps:

```swift
var virtualSource: MIDIEndpointRef = 0
var virtualDestination: MIDIEndpointRef = 0

// Create a virtual source (other apps can receive from your app)
MIDISourceCreateWithProtocol(client, "MyApp Output" as CFString, ._1_0, &virtualSource)

// Create a virtual destination (other apps can send to your app)
MIDIDestinationCreateWithProtocol(client, "MyApp Input" as CFString, ._1_0, &virtualDestination) { eventList, _ in
    // Handle incoming MIDI
}
```

## Bluetooth MIDI

CoreMIDI provides a built-in Bluetooth MIDI connection UI:

```swift
import CoreAudioKit

// Present the Bluetooth MIDI setup view
let bluetoothVC = CABTMIDICentralViewController()
// Present it in a navigation controller or sheet
```

**Note:** Requires `CoreAudioKit` framework. Works on iOS, not simulator.

## Network MIDI (Bonjour)

```swift
// Enable network MIDI session
let session = MIDINetworkSession.default()
session.isEnabled = true
session.connectionPolicy = .anyone // or .noOne, .hostsInContactList
```

## MIDIKit (Recommended Third-Party Wrapper)

For complex MIDI projects, consider `MIDIKit` (SPM: `https://github.com/orchetect/MIDIKit`). It wraps CoreMIDI in strongly-typed Swift with MIDI 2.0 support:

```swift
import MIDIKit

let midiManager = ObservableMIDIManager(clientName: "MyApp", model: "MyApp", manufacturer: "MyCompany")
try midiManager.start()

// Create input connection to all available outputs
try midiManager.addInputConnection(
    to: .allOutputs,
    tag: "myInput",
    receiver: .events { events, timeStamp, source in
        for event in events {
            switch event {
            case .noteOn(let payload):
                print("Note \(payload.note) velocity \(payload.velocity)")
            case .noteOff(let payload):
                print("Note off \(payload.note)")
            case .cc(let payload):
                print("CC \(payload.controller) = \(payload.value)")
            default: break
            }
        }
    }
)
```

## Permissions

No special permissions required for wired MIDI. For Bluetooth MIDI, add:

```
INFOPLIST_KEY_NSBluetoothAlwaysUsageDescription = "Connect to Bluetooth MIDI devices";
```

For network MIDI, add:

```
INFOPLIST_KEY_NSLocalNetworkUsageDescription = "Connect to MIDI devices on your network";
INFOPLIST_KEY_NSBonjourServices = "_apple-midi._udp";
```
