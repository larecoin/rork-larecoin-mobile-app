---
index: true
description: glassEffect API, GlassEffectContainer, morphing transitions
---

# Liquid Glass — Comprehensive Reference (iOS 26+)

Apple's most significant design evolution since iOS 7. A translucent, dynamic material that refracts and reflects surrounding content. Features real-time light bending (lensing), specular highlights responding to device motion, and adaptive behavior.

**Rule:** Liquid Glass is for the **navigation layer** only — tab bars, toolbars, sheets, controls. Never apply it to content (lists, tables, media).

---

## Core APIs

| API                                    | Purpose                                                                   |
| -------------------------------------- | ------------------------------------------------------------------------- |
| `.glassEffect()`                       | Apply glass material to any view                                          |
| `.glassEffect(in: Shape)`              | Glass with custom shape                                                   |
| `.glassEffect(.clear)`                 | High-transparency variant for media-rich backgrounds                      |
| `.glassEffect(.identity)`              | No glass effect — content unaffected (useful for conditional glass)       |
| `.glassEffect(.regular.interactive())` | Glass that responds to touch                                              |
| `.glassEffect(.regular.tint(.blue))`   | Tinted glass                                                              |
| `GlassEffectContainer`                 | Groups glass elements — enables morphing, blending, coordinated rendering |
| `.glassEffectID(_:in:)`                | Morphing transitions between glass elements                               |
| `.glassEffectUnion(id:namespace:)`     | Combine separate glass views into one unified shape                       |
| `.buttonStyle(.glass)`                 | Glass button                                                              |
| `.buttonStyle(.glassProminent)`        | Prominent glass button                                                    |

---

## Shapes

```swift
content.glassEffect()                             // default capsule
content.glassEffect(in: .rect(cornerRadius: 16))  // rounded rect
content.glassEffect(in: .capsule)                  // pill
content.glassEffect(in: .circle)                   // circle
content.glassEffect(in: CustomShape())             // any Shape conforming type
```

---

## Styles

```swift
// Regular — default, medium transparency, adapts to any content
content.glassEffect(.regular)

// Clear — high transparency, for media-rich backgrounds
content.glassEffect(.clear)

// Identity — no glass effect, content unaffected (useful for conditional states)
content.glassEffect(.identity)

// Interactive — responds to touch with haptic-like visual feedback
content.glassEffect(.regular.interactive())

// Tinted — color accent
content.glassEffect(.regular.tint(.orange))

// Combined
content.glassEffect(.regular.tint(.blue).interactive())

// For prominent/selected look, use tint + interactive
content.glassEffect(.regular.tint(.accentColor).interactive())
```

---

## GlassEffectContainer

Groups glass elements so they blend, morph, and render as a cohesive unit.

```swift
@available(iOS 26.0, *)
struct ControlCluster: View {
    var body: some View {
        GlassEffectContainer(spacing: 12) {
            HStack(spacing: 12) {
                Button(action: {}) {
                    Image(systemName: "play.fill")
                }
                .glassEffect(in: .circle)

                Button(action: {}) {
                    Image(systemName: "forward.fill")
                }
                .glassEffect(in: .circle)

                Button(action: {}) {
                    Image(systemName: "heart.fill")
                }
                .glassEffect(in: .circle)
            }
            .padding()
        }
    }
}
```

**`spacing` parameter:** Controls when nearby glass elements morph together. Elements within the spacing distance merge into a unified shape; beyond it, they separate. Animating state changes makes elements fluidly combine/split.

---

## glassEffectUnion — Combine Separate Views

Force separate glass elements (not adjacent) to render as one unified shape.

```swift
@available(iOS 26.0, *)
struct MapControls: View {
    @Namespace private var unionNamespace

    var body: some View {
        GlassEffectContainer {
            VStack(spacing: 0) {
                Button(action: {}) {
                    Image(systemName: "location.fill")
                }
                .glassEffectUnion(id: "mapButtons", namespace: unionNamespace)

                Divider()

                Button(action: {}) {
                    Image(systemName: "map.fill")
                }
                .glassEffectUnion(id: "mapButtons", namespace: unionNamespace)

                Divider()

                Button(action: {}) {
                    Image(systemName: "square.2.layers.3d.top.filled")
                }
                .glassEffectUnion(id: "mapButtons", namespace: unionNamespace)
            }
            .buttonStyle(.glassProminent)
        }
    }
}
```

Same `id` + `namespace` = rendered as one glass shape (like Apple Maps stacked controls).

---

## Morphing Transitions — glassEffectID

Smooth hero-like transitions between glass elements across state changes.

```swift
@available(iOS 26.0, *)
struct MorphingToolbar: View {
    @State private var showActions = false
    @Namespace private var morphNamespace

    var body: some View {
        GlassEffectContainer(spacing: 30) {
            if showActions {
                HStack(spacing: 12) {
                    Button("Copy", systemImage: "doc.on.doc") {}
                        .glassEffect(in: .capsule)
                    Button("Share", systemImage: "square.and.arrow.up") {}
                        .glassEffect(in: .capsule)
                    Button("Delete", systemImage: "trash") {}
                        .glassEffect(in: .capsule)
                        .tint(.red)
                }
                .glassEffectID("toolbar", in: morphNamespace)
            }

            Button(action: {
                withAnimation(.bouncy) { showActions.toggle() }
            }) {
                Image(systemName: showActions ? "xmark" : "ellipsis")
            }
            .glassEffect(in: .circle)
            .glassEffectID("toggle", in: morphNamespace)
        }
    }
}
```

The glass material smoothly morphs between the collapsed button and expanded toolbar.

---

## Tab Bar

### Modern Tab API (iOS 18+, glass automatic on iOS 26)

```swift
@available(iOS 26.0, *)
struct MainTabView: View {
    var body: some View {
        TabView {
            Tab("Home", systemImage: "house") {
                NavigationStack {
                    HomeView()
                }
            }

            Tab("Search", systemImage: "magnifyingglass", role: .search) {
                NavigationStack {
                    SearchView()
                        .searchable(text: .constant(""), prompt: "Search...")
                }
            }

            Tab("Profile", systemImage: "person") {
                NavigationStack {
                    ProfileView()
                }
            }
        }
        .tabBarMinimizeBehavior(.onScrollDown)
        .tabViewBottomAccessory {
            Button(action: { }) {
                Image(systemName: "plus")
            }
        }
    }
}
```

### Tab Bar Minimize Behavior

```swift
.tabBarMinimizeBehavior(.onScrollDown)  // collapses tab bar when scrolling down
.tabBarMinimizeBehavior(.onScrollUp)    // collapses when scrolling up
.tabBarMinimizeBehavior(.automatic)     // platform default
.tabBarMinimizeBehavior(.never)         // always visible
```

When minimized, tab bar collapses to show only the selected tab icon. The bottom accessory merges into the minimized bar.

### Tab Bottom Accessory

Floating action button above the tab bar with automatic glass styling:

```swift
.tabViewBottomAccessory {
    Button("New Post", systemImage: "plus") { }
}
```

### Sidebar Adaptable

Tabs become sidebar on iPad, tab bar on iPhone:

```swift
TabView {
    // tabs...
}
.tabViewStyle(.sidebarAdaptable)
```

---

## Navigation Bar & Toolbar

Native navigation bars get glass automatically when compiled against iOS 26 SDK.

```swift
@available(iOS 26.0, *)
struct DetailView: View {
    var body: some View {
        NavigationStack {
            ScrollView {
                // content
            }
            .navigationTitle("Favorites")
            .navigationSubtitle("Synced just now")  // new in iOS 26
            .toolbar {
                ToolbarItemGroup(placement: .topBarTrailing) {
                    Button("Add", systemImage: "plus") {}
                    Button("Share", systemImage: "square.and.arrow.up") {}
                }
            }
            .toolbar {
                ToolbarItem(placement: .bottomBar) {
                    Button("Details", systemImage: "info.circle") {}
                }
            }
        }
    }
}
```

### ToolbarSpacer

Fine-grained control over toolbar layout:

```swift
.toolbar {
    ToolbarItem(placement: .topBarLeading) {
        Button("Back", systemImage: "chevron.left") {}
    }
    ToolbarSpacer(.fixed)
    ToolbarItem(placement: .topBarTrailing) {
        Button("Edit", systemImage: "pencil") {}
    }
}
```

---

## Sheets — Liquid Glass Presentation

Partial-height sheets automatically get the floating Liquid Glass look.

```swift
@available(iOS 26.0, *)
struct SheetExample: View {
    @State private var showSheet = false
    @Namespace private var transition

    var body: some View {
        NavigationStack {
            ContentList()
                .toolbar {
                    ToolbarItem(placement: .bottomBar) {
                        Button("Info", systemImage: "info.circle") {
                            showSheet = true
                        }
                        .matchedTransitionSource(id: "info", in: transition)
                    }
                }
                .sheet(isPresented: $showSheet) {
                    InfoView()
                        .presentationDetents([.medium, .large])
                        .navigationTransition(.zoom(sourceID: "info", in: transition))
                }
        }
    }
}
```

- Partial detents (`.medium`, custom) → floating glass sheet
- `.large` detent → full-screen, opaque background
- `matchedTransitionSource` + `.navigationTransition(.zoom(...))` = morphing from button to sheet
- Must be inside `NavigationStack` for transitions to work
- **Don't** apply `.presentationBackground()` — let the system handle it

---

## Glass Controls

### Buttons

```swift
Button("Action") {}
    .buttonStyle(.glass)            // standard glass
    .controlSize(.large)

Button("Primary") {}
    .buttonStyle(.glassProminent)   // more visible variant
    .tint(.blue)
```

### Toggles

```swift
Toggle("Notifications", isOn: $enabled)
    // Automatically gets floating glass bubble on iOS 26
```

### Pickers

```swift
Picker("Mode", selection: $mode) {
    Text("Light").tag(0)
    Text("Dark").tag(1)
    Text("Auto").tag(2)
}
.pickerStyle(.segmented)
// Segmented control gets glass styling automatically
```

### Menus

```swift
Menu("Options") {
    Button("Copy", action: {})
    Button("Paste", action: {})
    Divider()
    Button("Delete", role: .destructive, action: {})
}
// Menu popup gets frosted-glass overlay automatically
```

---

## Backward Compatibility

Always wrap iOS 26 glass APIs:

```swift
extension View {
    @ViewBuilder
    func adaptiveGlass(in shape: some Shape = .capsule) -> some View {
        if #available(iOS 26.0, *) {
            self.glassEffect(in: shape)
        } else {
            self.background(shape.fill(.ultraThinMaterial))
        }
    }
}
```

More polished fallback with gradient edge highlight:

```swift
extension Shape {
    @ViewBuilder
    func glassedFallback() -> some View {
        self.fill(.ultraThinMaterial)
            .overlay(
                self.fill(
                    .linearGradient(
                        colors: [.white.opacity(0.15), .clear],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
            )
            .overlay(self.stroke(.white.opacity(0.2), lineWidth: 0.5))
    }
}
```

---

## What NOT to Do

1. **Don't apply glass to content** — lists, tables, media, images. Glass is for navigation/controls only.
2. **Don't stack glass on glass** — multiple layers create visual noise.
3. **Don't tint everything** — selective tinting highlights primary actions; universal tinting dilutes focus.
4. **Don't use `.background(.ultraThinMaterial)` with `.glassEffect()`** — they conflict.
5. **Apply padding BEFORE glassEffect** — glass fills the entire frame including padding:
   ```swift
   content.padding().glassEffect()     // ✅ padding inside glass boundary
   content.glassEffect().padding()     // ❌ padding outside glass — creates awkward gap
   ```
6. **Don't use `.presentationBackground()` on sheets** — let iOS 26 apply glass automatically.
7. **Don't force glass on text-heavy content** — readability suffers on translucent backgrounds.

---

## Complete Example: Music Player with Glass UI

```swift
@available(iOS 26.0, *)
struct MusicPlayerView: View {
    @State private var isPlaying = false
    @State private var showQueue = false
    @Namespace private var playerNamespace

    var body: some View {
        ZStack {
            // Background: album art
            Image("album_cover")
                .resizable()
                .scaledToFill()
                .ignoresSafeArea()

            VStack {
                Spacer()

                // Track info
                VStack(spacing: 4) {
                    Text("Song Title")
                        .font(.title2.bold())
                        .foregroundStyle(.white)
                    Text("Artist Name")
                        .font(.subheadline)
                        .foregroundStyle(.white.opacity(0.7))
                }

                // Progress bar
                ProgressView(value: 0.35)
                    .tint(.white)
                    .padding(.horizontal, 40)
                    .padding(.vertical, 20)

                // Controls
                GlassEffectContainer(spacing: 16) {
                    HStack(spacing: 24) {
                        Button(action: {}) {
                            Image(systemName: "backward.fill")
                                .font(.title2)
                        }
                        .glassEffect(in: .circle)

                        Button(action: { isPlaying.toggle() }) {
                            Image(systemName: isPlaying ? "pause.fill" : "play.fill")
                                .font(.title)
                        }
                        .glassEffect(in: .circle)
                        .glassEffectID("playPause", in: playerNamespace)

                        Button(action: {}) {
                            Image(systemName: "forward.fill")
                                .font(.title2)
                        }
                        .glassEffect(in: .circle)
                    }
                    .foregroundStyle(.white)
                }

                // Secondary controls
                HStack(spacing: 32) {
                    Button(action: {}) {
                        Image(systemName: "speaker.wave.2.fill")
                    }
                    Button(action: { showQueue = true }) {
                        Image(systemName: "list.bullet")
                    }
                    Button(action: {}) {
                        Image(systemName: "airplayaudio")
                    }
                }
                .foregroundStyle(.white.opacity(0.7))
                .padding(.top, 20)
                .padding(.bottom, 40)
            }
        }
        .sheet(isPresented: $showQueue) {
            QueueView()
                .presentationDetents([.medium, .large])
        }
    }
}
```

## Complete Example: Settings with Glass Sections

```swift
@available(iOS 26.0, *)
struct SettingsView: View {
    @State private var notificationsEnabled = true
    @State private var darkMode = false
    @State private var fontSize: Double = 16

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    // Profile section
                    HStack {
                        Image(systemName: "person.circle.fill")
                            .font(.system(size: 50))
                            .foregroundStyle(.blue)
                        VStack(alignment: .leading) {
                            Text("John Doe")
                                .font(.headline)
                            Text("john@example.com")
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }
                        Spacer()
                        Image(systemName: "chevron.right")
                            .foregroundStyle(.secondary)
                    }
                    .padding()
                    .glassEffect(in: .rect(cornerRadius: 16))

                    // Preferences section
                    VStack(spacing: 0) {
                        Toggle("Notifications", isOn: $notificationsEnabled)
                            .padding()
                        Divider().padding(.leading)
                        Toggle("Dark Mode", isOn: $darkMode)
                            .padding()
                        Divider().padding(.leading)
                        HStack {
                            Text("Font Size")
                            Spacer()
                            Text("\(Int(fontSize))pt")
                                .foregroundStyle(.secondary)
                        }
                        .padding()
                    }
                    .glassEffect(in: .rect(cornerRadius: 16))

                    // Actions
                    GlassEffectContainer(spacing: 12) {
                        Button(action: {}) {
                            Label("Export Data", systemImage: "square.and.arrow.up")
                                .frame(maxWidth: .infinity)
                        }
                        .buttonStyle(.glass)

                        Button(role: .destructive, action: {}) {
                            Label("Delete Account", systemImage: "trash")
                                .frame(maxWidth: .infinity)
                        }
                        .buttonStyle(.glass)
                        .tint(.red)
                    }
                }
                .padding()
            }
            .navigationTitle("Settings")
        }
    }
}
```
