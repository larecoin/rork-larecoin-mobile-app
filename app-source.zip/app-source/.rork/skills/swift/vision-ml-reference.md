---
index: true
description: Subject lifting, OCR, face/body/hand pose, CoreML inference
---

# Vision & Core ML — On-Device Intelligence

Vision provides pre-trained ML models for image analysis (subject detection, text recognition, face/body detection, contour detection). Core ML runs custom ML models on-device for style transfer, super-resolution, classification, and more.

**Import:** `import Vision`, `import CoreML`

---

## Vision Framework

### Subject Lifting / Background Removal (iOS 17+)

```swift
import Vision
import CoreImage
import CoreImage.CIFilterBuiltins

func removeBackground(from image: UIImage) async throws -> UIImage? {
    guard let ciImage = CIImage(image: image) else { return nil }

    let request = VNGenerateForegroundInstanceMaskRequest()
    let handler = VNImageRequestHandler(ciImage: ciImage)
    try handler.perform([request])

    guard let result = request.results?.first else { return nil }

    // Create mask from result
    let maskPixelBuffer = try result.generateScaledMaskForImage(
        forInstances: result.allInstances,
        from: handler
    )
    let maskCIImage = CIImage(cvPixelBuffer: maskPixelBuffer)

    // Apply mask to original image
    let blendFilter = CIFilter.blendWithMask()
    blendFilter.inputImage = ciImage
    blendFilter.maskImage = maskCIImage
    blendFilter.backgroundImage = CIImage(color: .clear).cropped(to: ciImage.extent)

    guard let output = blendFilter.outputImage else { return nil }

    let context = CIContext()
    guard let cgImage = context.createCGImage(output, from: output.extent) else { return nil }
    return UIImage(cgImage: cgImage)
}
```

### Individual Subject Selection

Select specific subjects (e.g., just the person, not the dog):

```swift
func selectSubject(at point: CGPoint, in image: UIImage) async throws -> UIImage? {
    guard let ciImage = CIImage(image: image) else { return nil }

    let request = VNGenerateForegroundInstanceMaskRequest()
    let handler = VNImageRequestHandler(ciImage: ciImage)
    try handler.perform([request])

    guard let result = request.results?.first else { return nil }

    // Find which instance is at the tapped point
    let instances = result.allInstances
    for instance in instances {
        let mask = try result.generateScaledMaskForImage(forInstances: [instance], from: handler)
        // Check if point falls within this instance's mask
        // Use this mask to isolate just this subject
    }
    return nil
}
```

### Text Recognition (OCR)

```swift
func recognizeText(in image: UIImage) async throws -> [String] {
    guard let cgImage = image.cgImage else { return [] }

    let request = VNRecognizeTextRequest()
    request.recognitionLevel = .accurate  // or .fast
    request.recognitionLanguages = ["en-US"]
    request.usesLanguageCorrection = true

    let handler = VNImageRequestHandler(cgImage: cgImage)
    try handler.perform([request])

    guard let observations = request.results else { return [] }

    return observations.compactMap { observation in
        observation.topCandidates(1).first?.string
    }
}
```

### iOS 18+ Simplified Vision API

```swift
import Vision

// iOS 18+ uses Swift concurrency natively
func recognizeTextModern(in image: UIImage) async throws -> [String] {
    guard let cgImage = image.cgImage else { return [] }

    let request = RecognizeTextRequest()
    request.recognitionLevel = .accurate

    let result = try await request.perform(on: cgImage)
    return result.map { $0.topCandidates(1).first?.string ?? "" }
}
```

### Face Detection

```swift
func detectFaces(in image: UIImage) throws -> [VNFaceObservation] {
    guard let cgImage = image.cgImage else { return [] }

    let request = VNDetectFaceRectanglesRequest()
    let handler = VNImageRequestHandler(cgImage: cgImage)
    try handler.perform([request])

    return request.results ?? []
}

// Each VNFaceObservation has:
// .boundingBox — CGRect in normalized coords (0-1, origin bottom-left)
// Convert to image coords:
func convertBoundingBox(_ box: CGRect, imageSize: CGSize) -> CGRect {
    CGRect(
        x: box.origin.x * imageSize.width,
        y: (1 - box.origin.y - box.height) * imageSize.height,
        width: box.width * imageSize.width,
        height: box.height * imageSize.height
    )
}
```

### Face Landmarks

```swift
let request = VNDetectFaceLandmarksRequest()
let handler = VNImageRequestHandler(cgImage: cgImage)
try handler.perform([request])

for face in request.results ?? [] {
    let landmarks = face.landmarks
    let leftEye = landmarks?.leftEye?.normalizedPoints   // [CGPoint]
    let rightEye = landmarks?.rightEye?.normalizedPoints
    let nose = landmarks?.nose?.normalizedPoints
    let outerLips = landmarks?.outerLips?.normalizedPoints
    let faceContour = landmarks?.faceContour?.normalizedPoints
    // Landmark regions: leftEye, rightEye, nose, outerLips, innerLips, faceContour, etc.
}
```

### Body Pose Detection

```swift
func detectBodyPose(in image: UIImage) throws -> [VNHumanBodyPoseObservation] {
    guard let cgImage = image.cgImage else { return [] }

    let request = VNDetectHumanBodyPoseRequest()
    let handler = VNImageRequestHandler(cgImage: cgImage)
    try handler.perform([request])

    for pose in request.results ?? [] {
        // Access individual joints
        if let nose = try? pose.recognizedPoint(.nose) {
            let position = nose.location  // normalized CGPoint
            let confidence = nose.confidence
        }

        // Get all joints by iterating JointName cases
        let allJointNames: [VNHumanBodyPoseObservation.JointName] = [
            .nose, .leftEye, .rightEye, .leftEar, .rightEar,
            .leftShoulder, .rightShoulder, .leftElbow, .rightElbow,
            .leftWrist, .rightWrist, .leftHip, .rightHip,
            .leftKnee, .rightKnee, .leftAnkle, .rightAnkle, .neck, .root
        ]
        let allJoints = allJointNames.compactMap { try? pose.recognizedPoint($0) }
    }

    return request.results ?? []
}
```

### Hand Pose Detection

```swift
let request = VNDetectHumanHandPoseRequest()
request.maximumHandCount = 2

let handler = VNImageRequestHandler(cgImage: cgImage)
try handler.perform([request])

for hand in request.results ?? [] {
    // 21 joints per hand
    let thumbTip = try? hand.recognizedPoint(.thumbTip)
    let indexTip = try? hand.recognizedPoint(.indexTip)
    let middleTip = try? hand.recognizedPoint(.middleTip)
    let ringTip = try? hand.recognizedPoint(.ringTip)
    let littleTip = try? hand.recognizedPoint(.littleTip)
    let wrist = try? hand.recognizedPoint(.wrist)
}
```

### Contour Detection

Extract edges/outlines from an image (auto-trace for vector conversion):

```swift
let request = VNDetectContoursRequest()
request.contrastAdjustment = 1.0
request.maximumImageDimension = 512

let handler = VNImageRequestHandler(cgImage: cgImage)
try handler.perform([request])

if let contours = request.results?.first {
    let topLevelCount = contours.topLevelContourCount

    for i in 0..<topLevelCount {
        let contour = try contours.contour(at: IndexPath(index: i))
        let path = contour.normalizedPath  // CGPath in normalized coords
        let pointCount = contour.pointCount
        // Convert to UIBezierPath for rendering
        let bezierPath = UIBezierPath(cgPath: path)
    }
}
```

### Saliency (What's Interesting in an Image)

```swift
// Attention-based (where do people look?)
let attention = VNGenerateAttentionBasedSaliencyImageRequest()

// Objectness-based (where are the objects?)
let objectness = VNGenerateObjectnessBasedSaliencyImageRequest()

let handler = VNImageRequestHandler(cgImage: cgImage)
try handler.perform([attention])

if let result = attention.results?.first {
    let salientRegions = result.salientObjects ?? []
    for region in salientRegions {
        let boundingBox = region.boundingBox  // most interesting area
    }
}
```

---

## Core ML — Custom ML Models

### Loading and Running a Model

```swift
import CoreML

// Load a compiled .mlmodelc
let config = MLModelConfiguration()
config.computeUnits = .all  // use GPU + Neural Engine

let model = try MLModel(contentsOf: modelURL, configuration: config)

// Create input
let input = try MLDictionaryFeatureProvider(dictionary: [
    "image": MLFeatureValue(cgImage: cgImage, pixelsWide: 512, pixelsHigh: 512,
                             pixelFormatType: kCVPixelFormatType_32BGRA,
                             options: nil)
])

// Run inference
let output = try model.prediction(from: input)

// Read output
if let outputImage = output.featureValue(for: "output")?.imageBufferValue {
    let ciImage = CIImage(cvPixelBuffer: outputImage)
}
```

### Style Transfer Pattern

```swift
class StyleTransferModel {
    private var model: MLModel?

    func loadModel(named name: String) throws {
        let config = MLModelConfiguration()
        config.computeUnits = .all
        model = try MLModel(contentsOf: Bundle.main.url(forResource: name, withExtension: "mlmodelc")!,
                            configuration: config)
    }

    func applyStyle(to image: CGImage, size: Int = 512) throws -> CGImage? {
        guard let model else { return nil }

        let input = try MLDictionaryFeatureProvider(dictionary: [
            "image": MLFeatureValue(cgImage: image, pixelsWide: size, pixelsHigh: size,
                                     pixelFormatType: kCVPixelFormatType_32BGRA, options: nil)
        ])

        let output = try model.prediction(from: input)

        guard let pixelBuffer = output.featureValue(for: "stylizedImage")?.imageBufferValue else {
            return nil
        }

        let ciImage = CIImage(cvPixelBuffer: pixelBuffer)
        let context = CIContext()
        return context.createCGImage(ciImage, from: ciImage.extent)
    }
}
```

### Vision + Core ML (Custom Classifier)

```swift
// Use a custom CoreML model with Vision
let model = try VNCoreMLModel(for: MyClassifier().model)

let request = VNCoreMLRequest(model: model) { request, error in
    guard let results = request.results as? [VNClassificationObservation] else { return }
    for classification in results.prefix(3) {
        print("\(classification.identifier): \(Int(classification.confidence * 100))%")
    }
}

let handler = VNImageRequestHandler(cgImage: cgImage)
try handler.perform([request])
```

### Available Pre-trained Models on Apple's Model Gallery

Download from developer.apple.com/machine-learning/models:

| Model                | Type             | Use Case                                     |
| -------------------- | ---------------- | -------------------------------------------- |
| MobileNetV2          | Classification   | Identify objects in images                   |
| FCRN-DepthPrediction | Depth estimation | Generate depth maps from 2D photos           |
| DeepLabV3            | Segmentation     | Per-pixel classification (person/sky/ground) |
| YOLOv3               | Object detection | Bounding boxes around objects                |
| PoseNet              | Pose estimation  | Human pose skeleton                          |

### CreateML — Train Custom Models

Train models directly on Mac without Python:

```swift
// In a macOS playground or app:
import CreateML

// Image classifier
let trainingData = MLImageClassifier.DataSource.labeledDirectories(at: trainingURL)
let classifier = try MLImageClassifier(trainingData: trainingData)
try classifier.write(to: outputURL)

// Sound classifier
let soundData = MLSoundClassifier.DataSource.labeledDirectories(at: soundURL)
let soundClassifier = try MLSoundClassifier(trainingData: soundData)
try soundClassifier.write(to: outputURL)
```

---

## Practical Patterns

### Auto-Crop to Subject

```swift
func autoCropToSubject(image: UIImage) throws -> UIImage? {
    guard let cgImage = image.cgImage else { return nil }

    let saliency = VNGenerateAttentionBasedSaliencyImageRequest()
    let handler = VNImageRequestHandler(cgImage: cgImage)
    try handler.perform([saliency])

    guard let result = saliency.results?.first,
          let salientObject = result.salientObjects?.first else { return nil }

    // Convert normalized rect to pixel rect
    let box = salientObject.boundingBox
    let imageSize = CGSize(width: cgImage.width, height: cgImage.height)
    let cropRect = CGRect(
        x: box.origin.x * imageSize.width,
        y: (1 - box.origin.y - box.height) * imageSize.height,
        width: box.width * imageSize.width,
        height: box.height * imageSize.height
    ).insetBy(dx: -20, dy: -20) // padding

    guard let cropped = cgImage.cropping(to: cropRect) else { return nil }
    return UIImage(cgImage: cropped)
}
```

### Drawing App: Pose Reference Overlay

```swift
struct PoseOverlayView: View {
    let image: UIImage
    @State private var joints: [CGPoint] = []

    var body: some View {
        ZStack {
            Image(uiImage: image)
                .resizable()
                .aspectRatio(contentMode: .fit)

            Canvas { context, size in
                let connections: [(VNHumanBodyPoseObservation.JointName, VNHumanBodyPoseObservation.JointName)] = [
                    (.leftShoulder, .leftElbow), (.leftElbow, .leftWrist),
                    (.rightShoulder, .rightElbow), (.rightElbow, .rightWrist),
                    (.leftShoulder, .rightShoulder),
                    (.leftHip, .rightHip),
                    (.leftHip, .leftKnee), (.leftKnee, .leftAnkle),
                    (.rightHip, .rightKnee), (.rightKnee, .rightAnkle),
                ]
                // Draw skeleton lines and joint dots
                for joint in joints {
                    context.fill(Circle().path(in: CGRect(x: joint.x - 4, y: joint.y - 4,
                                                          width: 8, height: 8)), with: .color(.red))
                }
            }
        }
        .task { await detectPose() }
    }

    func detectPose() async {
        guard let cgImage = image.cgImage else { return }
        let request = VNDetectHumanBodyPoseRequest()
        let handler = VNImageRequestHandler(cgImage: cgImage)
        try? handler.perform([request])
        // Convert normalized points to view coords and update joints
    }
}
```

---

## Permissions

No permissions needed for Vision or Core ML — they run entirely on-device with no network or sensor access.

Camera permission (`NSCameraUsageDescription`) needed only if processing live camera frames.
Photo library permission (`NSPhotoLibraryUsageDescription`) needed only if importing user photos.
