---
index: true
description: GCController, keyboard/mouse, GCVirtualController
---

# Game Controller — Physical Controllers, Keyboard, Virtual Controls

GCController, extended gamepad, keyboard/mouse, GCVirtualController for on-screen controls.

---

## Controller Discovery

Listen for connect/disconnect to support hot-plugging.

```swift
import GameController

class InputManager {
    var currentController: GCController?

    func setupControllerSupport() {
        NotificationCenter.default.addObserver(
            forName: .GCControllerDidConnect,
            object: nil,
            queue: .main
        ) { [weak self] notification in
            if let controller = notification.object as? GCController {
                self?.configureController(controller)
            }
        }

        NotificationCenter.default.addObserver(
            forName: .GCControllerDidDisconnect,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            self?.currentController = nil
            self?.fallbackToTouchControls()
        }

        // Check for already-connected controllers
        if let controller = GCController.controllers().first {
            configureController(controller)
        }

        GCController.startWirelessControllerDiscovery {}
    }

    func configureController(_ controller: GCController) {
        currentController = controller
        controller.playerIndex = .index1

        if let gamepad = controller.extendedGamepad {
            configureExtendedGamepad(gamepad)
        }
    }

    func fallbackToTouchControls() {
        // Enable touch/virtual controller
    }
}
```

---

## Extended Gamepad — All Inputs

### Event-Driven (Callbacks)

```swift
func configureExtendedGamepad(_ gamepad: GCExtendedGamepad) {
    // Left thumbstick — movement
    gamepad.leftThumbstick.valueChangedHandler = { _, xValue, yValue in
        // xValue, yValue: -1.0 to 1.0
        self.movePlayer(dx: xValue, dy: yValue)
    }

    // Right thumbstick — camera/aim
    gamepad.rightThumbstick.valueChangedHandler = { _, xValue, yValue in
        self.aimCamera(dx: xValue, dy: yValue)
    }

    // Face buttons
    gamepad.buttonA.pressedChangedHandler = { _, _, pressed in
        if pressed { self.jump() }
    }
    gamepad.buttonB.pressedChangedHandler = { _, _, pressed in
        if pressed { self.dodge() }
    }
    gamepad.buttonX.pressedChangedHandler = { _, _, pressed in
        if pressed { self.attack() }
    }
    gamepad.buttonY.pressedChangedHandler = { _, _, pressed in
        if pressed { self.interact() }
    }

    // Shoulders (digital)
    gamepad.leftShoulder.pressedChangedHandler = { _, _, pressed in
        if pressed { self.previousWeapon() }
    }
    gamepad.rightShoulder.pressedChangedHandler = { _, _, pressed in
        if pressed { self.nextWeapon() }
    }

    // Triggers (analog 0.0–1.0)
    gamepad.leftTrigger.valueChangedHandler = { _, value, pressed in
        self.brake(intensity: value) // analog value for variable braking
    }
    gamepad.rightTrigger.valueChangedHandler = { _, value, pressed in
        self.accelerate(intensity: value)
    }

    // D-pad
    gamepad.dpad.valueChangedHandler = { _, xValue, yValue in
        // xValue: -1 left, 1 right; yValue: -1 down, 1 up
    }

    // Thumbstick buttons (L3/R3)
    gamepad.leftThumbstickButton?.pressedChangedHandler = { _, _, pressed in
        if pressed { self.sprint() }
    }
    gamepad.rightThumbstickButton?.pressedChangedHandler = { _, _, pressed in
        if pressed { self.crouch() }
    }

    // Menu buttons
    gamepad.buttonMenu.pressedChangedHandler = { _, _, pressed in
        if pressed { self.pauseGame() }
    }
    gamepad.buttonOptions?.pressedChangedHandler = { _, _, pressed in
        if pressed { self.openInventory() }
    }
}
```

### Polling (In Game Loop)

```swift
func pollController() {
    guard let gamepad = currentController?.extendedGamepad else { return }

    let moveX = gamepad.leftThumbstick.xAxis.value
    let moveY = gamepad.leftThumbstick.yAxis.value
    let isJumping = gamepad.buttonA.isPressed
    let triggerValue = gamepad.rightTrigger.value

    if moveX != 0 || moveY != 0 {
        movePlayer(dx: moveX, dy: moveY)
    }
}
```

---

## Keyboard Input

Available on iPad and Mac Catalyst.

```swift
func setupKeyboardInput() {
    guard let keyboard = GCKeyboard.coalesced?.keyboardInput else { return }

    keyboard.keyChangedHandler = { _, _, keyCode, pressed in
        switch keyCode {
        case .keyW, .upArrow:
            self.moveUpPressed = pressed
        case .keyA, .leftArrow:
            self.moveLeftPressed = pressed
        case .keyS, .downArrow:
            self.moveDownPressed = pressed
        case .keyD, .rightArrow:
            self.moveRightPressed = pressed
        case .spacebar:
            if pressed { self.jump() }
        case .keyE:
            if pressed { self.interact() }
        case .leftShift:
            self.sprintPressed = pressed
        case .escape:
            if pressed { self.pauseGame() }
        case .one:
            if pressed { self.selectWeapon(0) }
        case .two:
            if pressed { self.selectWeapon(1) }
        case .three:
            if pressed { self.selectWeapon(2) }
        default:
            break
        }
    }
}

// Apply in game loop
func applyKeyboardMovement() {
    var dx: Float = 0
    var dy: Float = 0
    if moveUpPressed { dy += 1 }
    if moveDownPressed { dy -= 1 }
    if moveLeftPressed { dx -= 1 }
    if moveRightPressed { dx += 1 }

    // Normalize diagonal movement
    let length = sqrtf(dx * dx + dy * dy)
    if length > 0 {
        dx /= length
        dy /= length
    }

    let speed: Float = sprintPressed ? 2.0 : 1.0
    movePlayer(dx: dx * speed, dy: dy * speed)
}
```

---

## Mouse Input

```swift
func setupMouseInput() {
    guard let mouse = GCMouse.current?.mouseInput else { return }

    mouse.mouseMovedHandler = { _, deltaX, deltaY in
        self.aimCamera(dx: deltaX, dy: deltaY)
    }

    mouse.leftButton.pressedChangedHandler = { _, _, pressed in
        if pressed { self.shoot() }
    }

    mouse.rightButton?.pressedChangedHandler = { _, _, pressed in
        self.aiming = pressed
    }

    mouse.scroll.valueChangedHandler = { _, xValue, yValue in
        self.cycleWeapon(direction: yValue > 0 ? 1 : -1)
    }
}
```

---

## GCVirtualController — On-Screen Gamepad

System-provided virtual controls. Automatically hidden when a physical controller connects.

```swift
class VirtualControllerManager {
    var virtualController: GCVirtualController?

    func setupVirtualController() async throws {
        let config = GCVirtualController.Configuration()
        config.elements = [
            GCInputLeftThumbstick,
            GCInputButtonA,
            GCInputButtonB,
            GCInputRightShoulder,
        ]

        let vc = GCVirtualController(configuration: config)
        try await vc.connect()
        self.virtualController = vc

        // Treated as a normal GCController — configure same as physical
        if let controller = vc.controller,
           let gamepad = controller.extendedGamepad {
            configureExtendedGamepad(gamepad)
        }
    }

    func teardown() {
        virtualController?.disconnect()
        virtualController = nil
    }
}
```

### Custom Element Configuration

Element positioning is handled by the system. To customize element appearance or behavior, use `updateConfiguration(forElement:configuration:)` with `GCVirtualController.ElementConfiguration` if available on your target OS version.

---

## Unified Input Handler

Support touch, controller, and keyboard with a single abstraction.

```swift
protocol GameInput {
    var moveDirection: SIMD2<Float> { get }
    var aimDirection: SIMD2<Float> { get }
    var jumpPressed: Bool { get }
    var attackPressed: Bool { get }
}

class UnifiedInputManager: GameInput {
    var moveDirection: SIMD2<Float> = .zero
    var aimDirection: SIMD2<Float> = .zero
    var jumpPressed: Bool = false
    var attackPressed: Bool = false

    private var virtualControllerManager = VirtualControllerManager()
    private var hasPhysicalController = false

    // Keyboard state
    private var keyUp = false, keyDown = false, keyLeft = false, keyRight = false

    func setup() async {
        setupControllerNotifications()
        setupKeyboard()

        if GCController.controllers().isEmpty {
            try? await virtualControllerManager.setupVirtualController()
        }
    }

    func update() {
        if let gamepad = GCController.current?.extendedGamepad {
            moveDirection = SIMD2(gamepad.leftThumbstick.xAxis.value,
                                  gamepad.leftThumbstick.yAxis.value)
            aimDirection = SIMD2(gamepad.rightThumbstick.xAxis.value,
                                 gamepad.rightThumbstick.yAxis.value)
            jumpPressed = gamepad.buttonA.isPressed
            attackPressed = gamepad.buttonX.isPressed
        } else {
            var dx: Float = 0, dy: Float = 0
            if keyUp { dy += 1 }
            if keyDown { dy -= 1 }
            if keyLeft { dx -= 1 }
            if keyRight { dx += 1 }
            let len = sqrtf(dx * dx + dy * dy)
            if len > 0 { dx /= len; dy /= len }
            moveDirection = SIMD2(dx, dy)
        }
    }

    private func setupControllerNotifications() {
        NotificationCenter.default.addObserver(
            forName: .GCControllerDidConnect,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            self?.hasPhysicalController = true
            self?.virtualControllerManager.teardown()
        }
        NotificationCenter.default.addObserver(
            forName: .GCControllerDidDisconnect,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            guard let self else { return }
            if GCController.controllers().isEmpty {
                self.hasPhysicalController = false
                Task { try? await self.virtualControllerManager.setupVirtualController() }
            }
        }
    }

    private func setupKeyboard() {
        guard let keyboard = GCKeyboard.coalesced?.keyboardInput else { return }
        keyboard.keyChangedHandler = { [weak self] _, _, keyCode, pressed in
            switch keyCode {
            case .keyW, .upArrow: self?.keyUp = pressed
            case .keyS, .downArrow: self?.keyDown = pressed
            case .keyA, .leftArrow: self?.keyLeft = pressed
            case .keyD, .rightArrow: self?.keyRight = pressed
            case .spacebar: if pressed { self?.jumpPressed = true }
            default: break
            }
        }
    }
}
```

---

## Info.plist — Controller Support Keys

```xml
<!-- Declare supported controller types -->
<key>GCSupportedGameControllers</key>
<array>
    <dict>
        <key>ProfileName</key>
        <string>ExtendedGamepad</string>
    </dict>
    <dict>
        <key>ProfileName</key>
        <string>MicroGamepad</string>
    </dict>
</array>

<!-- Require controller (optional, for Apple TV) -->
<key>GCSupportsControllerUserInteraction</key>
<true/>
```

---

## Tilt Controls (Core Motion)

Accelerometer-based steering for racing games, ball-rolling games, and balance games. Use `CMMotionManager` for device tilt.

### Setup

```swift
import CoreMotion

class TiltInput {
    private let motion = CMMotionManager()
    var tilt: SIMD2<Float> = .zero // x = left/right, y = forward/back

    func start() {
        guard motion.isDeviceMotionAvailable else { return }
        motion.deviceMotionUpdateInterval = 1.0 / 60.0
        motion.startDeviceMotionUpdates(to: .main) { [weak self] data, _ in
            guard let data, let self else { return }
            // pitch = tilt forward/back, roll = tilt left/right
            self.tilt = SIMD2<Float>(
                Float(data.attitude.roll),  // negative = left, positive = right
                Float(data.attitude.pitch)  // negative = toward user, positive = away
            )
        }
    }

    func stop() {
        motion.stopDeviceMotionUpdates()
    }
}
```

### Mapping Tilt to Steering

```swift
// Racing game — map roll to steering angle
let steeringSensitivity: Float = 2.0
let maxSteer: Float = 1.0
let steeringInput = max(-maxSteer, min(tiltInput.tilt.x * steeringSensitivity, maxSteer))

// Ball-rolling game — map both axes to force
let force = SIMD3<Float>(tiltInput.tilt.x * 5.0, 0, -tiltInput.tilt.y * 5.0)
ballEntity.addForce(force, relativeTo: nil)
```

### Calibration

Players hold the device at different angles. Capture the "neutral" position on game start and subtract it.

```swift
extension TiltInput {
    private(set) var calibrationOffset: SIMD2<Float> = .zero

    func calibrate() {
        calibrationOffset = tilt
    }

    var calibratedTilt: SIMD2<Float> {
        tilt - calibrationOffset
    }
}
// Call calibrate() on first tap or at level start
```

**Important:** Create only ONE `CMMotionManager` instance per app. Add `NSMotionUsageDescription` to Info.plist.

---

## Common Mistakes

```swift
// ❌ Only checking GCController.controllers() at launch
// Controllers can connect/disconnect at any time

// ✅ Use notifications for connect/disconnect
NotificationCenter.default.addObserver(forName: .GCControllerDidConnect, ...)

// ❌ Forgetting to normalize diagonal keyboard movement
if keyUp { dy += 1 }
if keyRight { dx += 1 }
// Diagonal moves at sqrt(2) speed

// ✅ Normalize the vector
let length = sqrtf(dx * dx + dy * dy)
if length > 0 { dx /= length; dy /= length }

// ❌ Not hiding virtual controller when physical connects
// Player sees both on-screen buttons and uses physical controller

// ✅ Disconnect virtual controller on physical connect
virtualController?.disconnect()
```

---

## Related Skills

- **game-2d.md** — Virtual joystick and buttons as fallback when no controller
- **game-core.md** — GameManager input bridge pattern
