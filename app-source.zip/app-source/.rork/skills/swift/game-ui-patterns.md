---
index: true
description: "SwiftUI animation building blocks: springs, staggered entrance, PhaseAnimator, blur overlays, button feedback, floating text, health bars, hero transitions"
---

# Game UI — SwiftUI Building Blocks

Reusable animation and interaction primitives for game menus, HUD, and overlays.

For game-specific controls (joystick, action buttons): see `game-2d.md`. For accessibility: see `game-core.md`.

---

## Spring Presets — When to Use What

Spring animations are the default for game UI. Pick the preset that matches the emotional tone.

| Preset                                | Bounce         | Use For                                                  |
| ------------------------------------- | -------------- | -------------------------------------------------------- |
| `.snappy`                             | Minimal        | Buttons, toggles, nav transitions — crisp and responsive |
| `.smooth`                             | None           | Subtle fades, background shifts — calm, no bounce        |
| `.bouncy`                             | High           | Rewards, unlocks, celebrations — playful energy          |
| `.spring(duration: 0.5, bounce: 0.3)` | Custom         | Tune per-element when presets don't fit                  |
| `.interactiveSpring()`                | Gesture-driven | Drag-to-dismiss, swipe cards — follows finger naturally  |

```swift
// Button press
withAnimation(.snappy) { isPressed = false }

// Reward reveal
withAnimation(.bouncy) { showReward = true }

// Background transition
withAnimation(.smooth(duration: 0.8)) { currentTheme = .dark }
```

---

## Button Feedback

Visual + haptic response on taps is high-impact polish.

```swift
struct GameButton<Label: View>: View {
    let action: () -> Void
    @ViewBuilder let label: () -> Label
    @State private var isPressed = false
    private let haptic = UIImpactFeedbackGenerator(style: .medium)

    var body: some View {
        label()
            .scaleEffect(isPressed ? 0.92 : 1.0)
            .opacity(isPressed ? 0.8 : 1.0)
            .animation(.snappy, value: isPressed)
            .onLongPressGesture(minimumDuration: 0, pressing: { pressing in
                isPressed = pressing
                if pressing { haptic.impactOccurred() }
            }, perform: action)
    }
}
```

This wrapper adds press feedback to any button. Adapt the scale, opacity, and haptic style to match the game's feel.

---

## Staggered Entrance

Elements appear one after another with a cascade delay. Use for lists, menu items, grid cells.

```swift
struct StaggeredItem<Content: View>: View {
    let index: Int
    let content: Content
    @State private var appeared = false

    var body: some View {
        content
            .opacity(appeared ? 1 : 0)
            .offset(y: appeared ? 0 : 20)
            .animation(.spring(duration: 0.4, bounce: 0.2).delay(Double(index) * 0.06), value: appeared)
            .onAppear { appeared = true }
    }
}

struct MenuItem: Identifiable {
    let id = UUID()
    let title: String
}

// Usage — wrap each item with its index
let menuItems: [MenuItem] = [
    MenuItem(title: "Play"),
    MenuItem(title: "Settings"),
    MenuItem(title: "Credits"),
]

ForEach(Array(menuItems.enumerated()), id: \.element.id) { index, item in
    StaggeredItem(index: index, content: MenuRow(item: item))
}
```

Adjust `delay` multiplier (0.04–0.1) and `offset` distance for different feels. Smaller delay = snappier cascade, larger = more dramatic.

---

## PhaseAnimator — Multi-Step Entrance

For elements that need a choreographed entrance (bounce in, settle, pulse).

```swift
enum EntryPhase: CaseIterable {
    case hidden, overshoot, settle

    var scale: Double {
        switch self {
        case .hidden: 0.5
        case .overshoot: 1.1
        case .settle: 1.0
        }
    }
    var opacity: Double {
        switch self {
        case .hidden: 0
        case .overshoot, .settle: 1
        }
    }
}

// Apply to any view
Text("GAME OVER")
    .phaseAnimator(EntryPhase.allCases, trigger: showGameOver) { content, phase in
        content
            .scaleEffect(phase.scale)
            .opacity(phase.opacity)
    } animation: { phase in
        switch phase {
        case .hidden: .snappy
        case .overshoot: .spring(duration: 0.3, bounce: 0.4)
        case .settle: .smooth(duration: 0.2)
        }
    }
```

Define phases that match the element's personality. A score counter might `hidden → stretch → settle`. A warning might `hidden → shake → glow → settle`.

---

## Blur Overlay

Frosted glass effect over game content. Use for pause, dialogs, overlays.

```swift
// Overlay pattern — apply on top of the game view
ZStack {
    // Game content underneath
    GameView()

    if showPause {
        // Blur layer
        Color.black.opacity(0.3)
            .background(.ultraThinMaterial)
            .ignoresSafeArea()
            .transition(.opacity)

        // Content on top
        VStack { /* menu content */ }
            .transition(.scale.combined(with: .opacity))
    }
}
.animation(.smooth(duration: 0.3), value: showPause)
```

Combine `.ultraThinMaterial` with a tinted `Color` overlay. Adjust opacity (0.2–0.5) for different moods — lighter for pause, darker for game over.

---

## Floating Text

Animated text that rises and fades. Use for score popups, damage numbers, combo text, pickup labels.

```swift
struct FloatingText: View {
    let text: String
    let color: Color
    @State private var offset: CGFloat = 0
    @State private var opacity: Double = 1

    var body: some View {
        Text(text)
            .font(.system(size: 24, weight: .black, design: .rounded))
            .foregroundStyle(color)
            .offset(y: offset)
            .opacity(opacity)
            .onAppear {
                withAnimation(.easeOut(duration: 0.8)) { offset = -60 }
                withAnimation(.easeIn(duration: 0.8).delay(0.3)) { opacity = 0 }
            }
    }
}
```

Place these at the action point using a `ZStack` + absolute positioning. Create and remove with `id` changes. Scale the font size and distance by importance — big numbers for crits, small for regular hits.

---

## Score Counter with Rolling Animation

Numbers that roll up instead of snapping. Makes score changes feel earned.

```swift
struct RollingCounter: View {
    let value: Int
    @State private var displayValue: Int = 0

    var body: some View {
        Text("\(displayValue)")
            .contentTransition(.numericText(value: displayValue))
            .animation(.snappy, value: displayValue)
            .onChange(of: value) { _, newValue in
                displayValue = newValue
            }
    }
}
```

For large jumps, animate incrementally with a timer for a "slot machine" effect.

---

## Health / Progress Bar

Animated bar that smoothly decreases with damage flash.

```swift
struct AnimatedBar: View {
    let current: Double // 0...1
    let barColor: Color
    @State private var flashOpacity: Double = 0

    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .leading) {
                // Background
                Capsule().fill(.quaternary)

                // Trailing damage flash (shows where health WAS)
                Capsule()
                    .fill(barColor.opacity(0.4))
                    .frame(width: geo.size.width * current)
                    .opacity(flashOpacity)

                // Current value
                Capsule()
                    .fill(barColor)
                    .frame(width: geo.size.width * current)
                    .animation(.smooth(duration: 0.4), value: current)
            }
        }
        .frame(height: 8)
        .onChange(of: current) { old, new in
            if new < old {
                flashOpacity = 1
                withAnimation(.easeOut(duration: 0.6).delay(0.3)) { flashOpacity = 0 }
            }
        }
    }
}
```

The damage flash lingers briefly, then fades — a common pattern in action games (Zelda, Dark Souls). Customize bar color based on value (green → yellow → red) to communicate urgency.

---

## Hero Transitions

Smooth morphing between two views (e.g., level select card → level detail).

```swift
@Namespace private var heroSpace
@State private var selectedLevel: Level?

// Card in grid
ForEach(levels) { level in
    LevelCard(level: level)
        .matchedGeometryEffect(id: level.id, in: heroSpace)
        .onTapGesture { selectedLevel = level }
}

// Expanded detail
if let level = selectedLevel {
    LevelDetail(level: level)
        .matchedGeometryEffect(id: level.id, in: heroSpace)
        .onTapGesture { selectedLevel = nil }
}
```

The view morphs between positions, sizes, and corner radii automatically. Add `.matchedTransitionSource` (iOS 18+) for NavigationLink-based transitions.

---

## Animated Background

SpriteKit particles behind SwiftUI menus. Each game can use different particles to match its theme.

```swift
struct ParticleBackground: View {
    @State private var scene = ParticleScene(size: CGSize(width: 400, height: 800))

    var body: some View {
        SpriteView(scene: scene, options: [.allowsTransparency])
            .ignoresSafeArea()
            .allowsHitTesting(false)
    }
}

class ParticleScene: SKScene {
    override func didMove(to view: SKView) {
        backgroundColor = .clear
        // Create emitter matching game theme — examples:
        // Space game: slow-falling stars with twinkle
        // Fantasy: floating magical sparkles
        // Horror: drifting fog particles
        // Puzzle: gentle geometric shapes
    }
}
```

Layer this behind SwiftUI menus with a `ZStack`. The particles make menus feel alive without committing to a specific visual style.

---

## Countdown Timer

Animated timer with urgency feedback as time runs low.

```swift
struct GameTimer: View {
    let secondsRemaining: Int
    private var isUrgent: Bool { secondsRemaining <= 10 }

    var body: some View {
        Text(timeString)
            .font(.system(size: isUrgent ? 28 : 22, weight: .bold).monospacedDigit())
            .foregroundStyle(isUrgent ? .red : .primary)
            .scaleEffect(isUrgent ? 1.1 : 1.0)
            .animation(.snappy, value: secondsRemaining)
            .sensoryFeedback(isUrgent ? .warning : .selection, trigger: secondsRemaining)
    }

    private var timeString: String {
        let m = secondsRemaining / 60
        let s = secondsRemaining % 60
        return String(format: "%d:%02d", m, s)
    }
}
```

The timer pulses and turns red when urgent. Add `.sensoryFeedback` for haptic tick. Adapt the urgency threshold and visual treatment to the game's pacing.

---

## Principles (Read Before Designing Any Game UI)

1. **One-thumb zone** — Consider placing primary actions in the bottom-center for comfortable one-handed play. Score/timer works well at top, pause in corners.
2. **Feedback on taps** — Scale + haptic by default. Zero-feedback taps on important actions feel broken.
3. **Prefer springs** — Spring animations feel alive for most game UI. Use linear only when intentional (timers, progress fills).
4. **Progressive disclosure** — Show only what's needed now. Reveal features as the player progresses.
5. **Match the game's energy** — A zen puzzle game gets `.smooth` springs and subtle fades. A combat game gets `.bouncy` springs and aggressive scale effects.
6. **Performance** — Animate transforms (`.scaleEffect`, `.offset`, `.opacity`, `.rotation`) not layout (`.frame()`). Transforms are GPU-accelerated.
7. **Consider dark overlays** — Dark UI avoids washing out game content in action/atmospheric games. Light or thematic UI works well for casual/colorful games.
