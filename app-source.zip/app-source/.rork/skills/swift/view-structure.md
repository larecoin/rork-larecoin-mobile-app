---
index: true
description: Modifier ordering rules, view identity and stability, invalidation boundaries, extracting large bodies into real subviews
---

# SwiftUI View Structure & Composition Guide

> Keep view bodies declarative. Extract meaningful sections into real subviews with narrow inputs. Modifier order matters.

## Modifier Ordering

Modifier order matters. Apply in this general sequence:

```swift
Text("Hello")
    // 1. Content modifiers (font, color, text-specific)
    .font(.headline)
    .foregroundStyle(.primary)
    .lineLimit(2)
    // 2. Layout modifiers (frame, padding, alignment)
    .frame(maxWidth: .infinity, alignment: .leading)
    .padding()
    // 3. Background / overlay / border
    .background(.regularMaterial, in: .rect(cornerRadius: 12))
    .overlay {
        RoundedRectangle(cornerRadius: 12).strokeBorder(.separator)
    }
    // 4. Clipping
    .clipShape(.rect(cornerRadius: 12))
    // 5. Shadow
    .shadow(color: .black.opacity(0.1), radius: 8, y: 4)
    // 6. Interaction modifiers
    .onTapGesture { }
    // 7. Lifecycle / data flow
    .task { }
    .onChange(of: value) { _, _ in }
```

### Padding vs Background Order

```swift
// padding THEN background → background includes padding
Text("Tag")
    .padding(.horizontal, 12)
    .padding(.vertical, 6)
    .background(.blue, in: .capsule)

// background THEN padding → padding is outside background
Text("Tag")
    .background(.blue, in: .capsule)
    .padding()  // adds space around the background
```

## View Identity & Stability

SwiftUI uses **structural identity** (position in the view tree) and **explicit identity** (id, ForEach) to track views. Getting this wrong causes lost state and broken animations.

### Don't Swap Views Conditionally at the Same Position

```swift
// ❌ SwiftUI sees these as different views — state is lost, no smooth animation
if isGrid {
    GridView(items: items)  // identity = branch 0
} else {
    ListView(items: items)  // identity = branch 1
}

// ✅ Use a single view with different layout
ScrollView {
    let columns = isGrid
        ? [GridItem(.adaptive(minimum: 150))]
        : [GridItem(.flexible())]
    LazyVGrid(columns: columns) {
        ForEach(items) { item in
            ItemCell(item: item, isGrid: isGrid)
        }
    }
}
```

### Don't Create Objects or Do Expensive Computation in Body

```swift
// ❌ Logic, object creation in body — re-runs every render
var body: some View {
    let formatter = DateFormatter()
    formatter.dateStyle = .medium
    let sorted = items.sorted { $0.date > $1.date }
    List(sorted) { item in
        Text(formatter.string(from: item.date))
    }
}

// ✅ Move repeated transforms out of the rendering path
let sortedItems = viewModel.sortedItems

List(sortedItems) { item in
    Text(item.date, style: .date)
}
```

## Extract Subviews vs Computed Properties

SwiftUI views are invalidation boundaries. When data changes, SwiftUI re-evaluates the smallest view subtree that depends on that data. A computed `some View` property is still inside the parent's body; it improves local readability, but it does not create a new invalidation boundary.

For distinct sections, prefer extracting to **separate struct views** over `@ViewBuilder` computed properties. Give each subview only the data it reads or forwards to children. SwiftUI can skip a struct's `body` when its inputs have not changed, but computed properties re-execute on every parent state change.

```swift
// ✅ Best — section has a narrow input and can be skipped when unchanged
struct ParentView: View {
    @State private var count = 0
    let title: String

    var body: some View {
        VStack {
            Button("Tap: \(count)") { count += 1 }
            ExpensiveSection(title: title)  // body can be skipped during re-evaluation
        }
    }
}

struct ExpensiveSection: View {
    let title: String

    var body: some View {
        Text(title)
        ForEach(0..<100) { i in
            HStack { Image(systemName: "star"); Text("Item \(i)"); Spacer() }
        }
    }
}

// ⚠️ Acceptable for small sections — re-executes on every parent update
private var headerSection: some View {
    HStack {
        Text("Title")
        Spacer()
        Button("Action") { }
    }
}
```

Use **struct extraction** when:

- The section has many views or expensive rendering
- You need to isolate state changes for performance
- The component is reusable
- The parent currently has named sections such as header, content, footer, metadata, or related items

Use **computed properties** when:

- The section is small (2-5 simple views)
- It needs direct access to parent's state without passing many parameters
- It is a tiny repeated fragment with no independent invalidation story

Do not over-extract every small line of markup. The target is meaningful boundaries with clear inputs, not file churn.

## Prefer Modifiers Over Conditional Views

When toggling visibility of the **same view** (not swapping different views), prefer modifiers that preserve view identity:

```swift
// ✅ Same view, different states — preserves identity, animates smoothly
SomeView()
    .opacity(isVisible ? 1 : 0)

// ❌ Creates/destroys view — state lost, no smooth transition
if isVisible {
    SomeView()
}
```

Use conditionals when the views are **fundamentally different**:

```swift
// ✅ Different views — conditional is correct
if isLoggedIn {
    DashboardView()
} else {
    LoginView()
}
```

## Conditional Modifiers — Use Ternary, Not .if() Extensions

When you need to conditionally apply a modifier, use ternary expressions directly. Never create a `.if()` View extension — it changes structural identity on every toggle, breaking animations and losing `@State`.

```swift
// ✅ Ternary — same view identity, animates smoothly
Text("Hello")
    .foregroundStyle(isActive ? .blue : .primary)
    .fontWeight(isActive ? .bold : .regular)
    .background(isActive ? AnyShapeStyle(.blue.opacity(0.1)) : AnyShapeStyle(.clear))

// ❌ Anti-pattern — switches structural identity, breaks state & animations
extension View {
    func `if`<T: View>(_ condition: Bool, transform: (Self) -> T) -> some View {
        if condition { transform(self) } else { self }
    }
}
Text("Hello").if(isActive) { $0.bold().foregroundStyle(.blue) }
```

For modifiers that can't be ternary'd (e.g. adding a `.sheet` or `.overlay` conditionally), it's fine to use `if` in the body — those represent different view structures, not two states of the same view.

## Theming with @Observable

Use a single `Theme` object as the source of truth. Inject at app root, read via `@Environment`.

```swift
@MainActor
@Observable
final class Theme {
    var tintColor: Color = .blue
    var primaryBackground: Color = Color(.systemBackground)
    var secondaryBackground: Color = Color(.secondarySystemBackground)
    var labelColor: Color = .primary
}
```

### Inject at App Root

```swift
@main
struct MyApp: App {
    @State private var theme = Theme()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(theme)
        }
    }
}
```

### Read in Views

```swift
@Environment(Theme.self) private var theme

Text("Title")
    .foregroundStyle(theme.labelColor)
    .background(theme.primaryBackground)
```

Use semantic names (`primaryBackground`, `labelColor`, `tint`) — never sprinkle raw `Color` values in views. Store user-selected values in persistent storage if needed.
