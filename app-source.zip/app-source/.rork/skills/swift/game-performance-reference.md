---
index: true
description: MeshInstancesComponent, LowLevelMesh, trail/ribbon effects, PostProcessEffect (iOS 26+), triangle budgets
---

# RealityKit Game Performance — Instancing, LowLevelMesh, Optimization

MeshInstancesComponent, LowLevelMesh, entity pooling, particles, triangle budgets, draw call reduction.

Practical limits: ~1000 active entities, ~10K active particles, <100 draw calls, <512MB texture memory.

---

## MeshInstancesComponent (WWDC25)

Draw one mesh many times with a single entity. Massive performance win for repeated geometry (trees, asteroids, coins, decorations).

```swift
// Load the mesh to instance (iOS 26+)
let prototype = try await Entity(named: "tree.usdz")
guard let model = prototype.components[ModelComponent.self] else { return }

// Build per-instance transforms
let instanceCount = 200
var transforms: [float4x4] = []
for i in 0..<instanceCount {
    let angle = Float(i) / Float(instanceCount) * .pi * 2
    let radius: Float = Float.random(in: 3...8)
    let x = cos(angle) * radius
    let z = sin(angle) * radius
    let scale = Float.random(in: 0.8...1.2)

    var t = float4x4(1.0)  // identity
    t.columns.3 = SIMD4<Float>(x, 0, z, 1)  // position
    t.columns.0 *= scale
    t.columns.1 *= scale
    t.columns.2 *= scale
    transforms.append(t)
}

// Attach MeshInstancesComponent — renders all instances in one draw call
// API requires mesh reference + instance transforms (exact init may evolve in iOS 26 betas)
let instances = transforms.map { MeshInstancesComponent.Instance(transform: $0) }
prototype.components.set(MeshInstancesComponent(instances: instances))
```

**Key considerations:**

- All instances share the same mesh + materials — can't vary per instance without `LowLevelBuffer` + `CustomMaterial`
- For large areas, split into multiple entities with separate `MeshInstancesComponent` — enables frustum culling
- Uses more CPU than a single merged mesh, but far less memory than individual entities
- Works with `LowLevelBuffer` on iOS/macOS/tvOS to pass per-instance data to `CustomMaterial` shaders

---

## LowLevelMesh (iOS 18+ / visionOS 2+)

Custom vertex buffer layout. Update mesh contents at runtime from CPU or GPU (Metal compute). Use instead of `MeshDescriptor` when mesh changes every frame.

### CPU-Updated LowLevelMesh

```swift
// Define vertex structure (must match Metal shader if using one)
struct GameVertex {
    var position: SIMD3<Float>
    var normal: SIMD3<Float>
    var uv: SIMD2<Float>
}

// Define attributes — tell RealityKit how to read vertex data
let attributes: [LowLevelMesh.Attribute] = [
    .init(semantic: .position, format: .float3, offset: 0),
    .init(semantic: .normal, format: .float3,
          offset: MemoryLayout.offset(of: \GameVertex.normal)!),
    .init(semantic: .uv0, format: .float2,
          offset: MemoryLayout.offset(of: \GameVertex.uv)!)
]

let layouts: [LowLevelMesh.Layout] = [
    .init(bufferIndex: 0, bufferStride: MemoryLayout<GameVertex>.stride)
]

// Pre-allocate capacity (cannot grow after creation)
let maxVertices = 10000
let maxIndices = 60000

let descriptor = LowLevelMesh.Descriptor(
    vertexCapacity: maxVertices,
    vertexAttributes: attributes,
    vertexLayouts: layouts,
    indexCapacity: maxIndices,
    indexType: .uint32
)
let mesh = try LowLevelMesh(descriptor: descriptor)

// Populate vertices on CPU
mesh.withUnsafeMutableBytes(bufferIndex: 0) { buffer in
    let vertices = buffer.bindMemory(to: GameVertex.self)
    vertices[0] = GameVertex(position: [0, 0, 0], normal: [0, 1, 0], uv: [0, 0])
    vertices[1] = GameVertex(position: [1, 0, 0], normal: [0, 1, 0], uv: [1, 0])
    vertices[2] = GameVertex(position: [0, 0, 1], normal: [0, 1, 0], uv: [0, 1])
    // ... fill more vertices
}

// Populate indices
mesh.withUnsafeMutableIndices { buffer in
    let indices = buffer.bindMemory(to: UInt32.self)
    indices[0] = 0; indices[1] = 1; indices[2] = 2
}

// Define mesh parts (which triangles use which material)
mesh.parts.replaceAll([
    LowLevelMesh.Part(
        indexOffset: 0,
        indexCount: 3,
        topology: .triangle,
        materialIndex: 0
    )
])

// Create entity
let meshResource = try MeshResource(from: mesh)
let entity = ModelEntity(mesh: meshResource, materials: [SimpleMaterial(color: .green, isMetallic: false)])
```

### GPU-Updated LowLevelMesh (Metal Compute)

```swift
// Get Metal buffer directly for compute shader access
let vertexBuffer = mesh.replace(bufferIndex: 0, using: commandBuffer)
// vertexBuffer is an MTLBuffer — use in compute encoder

let computeEncoder = commandBuffer.makeComputeCommandEncoder()!
computeEncoder.setComputePipelineState(computePipeline)
computeEncoder.setBuffer(vertexBuffer, offset: 0, index: 0)
// ... set params, dispatch threads
computeEncoder.endEncoding()
commandBuffer.commit()
```

**When to use LowLevelMesh vs MeshDescriptor:**

- `MeshDescriptor` — one-time mesh generation, simple geometry
- `LowLevelMesh` — runtime mesh updates, procedural terrain, trails, deformable objects, anything that changes per-frame

---

## LowLevelTexture

Same concept as LowLevelMesh but for textures. Update texture data at runtime.

```swift
var descriptor = LowLevelTexture.Descriptor()
descriptor.textureType = .type2D
descriptor.pixelFormat = .rgba8Unorm
descriptor.width = 512
descriptor.height = 512
descriptor.textureUsage = [.shaderRead, .shaderWrite]

let texture = try LowLevelTexture(descriptor: descriptor)

// Update from CPU
texture.withUnsafeMutableBytes { buffer in
    let pixels = buffer.bindMemory(to: UInt32.self)
    // write pixel data...
}

// Or update from GPU compute shader
let mtlTexture = texture.replace(using: commandBuffer)
// use mtlTexture in compute encoder
```

**Use cases:** Dynamic minimaps, damage overlays, heightmap-based terrain textures, runtime-generated normal maps.

---

## Entity Pooling

Pre-create entities and toggle visibility instead of create/destroy. Apple explicitly recommends this for performance.

```swift
@Observable
class BulletPool {
    private var pool: [ModelEntity] = []
    private var activeCount = 0
    let poolSize = 50

    func initialize(parent: Entity) {
        let mesh = MeshResource.generateSphere(radius: 0.02)
        let material = SimpleMaterial(color: .yellow, isMetallic: true)

        for _ in 0..<poolSize {
            let bullet = ModelEntity(mesh: mesh, materials: [material])
            bullet.isEnabled = false  // hidden in pool
            bullet.physicsBody = PhysicsBodyComponent(
                massProperties: .init(shape: .generateSphere(radius: 0.02), mass: 0.1),
                material: .default, mode: .kinematic
            )
            bullet.collision = CollisionComponent(shapes: [.generateSphere(radius: 0.02)])
            parent.addChild(bullet)
            pool.append(bullet)
        }
    }

    func spawn(at position: SIMD3<Float>, velocity: SIMD3<Float>) -> ModelEntity? {
        guard let bullet = pool.first(where: { !$0.isEnabled }) else { return nil }
        bullet.position = position
        bullet.physicsMotion = PhysicsMotionComponent(linearVelocity: velocity)
        bullet.isEnabled = true
        return bullet
    }

    func despawn(_ bullet: ModelEntity) {
        bullet.isEnabled = false
        bullet.position = .zero
        bullet.physicsMotion?.linearVelocity = .zero
    }
}
```

**Key:** `isEnabled = false` stops rendering AND physics simulation for that entity. Much cheaper than `removeChild()` + `addChild()`.

---

## ParticleEmitterComponent

### Presets

```swift
// Built-in presets — attach to any entity
entity.components.set(ParticleEmitterComponent.Presets.fireworks)
entity.components.set(ParticleEmitterComponent.Presets.impact)   // explosion/smoke
entity.components.set(ParticleEmitterComponent.Presets.magic)
entity.components.set(ParticleEmitterComponent.Presets.rain)
entity.components.set(ParticleEmitterComponent.Presets.snow)
```

### Custom Particle Emitter

```swift
var particles = ParticleEmitterComponent()

// Emitter shape and size
particles.emitterShape = .sphere           // .point, .sphere, .box, .cylinder, .cone
particles.emitterShapeSize = [0.1, 0.1, 0.1]

// Particle properties
particles.mainEmitter.birthRate = 500       // particles per second
particles.mainEmitter.size = 0.02           // particle size
particles.mainEmitter.lifeSpan = 2.0        // seconds before particle dies
particles.mainEmitter.speed = 0.5           // initial velocity

// Color over lifetime
particles.mainEmitter.color = .evolving(
    start: .single(.orange),
    end: .single(.red.withAlphaComponent(0))
)

// Size over lifetime
particles.mainEmitter.sizeMultiplierAtEndOfLifespan = 0.0  // shrink to nothing

// Gravity influence
particles.mainEmitter.acceleration = [0, -2, 0]  // slight downward pull

entity.components.set(particles)
```

### One-Shot Burst (Explosions, Impacts)

```swift
// Trigger a burst of particles (does not require continuous emission)
if let emitter = entity.components[ParticleEmitterComponent.self] {
    entity.components[ParticleEmitterComponent.self]?.burst()
}
```

---

## Triangle Budgets & Draw Call Reduction

### Hard Numbers

| Platform         | Practical triangle budget | Notes                         |
| ---------------- | ------------------------- | ----------------------------- |
| iPhone (non-Pro) | ~100K triangles           | 60fps target                  |
| iPhone Pro       | ~200K triangles           | A17+ GPU                      |
| iPad Pro         | ~300K triangles           | M-series GPU                  |
| visionOS         | ~500K triangles           | Stereo rendering doubles cost |

Generated 3D models (`generate3DAsset` / `generate3DHumanoid`) have a fixed geometry density: any standard model (`generate3DAsset` prop or `generate3DHumanoid` character) is ~90-95K triangles after Meshy's adaptive remesh, a `lowPoly` one ~4K faces. Skinned humanoids cost more per triangle than static props and each animation clip is its own USDZ, so keep unique animated characters to a few and clone them. Plan the scene from those numbers: one standard model is already the whole non-Pro iPhone budget, so use **one standard hero** on non-Pro iPhones (two at most on iPhone Pro / iPad, ~180–190K before any fill) and budget every remaining `lowPoly` clone and procedural mesh inside what is left. Remember: `entity.clone(recursive: true)` and `MeshInstancesComponent` reduce draw calls and memory, NOT rendered triangles — every clone rasterizes its full mesh when visible, so mark anything cloned many times as `lowPoly`.

### Built-in Shape Polygon Counts (Approximate)

| Shape                              | Triangles | Vertices |
| ---------------------------------- | --------- | -------- |
| `generateBox(size: 0.1)`           | 12        | 24       |
| `generateSphere(radius: 0.05)`     | ~760      | ~382     |
| `generateCylinder(height:radius:)` | ~720      | ~362     |
| `generateCone(height:radius:)`     | ~360      | ~182     |
| `generatePlane(width:depth:)`      | 2         | 4        |

**`generateSphere` uses ~760 triangles per sphere.** If you need 100 spheres, that's 76K triangles just for spheres. Consider using lower-poly custom meshes via `MeshDescriptor` for game objects.

### Draw Call Reduction Strategies

1. **MeshInstancesComponent** — N identical meshes = 1 draw call instead of N
2. **Flatten entity hierarchy** — fewer parent entities = fewer render server updates
3. **Merge static geometry** — combine multiple static meshes into one `MeshDescriptor`
4. **Use `isEnabled = false`** for offscreen/pooled entities — stops rendering entirely
5. **Async loading** — `Entity(named:)` async to avoid frame drops
6. **Reduce material count** — each unique material = separate draw call
7. **Texture atlasing** — one texture with multiple sub-images = one material

### Async Loading Pattern

```swift
// Load heavy models without blocking the frame
Task {
    let model = try await Entity(named: "boss_character.usdz")
    // Safely add on main actor
    await MainActor.run {
        scene.addChild(model)
    }
}
```

### Hierarchy Flattening

```swift
// BAD: deep hierarchy — many transform updates propagated to render server
let root = Entity()
let level1 = Entity(); root.addChild(level1)
let level2 = Entity(); level1.addChild(level2)
let level3 = Entity(); level2.addChild(level3)

// BETTER: flat hierarchy — fewer updates
let root = Entity()
root.addChild(entity1)
root.addChild(entity2)
root.addChild(entity3)
```

Every entity in the hierarchy is a potential update sent to the render server. Fewer ancestors = fewer matrix multiplications per frame.

---

## SpriteKit Texture Atlases

Combine multiple sprites into a single texture to reduce draw calls and improve batch rendering.

```swift
// Load atlas
let atlas = SKTextureAtlas(named: "characters")
let walkFrames = (1...8).map { atlas.textureNamed("walk_\($0)") }

// Animate
let animation = SKAction.animate(with: walkFrames, timePerFrame: 0.1)
sprite.run(.repeatForever(animation))

// Preload atlases during loading screen
let atlases = [SKTextureAtlas(named: "characters"), SKTextureAtlas(named: "tiles"), SKTextureAtlas(named: "effects")]
SKTextureAtlas.preloadTextureAtlases(atlases) {
    // All textures now in GPU memory
}
```

**Rules:**

- Max atlas size: 4096×4096 (2048×2048 safer for older devices)
- One atlas per "set" of related sprites (characters, tiles, UI)
- Use `.xctextureatlasset` in Xcode or pass folder to `SKTextureAtlas(named:)`

---

## SpriteKit Memory Budgets

| Device            | Available RAM | Safe texture budget |
| ----------------- | ------------- | ------------------- |
| iPhone SE/8       | 2GB           | ~200MB textures     |
| iPhone 12-14      | 4-6GB         | ~500MB textures     |
| iPhone 15 Pro     | 8GB           | ~800MB textures     |
| iPad Pro M-series | 8-16GB        | ~1.5GB textures     |

A 1024×1024 RGBA texture = ~4MB. A 2048×2048 = ~16MB.

**Tip:** Use `SKTexture.size()` to check actual dimensions. Generated images from `generateImageAsset` are typically 1024×1024 (~4MB each).

---

## RealityKit Level of Detail (LOD)

Swap between high-poly and low-poly meshes based on distance to camera or on-screen size, so far-away models stop paying their full triangle cost.

### Native LevelOfDetailComponent (iOS 27+ beta)

RealityKit ships a built-in LOD component (WWDC 2026, "Explore advances in RealityKit"). Each detail level is an array of entities (`DetailLevel = [Entity]`) shown/hidden together. Two switching strategies:

```swift
// Distance-based: highest detail first, each level active up to maxDistance (meters).
if #available(iOS 27.0, *) {
    LevelOfDetailComponent.addByCameraDistance(to: container, levels: [
        (entities: [highDetailEntity], maxDistance: 8),
        (entities: [lowDetailEntity], maxDistance: 30),
    ])
}

// Screen-area-based (preferred): switches by the fraction of the screen the
// entity covers, so detail follows actual pixel coverage regardless of FOV.
if #available(iOS 27.0, *) {
    LevelOfDetailComponent.addByScreenArea(to: container, levels: [
        (entities: [highDetailEntity], minArea: 0.05),  // ≥5% of screen → high
        (entities: [lowDetailEntity], minArea: 0.0),    // anything smaller → low
    ])
}
```

Wrap in `#available(iOS 27.0, *)` and keep the highest-detail entity as the unconditional fallback on older systems. On earlier deployment targets, use the manual system below.

### Manual LOD system (works on all iOS versions)

```swift
nonisolated struct LODSystem: System {
    static let query = EntityQuery(where: .has(LODComponent.self))

    init(scene: Scene) {}

    func update(context: SceneUpdateContext) {
        guard let camera = context.scene.findEntity(named: "camera") else { return }
        let cameraPos = camera.position(relativeTo: nil)

        for entity in context.entities(matching: Self.query, updatingSystemWhen: .rendering) {
            guard var lod = entity.components[LODComponent.self] else { continue }
            let dist = distance(entity.position(relativeTo: nil), cameraPos)

            let newLevel: LODLevel
            if dist < lod.nearDistance { newLevel = .high }
            else if dist < lod.farDistance { newLevel = .medium }
            else { newLevel = .low }

            if newLevel != lod.currentLevel {
                lod.currentLevel = newLevel
                entity.components[LODComponent.self] = lod
                swapMesh(entity: entity, level: newLevel, lod: lod)
            }
        }
    }

    func swapMesh(entity: Entity, level: LODLevel, lod: LODComponent) {
        guard var model = entity.components[ModelComponent.self] else { return }
        switch level {
        case .high: model.mesh = lod.highMesh
        case .medium: model.mesh = lod.mediumMesh
        case .low: model.mesh = lod.lowMesh
        }
        entity.components[ModelComponent.self] = model
    }
}

nonisolated enum LODLevel { case high, medium, low }

nonisolated struct LODComponent: Component {
    var highMesh: MeshResource
    var mediumMesh: MeshResource
    var lowMesh: MeshResource
    var nearDistance: Float = 5.0
    var farDistance: Float = 15.0
    var currentLevel: LODLevel = .high
}
```

For games with generated 3D models (via `generate3DAsset` / `generate3DHumanoid`), you typically only have one LOD level per asset. Use `isEnabled = false` for entities beyond render distance instead, and generate heavily cloned assets (trees, rocks, coins) with `lowPoly: true` so they are cheap in the first place.

---

## Trail / Ribbon Effects (LowLevelMesh)

Sword trails, magic streaks, flight paths. Use a `LowLevelMesh` with `.triangleStrip` topology — append vertex pairs each frame.

```swift
struct TrailVertex {
    var position: SIMD3<Float>
    var uv: SIMD2<Float>
    var opacity: Float
}

class TrailRenderer {
    private var mesh: LowLevelMesh
    private var meshResource: MeshResource
    private let maxSegments = 60
    private var positions: [(left: SIMD3<Float>, right: SIMD3<Float>)] = []

    init() throws {
        let attributes: [LowLevelMesh.Attribute] = [
            .init(semantic: .position, format: .float3, offset: 0),
            .init(semantic: .uv0, format: .float2,
                  offset: MemoryLayout.offset(of: \TrailVertex.uv)!),
        ]
        let layouts: [LowLevelMesh.Layout] = [
            .init(bufferIndex: 0, bufferStride: MemoryLayout<TrailVertex>.stride)
        ]
        let desc = LowLevelMesh.Descriptor(
            vertexCapacity: maxSegments * 2,
            vertexAttributes: attributes,
            vertexLayouts: layouts,
            indexCapacity: 0,
            indexType: .uint32
        )
        mesh = try LowLevelMesh(descriptor: desc)
        meshResource = try MeshResource(from: mesh)
    }

    /// Call each frame from a System.update() with the current tip position and a width direction.
    func addSegment(center: SIMD3<Float>, right: SIMD3<Float>, width: Float) {
        let halfWidth = right * width * 0.5
        positions.append((center - halfWidth, center + halfWidth))
        if positions.count > maxSegments { positions.removeFirst() }
        rebuildMesh()
    }

    private func rebuildMesh() {
        let count = positions.count
        guard count >= 2 else { return }

        mesh.withUnsafeMutableBytes(bufferIndex: 0) { buffer in
            let verts = buffer.bindMemory(to: TrailVertex.self)
            for i in 0..<count {
                let t = Float(i) / Float(count - 1)
                let opacity = t // fade from tail (0) to tip (1)
                verts[i * 2] = TrailVertex(position: positions[i].left, uv: [0, t], opacity: opacity)
                verts[i * 2 + 1] = TrailVertex(position: positions[i].right, uv: [1, t], opacity: opacity)
            }
        }
        mesh.parts.replaceAll([
            LowLevelMesh.Part(indexOffset: 0, indexCount: count * 2,
                              topology: .triangleStrip, materialIndex: 0,
                              bounds: .init(min: [-10, -10, -10], max: [10, 10, 10]))
        ])
    }
}
```

Pair with an emissive `UnlitMaterial` or `CustomMaterial` for glow effects. The trail naturally fades — use the UV `v` coordinate in a shader to control opacity along the trail length.

---

## PostProcessEffect (iOS 26+ / macOS 26+)

Custom full-screen effects applied after rendering. Available since WWDC25 — use for bloom, fog, vignette, color grading, cel-shading outlines.

### Bloom Effect Example

```swift
import RealityKit
import MetalPerformanceShaders

struct BloomEffect: PostProcessEffect {
    var threshold: Float = 0.8
    var intensity: Float = 1.5

    func postProcess(context: PostProcessEffectContext<any MTLCommandBuffer>) {
        guard let commandBuffer = context.commandBuffer else { return }
        let source = context.sourceColorTexture
        let target = context.targetColorTexture

        // 1. Extract bright pixels
        let thresholdKernel = MPSImageThresholdToZero(
            device: commandBuffer.device,
            thresholdValue: threshold,
            linearGrayColorTransform: nil
        )

        let brightDesc = MTLTextureDescriptor.texture2DDescriptor(
            pixelFormat: source.pixelFormat,
            width: source.width, height: source.height,
            mipmapped: false
        )
        brightDesc.usage = [.shaderRead, .shaderWrite]
        guard var brightTex: any MTLTexture = commandBuffer.device.makeTexture(descriptor: brightDesc) else { return }
        thresholdKernel.encode(commandBuffer: commandBuffer, sourceTexture: source, destinationTexture: brightTex)

        // 2. Blur bright pixels
        let blur = MPSImageGaussianBlur(device: commandBuffer.device, sigma: 10.0)
        _ = blur.encode(commandBuffer: commandBuffer, inPlaceTexture: &brightTex)

        // 3. Composite: source + blurred bloom → target
        let add = MPSImageAdd(device: commandBuffer.device)
        add.encode(commandBuffer: commandBuffer,
                   primaryTexture: source,
                   secondaryTexture: brightTex,
                   destinationTexture: target)
    }
}
```

### Applying to RealityView

```swift
RealityView { content in
    // ... setup scene
    content.renderingEffects.customPostProcessing = .effect(BloomEffect())
}
```

### Other Effect Ideas

- **Fog:** Read depth buffer, blend fog color based on distance
- **Vignette:** Darken edges based on UV distance from center
- **Color Grading:** Apply LUT (look-up table) via `CIFilter`
- **Cel-Shading Outlines:** Sobel edge detection on depth + normal buffers

---

## Performance Tips

### SpriteKit Physics Body Cost

Choose the cheapest shape that fits. Each step up costs significantly more CPU.

| Shape                          | Relative Cost         | Use For                                             |
| ------------------------------ | --------------------- | --------------------------------------------------- |
| `circleOfRadius`               | 1x (cheapest)         | Balls, coins, bullets, round characters             |
| `rectangleOf`                  | 1.5x                  | Platforms, walls, boxes                             |
| Convex polygon (≤12 vertices)  | 3x                    | Irregular static obstacles                          |
| Compound (multiple shapes)     | 4x+                   | Complex characters (circle head + rect body)        |
| `SKPhysicsBody(texture:size:)` | 10x+ (most expensive) | Avoid in gameplay — use for static decorations only |

### Texture Preloading

Load textures during loading screens, not during gameplay. Frame drops from texture decoding are the #1 cause of stutter.

```swift
// Preload before presenting the game scene
let textures = (1...8).map { SKTexture(imageNamed: "walk_\($0)") }
SKTexture.preload(textures) {
    // Textures in GPU memory — safe to start gameplay
    let gameScene = GameScene(size: size)
    view.presentScene(gameScene, transition: .fade(withDuration: 0.5))
}
```

### SKAction Caching

Create frequently-used actions once, reuse everywhere. Actions are lightweight and copyable.

```swift
enum GameActions {
    static let fadeOutRemove = SKAction.sequence([.fadeOut(withDuration: 0.2), .removeFromParent()])
    static let popIn = SKAction.sequence([.scale(to: 0, duration: 0), .scale(to: 1.1, duration: 0.15), .scale(to: 1.0, duration: 0.05)])
    static let coinSound = SKAction.playSoundFileNamed("coin.mp3", waitForCompletion: false)
}

// Use everywhere:
enemy.run(GameActions.fadeOutRemove)
pickup.run(GameActions.popIn)
```

### RealityKit Shader Compilation

First-time loading of complex USDZ models causes a frame stutter (shader compilation). Shaders are cached after first load — only stutters once until device reboot.

```swift
// Preload during loading screen to avoid stutter during gameplay
Task {
    let _ = try? await Entity(named: "boss_character")
    let _ = try? await Entity(named: "environment_trees")
    // Shaders now compiled and cached — safe to start level
}
```

### Draw Call Reduction Checklist

- `SpriteView(scene:options: [.ignoresSiblingOrder])` — lets GPU optimize render order
- Use `zPosition` for layering instead of sibling order
- Group sprites from same texture atlas → single draw call
- Keep blend modes consistent on same Z layer
- Set `isDynamic = false` on all static physics bodies
- Use collision masks to limit which bodies check against each other
