---
index: true
description: "Procreate-style canvas: Metal pipeline, brush engine, layers"
---

# Building a Procreate-Style Canvas App — Complete Instruction Plan

This document is a step-by-step blueprint for building a GPU-accelerated drawing/painting app with layers, blend modes, brush engine, and 120fps rendering using Metal.

---

## Architecture Overview

```
┌──────────────────────────────────────────────────────┐
│                     SwiftUI App                       │
│  ┌────────────────┐  ┌─────────────────────────────┐ │
│  │  Tool Picker   │  │   Layer Panel (sidebar)     │ │
│  │  (brush, eraser│  │   - thumbnail per layer     │ │
│  │   color, size, │  │   - opacity slider          │ │
│  │   opacity)     │  │   - blend mode picker       │ │
│  └────────────────┘  │   - visibility toggle       │ │
│                      │   - reorder (drag)          │ │
│                      └─────────────────────────────┘ │
│  ┌──────────────────────────────────────────────────┐│
│  │          Metal Canvas View (MTKView)             ││
│  │  ┌────────────────────────────────────────────┐  ││
│  │  │  Layer N  [MTLTexture] ──────────┐         │  ││
│  │  │  Layer 2  [MTLTexture] ──────────┤ Blend   │  ││
│  │  │  Layer 1  [MTLTexture] ──────────┤ Comp.   │  ││
│  │  │  Background [MTLTexture] ────────┘ Shader  │  ││
│  │  │               │                            │  ││
│  │  │               ▼                            │  ││
│  │  │  Output → CAMetalLayer → Screen (120fps)   │  ││
│  │  └────────────────────────────────────────────┘  ││
│  │  Viewport Transform (pinch/zoom/rotate)          ││
│  └──────────────────────────────────────────────────┘│
│  ┌──────────────────────────────────────────────────┐│
│  │  Input Pipeline                                  ││
│  │  UITouch → coalesced → predicted → spline →     ││
│  │  stamp positions → Metal compute → layer texture ││
│  └──────────────────────────────────────────────────┘│
└──────────────────────────────────────────────────────┘
```

---

## Apple SDKs Required

| SDK                        | Role                                                                       | Import                          |
| -------------------------- | -------------------------------------------------------------------------- | ------------------------------- |
| **Metal**                  | GPU rendering: canvas textures, brush compositing, layer blending, display | `import Metal`                  |
| **MetalKit**               | MTKView for display, texture loading                                       | `import MetalKit`               |
| **UIKit Touch**            | Touch input: force, azimuth, altitude, coalesced/predicted                 | `import UIKit`                  |
| **PencilKit**              | Optional: turnkey drawing for simple apps                                  | `import PencilKit`              |
| **Core Image**             | Image filters (blur, sharpen, color adjust) on layers                      | `import CoreImage`              |
| **Core Graphics**          | Bezier math, path tessellation, brush stamp generation                     | `import CoreGraphics`           |
| **simd**                   | Vector/matrix math for transforms                                          | `import simd`                   |
| **Accelerate**             | Bulk pixel operations, color space math                                    | `import Accelerate`             |
| **Core Haptics**           | Apple Pencil Pro squeeze/roll haptic feedback                              | `import CoreHaptics`            |
| **PhotosUI**               | Image import from photo library                                            | `import PhotosUI`               |
| **UniformTypeIdentifiers** | Custom file format, document-based app                                     | `import UniformTypeIdentifiers` |

---

## Phase 1: Metal Canvas Foundation

**SDKs:** Metal, MetalKit, UIKit

### Step 1.1 — MTKView + SwiftUI Integration

The canvas is an `MTKView` wrapped for SwiftUI via `UIViewRepresentable`. The MTKView drives the render loop at the display's refresh rate (120fps on ProMotion iPads).

```swift
import SwiftUI
import MetalKit

struct MetalCanvasView: UIViewRepresentable {
    var canvasState: CanvasState

    func makeUIView(context: Context) -> MTKView {
        let mtkView = MTKView()
        mtkView.device = MTLCreateSystemDefaultDevice()
        mtkView.delegate = context.coordinator
        mtkView.preferredFramesPerSecond = 120
        mtkView.enableSetNeedsDisplay = false // continuous rendering
        mtkView.isPaused = false
        mtkView.colorPixelFormat = .bgra8Unorm
        mtkView.clearColor = MTLClearColor(red: 1, green: 1, blue: 1, alpha: 1)

        // Touch handling
        mtkView.isMultipleTouchEnabled = true
        mtkView.isUserInteractionEnabled = true

        context.coordinator.setupMetal(device: mtkView.device!)
        return mtkView
    }

    func updateUIView(_ uiView: MTKView, context: Context) {}

    func makeCoordinator() -> CanvasRenderer {
        CanvasRenderer(canvasState: canvasState)
    }
}
```

### Step 1.2 — Metal Device & Pipeline Setup

Every Metal app needs: device → command queue → pipeline states → textures → render loop.

```swift
class CanvasRenderer: NSObject, MTKViewDelegate {
    var device: MTLDevice!
    var commandQueue: MTLCommandQueue!
    var renderPipelineState: MTLRenderPipelineState!
    var computePipelineState: MTLComputePipelineState!

    let canvasState: CanvasState

    init(canvasState: CanvasState) {
        self.canvasState = canvasState
        super.init()
    }

    func setupMetal(device: MTLDevice) {
        self.device = device
        self.commandQueue = device.makeCommandQueue()!

        let library = device.makeDefaultLibrary()!

        // Render pipeline: draws the final composited image to screen
        let rpd = MTLRenderPipelineDescriptor()
        rpd.vertexFunction = library.makeFunction(name: "vertexPassthrough")
        rpd.fragmentFunction = library.makeFunction(name: "fragmentComposite")
        rpd.colorAttachments[0].pixelFormat = .bgra8Unorm
        // Enable alpha blending on the output
        rpd.colorAttachments[0].isBlendingEnabled = true
        rpd.colorAttachments[0].rgbBlendOperation = .add
        rpd.colorAttachments[0].alphaBlendOperation = .add
        rpd.colorAttachments[0].sourceRGBBlendFactor = .one
        rpd.colorAttachments[0].sourceAlphaBlendFactor = .one
        rpd.colorAttachments[0].destinationRGBBlendFactor = .oneMinusSourceAlpha
        rpd.colorAttachments[0].destinationAlphaBlendFactor = .oneMinusSourceAlpha
        renderPipelineState = try! device.makeRenderPipelineState(descriptor: rpd)

        // Compute pipeline: stamps brush onto layer texture
        let brushFunction = library.makeFunction(name: "brushStampKernel")!
        computePipelineState = try! device.makeComputePipelineState(function: brushFunction)
    }

    // MTKViewDelegate — called every frame
    func draw(in view: MTKView) {
        guard let drawable = view.currentDrawable,
              let rpd = view.currentRenderPassDescriptor else { return }

        let commandBuffer = commandQueue.makeCommandBuffer()!

        // 1. Composite all layers into output
        let encoder = commandBuffer.makeRenderCommandEncoder(descriptor: rpd)!
        encoder.setRenderPipelineState(renderPipelineState)
        // Bind layer textures and draw fullscreen quad
        // ... (see Phase 4 for compositing)
        encoder.endEncoding()

        commandBuffer.present(drawable)
        commandBuffer.commit()
    }

    func mtkView(_ view: MTKView, drawableSizeWillChange size: CGSize) {
        // Handle resize
    }
}
```

### Step 1.3 — Canvas Texture Creation

Each layer is an offscreen `MTLTexture`. The canvas resolution is independent of the view size (e.g., 4096x4096 canvas displayed in a 1024x1024 view).

```swift
func createCanvasTexture(width: Int, height: Int) -> MTLTexture {
    let descriptor = MTLTextureDescriptor.texture2DDescriptor(
        pixelFormat: .rgba16Float,  // 16-bit float for HDR / precision
        width: width,
        height: height,
        mipmapped: false
    )
    descriptor.usage = [.shaderRead, .shaderWrite, .renderTarget]
    descriptor.storageMode = .private // GPU-only for performance
    return device.makeTexture(descriptor: descriptor)!
}
```

**Pixel format choice:**

- `.rgba8Unorm` — 8-bit per channel, 4 bytes per pixel. Good for most apps.
- `.rgba16Float` — 16-bit float per channel, 8 bytes per pixel. HDR-capable, better for blending precision. Procreate uses this.
- `.rgba32Float` — 32-bit float, 16 bytes per pixel. Overkill for most cases.

**Memory math:** 4096x4096 canvas at rgba16Float = 4096 × 4096 × 8 bytes = **128 MB per layer**. 10 layers = 1.28 GB. This is why memory management matters.

---

## Phase 2: Touch Input Pipeline

**SDKs:** UIKit (UITouch, UIGestureRecognizer)

### Step 2.1 — Capturing Touch Events

Override touch methods on a UIView subclass (or the MTKView itself). The key insight: `coalescedTouches(for:)` gives you ALL touch samples between frames (up to 240Hz on iPad Pro with Apple Pencil), and `predictedTouches(for:)` gives you estimated future points to reduce perceived latency.

```swift
class CanvasTouchView: MTKView {
    var currentStroke: StrokeData?
    weak var strokeDelegate: StrokeDelegate?

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else { return }
        currentStroke = StrokeData()

        let point = createStrokePoint(from: touch)
        currentStroke?.points.append(point)
        strokeDelegate?.strokeBegan(currentStroke!)
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first, var stroke = currentStroke else { return }

        // Get ALL sub-frame touch samples (240Hz with Apple Pencil)
        let coalescedTouches = event?.coalescedTouches(for: touch) ?? [touch]
        for coalescedTouch in coalescedTouches {
            let point = createStrokePoint(from: coalescedTouch)
            stroke.points.append(point)
        }

        // Get predicted future points for lower latency display
        let predictedTouches = event?.predictedTouches(for: touch) ?? []
        let predictions = predictedTouches.map { createStrokePoint(from: $0) }

        currentStroke = stroke
        strokeDelegate?.strokeMoved(stroke, predicted: predictions)
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let stroke = currentStroke else { return }
        strokeDelegate?.strokeEnded(stroke)
        currentStroke = nil
    }

    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        currentStroke = nil
        strokeDelegate?.strokeCancelled()
    }

    private func createStrokePoint(from touch: UITouch) -> StrokePoint {
        let location = touch.location(in: self)
        return StrokePoint(
            position: SIMD2<Float>(Float(location.x), Float(location.y)),
            force: Float(touch.force > 0 ? touch.force / touch.maximumPossibleForce : 0.5),
            azimuth: Float(touch.azimuthAngle(in: self)),
            altitude: Float(touch.altitudeAngle),
            timestamp: touch.timestamp,
            type: touch.type // .pencil or .direct (finger)
        )
    }
}

struct StrokePoint {
    var position: SIMD2<Float>
    var force: Float         // 0.0–1.0 normalized
    var azimuth: Float       // radians, 0 = pointing right
    var altitude: Float      // radians, 0 = flat, π/2 = perpendicular
    var timestamp: TimeInterval
    var type: UITouch.TouchType
}

struct StrokeData {
    var points: [StrokePoint] = []
}
```

### Step 2.2 — Apple Pencil Pro Features (iOS 17.5+)

```swift
// Barrel roll (rotation around pencil axis — Apple Pencil Pro)
if #available(iOS 17.5, *) {
    let rollAngle = touch.rollAngle  // radians, 0 = natural grip
    // Use for rotating brush shape (calligraphy, flat brushes)
}

// Squeeze gesture — handled via UIPencilInteraction
let pencilInteraction = UIPencilInteraction()
pencilInteraction.delegate = self
view.addInteraction(pencilInteraction)

// In delegate:
extension CanvasController: UIPencilInteractionDelegate {
    func pencilInteractionDidTap(_ interaction: UIPencilInteraction) {
        // Double-tap: switch tool (e.g., pen ↔ eraser)
    }

    @available(iOS 17.5, *)
    func pencilInteraction(_ interaction: UIPencilInteraction,
                           didReceiveSqueeze squeeze: UIPencilInteraction.Squeeze) {
        // Squeeze: show/hide tool palette
        let feedbackGenerator = UIImpactFeedbackGenerator(style: .light)
        feedbackGenerator.impactOccurred()
    }
}
```

### Step 2.3 — UITouch Property Reference

| Property                              | Range                                      | Apple Pencil Only?       | Use Case                      |
| ------------------------------------- | ------------------------------------------ | ------------------------ | ----------------------------- |
| `force`                               | 0.0 to `maximumPossibleForce` (~6.67)      | No (3D Touch phones too) | Brush size / opacity          |
| `azimuthAngle(in:)`                   | 0 to 2π radians                            | Yes                      | Brush rotation (calligraphy)  |
| `altitudeAngle`                       | 0 (flat) to π/2 (perpendicular)            | Yes                      | Shading (tilt = wider stroke) |
| `rollAngle`                           | -π to π (iPadOS 17.5+, Pencil Pro)         | Yes (Pro only)           | Rotate flat/chisel brushes    |
| `type`                                | `.direct` / `.pencil` / `.indirectPointer` | N/A                      | Distinguish finger vs pencil  |
| `estimatedProperties`                 | Set of properties being estimated          | Yes                      | Know which values may update  |
| `estimatedPropertiesExpectingUpdates` | Set of properties that will refine         | Yes                      | Force refinement after lift   |

### Step 2.4 — Viewport Gestures (Pinch/Zoom/Rotate)

Use `UIGestureRecognizer`s on the canvas view for viewport manipulation (not drawing):

```swift
func setupViewportGestures() {
    let pinch = UIPinchGestureRecognizer(target: self, action: #selector(handlePinch))
    let rotate = UIRotationGestureRecognizer(target: self, action: #selector(handleRotation))
    let pan = UIPanGestureRecognizer(target: self, action: #selector(handlePan))
    pan.minimumNumberOfTouches = 2  // 2-finger pan = viewport move
    pan.maximumNumberOfTouches = 2

    // Allow simultaneous recognition
    pinch.delegate = self
    rotate.delegate = self
    pan.delegate = self

    addGestureRecognizer(pinch)
    addGestureRecognizer(rotate)
    addGestureRecognizer(pan)
}

// UIGestureRecognizerDelegate
func gestureRecognizer(_ g1: UIGestureRecognizer,
                       shouldRecognizeSimultaneouslyWith g2: UIGestureRecognizer) -> Bool {
    return true // pinch + rotate + pan simultaneously
}
```

The viewport is stored as a `simd_float3x3` (2D affine transform) applied in the vertex shader to transform canvas coordinates → screen coordinates.

---

## Phase 3: Brush Engine

**SDKs:** Metal (compute shaders), Core Graphics (path math), simd

### Step 3.1 — Stroke Path Interpolation (Catmull-Rom Spline)

Raw touch points are noisy and unevenly spaced. Fit a Catmull-Rom spline to produce smooth, evenly-spaced stamp positions:

```swift
func catmullRomInterpolate(
    p0: SIMD2<Float>, p1: SIMD2<Float>,
    p2: SIMD2<Float>, p3: SIMD2<Float>,
    t: Float, alpha: Float = 0.5
) -> SIMD2<Float> {
    // Centripetal Catmull-Rom (alpha = 0.5)
    let d1 = simd_length(p1 - p0)
    let d2 = simd_length(p2 - p1)
    let d3 = simd_length(p3 - p2)

    let t1 = pow(d1, alpha)
    let t2 = t1 + pow(d2, alpha)
    let t3 = t2 + pow(d3, alpha)

    let tScaled = t1 + t * (t2 - t1)

    let a1 = p0 * ((t1 - tScaled) / t1) + p1 * (tScaled / t1)
    let a2 = p1 * ((t2 - tScaled) / (t2 - t1)) + p2 * ((tScaled - t1) / (t2 - t1))
    let a3 = p2 * ((t3 - tScaled) / (t3 - t2)) + p3 * ((tScaled - t2) / (t3 - t2))

    let b1 = a1 * ((t2 - tScaled) / t2) + a2 * (tScaled / t2)
    let b2 = a2 * ((t3 - tScaled) / (t3 - t1)) + a3 * ((tScaled - t1) / (t3 - t1))

    return b1 * ((t2 - tScaled) / (t2 - t1)) + b2 * ((tScaled - t1) / (t2 - t1))
}

func generateStampPositions(from points: [StrokePoint], spacing: Float) -> [StampData] {
    guard points.count >= 4 else { return [] }
    var stamps: [StampData] = []
    var distanceAccumulator: Float = 0

    for i in 1..<(points.count - 2) {
        let p0 = points[i - 1].position
        let p1 = points[i].position
        let p2 = points[i + 1].position
        let p3 = points[i + 2].position

        let segmentLength = simd_length(p2 - p1)
        let steps = max(1, Int(segmentLength / (spacing * 0.25)))

        for step in 0..<steps {
            let t = Float(step) / Float(steps)
            let pos = catmullRomInterpolate(p0: p0, p1: p1, p2: p2, p3: p3, t: t)
            distanceAccumulator += spacing * 0.25

            if distanceAccumulator >= spacing {
                distanceAccumulator -= spacing
                let lerpedForce = points[i].force + t * (points[i + 1].force - points[i].force)
                stamps.append(StampData(
                    position: pos,
                    size: lerpedForce, // 0-1 maps to min-max brush size
                    opacity: lerpedForce,
                    rotation: points[i].azimuth
                ))
            }
        }
    }
    return stamps
}

struct StampData {
    var position: SIMD2<Float>
    var size: Float
    var opacity: Float
    var rotation: Float
}
```

### Step 3.2 — Brush Stamp Texture

A brush stamp is a small grayscale texture defining the brush's shape. White = full opacity, black = transparent. This is uploaded to the GPU once.

```swift
func generateRoundBrushStamp(diameter: Int, hardness: Float) -> MTLTexture {
    let descriptor = MTLTextureDescriptor.texture2DDescriptor(
        pixelFormat: .r8Unorm,
        width: diameter, height: diameter,
        mipmapped: false
    )
    descriptor.usage = [.shaderRead]
    let texture = device.makeTexture(descriptor: descriptor)!

    var pixels = [UInt8](repeating: 0, count: diameter * diameter)
    let center = Float(diameter) / 2.0
    let radius = center

    for y in 0..<diameter {
        for x in 0..<diameter {
            let dx = Float(x) - center + 0.5
            let dy = Float(y) - center + 0.5
            let dist = sqrt(dx * dx + dy * dy) / radius

            var alpha: Float
            if dist > 1.0 {
                alpha = 0
            } else {
                // hardness: 0 = soft falloff, 1 = hard edge
                let falloff = (dist - hardness) / (1.0 - hardness + 0.001)
                alpha = max(0, 1.0 - max(0, falloff))
            }

            pixels[y * diameter + x] = UInt8(alpha * 255)
        }
    }

    texture.replace(
        region: MTLRegion(origin: .init(), size: .init(width: diameter, height: diameter, depth: 1)),
        mipmapLevel: 0,
        withBytes: pixels,
        bytesPerRow: diameter
    )
    return texture
}
```

### Step 3.3 — Metal Compute Shader for Brush Compositing

This compute kernel stamps the brush onto a layer texture. Called once per stamp position.

```metal
// BrushShaders.metal
#include <metal_stdlib>
using namespace metal;

struct StampParams {
    float2 position;    // center of stamp in canvas coords
    float size;         // stamp diameter in pixels
    float opacity;      // 0-1
    float rotation;     // radians
    float4 color;       // brush RGBA
};

kernel void brushStampKernel(
    texture2d<half, access::read_write> canvas [[texture(0)]],
    texture2d<half, access::read>       stamp  [[texture(1)]],
    constant StampParams& params [[buffer(0)]],
    uint2 gid [[thread_position_in_grid]]
) {
    float2 canvasSize = float2(canvas.get_width(), canvas.get_height());
    float halfSize = params.size * 0.5;

    // Stamp bounding box
    float2 stampMin = params.position - halfSize;
    float2 stampMax = params.position + halfSize;

    float2 pixelPos = float2(gid);
    if (pixelPos.x < stampMin.x || pixelPos.x >= stampMax.x ||
        pixelPos.y < stampMin.y || pixelPos.y >= stampMax.y) {
        return;
    }

    // UV within the stamp (0-1)
    float2 uv = (pixelPos - stampMin) / params.size;

    // Apply rotation around stamp center
    float cosR = cos(params.rotation);
    float sinR = sin(params.rotation);
    float2 centered = uv - 0.5;
    float2 rotated = float2(
        centered.x * cosR - centered.y * sinR,
        centered.x * sinR + centered.y * cosR
    );
    uv = rotated + 0.5;

    if (uv.x < 0 || uv.x > 1 || uv.y < 0 || uv.y > 1) return;

    // Sample stamp texture
    constexpr sampler s(coord::normalized, filter::linear);
    half stampAlpha = stamp.sample(s, uv).r;

    // Final alpha with brush opacity and pressure
    half finalAlpha = stampAlpha * half(params.opacity);

    // Read existing canvas pixel
    half4 dst = canvas.read(gid);

    // Composite (premultiplied alpha "over")
    half4 src = half4(half3(params.color.rgb), 1.0h) * finalAlpha;
    half4 result = src + dst * (1.0h - finalAlpha);

    canvas.write(result, gid);
}
```

### Step 3.4 — Dispatching the Compute Shader from Swift

```swift
func applyBrushStamps(_ stamps: [StampData], to layerTexture: MTLTexture,
                       brushStamp: MTLTexture, color: SIMD4<Float>) {
    guard let commandBuffer = commandQueue.makeCommandBuffer(),
          let encoder = commandBuffer.makeComputeCommandEncoder() else { return }

    encoder.setComputePipelineState(computePipelineState)
    encoder.setTexture(layerTexture, index: 0)
    encoder.setTexture(brushStamp, index: 1)

    for stamp in stamps {
        var params = StampParams(
            position: stamp.position,
            size: stamp.size * Float(brushDiameter),
            opacity: stamp.opacity * brushOpacity,
            rotation: stamp.rotation,
            color: color
        )
        encoder.setBytes(&params, length: MemoryLayout<StampParams>.size, index: 0)

        // Dispatch over the stamp's bounding box only (not entire canvas)
        let stampPixels = Int(params.size) + 2
        let threadgroupSize = MTLSize(width: 16, height: 16, depth: 1)
        let threadgroups = MTLSize(
            width: (stampPixels + 15) / 16,
            height: (stampPixels + 15) / 16,
            depth: 1
        )
        encoder.dispatchThreadgroups(threadgroups, threadsPerThreadgroup: threadgroupSize)
    }

    encoder.endEncoding()
    commandBuffer.commit()
}

struct StampParams {
    var position: SIMD2<Float>
    var size: Float
    var opacity: Float
    var rotation: Float
    var color: SIMD4<Float>
}
```

### Step 3.5 — Dual-Texture Active Stroke Pattern

To support undo and non-destructive stroke preview:

```
Layer Texture (committed) ──────┐
                                 ├── display composite
Active Stroke Texture (temp) ───┘

touchesBegan:  clear active stroke texture
touchesMoved:  stamp brush onto active stroke texture
touchesEnded:  composite active stroke → layer texture (commit)
               push undo snapshot
               clear active stroke texture
```

This means in-progress strokes can be canceled without affecting the layer, and the stroke appears with correct opacity accumulation (stamps don't double-blend mid-stroke).

---

## Phase 4: Layer System & Compositing

**SDKs:** Metal (fragment shaders)

### Step 4.1 — Layer Data Model

```swift
@Observable
class CanvasState {
    var layers: [Layer] = []
    var activeLayerIndex: Int = 0
    var canvasWidth: Int = 4096
    var canvasHeight: Int = 4096

    var activeLayer: Layer { layers[activeLayerIndex] }

    func addLayer() {
        let layer = Layer(
            texture: createCanvasTexture(width: canvasWidth, height: canvasHeight),
            name: "Layer \(layers.count + 1)"
        )
        layers.append(layer)
    }
}

struct Layer: Identifiable {
    let id = UUID()
    var texture: MTLTexture
    var name: String
    var opacity: Float = 1.0
    var blendMode: BlendMode = .normal
    var isVisible: Bool = true
    var isLocked: Bool = false
}

enum BlendMode: String, CaseIterable {
    case normal, multiply, screen, overlay
    case darken, lighten
    case colorDodge, colorBurn
    case softLight, hardLight
    case difference, exclusion
    case hue, saturation, color, luminosity
}
```

### Step 4.2 — Layer Compositing Fragment Shader

Each frame, composite all visible layers bottom-to-top in a single render pass:

```metal
// CompositeShaders.metal
#include <metal_stdlib>
using namespace metal;

struct VertexOut {
    float4 position [[position]];
    float2 texCoord;
};

// Fullscreen quad vertex shader
vertex VertexOut vertexPassthrough(uint vid [[vertex_id]]) {
    float2 positions[4] = {
        float2(-1, -1), float2(1, -1),
        float2(-1,  1), float2(1,  1)
    };
    float2 texCoords[4] = {
        float2(0, 1), float2(1, 1),
        float2(0, 0), float2(1, 0)
    };
    VertexOut out;
    out.position = float4(positions[vid], 0, 1);
    out.texCoord = texCoords[vid];
    return out;
}

// Blend mode functions
half3 blendMultiply(half3 base, half3 blend) {
    return base * blend;
}

half3 blendScreen(half3 base, half3 blend) {
    return 1.0h - (1.0h - base) * (1.0h - blend);
}

half3 blendOverlay(half3 base, half3 blend) {
    half3 result;
    for (int i = 0; i < 3; i++) {
        result[i] = base[i] < 0.5h
            ? 2.0h * base[i] * blend[i]
            : 1.0h - 2.0h * (1.0h - base[i]) * (1.0h - blend[i]);
    }
    return result;
}

half3 blendDarken(half3 base, half3 blend) {
    return min(base, blend);
}

half3 blendLighten(half3 base, half3 blend) {
    return max(base, blend);
}

half3 blendColorDodge(half3 base, half3 blend) {
    return base / max(1.0h - blend, 0.001h);
}

half3 blendColorBurn(half3 base, half3 blend) {
    return 1.0h - (1.0h - base) / max(blend, 0.001h);
}

half3 blendSoftLight(half3 base, half3 blend) {
    half3 result;
    for (int i = 0; i < 3; i++) {
        result[i] = blend[i] < 0.5h
            ? base[i] - (1.0h - 2.0h * blend[i]) * base[i] * (1.0h - base[i])
            : base[i] + (2.0h * blend[i] - 1.0h) * (sqrt(base[i]) - base[i]);
    }
    return result;
}

half3 blendHardLight(half3 base, half3 blend) {
    return blendOverlay(blend, base); // overlay with args swapped
}

half3 blendDifference(half3 base, half3 blend) {
    return abs(base - blend);
}

half3 blendExclusion(half3 base, half3 blend) {
    return base + blend - 2.0h * base * blend;
}

// Apply selected blend mode
half3 applyBlend(half3 base, half3 blend, int mode) {
    switch (mode) {
        case 0: return blend;                         // normal
        case 1: return blendMultiply(base, blend);
        case 2: return blendScreen(base, blend);
        case 3: return blendOverlay(base, blend);
        case 4: return blendDarken(base, blend);
        case 5: return blendLighten(base, blend);
        case 6: return blendColorDodge(base, blend);
        case 7: return blendColorBurn(base, blend);
        case 8: return blendSoftLight(base, blend);
        case 9: return blendHardLight(base, blend);
        case 10: return blendDifference(base, blend);
        case 11: return blendExclusion(base, blend);
        default: return blend;
    }
}

struct LayerInfo {
    float opacity;
    int blendMode;
    int isVisible;
    int _pad;
};

fragment half4 fragmentComposite(
    VertexOut in [[stage_in]],
    texture2d<half> layer0 [[texture(0)]],
    texture2d<half> layer1 [[texture(1)]],
    texture2d<half> layer2 [[texture(2)]],
    texture2d<half> layer3 [[texture(3)]],
    constant LayerInfo* layerInfos [[buffer(0)]],
    constant int& layerCount [[buffer(1)]]
) {
    constexpr sampler s(coord::normalized, filter::linear);
    float2 uv = in.texCoord;

    // Start with layer 0 (background)
    half4 result = half4(1, 1, 1, 1); // white canvas

    // Array of textures (up to 4 shown; expand as needed)
    texture2d<half> layers[4] = { layer0, layer1, layer2, layer3 };

    for (int i = 0; i < min(layerCount, 4); i++) {
        if (layerInfos[i].isVisible == 0) continue;

        half4 src = layers[i].sample(s, uv);
        half srcAlpha = src.a * half(layerInfos[i].opacity);

        if (srcAlpha < 0.001h) continue;

        half3 blended = applyBlend(result.rgb, src.rgb, layerInfos[i].blendMode);
        result.rgb = mix(result.rgb, blended, srcAlpha);
        result.a = result.a + srcAlpha * (1.0h - result.a);
    }

    return result;
}
```

For more than 4 layers: use multiple render passes, or use argument buffers / texture arrays (`texture2d_array`).

---

## Phase 5: Undo/Redo System

### Step 5.1 — Region-Based Undo Snapshots

Full-texture copies are too expensive. Capture only the changed bounding rect:

```swift
struct UndoSnapshot {
    let layerIndex: Int
    let region: MTLRegion
    let texture: MTLTexture  // small texture covering just the changed region
}

class UndoManager {
    var undoStack: [UndoSnapshot] = []
    var redoStack: [UndoSnapshot] = []
    let maxUndoSteps = 50

    func captureBeforeStroke(layerTexture: MTLTexture, boundingRect: CGRect,
                              layerIndex: Int, device: MTLDevice) {
        let x = max(0, Int(boundingRect.minX))
        let y = max(0, Int(boundingRect.minY))
        let w = min(Int(boundingRect.width) + 1, layerTexture.width - x)
        let h = min(Int(boundingRect.height) + 1, layerTexture.height - y)

        let region = MTLRegion(origin: MTLOrigin(x: x, y: y, z: 0),
                                size: MTLSize(width: w, height: h, depth: 1))

        // Create a small texture for just this region
        let desc = MTLTextureDescriptor.texture2DDescriptor(
            pixelFormat: layerTexture.pixelFormat,
            width: w, height: h, mipmapped: false
        )
        desc.usage = [.shaderRead, .shaderWrite]
        let snapshot = device.makeTexture(descriptor: desc)!

        // Copy region via blit encoder
        let commandBuffer = commandQueue.makeCommandBuffer()!
        let blit = commandBuffer.makeBlitCommandEncoder()!
        blit.copy(from: layerTexture, sourceSlice: 0, sourceLevel: 0,
                  sourceOrigin: region.origin, sourceSize: region.size,
                  to: snapshot, destinationSlice: 0, destinationLevel: 0,
                  destinationOrigin: MTLOrigin(x: 0, y: 0, z: 0))
        blit.endEncoding()
        commandBuffer.commit()

        undoStack.append(UndoSnapshot(layerIndex: layerIndex, region: region, texture: snapshot))
        redoStack.removeAll()

        if undoStack.count > maxUndoSteps {
            undoStack.removeFirst()
        }
    }

    func undo(layers: inout [Layer]) {
        guard let snapshot = undoStack.popLast() else { return }
        // Before restoring, capture current state for redo
        // ... (same capture logic)

        // Blit the snapshot back to the layer texture
        let commandBuffer = commandQueue.makeCommandBuffer()!
        let blit = commandBuffer.makeBlitCommandEncoder()!
        blit.copy(from: snapshot.texture, sourceSlice: 0, sourceLevel: 0,
                  sourceOrigin: MTLOrigin(x: 0, y: 0, z: 0),
                  sourceSize: MTLSize(width: snapshot.texture.width,
                                      height: snapshot.texture.height, depth: 1),
                  to: layers[snapshot.layerIndex].texture,
                  destinationSlice: 0, destinationLevel: 0,
                  destinationOrigin: snapshot.region.origin)
        blit.endEncoding()
        commandBuffer.commit()
    }
}
```

---

## Phase 6: Core Image Filters on Layers

**SDKs:** Core Image, Metal

### Step 6.1 — Setting Up CIContext with Metal

```swift
let ciContext = CIContext(mtlDevice: device, options: [
    .workingColorSpace: CGColorSpace(name: CGColorSpace.sRGB)!,
    .outputPremultiplied: true
])
```

### Step 6.2 — Applying Filters to a Layer

```swift
func applyGaussianBlur(to layerTexture: MTLTexture, radius: Float) {
    let ciImage = CIImage(mtlTexture: layerTexture)!

    let filter = CIFilter.gaussianBlur()
    filter.inputImage = ciImage
    filter.radius = radius

    guard let output = filter.outputImage else { return }

    let commandBuffer = commandQueue.makeCommandBuffer()!
    ciContext.render(output, to: layerTexture, commandBuffer: commandBuffer,
                    bounds: output.extent, colorSpace: CGColorSpace(name: CGColorSpace.sRGB)!)
    commandBuffer.commit()
}
```

### Step 6.3 — Useful CIFilters for a Drawing App

| Filter                | Class                    | Key Parameters                         | Use Case           |
| --------------------- | ------------------------ | -------------------------------------- | ------------------ |
| Gaussian Blur         | `CIGaussianBlur`         | `radius`                               | Soften layer       |
| Motion Blur           | `CIMotionBlur`           | `radius`, `angle`                      | Directional blur   |
| Sharpen               | `CISharpenLuminance`     | `sharpness`, `radius`                  | Sharpen details    |
| Color Controls        | `CIColorControls`        | `brightness`, `contrast`, `saturation` | Adjust colors      |
| Hue Adjust            | `CIHueAdjust`            | `angle`                                | Rotate hue         |
| Exposure              | `CIExposureAdjust`       | `ev`                                   | Brighten/darken    |
| Vibrance              | `CIVibrance`             | `amount`                               | Boost muted colors |
| Noise Reduction       | `CINoiseReduction`       | `noiseLevel`, `sharpness`              | Smooth noise       |
| Perspective Transform | `CIPerspectiveTransform` | corner points                          | Warp layer         |
| Pixellate             | `CIPixellate`            | `scale`                                | Pixel art effect   |
| Crystallize           | `CICrystallize`          | `radius`                               | Crystal effect     |
| Pointillize           | `CIPointillize`          | `radius`                               | Pointillism        |
| Comic Effect          | `CIComicEffect`          | (none)                                 | Cartoon style      |
| Edges                 | `CIEdges`                | `intensity`                            | Edge detection     |

---

## Phase 7: PencilKit Quick-Start (Alternative to Custom Engine)

**SDK:** PencilKit

If a full Metal engine is too complex, PencilKit provides a turnkey drawing canvas. It handles strokes, tools, undo, and the tool picker automatically. The tradeoff: no custom blend modes, no layer system, limited brush customization.

### Step 7.1 — Basic PencilKit Canvas

```swift
import SwiftUI
import PencilKit

struct DrawingView: UIViewRepresentable {
    @Binding var canvasView: PKCanvasView
    @Binding var drawing: PKDrawing

    func makeUIView(context: Context) -> PKCanvasView {
        canvasView.tool = PKInkingTool(.pen, color: .black, width: 5)
        canvasView.drawingPolicy = .anyInput // finger + pencil
        canvasView.delegate = context.coordinator
        canvasView.drawing = drawing
        canvasView.backgroundColor = .white
        canvasView.isOpaque = true
        return canvasView
    }

    func updateUIView(_ uiView: PKCanvasView, context: Context) {}

    func makeCoordinator() -> Coordinator {
        Coordinator(drawing: $drawing)
    }

    class Coordinator: NSObject, PKCanvasViewDelegate {
        @Binding var drawing: PKDrawing

        init(drawing: Binding<PKDrawing>) {
            _drawing = drawing
        }

        func canvasViewDrawingDidChange(_ canvasView: PKCanvasView) {
            drawing = canvasView.drawing
        }
    }
}
```

### Step 7.2 — Tool Picker

```swift
struct DrawingScreen: View {
    @State private var canvasView = PKCanvasView()
    @State private var drawing = PKDrawing()
    @State private var showToolPicker = true

    var body: some View {
        DrawingView(canvasView: $canvasView, drawing: $drawing)
            .onAppear {
                if showToolPicker {
                    let toolPicker = PKToolPicker()
                    toolPicker.setVisible(true, forFirstResponder: canvasView)
                    toolPicker.addObserver(canvasView)
                    canvasView.becomeFirstResponder()
                }
            }
    }
}
```

### Step 7.3 — PKStroke Anatomy

Each stroke in PencilKit is a `PKStroke` containing an array of `PKStrokePoint`s:

| Property     | Type           | Description                |
| ------------ | -------------- | -------------------------- |
| `location`   | `CGPoint`      | Position on canvas         |
| `force`      | `CGFloat`      | Pressure (0-1)             |
| `azimuth`    | `CGFloat`      | Pencil direction (radians) |
| `altitude`   | `CGFloat`      | Pencil tilt (radians)      |
| `opacity`    | `CGFloat`      | Point opacity              |
| `size`       | `CGSize`       | Point size                 |
| `timeOffset` | `TimeInterval` | Time since stroke start    |

### Step 7.4 — Export Drawing

```swift
// Export as PNG image
let image = drawing.image(from: drawing.bounds, scale: UIScreen.main.scale)

// Export as data (for persistence)
let data = drawing.dataRepresentation()

// Restore from data
let restored = try PKDrawing(data: data)
```

### PencilKit vs Custom Metal Engine

| Feature                   | PencilKit       | Custom Metal       |
| ------------------------- | --------------- | ------------------ |
| Setup complexity          | 3 lines of code | Weeks of work      |
| Layers                    | No              | Yes                |
| Blend modes               | No              | Yes (all 16+)      |
| Custom brushes            | Very limited    | Unlimited          |
| Performance               | Good (60fps)    | Excellent (120fps) |
| Undo/redo                 | Built-in        | Must implement     |
| Apple Pencil Pro features | Auto-supported  | Must implement     |
| Canvas resolution         | Limited         | Any (4K+)          |
| Export to PSD/layers      | No              | Yes                |
| Filter effects            | No              | Yes (Core Image)   |

**Recommendation:** Use PencilKit for annotation apps, note-taking, signing. Use custom Metal for anything that needs layers, custom brushes, or pro-grade control.

---

## Phase 8: Export & File System

### Step 8.1 — Export as PNG/JPEG

```swift
func exportCanvas(layers: [Layer], format: ExportFormat) -> Data? {
    // Composite all layers to a single texture (same as display composite)
    let composited = compositeAllLayers(layers)

    // Read pixels from GPU texture
    let width = composited.width
    let height = composited.height
    let bytesPerRow = width * 4
    var pixels = [UInt8](repeating: 0, count: width * height * 4)

    composited.getBytes(&pixels, bytesPerRow: bytesPerRow,
                         from: MTLRegion(origin: .init(), size: .init(width: width, height: height, depth: 1)),
                         mipmapLevel: 0)

    let colorSpace = CGColorSpaceCreateDeviceRGB()
    guard let context = CGContext(
        data: &pixels,
        width: width, height: height,
        bitsPerComponent: 8,
        bytesPerRow: bytesPerRow,
        space: colorSpace,
        bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue
    ), let cgImage = context.makeImage() else { return nil }

    let uiImage = UIImage(cgImage: cgImage)
    switch format {
    case .png: return uiImage.pngData()
    case .jpeg: return uiImage.jpegData(compressionQuality: 0.9)
    }
}
```

### Step 8.2 — Timelapse Recording

Capture canvas state each frame (or every N frames) and encode to video:

```swift
import AVFoundation

class TimelapseRecorder {
    var assetWriter: AVAssetWriter?
    var pixelBufferAdaptor: AVAssetWriterInputPixelBufferAdaptor?
    var frameCount: Int = 0

    func captureFrame(from texture: MTLTexture) {
        // Create CVPixelBuffer from MTLTexture
        // Append to asset writer
        // ... (use CVPixelBufferPool for performance)
    }
}
```

---

## Phase 9: SwiftUI App Chrome

### Step 9.1 — Color Picker

```swift
struct BrushColorPicker: View {
    @Binding var selectedColor: Color

    var body: some View {
        ColorPicker("Brush Color", selection: $selectedColor, supportsOpacity: true)
    }
}
```

### Step 9.2 — Brush Size & Opacity Sliders

```swift
struct BrushControls: View {
    @Binding var brushSize: CGFloat
    @Binding var brushOpacity: CGFloat

    var body: some View {
        VStack {
            HStack {
                Image(systemName: "circle.fill")
                    .font(.caption2)
                Slider(value: $brushSize, in: 1...200)
                Image(systemName: "circle.fill")
                    .font(.title)
            }
            HStack {
                Text("Opacity")
                    .font(.caption)
                Slider(value: $brushOpacity, in: 0...1)
                Text("\(Int(brushOpacity * 100))%")
                    .font(.caption.monospaced())
            }
        }
        .padding()
    }
}
```

### Step 9.3 — Layer Panel

```swift
struct LayerPanel: View {
    var canvasState: CanvasState

    var body: some View {
        List {
            ForEach(canvasState.layers.reversed()) { layer in
                HStack {
                    // Thumbnail (render small version of layer)
                    RoundedRectangle(cornerRadius: 4)
                        .fill(.gray.opacity(0.2))
                        .frame(width: 48, height: 48)

                    VStack(alignment: .leading) {
                        Text(layer.name)
                            .font(.caption)
                        Text(layer.blendMode.rawValue.capitalized)
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                    }

                    Spacer()

                    Button {
                        // Toggle visibility
                    } label: {
                        Image(systemName: layer.isVisible ? "eye" : "eye.slash")
                    }
                }
            }
            .onMove { from, to in
                // Reorder layers
            }
        }
    }
}
```

---

## Key Imports Reference

```swift
import Metal          // MTLDevice, MTLCommandQueue, MTLTexture, pipelines
import MetalKit       // MTKView, MTKTextureLoader
import UIKit          // UITouch, UIGestureRecognizer, UIPencilInteraction
import PencilKit      // PKCanvasView, PKDrawing, PKToolPicker (turnkey alternative)
import CoreImage      // CIFilter, CIContext, CIImage (layer filters)
import CoreGraphics   // CGContext, CGImage, UIBezierPath (path math, export)
import simd           // SIMD2, SIMD4, simd_float3x3 (vector/matrix math)
import Accelerate     // vDSP (bulk pixel ops, color space conversion)
import CoreHaptics    // CHHapticEngine (Apple Pencil Pro feedback)
import PhotosUI       // PHPickerViewController (image import)
import AVFoundation   // AVAssetWriter (timelapse recording)
```

---

## Permissions Reference

| Permission            | Key                                               | Example Value                       |
| --------------------- | ------------------------------------------------- | ----------------------------------- |
| Photo Library (read)  | `INFOPLIST_KEY_NSPhotoLibraryUsageDescription`    | "Import images as reference layers" |
| Photo Library (write) | `INFOPLIST_KEY_NSPhotoLibraryAddUsageDescription` | "Save your artwork to Photos"       |

---

## Memory Management for Large Canvases

| Canvas Size | Layers (rgba16Float)         | Memory per Layer | 10 Layers |
| ----------- | ---------------------------- | ---------------- | --------- |
| 2048×2048   | Small                        | 32 MB            | 320 MB    |
| 4096×4096   | Standard (Procreate default) | 128 MB           | 1.28 GB   |
| 8192×8192   | Large                        | 512 MB           | 5.12 GB   |
| 16384×16384 | Maximum                      | 2 GB             | 20 GB     |

**Strategies:**

- Limit max layers based on canvas size (Procreate does this)
- Use `.rgba8Unorm` (half the memory) when HDR isn't needed
- Use tiled rendering for very large canvases (only load visible tiles)
- Release undo history when memory pressure is high
- Use `storageMode: .private` for GPU-only textures (no CPU copy)
