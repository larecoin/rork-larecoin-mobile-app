---
index: true
description: "@MainActor, nonisolated, Sendable, actors, async/await, Swift 6 errors, diagnostics workflow"
---

# Swift Concurrency Reference

> Start with @MainActor for UI code. Add async/await for I/O. Only move CPU work off-main when profiling shows you need it.

## Diagnostic Fast Path

Before changing concurrency code:

1. Capture the exact compiler or lint diagnostic and the offending symbol.
2. Identify the isolation boundary: `@MainActor`, another actor, `nonisolated`, or a `Sendable` transfer.
3. Confirm whether the code is truly UI-bound before adding `@MainActor`.
4. Prefer the smallest safe fix that preserves behavior.

## Guardrails

- Do not use `@MainActor` as a blanket fix for background services or pure data types.
- Do not add fake suspension points like `await Task.yield()` just to satisfy a lint rule.
- Prefer structured concurrency (`async/await`, `async let`, `withTaskGroup`) over `Task.detached`.
- Treat `@unchecked Sendable` and `nonisolated(unsafe)` as last resorts, and only when you can explain the safety invariant.

## Quick Error Router

> See **Common Swift 6 Errors and Fixes** below for full code examples.

| Diagnostic                                              | First check                                                          | Smallest safe fix                                                                        |
| ------------------------------------------------------- | -------------------------------------------------------------------- | ---------------------------------------------------------------------------------------- |
| Main actor-isolated API used from nonisolated code      | Is the caller actually UI-owned?                                     | Isolate the caller correctly or use `await MainActor.run { ... }` for a narrow hop       |
| Non-Sendable value crossing an actor boundary           | What value is crossing the boundary?                                 | Keep the work in one isolation domain or convert to an immutable `Sendable` type         |
| Actor-isolated property mutated from `nonisolated` code | Does this method need to be `nonisolated`?                           | Make the method isolated again or move the mutation behind an actor hop                  |
| `async_without_await` lint                              | Is `async` required by a protocol, override, or isolation attribute? | Remove `async` if not required; if forced by protocol/override, keep it and document why |

## @MainActor — UI Thread Isolation

### On Classes (ViewModel Pattern)

```swift
@MainActor
@Observable
final class ProfileViewModel {
    var name = ""
    var isLoading = false

    func loadProfile() async {
        isLoading = true
        let profile = try? await ProfileService.fetch()
        name = profile?.name ?? ""
        isLoading = false
    }
}
```

### On Functions

```swift
@MainActor
func updateUI(with data: Data) {
    label.text = String(data: data, encoding: .utf8)
}
```

### nonisolated — Opt Out of MainActor

```swift
@MainActor
@Observable
final class ImageLoader {
    var image: UIImage?

    nonisolated func processImage(_ data: Data) -> UIImage? {
        UIImage(data: data)?.preparingThumbnail(of: CGSize(width: 200, height: 200))
    }
}
```

### SwiftUI Closures That May Run Off-Main

Some SwiftUI APIs use `Sendable` closures and may evaluate them off the main actor for performance, including `Shape` path building, `Layout` methods, `visualEffect`, and `onGeometryChange`.

- Do not read `@MainActor` state directly inside those closures.
- Capture value copies instead of sending `self` just to read one property.
- Keep these closures pure and lightweight; move UI-owned mutations back to `@MainActor`.

## async/await

### Basic Async Function

```swift
func fetchUser(id: String) async throws -> User {
    let url = URL(string: "https://api.example.com/users/\(id)")!
    let (data, _) = try await URLSession.shared.data(from: url)
    return try JSONDecoder().decode(User.self, from: data)
}
```

### Calling from SwiftUI

```swift
struct UserView: View {
    @State private var user: User?

    var body: some View {
        VStack {
            if let user {
                Text(user.name)
            }
        }
        .task {
            user = try? await fetchUser(id: "123")
        }
    }
}
```

### .task with ID — Re-Run on Value Change

```swift
.task(id: selectedCategory) {
    items = try? await fetchItems(for: selectedCategory)
}
```

## Task Groups — Parallel Work

```swift
func loadDashboard() async throws -> Dashboard {
    async let profile = fetchProfile()
    async let stats = fetchStats()
    async let notifications = fetchNotifications()

    return Dashboard(
        profile: try await profile,
        stats: try await stats,
        notifications: try await notifications
    )
}
```

### TaskGroup for Dynamic Parallelism

```swift
func loadImages(urls: [URL]) async -> [UIImage] {
    await withTaskGroup(of: UIImage?.self) { group in
        for url in urls {
            group.addTask {
                let (data, _) = try? await URLSession.shared.data(from: url)
                return data.flatMap { UIImage(data: $0) }
            }
        }

        var images: [UIImage] = []
        for await image in group {
            if let image { images.append(image) }
        }
        return images
    }
}

// Swift 6.1+: type inferred from first addTask (no `of:` needed)
await withTaskGroup { group in
    group.addTask { await fetchImage(url1) }
    group.addTask { await fetchImage(url2) }
}
```

## Sendable

Types that cross actor boundaries must be `Sendable`:

```swift
// Value types are automatically Sendable
struct UserData: Sendable {
    let name: String
    let email: String
}

// Classes need explicit conformance + immutability
final class Config: Sendable {
    let apiKey: String    // Only let properties
    let baseURL: URL

    init(apiKey: String, baseURL: URL) {
        self.apiKey = apiKey
        self.baseURL = baseURL
    }
}

// @unchecked Sendable — you promise thread safety (use sparingly)
final class Cache: @unchecked Sendable {
    private let lock = NSLock()
    private var storage: [String: Data] = [:]

    func get(_ key: String) -> Data? {
        lock.withLock { storage[key] }
    }
}
```

### sending — Transfer Ownership Across Boundaries (Swift 6.0+)

`sending` marks parameters or return values that transfer ownership across isolation boundaries:

```swift
func processData(_ data: sending Data) async {
    // data is guaranteed not to be accessed by the caller after this point
}

func createItem() -> sending Item {
    // Caller receives exclusive ownership
    Item()
}
```

The compiler enforces that `sending` values aren't used after being passed to another isolation domain.

### nonisolated(unsafe) — Suppress Isolation Checking (Swift 5.10+)

Suppress isolation checking when you know a value is safe but the compiler can't prove it:

```swift
nonisolated(unsafe) var globalConfig: Config?
```

Use sparingly — incorrect use causes data races the compiler won't catch.

## Actors — Isolated Mutable State

```swift
actor ImageCache {
    private var cache: [URL: UIImage] = [:]

    func image(for url: URL) -> UIImage? {
        cache[url]
    }

    func store(_ image: UIImage, for url: URL) {
        cache[url] = image
    }
}

// Usage — must await
let cache = ImageCache()
await cache.store(image, for: url)
let cached = await cache.image(for: url)
```

## Bridging Callbacks to async/await

### withCheckedContinuation

```swift
func fetchLocation() async -> CLLocation? {
    await withCheckedContinuation { continuation in
        locationManager.requestLocation { location in
            continuation.resume(returning: location)
        }
    }
}
```

### withCheckedThrowingContinuation

```swift
func authenticate() async throws -> Token {
    try await withCheckedThrowingContinuation { continuation in
        authService.login { result in
            switch result {
            case .success(let token):
                continuation.resume(returning: token)
            case .failure(let error):
                continuation.resume(throwing: error)
            }
        }
    }
}
```

**CRITICAL:** Resume exactly once. Double-resume crashes. Never-resume leaks.

### Resume Methods

| Method                      | Use                       |
| --------------------------- | ------------------------- |
| `.resume(returning: value)` | Return a value            |
| `.resume(throwing: error)`  | Throw an error            |
| `.resume(with: result)`     | Pass a `Result<T, Error>` |
| `.resume()`                 | Return Void               |

## Common Swift 6 Errors and Fixes

### "Sending 'self' risks causing data races"

```swift
// ❌ Error: sending 'self' risks causing data races
@Observable
class VM {
    var data: [Item] = []

    func load() async {
        let data = await fetch()    // fetch() is nonisolated
        self.data = data            // Error: sending 'self' risks data race
    }
}

// ✅ Fix: Mark the class @MainActor so load() is isolated
@Observable
@MainActor
class VM {
    var data: [Item] = []

    func load() async {
        let data = await fetch()
        self.data = data            // Back on MainActor — fine
    }
}
```

### "Non-sendable type cannot cross actor boundary"

```swift
// ❌ Passing non-Sendable type across actors
class MyData { var value = 0 }    // Not Sendable

Task { @MainActor in
    let data = MyData()
    await backgroundActor.process(data)    // Error
}

// ✅ Fix 1: Make it Sendable (struct or final class with let)
struct MyData: Sendable { let value: Int }

// ✅ Fix 2: Use @unchecked Sendable if you manage thread safety
final class MyData: @unchecked Sendable { ... }
```

### "Actor-isolated property cannot be mutated from nonisolated context"

```swift
// ❌
@MainActor class VM {
    var count = 0

    nonisolated func increment() {
        count += 1    // Error: can't mutate MainActor property
    }
}

// ✅ Make the function isolated or use Task
@MainActor class VM {
    var count = 0

    func increment() {    // Inherits @MainActor
        count += 1
    }
}
```

### "Call to main actor-isolated function in synchronous nonisolated context"

```swift
// ❌
func doWork() {
    updateUI()    // Error: updateUI is @MainActor
}

// ✅ Fix 1: Make caller async
func doWork() async {
    await updateUI()
}

// ✅ Fix 2: Use Task
func doWork() {
    Task { @MainActor in
        updateUI()
    }
}
```

## Cancellation

```swift
func loadData() async throws -> [Item] {
    var items: [Item] = []

    for page in 1...10 {
        try Task.checkCancellation()    // Throws if cancelled

        let pageItems = try await fetchPage(page)
        items.append(contentsOf: pageItems)
    }
    return items
}

// Check without throwing
if Task.isCancelled { return }
```

`.task` modifier cancels automatically when the view disappears.

## Swift 6.2 — Approachable Concurrency (Xcode 26)

Swift 6.2 introduces "Approachable Concurrency" — a set of features that make concurrency simpler by defaulting to main-actor isolation.

### Default MainActor Isolation (SE-0466)

New Xcode 26 projects infer `@MainActor` on most declarations that lack explicit isolation. Exceptions: `actor` types, `Sendable`/`CodingKey` conformances, typealiases, imports.

```swift
// Most code is @MainActor by default in new projects
func updateUI() {
    // Runs on main actor — no annotation needed
}

@Observable
class ViewModel {
    // Already @MainActor — no annotation needed
    var count = 0
}
```

Build setting: `SWIFT_DEFAULT_ACTOR_ISOLATION = MainActor` (new projects default to this).

A separate setting `SWIFT_APPROACHABLE_CONCURRENCY` enables additional features including `nonisolated(nonsending)` as default (SE-0461).

### Quick Notes

- Async functions stay on the caller's actor by default unless the implementation explicitly offloads work.
- Main-actor-by-default reduces noise for UI-bound code, but it does not make CPU-heavy work acceptable on the main actor.
- Prefer minimal annotations when the code is naturally UI-owned.

### @concurrent — Opt Out of MainActor

Use `@concurrent` to explicitly run off the main actor. It implies `nonisolated` and cannot be combined with `@MainActor`:

```swift
@concurrent
func processImage(_ data: Data) -> UIImage? {
    // Runs on a cooperative thread pool, NOT on main actor
    UIImage(data: data)?.preparingThumbnail(of: CGSize(width: 200, height: 200))
}

@concurrent
func heavyComputation(_ values: [Double]) -> Double {
    values.reduce(0, +) / Double(values.count)
}
```

### nonisolated(nonsending) — Stay on Caller's Actor (SE-0461)

Async functions marked `nonisolated` now default to `nonisolated(nonsending)` — they run on whatever actor the caller is on, avoiding unnecessary hops. Arguments don't need to be `Sendable`:

```swift
// Runs on the caller's actor (no hop)
nonisolated func formatDate(_ date: Date) async -> String {
    // If called from @MainActor, stays on main actor
    // If called from another actor, stays on that actor
    let formatter = DateFormatter()
    formatter.dateStyle = .medium
    return formatter.string(from: date)
}
```

Enabled by `SWIFT_APPROACHABLE_CONCURRENCY` build setting. Use `@concurrent` to opt a function into the old behavior (hop off the caller's actor).

### Task.immediate (SE-0472)

Start a task synchronously on the current actor, only suspending at the first actual suspension point:

```swift
@MainActor
func refresh() {
    Task.immediate {
        // Runs synchronously here (no hop)
        showLoadingIndicator()

        // First actual suspension point — may hop
        let data = await fetchData()
        updateUI(with: data)
    }
}
```

Also available: `Task.immediateDetached { }` and `group.addImmediateTask { }`.

## Anti-Patterns

| Anti-Pattern                                       | Fix                                                                                                      |
| -------------------------------------------------- | -------------------------------------------------------------------------------------------------------- |
| `DispatchQueue.main.async` in SwiftUI              | Use `@MainActor` or `Task { @MainActor in }`                                                             |
| `DispatchQueue.global().async` for background work | Prefer structured concurrency or nonisolated async functions; reserve `Task.detached` for escape hatches |
| Forgetting `@MainActor` on Observable classes      | All ViewModels should be `@MainActor` (automatic in Swift 6.2)                                           |
| `Task { }` inside `.onAppear`                      | Use `.task { }` — auto-cancels on disappear                                                              |
| Resuming continuation zero or multiple times       | Always resume exactly once on all paths                                                                  |
| Global mutable state without actor isolation       | Use an `actor` or `@MainActor` singleton. Last resort: `nonisolated(unsafe)`                             |
| `@concurrent` combined with `@MainActor`           | These are mutually exclusive — pick one                                                                  |
