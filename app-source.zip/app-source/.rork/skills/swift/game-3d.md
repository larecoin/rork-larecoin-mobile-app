---
index: true
description: ECS, collision, camera, characters, animation, forces, entity pooling
---

# RealityKit 3D Game Development

Consolidated reference for building 3D games with RealityKit on iOS. Covers ECS, collisions, cameras, generated model placement, forces, character controllers, animation, pooling, audio, joints, and raycasting.

Choose device orientation before creating a Swift/RealityKit 3D game. Follow explicit user requests first, then infer from gameplay, camera, and controls: use `createApp` with `swiftTemplateProfile: "landscape-3d-game"` when the chosen orientation is landscape, including explicit landscape/horizontal requests, generic or ambiguous Swift/RealityKit 3D games, racing/driving/flight, FPS/TPS/shooters, arena combat, action RPG/open-world/adventure, sports/fighting, dual-stick controls, wide tactical maps, or any game that needs a wide camera view or two-thumb controls. Keep portrait/default orientation for portrait-first designs such as endless/lane runners, vertical runners/climbers/fallers, one-tap or swipe hypercasual games, idle/merge/tycoon/collection games, card/board/puzzle/gacha games, vertical shooters, rhythm lane games, AR/model viewers, product viewers, and non-game 3D showcases. If a generic 3D game is ambiguous, do not ask; default to landscape and use `swiftTemplateProfile: "landscape-3d-game"`. For an existing Swift app whose chosen design is landscape, set the main iOS target's iPhone/iPad orientations to LandscapeLeft/LandscapeRight, set `INFOPLIST_KEY_UIRequiresFullScreen` to `YES`, and mark the app's `rork.json` settings with `previewOrientation: "landscape"` before final RealityKit integration. Keep device orientation separate from generated-model local axes; model facing still comes from the persisted orientation metadata in the generation tool outputs.

Read `game-core.md` first (crash prevention, state machine, save/load, audio, game polish). Related files:

- `realitykit-reference.md` — shapes, USDZ loading, advanced animation (IK, blend shapes)
- `realitykit-materials.md` — PBR textures, Metal shaders (dissolve, shield, toon, water)
- `realitykit-environment.md` — terrain, skybox, IBL, fog, water, portals
- `game-performance-reference.md` — instancing, LowLevelMesh, trails, PostProcessEffect, budgets
- `game-asset-integration.md` — bundled asset patterns for generated images, audio, 3D, video
- `game-world-layout.md` — units/scale, ground y=0, scene graph & camera ownership, level layouts per genre

---

## RealityKit ECS + RealityView Setup

RealityKit uses Entity-Component-System (ECS): **Entities** are containers, **Components** hold data, **Systems** run logic each frame over entities matching a query.

```swift
nonisolated struct PlayerComponent: Component {
    var speed: Float = 5.0
    var health: Int = 100
}

nonisolated struct PlayerMovementSystem: System {
    static let query = EntityQuery(where: .has(PlayerComponent.self))
    init(scene: Scene) {}

    func update(context: SceneUpdateContext) {
        let dt = min(Float(context.deltaTime), 1.0 / 30.0)
        for entity in context.entities(matching: Self.query, updatingSystemWhen: .rendering) {
            // per-frame logic
        }
    }
}
```

### RealityView make/update Pattern

```swift
RealityView { content in
    // runs ONCE — create entities, subscribe to events
    PlayerMovementSystem.registerSystem()
    PlayerComponent.registerComponent()
} update: { content in
    // runs ONLY when @State changes — NOT every frame
    // DO NOT put game logic here
}
```

**CRITICAL:** `RealityView update` is NOT a game loop. It only fires when SwiftUI `@State` changes. All per-frame logic must go in a custom `System.update()`.

### Systems Must Use `updatingSystemWhen: .rendering`

Without this, systems stall after ~20 frames on visionOS:

```swift
// WRONG — systems stop ticking
let entities = context.scene.performQuery(Self.query)

// CORRECT — forces continuous updates
for entity in context.entities(matching: Self.query, updatingSystemWhen: .rendering) { }
```

Workaround if you cannot change the query — subscribe to `SceneEvents.Update` (even empty forces the render loop). Keep the returned `EventSubscription` alive in `@State`; discarding it can cancel the subscription:

```swift
@State private var renderLoopSub: EventSubscription?

RealityView { content in
    renderLoopSub = content.subscribe(to: SceneEvents.Update.self) { _ in }
}
```

### Always Clamp deltaTime

During stalls, `deltaTime` can spike to 0.5s+ causing objects to teleport through walls:

```swift
let dt = min(Float(context.deltaTime), 1.0 / 30.0)
```

### Entity Count Budget

| Entity Count | Expected FPS (iPhone Pro) | Notes                                                 |
| ------------ | ------------------------- | ----------------------------------------------------- |
| <500         | 60fps                     | Comfortable budget                                    |
| 500-1000     | 30-60fps                  | Profile and optimize                                  |
| >1000        | <30fps                    | Use entity pooling, `isEnabled = false` for offscreen |

### Game State <-> SwiftUI Bridge

**ECS -> SwiftUI** — read component state in UI:

```swift
nonisolated struct ScoreComponent: Component { var score: Int = 0 }

struct ScoreView: View {
    let gameEntity: Entity
    var body: some View {
        if let s = gameEntity.components[ScoreComponent.self] {
            Text("Score: \(s.score)")
        }
    }
}
```

**SwiftUI -> ECS** — share input via `@Observable`:

```swift
@Observable
class GameInput {
    var moveDirection: SIMD2<Float> = .zero
    var jumpPressed = false
}

nonisolated struct MySystem: System {
    @MainActor static var input: GameInput?
    // read Self.input in update()
}
```

---

## Collision Groups & Events

### Named Collision Groups

```swift
nonisolated struct GameCollisionGroup {
    static let player = CollisionGroup(rawValue: 1 << 0)
    static let enemy = CollisionGroup(rawValue: 1 << 1)
    static let projectile = CollisionGroup(rawValue: 1 << 2)
    static let wall = CollisionGroup(rawValue: 1 << 3)
    static let pickup = CollisionGroup(rawValue: 1 << 4)
    static let trigger = CollisionGroup(rawValue: 1 << 5)
    static let ground = CollisionGroup(rawValue: 1 << 6)
    static let deathZone = CollisionGroup(rawValue: 1 << 7)
}
```

### CollisionFilter with Group and Mask

```swift
player.collision = CollisionComponent(
    shapes: [.generateCapsule(height: 1.8, radius: 0.3)],
    mode: .default,
    filter: CollisionFilter(
        group: GameCollisionGroup.player,
        mask: GameCollisionGroup.wall.union(.enemy).union(.pickup)
    )
)

// Projectile: trigger-only on enemies, passes through everything else
bullet.collision = CollisionComponent(
    shapes: [.generateSphere(radius: 0.05)],
    mode: .trigger,
    filter: CollisionFilter(group: GameCollisionGroup.projectile, mask: GameCollisionGroup.enemy)
)

// Pickup: trigger-only, detects player
coin.collision = CollisionComponent(
    shapes: [.generateSphere(radius: 0.3)],
    mode: .trigger,
    filter: CollisionFilter(group: GameCollisionGroup.pickup, mask: GameCollisionGroup.player)
)
```

`.default` = physical collision response (bounce, block). `.trigger` = fires events but no physical response (pickups, damage zones, checkpoints).

### Collision Event Subscription

Subscribe in RealityView `make` closure. Store in `@State` to keep alive.

```swift
@State private var collisionSub: EventSubscription?

RealityView { content in
    collisionSub = content.subscribe(to: CollisionEvents.Began.self, on: player) { event in
        let other = event.entityA == player ? event.entityB : event.entityA
        if other.components.has(PickupComponent.self) {
            collectPickup(other)
        } else if other.components.has(EnemyComponent.self) {
            takeDamage()
        }
    }
}
```

Event types: `CollisionEvents.Began` (start touching), `.Updated` (every frame while in contact), `.Ended` (stop touching).

### Trigger Volumes

```swift
let damageZone = Entity()
damageZone.collision = CollisionComponent(
    shapes: [.generateBox(width: 2, height: 1, depth: 2)],
    mode: .trigger,
    filter: CollisionFilter(group: GameCollisionGroup.deathZone, mask: GameCollisionGroup.player)
)
```

**Safe removal pattern:** Never remove entities inside a collision callback. Queue removal and process outside:

```swift
var entitiesToRemove: [Entity] = []
// In callback: entitiesToRemove.append(other)
// In system update: entitiesToRemove.forEach { $0.removeFromParent() }; entitiesToRemove.removeAll()
```

---

## Camera Systems

### PerspectiveCameraComponent Properties

```swift
let camera = Entity()
var perspective = PerspectiveCameraComponent()
perspective.fieldOfViewInDegrees = 60     // default ~60, wider = more visible, more distortion
perspective.near = 0.01                    // near clip plane (objects closer are invisible)
perspective.far = 100                      // far clip plane (objects further are invisible)
camera.components.set(perspective)
camera.look(at: .zero, from: [0, 5, 10], relativeTo: nil)
content.add(camera)
```

### OrthographicCameraComponent (Isometric / 2.5D)

```swift
let camera = Entity()
var ortho = OrthographicCameraComponent()
ortho.scale = 5.0  // visible area in meters (larger = more zoomed out)
camera.components.set(ortho)
camera.look(at: .zero, from: [10, 10, 10], relativeTo: nil) // isometric angle
content.add(camera)
```

### Third-Person Follow Camera (System-based)

```swift
nonisolated struct CameraFollowSystem: System {
    static let query = EntityQuery(where: .has(CameraTargetComponent.self))
    init(scene: Scene) {}

    func update(context: SceneUpdateContext) {
        let dt = Float(context.deltaTime)
        for entity in context.entities(matching: Self.query, updatingSystemWhen: .rendering) {
            guard let target = entity.components[CameraTargetComponent.self],
                  let camera = entity.children.first(where: { $0.components.has(PerspectiveCameraComponent.self) })
            else { continue }

            let targetPos = entity.position(relativeTo: nil)
            let desiredPos = targetPos + target.offset
            let currentPos = camera.position(relativeTo: nil)
            let smoothed = currentPos + (desiredPos - currentPos) * min(dt * target.smoothSpeed, 1.0)
            camera.setPosition(smoothed, relativeTo: nil)
            camera.look(at: targetPos + [0, 1, 0], from: smoothed, relativeTo: nil)
        }
    }
}

nonisolated struct CameraTargetComponent: Component {
    var offset: SIMD3<Float> = [0, 3, 6]
    var smoothSpeed: Float = 5.0
}
```

**CRITICAL:** RealityKit's default forward is `-Z`. Camera should be at `+Z` behind the entity.

For generated 3D characters, choose the camera/control pattern from the requested genre before wiring joystick math. Free-orbit third-person games rotate the joystick vector by stored camera yaw to get the world movement direction; lock-behind chase cameras derive movement from the game's chase/vehicle/character rules; fixed-world or runner cameras map screen-up to one fixed world direction; camera-relative controls without a free-orbit UI project the active camera's forward/right onto XZ and combine them with the joystick components. Do not add right-side camera drag, crosshair aim, or two-thumb shooter controls unless the user request or genre calls for them.

---

## Generated Model Placement Fix

Generated USDZ models have provider-specific facing direction and origin placement. New Meshy models request a bottom origin, but legacy outputs and other providers can still arrive with the origin inside the mesh. This is the most critical pattern for Rork — every 3D game uses generated models.

Every generated model's persisted orientation verdict arrives as the ORIENTATION METADATA line in its generation / bundling tool output (`hasIntrinsicFront`, `localFrontAxis`, `localUpAxis`, `semanticType`, `confidence`). Write the placement helpers once in app code per `game-asset-integration.md` (`GeneratedModelAxis`, `generatedModelOrientationCorrection`, `makeGeneratedModelContainer`, `attachGeneratedModelVisual`) and route every generated-model load through them. Do not first write ad-hoc `Entity(named:)`, `.orientation = .pi`, or `clone.position = ...` code and then fix it later. The first implementation should already separate gameplay containers from visual children.

**Three problems and fixes:**

- **Position:** origin may not sit on the floor or center of the mesh. Fix: use a gameplay container, a runtime child named `generated_model_runtime`, and the loaded visual under that child. Center the visual on X/Z and shift it up by `-bounds.min.y`; this is a no-op when the local bottom is already at `0`.
- **Orientation:** use the `localFrontAxis` and `localUpAxis` from the ORIENTATION METADATA line in the model's generation / bundling tool output (`listExistingAssets` re-lists it for reused models). Choose `desiredWorldForward` from the gameplay movement/facing direction, not from the camera, preview, or thumbnail, then align the local axis to it via the body-frame correction.
- **Scale:** arbitrary size. Fix: normalize by the extent that matches the semantic size you are setting: `bounds.extents.y` for characters and floor props, the extent along `localFrontAxis` for elongated weapon or vehicle parts whose requested size is their length, and the longest extent for directionless objects sized by dominant extent.

Keep the normalized visual's local offset intact. Do not call the placement helpers and then set `visual.position` to a world/anchor position. Set `container.position` for gameplay placement, apply bob/lean/recoil/hover to the `generated_model_runtime` child, and keep `visual.position` reserved for centering and grounding.
The container's world position is the model's visual anchor. Keep collision footprints, hitboxes, blocked cells, sockets, and other gameplay occupancy data separate from that visual anchor. A collision shape can span multiple slots without moving the rendered model between those slots; center between slots only when the rendered object itself physically spans them.
For cached templates, the same rule applies: do not normalize a preloaded template, clone it, and then set `clone.position` to the spawn/world position. Create a fresh gameplay container for each spawn, put the cloned visual inside it, and set only the container's world transform.
For object pools that reuse existing gameplay containers, call your `attachGeneratedModelVisual(...)` helper on the pooled slot instead of repeating the runtime-child / normalization steps inline in scene code.

For composed objects made from multiple generated models, create one assembly root and attach each part to a named socket/container child. The assembly root moves the whole object; sockets define part offsets and pivots; `generated_model_runtime` handles local part motion; the visual child remains reserved for generated-asset import correction. Derive left/right, front/back, and top/bottom from the parent object's semantic axes or explicit socket names, not from screen side, camera view, preview thumbnail, or spawn order. Keep motion axes separate from `localFrontAxis`: wheel spin uses the axle axis, weapon slide/bolt recoil uses the barrel/recoil axis, doors use hinge axes, and hands/arms follow their left/right socket pose.

Vehicle assemblies (car + wheels, helicopter + rotor) have three extra rules: (1) a part model reused several times (one wheel placed four times) is loaded ONCE and `clone(recursive: true)`d for every additional socket — a RealityKit `Entity` has a single parent, so attaching the same instance to several sockets silently re-parents it and only the last placement stays visible; (2) wheels/rotors are honestly directionless — align each one's spin axis onto the semantic axle/hub axis derived from the assembly's rest forward via cross products, not hardcoded world vectors; (3) models that are assembly parts must NOT also get standalone `makeGeneratedModelContainer` placements. For several instances (AI racers, traffic), build the assembly once and `clone(recursive: true)` the root per instance, or wrap the construction in a factory function.

Final assembly code must derive socket constants from the corrected root visual bounds. Do not keep fixed offsets from an asset-independent scaffold when the real mesh is available. After the root visual is attached, measure `root.visualBounds(relativeTo: root)` and derive fore/rear/top/bottom/left/right socket positions from those bounds plus the assembly's semantic axes. Store the base transform of the assembly root and every animated socket/runtime child, then compose reload, recoil, sway, wheel spin, or slide deltas from those rest transforms. Do not assign a fresh `Transform()` or `.zero` during animation because that drops the socket position/orientation.

For first-person weapons, parent the weapon container under the camera entity and hard-wire camera-local `[0, 0, -1]` as the forward — apply the body-frame correction with the classifier-verified `localFrontAxis` (the muzzle) against that camera-local forward so the muzzle always tracks the view direction. Never compute a world-space `desiredWorldForward` for a held weapon; world "toward the player" vectors point INTO the camera and render the weapon stock-first. Scale by the weapon's full length along its front axis. Put the left/right hands on signed parent-local sockets, slide the bolt along the recoil/barrel axis from its rest transform, drop/insert the magazine from its socket rest transform, and apply recoil/sway to the container's runtime child. For MULTI-PART first-person weapons (body + magazine + bolt), parent the assembly root under the camera at the grip offset and keep every part's OWN `localFrontAxis`/`localUpAxis`/scale rule/vertical anchor from its metadata; copying the body's axes onto the magazine or bolt is how parts end up sideways or invisible.

When adding procedural wobble, lean, recoil, or idle animation, apply it to the `generated_model_runtime` child. Do not overwrite the normalized visual's `orientation` later with the animation rotation, or the body-frame correction will be lost and the generated model will lose its semantic front.

This rule also applies when a generated USDZ is rendered as a SwiftUI overlay or inside an `ARView` / `UIViewRepresentable` wrapper. Do not hide orientation behind a `rotation(for:)` helper that returns raw `.pi` constants; pass `localFrontAxis` and `localUpAxis` to `makeGeneratedModelContainer` / `attachGeneratedModelVisual`.

Choose `desiredWorldForward` from the object's role in the scene:

- Player/NPC: movement or facing direction.
- Vehicle: travel direction.
- Obstacle, sign, door, or pickup meant to face the player: vector toward the player or camera target.
- Decorative directionless prop: `localFrontAxis: nil` / no yaw correction.

For forward-scrolling endless runners, this becomes a concrete example: if the camera follows from `+Z` and the track extends toward `-Z`, the player/runner usually faces `[0, 0, -1]`, while oncoming trams or vehicles facing the player use `[0, 0, 1]`.

### Complete Pattern: Write the Placement Helper Once

Write `makeGeneratedModelContainer` / `attachGeneratedModelVisual` once in app code per the recipe in `game-asset-integration.md` and call them from scene code; do not repeat the normalization steps inline per model. The persisted `localFrontAxis` / `localUpAxis` for each model come from the ORIENTATION METADATA line in its generation / bundling tool output.

```swift
// Character (1.8m tall): pass localFrontAxis from the model's ORIENTATION METADATA.
// For an endless runner with camera behind at +Z and track ahead at -Z,
// the runner faces [0, 0, -1].
let player = await makeGeneratedModelContainer(
    resourceName: "runner",
    targetHeight: 1.8,
    localFrontAxis: .positiveZ,
    localUpAxis: .positiveY,
    desiredWorldForward: [0, 0, -1],
    worldPosition: [0, 0, 0],
    fallback: {
        ModelEntity(
            mesh: .generateBox(size: [0.5, 1.8, 0.5]),
            materials: [SimpleMaterial(color: .gray, isMetallic: false)]
        )
    }
)

// Oncoming tram facing the player in that same runner world.
let tram = await makeGeneratedModelContainer(
    resourceName: "city_tram",
    targetHeight: 2.4,
    localFrontAxis: .negativeX,
    localUpAxis: .positiveY,
    desiredWorldForward: [0, 0, 1],
    worldPosition: [2, 0, -20],
    fallback: {
        ModelEntity(
            mesh: .generateBox(size: [1.4, 2.4, 4.0]),
            materials: [SimpleMaterial(color: .gray, isMetallic: false)]
        )
    }
)

// Building (8m tall, beside the road)
let house = await makeGeneratedModelContainer(
    resourceName: "house",
    targetHeight: 8.0,
    localFrontAxis: nil,
    desiredWorldForward: [0, 0, -1],
    worldPosition: [6, 0, -15],
    fallback: {
        ModelEntity(
            mesh: .generateBox(size: [3.0, 8.0, 3.0]),
            materials: [SimpleMaterial(color: .gray, isMetallic: false)]
        )
    }
)

root.addChild(player)
root.addChild(tram)
root.addChild(house)
```

For object-pool slots, keep the collision/scrolling components on the slot and only replace the normalized visual:

```swift
let visual = tramTemplate?.clone(recursive: true) ?? ModelEntity(
    mesh: .generateBox(size: [1.4, 2.4, 4.0]),
    materials: [SimpleMaterial(color: .gray, isMetallic: false)]
)
attachGeneratedModelVisual(
    visual,
    to: slot,
    targetHeight: 2.4,
    localFrontAxis: .negativeX,
    localUpAxis: .positiveY,
    desiredWorldForward: [0, 0, 1]
)
slot.position = [laneX, 0, spawnZ]
```

For assembly sockets, keep each part on its own named socket and animate the socket or runtime child:

```swift
let vehicleRoot = Entity()
vehicleRoot.name = "vehicle_assembly"
root.addChild(vehicleRoot)

let frontLeftWheelSocket = Entity()
frontLeftWheelSocket.name = "front_left_wheel_socket"
frontLeftWheelSocket.position = [-0.9, 0.35, -1.2]
vehicleRoot.addChild(frontLeftWheelSocket)

let wheelVisual = wheelTemplate?.clone(recursive: true) ?? ModelEntity(
    mesh: .generateCylinder(height: 0.25, radius: 0.35),
    materials: [SimpleMaterial(color: .gray, isMetallic: false)]
)
attachGeneratedModelVisual(
    wheelVisual,
    to: frontLeftWheelSocket,
    targetHeight: 0.7,
    localFrontAxis: nil,
    desiredWorldForward: [0, 0, 1]
)

if let wheelRuntime = frontLeftWheelSocket.findEntity(named: "generated_model_runtime") {
    // Absolute accumulated spin angle around the parent-local axle axis.
    wheelRuntime.orientation = simd_quatf(angle: wheelSpinAngle, axis: [1, 0, 0])
}
```

If orientation metadata says `hasIntrinsicFront=false`, pass `localFrontAxis: nil`; do not add arbitrary yaw correction for balls, rocks, crates, trees, or other directionless props.

---

## Forces & Movement

### Physics Body Modes

```swift
// Dynamic (affected by forces — players, projectiles, ragdolls)
entity.components.set(PhysicsBodyComponent(
    shapes: [.generateSphere(radius: 0.2)], density: 1.0, mode: .dynamic
))
// Static (immovable — walls, floors)
entity.components.set(PhysicsBodyComponent(
    shapes: [.generateBox(size: wallSize)], density: 0, mode: .static
))
// Kinematic (script-controlled, pushes dynamic objects — moving platforms)
entity.components.set(PhysicsBodyComponent(
    shapes: [.generateBox(size: platformSize)], density: 0, mode: .kinematic
))
```

### Physics Materials (Friction & Bounciness)

```swift
let material = PhysicsMaterialResource.generate(
    staticFriction: 0.5,    // resistance to start sliding (0 = ice, 1 = rubber)
    dynamicFriction: 0.3,   // resistance while sliding
    restitution: 0.8         // bounciness (0 = no bounce, 1 = full bounce)
)
entity.components.set(PhysicsBodyComponent(
    shapes: [.generateSphere(radius: 0.2)], mass: 1.0, material: material, mode: .dynamic
))
```

Common presets:

- **Ice:** `staticFriction: 0.05, dynamicFriction: 0.02, restitution: 0.1`
- **Rubber ball:** `staticFriction: 0.8, dynamicFriction: 0.6, restitution: 0.9`
- **Metal:** `staticFriction: 0.4, dynamicFriction: 0.3, restitution: 0.3`
- **Wood:** `staticFriction: 0.5, dynamicFriction: 0.4, restitution: 0.4`

### Damping (How Objects Slow Down)

```swift
var body = PhysicsBodyComponent(shapes: [.generateSphere(radius: 0.2)], density: 1.0, mode: .dynamic)
body.linearDamping = 0.5     // resistance to linear movement (0 = no drag, higher = more drag)
body.angularDamping = 0.8    // resistance to rotation (0 = spins forever, higher = stops faster)
entity.components.set(body)
```

- **Space (no atmosphere):** `linearDamping: 0, angularDamping: 0`
- **Air (normal):** `linearDamping: 0.1, angularDamping: 0.5`
- **Water:** `linearDamping: 2.0, angularDamping: 3.0`
- **Mud/honey:** `linearDamping: 5.0, angularDamping: 5.0`

### Localized Physics (PhysicsSimulationComponent)

Override gravity per-entity for water zones, space sections, slow-motion areas:

```swift
var sim = PhysicsSimulationComponent()
sim.gravity = SIMD3<Float>(0, -2, 0) // low gravity (default is ~[0, -9.81, 0])
waterZoneEntity.components.set(sim)

// Zero gravity (space)
sim.gravity = .zero
spaceZoneEntity.components.set(sim)
```

### Direct Velocity (Kinematic Bodies)

```swift
var motion = entity.components[PhysicsMotionComponent.self] ?? PhysicsMotionComponent()
motion.linearVelocity = SIMD3<Float>(moveX, verticalVelocity, moveZ) * speed
entity.components[PhysicsMotionComponent.self] = motion
```

### Forces (Continuous, Per-Frame) vs Impulses (One-Shot)

```swift
entity.addForce([0, 0, -10], relativeTo: nil)                        // wind, thrusters
entity.addForce([5, 0, 0], at: [0, 1, 0], relativeTo: entity)       // force at offset (torque)
entity.applyImpulse([0, 8, 0], at: .zero, relativeTo: nil)           // jump, explosion knockback
```

### Explosion Radial Impulse

```swift
func explode(at center: SIMD3<Float>, radius: Float, force: Float, scene: Scene) {
    let query = EntityQuery(where: .has(PhysicsBodyComponent.self))
    for entity in scene.performQuery(query) {
        let dir = entity.position(relativeTo: nil) - center
        let dist = length(dir)
        guard dist < radius, dist > 0.01 else { continue }
        entity.applyImpulse(normalize(dir) * force * (1 - dist / radius), at: .zero, relativeTo: nil)
    }
}
```

---

## Character Controller

`CharacterControllerComponent` handles walking on surfaces, sliding along walls, and stepping up ledges. **Do NOT add `CollisionComponent` or `PhysicsBodyComponent` to the same entity** — they are incompatible. CharacterController manages its own collision.

```swift
character.components.set(CharacterControllerComponent(
    radius: 0.3,           // capsule collision radius
    height: 1.8,           // capsule collision height
    skinWidth: 0.01,       // buffer to prevent tunneling
    slopeLimit: .pi / 4,   // max walkable slope (radians)
    stepLimit: 0.3         // max step-up height
))

// Per-frame movement (call from System.update)
character.moveCharacter(
    by: SIMD3<Float>(moveX, 0, moveZ) * speed * Float(context.deltaTime),
    deltaTime: context.deltaTime, relativeTo: nil
)

// Instant reposition
character.teleportCharacter(to: targetPosition, relativeTo: nil)
```

### Grounded State

```swift
if let state = character.components[CharacterControllerStateComponent.self] {
    if state.isOnGround { /* can jump */ }
}
```

### Complete Jumping Pattern

**Rotating the player to face movement direction: write ONE facing helper and use it everywhere.** Inconsistent yaw math is the most common bug in AI-generated movement systems. The body-frame correction applied during model load already aligned the visual to its rest `desiredWorldForward`, so gameplay facing yaw must compose against that rest direction — rotate the runtime child (the facing node), never the normalized visual. Pass a world XZ movement vector, not raw screen joystick values. SwiftUI `DragGesture.translation.height` is positive downward; negate it when building joystick state so joystick `y > 0` means visual up/forward. Choose the camera/control pattern from the requested genre before wiring joystick math: free-orbit third-person rotates the joystick vector by stored camera yaw; lock-behind chase derives movement from the game's chase/vehicle/character rules; fixed-world or runner cameras map screen-up to one fixed world direction. Use the same world vector for movement and rotation; from `System.update`, wrap the rotation call in `MainActor.assumeIsolated { ... }`. For `CharacterControllerComponent` entities, rotate the generated-model facing node instead of the root character entity — rotating the physics root makes left/right/back input slide the run animation sideways. Third-person humanoids usually turn to face left/right/back input, not strafe sideways, unless the user explicitly asks for strafe/aim controls. Do not add right-side camera drag, crosshair aim, or two-thumb shooter controls unless the user request or genre calls for them. Mixed-up signs walk the character backwards (visible: joystick forward -> character faces camera while moving away).

```swift
/// Rotates the generated model's facing node so its rest forward tracks `direction` (world XZ).
@MainActor
func rotateGeneratedModelContainerToFace(_ container: Entity, direction: SIMD2<Float>) {
    guard simd_length(direction) > 0.001 else { return }
    let target = container.findEntity(named: "generated_model_runtime") ?? container
    target.orientation = simd_quatf(angle: atan2(direction.x, -direction.y), axis: [0, 1, 0])
}
```

Adjust the `atan2` argument signs once so joystick-forward faces away from the camera in YOUR camera setup, then never touch them again — fix sign bugs at the world-direction layer, not by sprinkling per-call negations.

```swift
nonisolated struct PlayerMovementSystem: System {
    static let query = EntityQuery(where: .has(CharacterControllerComponent.self) && .has(PlayerComponent.self))
    init(scene: Scene) {}

    func update(context: SceneUpdateContext) {
        for entity in context.entities(matching: Self.query, updatingSystemWhen: .rendering) {
            guard var player = entity.components[PlayerComponent.self] else { continue }
            let dt = Float(context.deltaTime)

            player.verticalVelocity -= 9.81 * dt

            if let state = entity.components[CharacterControllerStateComponent.self],
               state.isOnGround, player.wantsJump {
                player.verticalVelocity = player.jumpForce
                player.wantsJump = false
            }

            let movement = SIMD3<Float>(
                player.moveDirection.x * player.speed * dt,
                player.verticalVelocity * dt,
                player.moveDirection.z * player.speed * dt
            )
            entity.moveCharacter(by: movement, deltaTime: context.deltaTime, relativeTo: nil)

            // Face the direction we are moving — the helper accounts for the
            // body-frame correction's sign conventions automatically.
            MainActor.assumeIsolated {
                rotateGeneratedModelContainerToFace(entity, direction: [player.moveDirection.x, player.moveDirection.z])
            }

            entity.components[PlayerComponent.self] = player
        }
    }
}

nonisolated struct PlayerComponent: Component {
    var speed: Float = 3.0
    var jumpForce: Float = 5.0
    var verticalVelocity: Float = 0
    var moveDirection: SIMD3<Float> = .zero
    var wantsJump: Bool = false
}
```

---

## Animation State Machine

```swift
// `@Observable` lives in the Observation module; import it explicitly so this
// snippet compiles standalone (SwiftUI re-exports Observation transitively,
// but a RealityKit-only file does not).
import Observation
import RealityKit

nonisolated enum AnimState {
    case idle, walk, run, attack, jump, fall, die
}

@MainActor
@Observable
class AnimationStateMachine {
    private(set) var currentState: AnimState?
    private var resources: [AnimState: String] = [:]
    private var player: GeneratedModelAnimationPlayer?

    func setup(container: Entity, stateResources: [AnimState: String]) async {
        resources = stateResources
        let animationPlayer = GeneratedModelAnimationPlayer(container: container)
        await animationPlayer.preload(Array(stateResources.values))
        player = animationPlayer
        transition(to: .idle)
    }

    func transition(to newState: AnimState) {
        guard newState != currentState else { return }
        currentState = newState

        switch newState {
        case .idle, .walk, .run:
            player?.setLoop(resources[newState])
        case .attack, .jump, .fall, .die:
            player?.playOnce(resources[newState], restoreAfter: .milliseconds(650))
        }
    }
}

nonisolated struct AnimationStateComponent: Component {
    let stateMachine: AnimationStateMachine
}
```

### AnimationSystem — Drive State from Velocity

```swift
nonisolated struct AnimationSystem: System {
    static let query = EntityQuery(where: .has(PlayerComponent.self))
    init(scene: Scene) {}

    func update(context: SceneUpdateContext) {
        for entity in context.entities(matching: Self.query, updatingSystemWhen: .rendering) {
            Task { @MainActor in
                guard let sm = entity.components[AnimationStateComponent.self]?.stateMachine else { return }
                let velocity = entity.components[PhysicsMotionComponent.self]?.linearVelocity ?? .zero
                let speed = length(SIMD2<Float>(velocity.x, velocity.z))
                let nextState: AnimState = speed > 3.0 ? .run : speed > 0.5 ? .walk : .idle
                sm.transition(to: nextState)
            }
        }
    }
}
```

### Loading and Playing Meshy USDZ Animations

**Default path: write the `GeneratedModelAnimationPlayer` pattern from `.rork/skills/swift/generated-3d-animations.md` into app code and use the exact `resourceName` strings reported by the animation waitTask.** App code owns the gameplay-state mapping; the player owns generated-animation playback mechanics, including stopping stale loops and restoring the base visual when a state has no bundled clip.

Read `.rork/skills/swift/generated-3d-animations.md` for the full wiring pattern (state-machine holder, RealityKit system that drives transitions). The summary:

```swift
let hero = await makeGeneratedModelContainer(
    resourceName: "player_character",
    targetHeight: 1.8,
    localFrontAxis: .positiveZ,
    localUpAxis: .positiveY,
    desiredWorldForward: [0, 0, -1],
    worldPosition: [0, 0, 0],
    fallback: { fallbackHero() }
)
// resource names below come verbatim from the animation waitTask output.
let animationPlayer = GeneratedModelAnimationPlayer(container: hero)
await animationPlayer.preload(["player_character-anim-casual-walk"])
animationPlayer.setLoop("player_character-anim-casual-walk")
animationPlayer.setLoop(nil) // stops the generated playback and restores the base visual
```

Do not extract `AnimationResource` from generated Meshy animation files. The accepted animation files are separate `*-anim-*.usdz` FULL entities; the player attaches the full animation entity inside the runtime wrapper and plays the clip only on its owning entity.

### AnimationPlaybackController

```swift
let controller = character.playAnimation(walkAnim.repeat(duration: .infinity))
controller.pause()
controller.resume()
controller.speed = 2.0       // double speed
controller.blendFactor = 0.5 // 0 = no effect, 1 = full effect
```

---

## Entity Pooling & Spawning

`isEnabled = false` is Apple's recommended pattern — stops rendering and physics without addChild/removeChild overhead.

```swift
class EntityPool {
    private var available: [Entity] = []
    private let factory: () -> Entity

    init(size: Int, parent: Entity, factory: @escaping () -> Entity) {
        self.factory = factory
        for _ in 0..<size {
            let entity = factory()
            entity.isEnabled = false
            parent.addChild(entity)
            available.append(entity)
        }
    }

    func spawn(at position: SIMD3<Float>) -> Entity? {
        guard let entity = available.popLast() else { return nil }
        entity.position = position
        entity.isEnabled = true
        return entity
    }

    func despawn(_ entity: Entity) {
        entity.isEnabled = false
        entity.position = .zero
        available.append(entity)
    }
}
```

### Entity Hierarchy for Games

```swift
let levelRoot = Entity()
levelRoot.name = "level"

let environment = Entity(); environment.name = "environment"
let characters = Entity(); characters.name = "characters"
let pickups = Entity(); pickups.name = "pickups"

levelRoot.addChild(environment)
levelRoot.addChild(characters)
levelRoot.addChild(pickups)
content.add(levelRoot)

// Find at runtime
let player = levelRoot.findEntity(named: "player")
let allEnemies = characters.children.filter { $0.components.has(EnemyComponent.self) }
```

---

## Lighting, Skybox, Environment

See `realitykit-environment.md` for full lighting setup (directional/spot/point lights, IBL, skybox, fog, terrain).

**Quick reference limits:** Max 8 dynamic lights per scene. Only 1 directional. Only spot + directional cast shadows.

### BillboardComponent (Always Face Camera)

Health bars, damage numbers, floating labels — any flat element that should always face the camera:

```swift
entity.components.set(BillboardComponent())
// The entity will automatically rotate to face the active camera every frame
```

### OpacityComponent (Fade Entities)

Fade entities in/out without modifying materials:

```swift
entity.components.set(OpacityComponent(opacity: 0.5))

// Animate fade-out
entity.components.set(OpacityComponent(opacity: 0))
// Combine with move(to:duration:) for animated fade
```

---

## Spatial Audio

RealityKit handles 3D audio positioning automatically.

```swift
// Spatial — 3D positioned sound
let audioEntity = Entity()
audioEntity.spatialAudio = SpatialAudioComponent(gain: -5) // dB
audioEntity.position = [2, 0, -3]
if let resource = try? AudioFileResource.load(named: "engine_loop", configuration: .init(shouldLoop: true)) {
    audioEntity.playAudio(resource)
}

// Ambient — non-directional (background music)
let ambientEntity = Entity()
ambientEntity.ambientAudio = AmbientAudioComponent()
if let music = try? AudioFileResource.load(named: "background_music", configuration: .init(shouldLoop: true)) {
    ambientEntity.playAudio(music)
}

// Gain control (dB scale, 0 = full volume)
audioEntity.spatialAudio?.gain = -10
ambientEntity.ambientAudio?.gain = -5
```

### AudioPlaybackController

`playAudio()` returns a controller for runtime audio management:

```swift
let controller = audioEntity.playAudio(resource)
controller.pause()
controller.play()
controller.stop()
controller.gain = -3                          // volume in dB
controller.speed = 1.5                        // playback speed
controller.fade(to: .init(gain: -20), duration: 2.0)  // fade out over 2 seconds
```

### Distance Attenuation & Directivity

```swift
var spatial = SpatialAudioComponent()
spatial.gain = 0
spatial.distanceAttenuation = .rolloff(factor: 1.0)  // 1.0 = realistic falloff, higher = faster fade
spatial.directivity = .beam(focus: 0.5)               // 0 = omnidirectional, 1 = narrow beam
audioEntity.components.set(spatial)
```

---

## Physics Joints

Connect two physics bodies. Both need `PhysicsBodyComponent` and `CollisionComponent`.

```swift
let pin1 = entityA.pins.set(named: "hookA", position: [0, 0, 0.1], orientation: .init(angle: 0, axis: [0, 1, 0]))
let pin2 = entityB.pins.set(named: "hookB", position: [0, 0, -0.1], orientation: .init(angle: 0, axis: [0, 1, 0]))
```

**Joint types:**

- **Fixed** — welded, no movement: `PhysicsFixedJoint(pin0:pin1:)`
- **Spherical** — ball-and-socket, rotation on all axes: `PhysicsSphericalJoint(pin0:pin1:)`
- **Revolute** — hinge, rotation around one axis: `PhysicsRevoluteJoint(pin0:pin1:)`
- **Prismatic** — slider, translation along one axis: `PhysicsPrismaticJoint(pin0:pin1:)`

```swift
// Weld sword to character hand
let handPin = character.pins.set(named: "hand", position: [0.3, 0.8, 0])
let swordPin = sword.pins.set(named: "grip", position: [0, 0, 0])
try character.addJoint(PhysicsFixedJoint(pin0: handPin, pin1: swordPin))

// Limits
var hinge = PhysicsRevoluteJoint(pin0: pin1, pin1: pin2)
hinge.angularLimit = .range(-.pi/2 ... .pi/2)

// Distance joint — ropes, chains, tethers (maintains min/max distance)
var distance = PhysicsDistanceJoint(pin0: ceilingPin, pin1: pendulumPin)
distance.distanceLimit = .range(1.0 ... 3.0) // min 1m, max 3m
try ceilingEntity.addJoint(distance)
```

---

## Force Effects

Apply continuous forces to physics bodies within a volume.

```swift
// Gravity well — radial pull (negative = inward)
gravityWell.components.set(ForceEffectComponent(effects: [
    ForceEffect(effect: ConstantRadialForceEffect(strength: -5.0), mask: .all)
]))
gravityWell.components.set(CollisionComponent(shapes: [.generateSphere(radius: 3.0)], mode: .trigger))

// Vortex — swirl around axis
tornado.components.set(ForceEffectComponent(effects: [
    ForceEffect(effect: VortexForceEffect(strength: 2.0, axis: [0, 1, 0]), mask: .all)
]))

// Drag — air/water resistance
waterZone.components.set(ForceEffectComponent(effects: [
    ForceEffect(effect: DragForceEffect(strength: 3.0), mask: .all)
]))

// Turbulence — random chaos
turbulenceZone.components.set(ForceEffectComponent(effects: [
    ForceEffect(effect: TurbulenceForceEffect(strength: 1.0, smoothness: 0.5, speed: 1.0), mask: .all)
]))
```

---

## Raycasting

```swift
let results = scene.raycast(
    origin: gunEntity.position(relativeTo: nil),
    direction: gunEntity.transform.rotation.act(SIMD3<Float>(0, 0, -1)), // RealityKit forward is -Z
    length: 100, query: .all,
    mask: GameCollisionGroup.enemy.union(.wall)
)
if let hit = results.first {
    let hitEntity = hit.entity
    let hitPosition = hit.position
    let hitDistance = hit.distance
}

// Ground detection
let groundHits = scene.raycast(
    origin: entity.position(relativeTo: nil) + [0, 0.1, 0],
    direction: [0, -1, 0], length: 2.0, query: .nearest,
    mask: GameCollisionGroup.ground
)
let isGrounded = groundHits.first != nil
```

---

## Performance Budgets

See `game-performance-reference.md` for full budgets, MeshInstancesComponent, LowLevelMesh, LOD, trail effects, and PostProcessEffect.

Quick limits: ~100K triangles (iPhone), ~200K (Pro), <100 draw calls, ~1000 active entities. Use `isEnabled = false` for offscreen entities.

---

## Particles & Effects

### Particle Trails

Set `particlesInheritTransform = false` so particles stay in world space as the entity moves.

```swift
func makeEngineTrail() -> ParticleEmitterComponent {
    var particles = ParticleEmitterComponent()
    particles.emitterShape = .point
    particles.birthDirection = .local
    particles.emissionDirection = [0, 0, 1]
    particles.particlesInheritTransform = false
    particles.mainEmitter.birthRate = 200
    particles.mainEmitter.size = 0.03
    particles.mainEmitter.lifeSpan = 0.8
    particles.mainEmitter.speed = 0.5
    particles.mainEmitter.color = .evolving(
        start: .single(.init(red: 0.3, green: 0.6, blue: 1.0, alpha: 1.0)),
        end: .single(.init(red: 0.1, green: 0.1, blue: 0.3, alpha: 0.0))
    )
    particles.mainEmitter.sizeMultiplierAtEndOfLifespan = 0.0
    return particles
}

let engineGlow = Entity()
engineGlow.position = [0, 0, 0.5]
engineGlow.components.set(makeEngineTrail())
spaceshipEntity.addChild(engineGlow)
```

### Explosion Burst

```swift
func spawnExplosion(at position: SIMD3<Float>, parent: Entity) {
    let entity = Entity()
    entity.position = position
    var particles = ParticleEmitterComponent.Presets.impact
    particles.timing = .once(warmUp: 0, emit: .init(duration: 0.2))
    entity.components.set(particles)
    parent.addChild(entity)

    let remove = SetEntityEnabledAction(isEnabled: false)
    if let anim = try? AnimationResource.makeActionAnimation(for: remove, duration: 1.0 / 30.0, delay: 2.0) {
        entity.playAnimation(anim)
    }
}
```

### Materials & Shaders

See `realitykit-materials.md` for full PBR channels, texture loading, CustomMaterial Metal shaders (dissolve, shield, toon, glow), and material recipes.

---

## Complete 3D Game Skeleton

Minimal example showing how the pieces connect — floor, player, camera, lighting, collision events, gesture input. For UI overlays: `game-ui-patterns.md`. For environment (terrain, skybox, fog): `realitykit-environment.md`.

```swift
import SwiftUI
import RealityKit

struct Game3DView: View {
    @State private var gameInput = GameInput()
    @State private var collisionSub: EventSubscription?

    var body: some View {
        ZStack {
            RealityView { content in
                PlayerMovementSystem.registerSystem()
                PlayerMovementSystem.input = gameInput // @MainActor static var input: GameInput? (see SwiftUI→ECS bridge above)
                PlayerComponent.registerComponent()
                CameraFollowSystem.registerSystem()
                CameraTargetComponent.registerComponent()

                // Lighting
                let sun = Entity()
                var directional = DirectionalLightComponent()
                directional.intensity = 10000
                sun.components.set(directional)
                sun.look(at: .zero, from: [5, 10, 5], relativeTo: nil)
                content.add(sun)

                // Floor
                let floor = ModelEntity(
                    mesh: .generatePlane(width: 20, depth: 20),
                    materials: [SimpleMaterial(color: .gray, isMetallic: false)]
                )
                floor.components.set(CollisionComponent(shapes: [.generateBox(size: [20, 0.01, 20])], mode: .default))
                floor.components.set(PhysicsBodyComponent(mode: .static))
                content.add(floor)

                // Player
                let player: Entity
                if let loaded = try? await Entity(named: "player") {
                    player = loaded
                } else {
                    player = ModelEntity(
                        mesh: .generateBox(size: [0.4, 0.8, 0.4]),
                        materials: [SimpleMaterial(color: .blue, isMetallic: false)]
                    )
                }
                player.name = "player"
                player.position = [0, 1, 0]
                player.components.set(PlayerComponent())
                // CharacterControllerComponent provides its own collision — do NOT add CollisionComponent
                player.components.set(CharacterControllerComponent(
                    radius: 0.3, height: 0.8,
                    collisionFilter: CollisionFilter(group: GameCollisionGroup.player, mask: .all)
                ))

                // Camera: child of the player ON PURPOSE — CameraFollowSystem looks the
                // camera up via entity.children and then sets its position in WORLD
                // space (setPosition(relativeTo: nil)) every frame, so the inherited
                // parent transform is overridden, not double-applied. Do not ALSO drive
                // this camera from a second follow/orbit updater; pick one driver per
                // game (see game-world-layout.md, Camera Ownership).
                let camera = Entity()
                camera.components.set(PerspectiveCameraComponent())
                camera.look(at: .zero, from: [0, 5, 10], relativeTo: nil)
                player.components.set(CameraTargetComponent(offset: [0, 3, 6]))
                player.addChild(camera)
                content.add(player)

                // Collision events
                collisionSub = content.subscribe(to: CollisionEvents.Began.self, on: player) { event in
                    let other = event.entityA == player ? event.entityB : event.entityA
                    // handle pickup, damage, etc.
                }
            }
            .gesture(
                SpatialTapGesture()
                    .targetedToAnyEntity()
                    .onEnded { value in
                        let tappedEntity = value.entity
                        // handle tap on entity
                    }
            )

            VStack {
                Spacer()
                JoystickView(direction: $gameInput.moveDirection)
                    .frame(height: 150)
            }
        }
    }
}
```

---

## Scene Switching (Level Transitions)

RealityKit has no scene transitions. Swap entity graphs instead:

```swift
@Observable
class LevelManager {
    var currentLevelRoot: Entity?
    var isLoading = false

    func loadLevel<C: RealityViewContentProtocol>(_ level: Int, in content: inout C) async {
        isLoading = true
        if let old = currentLevelRoot { content.remove(old) }

        let root = Entity()
        root.name = "level_\(level)"

        async let floor = ModelEntity(mesh: .generatePlane(width: 10, depth: 10),
                                      materials: [SimpleMaterial(color: .gray, isMetallic: false)])
        async let player = (try? await Entity(named: "player")) ?? ModelEntity(
            mesh: .generateBox(size: 0.3), materials: [SimpleMaterial(color: .blue, isMetallic: false)])

        root.addChild(await floor)
        root.addChild(await player)
        content.add(root)
        currentLevelRoot = root
        isLoading = false
    }
}
```

For fade transitions, use a SwiftUI opacity overlay toggled by `isLoading`.
