---
index: true
description: GKAgent, pathfinding, decision trees, random sources
---

# GameplayKit AI — Agents, Pathfinding, State Machines, Randomness

> Use GKAgent2D for steering behaviors, GKGridGraph for tile pathfinding, GKObstacleGraph for free movement. Always use GKRandomSource (not Int.random) for reproducible gameplay.

---

GKAgent, GKGoal, pathfinding graphs, GKNoise, random sources, decision trees, rule systems.

---

## GKAgent2D — Autonomous Movement

Agents are entities that move themselves according to goals. Attach a delegate to sync with your sprite.

```swift
import GameplayKit
import SpriteKit

class EnemyAgent: NSObject, GKAgentDelegate {
    let agent = GKAgent2D()
    let spriteNode: SKSpriteNode

    init(sprite: SKSpriteNode) {
        self.spriteNode = sprite
        super.init()
        agent.delegate = self
        agent.maxSpeed = 100
        agent.maxAcceleration = 50
        agent.radius = Float(sprite.size.width / 2)
        agent.mass = 1.0
    }

    func agentWillUpdate(_ agent: GKAgent) {
        guard let agent2d = agent as? GKAgent2D else { return }
        agent2d.position = vector_float2(
            Float(spriteNode.position.x),
            Float(spriteNode.position.y)
        )
    }

    func agentDidUpdate(_ agent: GKAgent) {
        guard let agent2d = agent as? GKAgent2D else { return }
        spriteNode.position = CGPoint(
            x: CGFloat(agent2d.position.x),
            y: CGFloat(agent2d.position.y)
        )
    }
}
```

Update agents every frame from your scene:

```swift
class GameScene: SKScene {
    var agentSystem = GKComponentSystem(componentClass: GKAgent2D.self)
    private var lastUpdateTime: TimeInterval = 0

    override func update(_ currentTime: TimeInterval) {
        let dt = lastUpdateTime == 0 ? 0 : currentTime - lastUpdateTime
        lastUpdateTime = currentTime
        agentSystem.update(deltaTime: dt)
    }
}
```

---

## GKGoal — Steering Behaviors

Goals define what an agent wants to do. Combine multiple goals with weights.

```swift
// Chase player
let seekGoal = GKGoal(toSeekAgent: playerAgent)

// Flee from player
let fleeGoal = GKGoal(toFleeAgent: playerAgent)

// Wander randomly
let wanderGoal = GKGoal(toWander: 1.0)

// Avoid obstacles
let obstacles = SKNode.obstacles(fromNodeBounds: obstacleNodes)
let avoidGoal = GKGoal(toAvoid: obstacles, maxPredictionTime: 2.0)

// Follow path
let path = GKPath(points: pathPoints, radius: 10, cyclical: true)
let followGoal = GKGoal(toFollow: path, maxPredictionTime: 1.0, forward: true)

// Stay on path (stricter than follow)
let stayGoal = GKGoal(toStayOn: path, maxPredictionTime: 1.0)

// Intercept (predict target position)
let interceptGoal = GKGoal(toInterceptAgent: playerAgent, maxPredictionTime: 2.0)

// Reach target speed
let speedGoal = GKGoal(toReachTargetSpeed: 200)
```

### Flocking (Boids)

Three goals create emergent flocking behavior:

```swift
let agents: [GKAgent2D] = allBirdAgents

let separateGoal = GKGoal(toSeparateFrom: agents, maxDistance: 50, maxAngle: .pi)
let alignGoal = GKGoal(toAlignWith: agents, maxDistance: 100, maxAngle: .pi)
let cohereGoal = GKGoal(toCohereWith: agents, maxDistance: 100, maxAngle: .pi)

let behavior = GKBehavior(goals: [separateGoal, alignGoal, cohereGoal],
                           andWeights: [1.0, 0.5, 0.5])

for agent in agents {
    agent.behavior = behavior
}
```

### Combining Goals with Weights

```swift
let behavior = GKBehavior(goals: [seekGoal, avoidGoal, separateGoal],
                           andWeights: [0.5, 1.0, 0.3])
enemy.agent.behavior = behavior
```

Higher weight = stronger influence. Avoidance typically needs the highest weight.

---

## Dynamic Goal Switching

Switch behaviors based on game state (patrol, chase, flee):

```swift
class EnemyAI {
    let agent: GKAgent2D
    let playerAgent: GKAgent2D
    let patrolPath: GKPath

    private let patrolBehavior: GKBehavior
    private let chaseBehavior: GKBehavior
    private let fleeBehavior: GKBehavior

    init(agent: GKAgent2D, playerAgent: GKAgent2D, patrolPath: GKPath, obstacles: [GKPolygonObstacle]) {
        self.agent = agent
        self.playerAgent = playerAgent
        self.patrolPath = patrolPath

        let avoidGoal = GKGoal(toAvoid: obstacles, maxPredictionTime: 2.0)

        patrolBehavior = GKBehavior(goals: [
            GKGoal(toFollow: patrolPath, maxPredictionTime: 1.0, forward: true),
            avoidGoal
        ], andWeights: [0.8, 1.0])

        chaseBehavior = GKBehavior(goals: [
            GKGoal(toSeekAgent: playerAgent),
            GKGoal(toInterceptAgent: playerAgent, maxPredictionTime: 1.0),
            avoidGoal
        ], andWeights: [0.6, 0.4, 1.0])

        fleeBehavior = GKBehavior(goals: [
            GKGoal(toFleeAgent: playerAgent),
            avoidGoal
        ], andWeights: [1.0, 1.0])
    }

    func update(enemyHealth: Float) {
        let dx = agent.position.x - playerAgent.position.x
        let dy = agent.position.y - playerAgent.position.y
        let distanceToPlayer = sqrtf(dx * dx + dy * dy)

        if enemyHealth < 20 {
            agent.behavior = fleeBehavior
        } else if distanceToPlayer < 300 {
            agent.behavior = chaseBehavior
        } else {
            agent.behavior = patrolBehavior
        }
    }
}
```

---

## Pathfinding — GKGridGraph (Tile-Based)

For grid/tile-based games. Nodes snap to integer positions.

```swift
let graph = GKGridGraph(
    fromGridStartingAt: vector_int2(0, 0),
    width: 20,
    height: 15,
    diagonalsAllowed: true,
    nodeClass: GKGridGraphNode.self
)

// Remove wall tiles
let wallPositions = [vector_int2(5, 3), vector_int2(5, 4), vector_int2(5, 5)]
let wallNodes = wallPositions.compactMap { graph.node(atGridPosition: $0) }
graph.remove(wallNodes)

// Find path
if let startNode = graph.node(atGridPosition: vector_int2(0, 0)),
   let endNode = graph.node(atGridPosition: vector_int2(19, 14)) {
    let path = graph.findPath(from: startNode, to: endNode)
    let gridPath = path.compactMap { $0 as? GKGridGraphNode }
    for node in gridPath {
        let tilePos = node.gridPosition // vector_int2
        // Move character tile-by-tile
    }
}
```

### Weighted Grid (Custom Costs)

Subclass `GKGridGraphNode` for terrain costs:

```swift
class WeightedGridNode: GKGridGraphNode {
    var weight: Float = 1.0

    override func cost(to node: GKGraphNode) -> Float {
        guard let weighted = node as? WeightedGridNode else {
            return super.cost(to: node)
        }
        return weighted.weight
    }
}

let graph = GKGridGraph(
    fromGridStartingAt: vector_int2(0, 0),
    width: 20,
    height: 15,
    diagonalsAllowed: true,
    nodeClass: WeightedGridNode.self
)

// Make swamp tiles expensive
if let swampNode = graph.node(atGridPosition: vector_int2(3, 7)) as? WeightedGridNode {
    swampNode.weight = 5.0
}
```

---

## Pathfinding — GKObstacleGraph (Free Movement)

For non-grid games with arbitrary obstacle shapes.

```swift
let obstacles = SKNode.obstacles(fromNodeBounds: wallNodes)
let graph = GKObstacleGraph(obstacles: obstacles, bufferRadius: 10)

let start = GKGraphNode2D(point: vector_float2(100, 100))
let end = GKGraphNode2D(point: vector_float2(500, 400))
graph.connectUsingObstacles(node: start)
graph.connectUsingObstacles(node: end)

let path = graph.findPath(from: start, to: end)
let pathNodes = path.compactMap { $0 as? GKGraphNode2D }
let cgPoints = pathNodes.map {
    CGPoint(x: CGFloat($0.position.x), y: CGFloat($0.position.y))
}

// Clean up temporary nodes
graph.remove([start, end])
```

Follow the path with `SKAction`:

```swift
func followPath(_ points: [CGPoint], speed: CGFloat) -> SKAction {
    var actions: [SKAction] = []
    for i in 1..<points.count {
        let dx = points[i].x - points[i - 1].x
        let dy = points[i].y - points[i - 1].y
        let distance = sqrt(dx * dx + dy * dy)
        let duration = TimeInterval(distance / speed)
        actions.append(SKAction.move(to: points[i], duration: duration))
    }
    return SKAction.sequence(actions)
}
```

---

## GKMeshGraph (Navigation Mesh)

For complex open areas with scattered obstacles. More efficient than obstacle graph for large spaces.

```swift
let meshGraph = GKMeshGraph(
    bufferRadius: 5.0,
    minCoordinate: vector_float2(0, 0),
    maxCoordinate: vector_float2(1000, 800)
)
meshGraph.addObstacles(obstacles)
meshGraph.triangulate()

let start = GKGraphNode2D(point: vector_float2(50, 50))
let end = GKGraphNode2D(point: vector_float2(900, 700))
meshGraph.connectUsingObstacles(node: start)
meshGraph.connectUsingObstacles(node: end)

let path = meshGraph.findPath(from: start, to: end)
meshGraph.remove([start, end])
```

---

## GKRandomSource — Game-Safe Randomness

Never use `Int.random(in:)` for gameplay that needs reproducibility or fairness guarantees.

```swift
// Fast, non-reproducible
let arc4 = GKARC4RandomSource()

// Reproducible with seed (replays, procedural generation)
let mersenne = GKMersenneTwisterRandomSource(seed: 12345)

// Lightweight
let linear = GKLinearCongruentialRandomSource()
```

### Distributions

```swift
let random = GKARC4RandomSource()

// Uniform — equal chance for all values
let uniform = GKRandomDistribution(randomSource: random, lowestValue: 1, highestValue: 6)
let roll = uniform.nextInt() // 1-6, equal probability

// Gaussian (bell curve) — results cluster near center
let gaussian = GKGaussianDistribution(randomSource: random, lowestValue: 1, highestValue: 100)
let damage = gaussian.nextInt() // mostly 40-60, rarely 1 or 100

// Shuffled — every value appears before any repeats (fair dice)
let shuffled = GKShuffledDistribution(randomSource: random, lowestValue: 1, highestValue: 6)
// Guarantees you see all 1-6 before any number repeats

// Random float 0.0-1.0
let fraction = Float(random.nextInt(upperBound: 1000)) / 1000.0
```

### Shuffle Arrays

```swift
let items = ["sword", "shield", "potion", "scroll"]
let shuffled = random.arrayByShufflingObjects(in: items) as! [String]
```

### Seeded Random for Procedural Levels

```swift
func generateLevel(seed: UInt64) -> [[Int]] {
    let source = GKMersenneTwisterRandomSource(seed: seed)
    let dist = GKRandomDistribution(randomSource: source, lowestValue: 0, highestValue: 3)
    var grid: [[Int]] = []
    for _ in 0..<20 {
        var row: [Int] = []
        for _ in 0..<15 {
            row.append(dist.nextInt())
        }
        grid.append(row)
    }
    return grid
}
```

---

## GKNoise — Procedural Generation

See `game-procedural-generation.md` for full noise reference (Perlin, Billowy, Ridged, Voronoi), terrain generation, caves, dungeons, loot tables, and wave spawning.

---

## GKDecisionTree — Data-Driven AI

```swift
let root = GKDecisionTree(attribute: "health" as NSObjectProtocol)

// Build tree: health > 50 → check distance, else flee
let healthNode = root.rootNode!
let healthBranch = healthNode.createBranch(value: NSNumber(value: 50), attribute: "distance" as NSObjectProtocol)
healthBranch.createBranch(value: NSNumber(value: 200), attribute: "attack" as NSObjectProtocol)
healthBranch.createBranch(value: NSNumber(value: 500), attribute: "patrol" as NSObjectProtocol)

// Query
let answers: [AnyHashable: NSObjectProtocol] = [
    "health" as NSString: NSNumber(value: 80),
    "distance" as NSString: NSNumber(value: 150)
]
let action = root.findAction(forAnswers: answers) // "attack"
```

---

## GKRuleSystem — Rule-Based AI

```swift
let ruleSystem = GKRuleSystem()
ruleSystem.state["health"] = 30.0
ruleSystem.state["ammo"] = 0
ruleSystem.state["nearCover"] = true

ruleSystem.add(GKRule(predicate: NSPredicate(format: "$health < 50 AND $nearCover == YES"),
                       assertingFact: "shouldTakeCover" as NSObjectProtocol,
                       grade: 0.9))

ruleSystem.add(GKRule(predicate: NSPredicate(format: "$ammo == 0"),
                       assertingFact: "shouldReload" as NSObjectProtocol,
                       grade: 0.8))

ruleSystem.add(GKRule(predicate: NSPredicate(format: "$health > 70 AND $ammo > 0"),
                       assertingFact: "shouldAttack" as NSObjectProtocol,
                       grade: 0.7))

ruleSystem.evaluate()

let coverGrade = ruleSystem.grade(forFact: "shouldTakeCover" as NSObjectProtocol) // 0.9
let attackGrade = ruleSystem.grade(forFact: "shouldAttack" as NSObjectProtocol) // 0.0
```

---

## GKStateMachine

```swift
class IdleState: GKState {
    override func isValidNextState(_ stateClass: AnyClass) -> Bool {
        return stateClass == PatrolState.self || stateClass == ChaseState.self
    }

    override func didEnter(from previousState: GKState?) {
        // Play idle animation
    }
}

class PatrolState: GKState {
    override func isValidNextState(_ stateClass: AnyClass) -> Bool {
        return stateClass == ChaseState.self || stateClass == IdleState.self
    }

    override func update(deltaTime seconds: TimeInterval) {
        // Move along patrol path
    }
}

class ChaseState: GKState {
    override func isValidNextState(_ stateClass: AnyClass) -> Bool {
        return stateClass == IdleState.self || stateClass == AttackState.self
    }
}

class AttackState: GKState {
    override func isValidNextState(_ stateClass: AnyClass) -> Bool {
        return stateClass == ChaseState.self || stateClass == IdleState.self
    }
}

let stateMachine = GKStateMachine(states: [
    IdleState(), PatrolState(), ChaseState(), AttackState()
])
stateMachine.enter(IdleState.self)

// In game loop
stateMachine.update(deltaTime: dt)

// Transition
stateMachine.enter(ChaseState.self) // returns false if invalid transition
```

---

## RealityKit Integration (3D Pathfinding)

GameplayKit pathfinding uses 2D coordinates. For RealityKit 3D games, project to the ground plane (XZ) and convert back.

```swift
import GameplayKit
import RealityKit

/// Convert RealityKit world position to GameplayKit graph coordinate
func toGraphPoint(_ position: SIMD3<Float>) -> vector_float2 {
    vector_float2(position.x, position.z)
}

/// Convert GameplayKit path node back to RealityKit world position (Y = ground height)
func toWorldPosition(_ point: vector_float2, groundY: Float = 0) -> SIMD3<Float> {
    SIMD3<Float>(point.x, groundY, point.y)
}

/// Find path between two RealityKit entities using a GKGridGraph
func findPath(
    from start: SIMD3<Float>,
    to end: SIMD3<Float>,
    graph: GKGridGraph<GKGridGraphNode>
) -> [SIMD3<Float>] {
    let startNode = graph.node(atGridPosition: vector_int2(Int32(start.x), Int32(start.z)))
    let endNode = graph.node(atGridPosition: vector_int2(Int32(end.x), Int32(end.z)))
    guard let s = startNode, let e = endNode else { return [] }
    let path = graph.findPath(from: s, to: e)
    return path.compactMap { node in
        guard let gridNode = node as? GKGridGraphNode else { return nil }
        return SIMD3<Float>(Float(gridNode.gridPosition.x), 0, Float(gridNode.gridPosition.y))
    }
}
```

### Following a Path in a RealityKit System

```swift
nonisolated struct PathFollowComponent: Component {
    var path: [SIMD3<Float>] = []
    var currentIndex = 0
    var speed: Float = 3.0
}

nonisolated struct PathFollowSystem: System {
    static let query = EntityQuery(where: .has(PathFollowComponent.self))
    init(scene: Scene) {}

    func update(context: SceneUpdateContext) {
        let dt = min(Float(context.deltaTime), 1.0 / 30.0)
        for entity in context.entities(matching: Self.query, updatingSystemWhen: .rendering) {
            guard var pf = entity.components[PathFollowComponent.self],
                  pf.currentIndex < pf.path.count else { continue }

            let target = pf.path[pf.currentIndex]
            let pos = entity.position(relativeTo: nil)
            let dir = target - pos
            let dist = length(dir)

            if dist < 0.2 {
                pf.currentIndex += 1
            } else {
                let move = normalize(dir) * pf.speed * dt
                entity.setPosition(pos + move, relativeTo: nil)
                // Face movement direction
                entity.look(at: target, from: pos, relativeTo: nil)
            }
            entity.components[PathFollowComponent.self] = pf
        }
    }
}
```

---

## Common Mistakes

```swift
// ❌ Forgetting to update agents in game loop
// Agents do nothing without update calls

// ✅ Update every frame (guard first frame where lastUpdateTime is 0)
override func update(_ currentTime: TimeInterval) {
    let dt = lastUpdateTime == 0 ? 0 : currentTime - lastUpdateTime
    lastUpdateTime = currentTime
    agentSystem.update(deltaTime: dt)
}

// ❌ Not cleaning up temporary pathfinding nodes
graph.connectUsingObstacles(node: tempNode)
let path = graph.findPath(from: tempNode, to: target)
// leaked node stays in graph

// ✅ Always remove temporary nodes
graph.remove([tempNode])

// ❌ Using Int.random for gameplay logic
let damage = Int.random(in: 1...10) // not reproducible

// ✅ Use GKRandomSource for deterministic replays
let source = GKMersenneTwisterRandomSource(seed: replaySeed)
let damage = GKRandomDistribution(randomSource: source, lowestValue: 1, highestValue: 10).nextInt()
```
