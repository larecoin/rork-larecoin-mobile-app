---
index: true
description: WeatherService, current/hourly/daily forecasts, alerts
---

# WeatherKit — Weather Data

WeatherKit provides weather forecasts powered by Apple Weather. Offers current conditions, hourly/daily/minute forecasts, severe alerts, and historical comparisons via a Swift async API.

**Import:** `import WeatherKit`
**Requires:** Apple Developer Program membership, WeatherKit capability enabled in Xcode, WeatherKit service enabled on App ID in developer portal.

---

## Setup

1. Xcode → Target → Signing & Capabilities → `+ Capability` → WeatherKit
2. developer.apple.com → Certificates, Identifiers & Profiles → App IDs → enable WeatherKit
3. Free tier: 500,000 API calls/month

## Basic Usage

```swift
import WeatherKit
import CoreLocation

let weatherService = WeatherService.shared
let location = CLLocation(latitude: 37.7749, longitude: -122.4194)

// All weather data at once
let weather = try await weatherService.weather(for: location)
let current = weather.currentWeather
let hourly = weather.hourlyForecast
let daily = weather.dailyForecast
let alerts = weather.weatherAlerts
```

## Selective Requests (More Efficient)

```swift
// Only current
let current = try await weatherService.weather(for: location, including: .current)

// Only hourly
let hourly = try await weatherService.weather(for: location, including: .hourly)

// Batch (single network call)
let (current, hourly, daily) = try await weatherService.weather(
    for: location,
    including: .current, .hourly, .daily
)

// Minute-by-minute precipitation (select regions only)
let minute = try await weatherService.weather(for: location, including: .minute)

// Severe weather alerts
let alerts = try await weatherService.weather(for: location, including: .alerts)
```

## CurrentWeather Properties

| Property                 | Type                           | Description                                |
| ------------------------ | ------------------------------ | ------------------------------------------ |
| `temperature`            | `Measurement<UnitTemperature>` | Current temperature                        |
| `apparentTemperature`    | `Measurement<UnitTemperature>` | Feels-like temperature                     |
| `humidity`               | `Double`                       | 0-1 (multiply by 100 for %)                |
| `dewPoint`               | `Measurement<UnitTemperature>` | Dew point                                  |
| `wind.speed`             | `Measurement<UnitSpeed>`       | Wind speed                                 |
| `wind.direction`         | `Measurement<UnitAngle>`       | Wind direction (degrees from north)        |
| `wind.gust`              | `Measurement<UnitSpeed>?`      | Wind gust speed                            |
| `pressure`               | `Measurement<UnitPressure>`    | Barometric pressure                        |
| `pressureTrend`          | `.rising / .falling / .steady` | Pressure change direction                  |
| `uvIndex`                | `UVIndex`                      | UV index (.value: Int, .category)          |
| `visibility`             | `Measurement<UnitLength>`      | Visibility distance                        |
| `cloudCover`             | `Double`                       | 0-1 cloud coverage                         |
| `cloudCoverByAltitude`   | (iOS 18+)                      | Low/mid/high cloud layers                  |
| `condition`              | `WeatherCondition`             | .clear, .rain, .snow, .thunderstorms, etc. |
| `symbolName`             | `String`                       | SF Symbol name for condition icon          |
| `precipitationIntensity` | `Measurement<UnitSpeed>`       | Current precipitation rate                 |
| `isDaylight`             | `Bool`                         | Whether sun is up                          |

## HourWeather Properties (Hourly Forecast)

All CurrentWeather properties plus:

| Property              | Type                      | Description                       |
| --------------------- | ------------------------- | --------------------------------- |
| `date`                | `Date`                    | Forecast hour                     |
| `precipitationChance` | `Double`                  | 0-1 probability of precipitation  |
| `precipitationAmount` | `Measurement<UnitLength>` | Expected total (iOS 18+: by type) |
| `snowfallAmount`      | `Measurement<UnitLength>` | Expected snowfall (iOS 18+)       |
| `rainAmount`          | `Measurement<UnitLength>` | Expected rain (iOS 18+)           |
| `sleetAmount`         | `Measurement<UnitLength>` | Expected sleet (iOS 18+)          |

The hourly forecast provides 240+ hours (10 days) of data.

## DayWeather Properties (Daily Forecast)

| Property              | Type                           | Description                                 |
| --------------------- | ------------------------------ | ------------------------------------------- |
| `date`                | `Date`                         | Forecast day                                |
| `highTemperature`     | `Measurement<UnitTemperature>` | Day high                                    |
| `lowTemperature`      | `Measurement<UnitTemperature>` | Day low                                     |
| `precipitationChance` | `Double`                       | 0-1                                         |
| `precipitation`       | `Precipitation`                | .rain, .snow, .sleet, .hail, .mixed, .clear |
| `precipitationAmount` | `Measurement<UnitLength>`      | Total precipitation                         |
| `snowfallAmount`      | `Measurement<UnitLength>`      | Total snowfall (iOS 18+)                    |
| `wind.speed`          | `Measurement<UnitSpeed>`       | Average wind                                |
| `wind.gust`           | `Measurement<UnitSpeed>?`      | Max gust                                    |
| `sun.sunrise`         | `Date?`                        | Sunrise time                                |
| `sun.sunset`          | `Date?`                        | Sunset time                                 |
| `moon.moonrise`       | `Date?`                        | Moonrise time                               |
| `moon.moonset`        | `Date?`                        | Moonset time                                |
| `moon.phase`          | `MoonPhase`                    | .new, .waxingCrescent, .firstQuarter, etc.  |
| `uvIndex`             | `UVIndex`                      | Max UV for the day                          |

10-day forecast.

## MinuteWeather (Precipitation Next Hour)

```swift
if let minuteForecast = try await weatherService.weather(for: location, including: .minute) {
    for minute in minuteForecast {
        let chance = minute.precipitationChance    // 0-1
        let intensity = minute.precipitationIntensity // mm/hr
    }
}
```

Available in select regions only. Returns nil where unsupported.

## Weather Alerts

```swift
if let alerts = try await weatherService.weather(for: location, including: .alerts) {
    for alert in alerts {
        let severity = alert.severity   // .minor, .moderate, .severe, .extreme
        let summary = alert.summary     // human-readable description
        let region = alert.region       // affected area name
        let source = alert.source       // issuing authority
        let detailsURL = alert.detailsURL // link to full alert
    }
}
```

## WeatherCondition Enum

Common values: `.clear`, `.mostlyClear`, `.partlyCloudy`, `.mostlyCloudy`, `.cloudy`, `.rain`, `.heavyRain`, `.drizzle`, `.snow`, `.heavySnow`, `.sleet`, `.freezingRain`, `.thunderstorms`, `.tropicalStorm`, `.hurricane`, `.foggy`, `.haze`, `.smoky`, `.windy`, `.blowingDust`, `.hot`, `.blizzard`

Each condition has a corresponding SF Symbol via `symbolName`.

## Formatting Weather Data

```swift
// Temperature — auto-formats to user's locale
let temp = current.temperature
let formatted = temp.formatted() // "72°F" or "22°C"

// Wind
let windSpeed = current.wind.speed.formatted() // "12 mph" or "19 km/h"

// Custom formatting
let celsius = temp.converted(to: .celsius)
let customFormat = celsius.formatted(.measurement(width: .abbreviated)) // "22 °C"

// Wind direction as compass
let degrees = current.wind.direction.converted(to: .degrees).value
let compass = compassDirection(from: degrees) // "NW", "SSE", etc.
```

## Historical Comparisons (iOS 18+)

```swift
let historical = try await weatherService.weather(
    for: location,
    including: .historicalComparisons
)
// Compare today's temperature/precipitation to historical averages
```

## Attribution (Required)

Apple requires you to display WeatherKit attribution:

```swift
let attribution = try await WeatherService.shared.attribution
// attribution.legalPageURL — link to Apple Weather legal page
// attribution.squareMarkURL — Apple Weather square logo
// attribution.combinedMarkDarkURL — combined logo for dark backgrounds
// attribution.combinedMarkLightURL — combined logo for light backgrounds
```

Display the Apple Weather logo and provide a link to the legal page somewhere accessible in your app (e.g., settings or about screen).

## Error Handling

```swift
do {
    let weather = try await weatherService.weather(for: location)
} catch WeatherError.permissionDenied {
    // WeatherKit capability not configured
} catch WeatherError.rateLimited {
    // Exceeded 500K free calls/month
} catch {
    // Network or other error
}
```

## Permissions

WeatherKit itself requires no user-facing permissions. But you'll need Core Location permission to get the user's coordinates:

```
INFOPLIST_KEY_NSLocationWhenInUseUsageDescription = "Show weather for your location";
```
