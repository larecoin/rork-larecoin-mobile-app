---
index: true
description: WidgetKit, TimelineProvider, App Groups, Live Activities, Dynamic Island
---

# Widgets & Live Activities Reference

> Widgets are archived snapshots on a timeline, NOT live views. They render once, get archived, and the system displays the snapshot. Use App Groups to share data between app and widget.

## Widget Setup

### 1. Create Widget Target

Add a Widget Extension target. This creates a separate binary — it cannot access main app data directly.

### 2. App Groups (Required for Data Sharing)

Both the main app AND the widget target must have the same App Group entitlement:

```xml
<!-- In both targets' .entitlements file -->
<key>com.apple.security.application-groups</key>
<array>
    <string>group.com.yourapp.shared</string>
</array>
```

See `capabilities-entitlements.md` for entitlements file setup.

## Basic Widget

```swift
import WidgetKit
import SwiftUI

struct SimpleEntry: TimelineEntry {
    let date: Date
    let title: String
    let value: String
}

struct Provider: TimelineProvider {
    func placeholder(in context: Context) -> SimpleEntry {
        SimpleEntry(date: Date(), title: "Loading...", value: "--")
    }

    func getSnapshot(in context: Context, completion: @escaping (SimpleEntry) -> Void) {
        let entry = SimpleEntry(date: Date(), title: "Tasks", value: "5 remaining")
        completion(entry)
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<SimpleEntry>) -> Void) {
        let data = UserDefaults(suiteName: "group.com.yourapp.shared")
        let title = data?.string(forKey: "widgetTitle") ?? "Tasks"
        let value = data?.string(forKey: "widgetValue") ?? "0"

        let entry = SimpleEntry(date: Date(), title: title, value: value)
        let nextUpdate = Calendar.current.date(byAdding: .hour, value: 1, to: Date())!
        let timeline = Timeline(entries: [entry], policy: .after(nextUpdate))
        completion(timeline)
    }
}

struct MyWidgetView: View {
    var entry: SimpleEntry

    var body: some View {
        VStack(alignment: .leading) {
            Text(entry.title)
                .font(.headline)
            Text(entry.value)
                .font(.title.bold())
        }
        .containerBackground(.fill.tertiary, for: .widget)
    }
}

@main
struct MyWidget: Widget {
    let kind = "MyWidget"

    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: Provider()) { entry in
            MyWidgetView(entry: entry)
        }
        .configurationDisplayName("My Widget")
        .description("Shows current status.")
        .supportedFamilies([.systemSmall, .systemMedium])
    }
}
```

## AppIntentTimelineProvider (iOS 17+)

Async alternative to TimelineProvider — uses `async` methods and supports App Intents for user configuration:

```swift
import AppIntents

struct ConfigurableProvider: AppIntentTimelineProvider {
    func placeholder(in context: Context) -> SimpleEntry {
        SimpleEntry(date: Date(), title: "Loading...", value: "--")
    }

    func snapshot(for configuration: MyWidgetIntent, in context: Context) async -> SimpleEntry {
        SimpleEntry(date: Date(), title: "Tasks", value: "5 remaining")
    }

    func timeline(for configuration: MyWidgetIntent, in context: Context) async -> Timeline<SimpleEntry> {
        let title = configuration.category?.name ?? "All"
        let entry = SimpleEntry(date: Date(), title: title, value: "3 items")
        return Timeline(entries: [entry], policy: .after(Date().addingTimeInterval(3600)))
    }
}
```

Use `AppIntentConfiguration` instead of `StaticConfiguration` when using this provider.

## Data Sharing Between App and Widget

```swift
// ✅ In main app — write to shared UserDefaults
let shared = UserDefaults(suiteName: "group.com.yourapp.shared")!
shared.set("5 tasks", forKey: "widgetValue")

// Tell widget to refresh
import WidgetKit
WidgetCenter.shared.reloadAllTimelines()

// ❌ WRONG — Widget CANNOT see this
UserDefaults.standard.set("5 tasks", forKey: "widgetValue")
```

### File Sharing via App Group Container

```swift
let containerURL = FileManager.default.containerURL(
    forSecurityApplicationGroupIdentifier: "group.com.yourapp.shared"
)!
let fileURL = containerURL.appendingPathComponent("data.json")

// Main app writes
try data.write(to: fileURL)

// Widget reads in TimelineProvider
let data = try Data(contentsOf: fileURL)
```

### SwiftData with App Groups

```swift
let config = ModelConfiguration(
    groupContainer: .identifier("group.com.yourapp.shared")
)
let container = try ModelContainer(for: Task.self, configurations: config)
```

## Timeline Refresh Policies

| Policy         | Behavior                                            |
| -------------- | --------------------------------------------------- |
| `.atEnd`       | Request new timeline when last entry expires        |
| `.after(Date)` | Request new timeline after specific time            |
| `.never`       | Don't auto-refresh (manual only via `WidgetCenter`) |

```swift
// Refresh every 30 minutes
let timeline = Timeline(entries: entries, policy: .after(
    Date().addingTimeInterval(30 * 60)
))

// Never auto-refresh — only when app calls reloadAllTimelines()
let timeline = Timeline(entries: [entry], policy: .never)
```

### Manual Refresh from App

```swift
// Reload all widgets
WidgetCenter.shared.reloadAllTimelines()

// Reload specific widget
WidgetCenter.shared.reloadTimelines(ofKind: "MyWidget")
```

Widget refreshes are unlimited while the app is in the foreground. Background refreshes have a system-managed budget based on usage patterns.

## Widget Families

```swift
.supportedFamilies([
    .systemSmall,       // 2×2 grid square
    .systemMedium,      // 4×2 wide rectangle
    .systemLarge,       // 4×4 large square
    .systemExtraLarge,  // iPad only
    .accessoryCircular, // Lock Screen circular
    .accessoryRectangular, // Lock Screen rectangular
    .accessoryInline,   // Lock Screen inline text
])
```

### Adapting Layout by Family

```swift
struct MyWidgetView: View {
    @Environment(\.widgetFamily) var family
    var entry: SimpleEntry

    var body: some View {
        switch family {
        case .systemSmall:
            CompactView(entry: entry)
        case .systemMedium:
            WideView(entry: entry)
        default:
            FullView(entry: entry)
        }
    }
}
```

### Prevent Background Removal

```swift
// Keep the container background even in StandBy or Smart Stack
.containerBackgroundRemovable(false)
```

## Interactive Widgets (iOS 17+)

Buttons and Toggles work in widgets via App Intents:

```swift
import AppIntents

struct ToggleTaskIntent: AppIntent {
    static var title: LocalizedStringResource = "Toggle Task"

    @Parameter(title: "Task ID")
    var taskID: String

    func perform() async throws -> some IntentResult {
        let shared = UserDefaults(suiteName: "group.com.yourapp.shared")!
        let key = "task_\(taskID)_completed"
        shared.set(!shared.bool(forKey: key), forKey: key)

        WidgetCenter.shared.reloadAllTimelines()
        return .result()
    }
}

// In widget view
Button(intent: ToggleTaskIntent(taskID: task.id)) {
    Image(systemName: task.isCompleted ? "checkmark.circle.fill" : "circle")
}
```

## Live Activities & Dynamic Island

### Define Attributes

```swift
import ActivityKit

struct DeliveryAttributes: ActivityAttributes {
    public struct ContentState: Codable, Hashable {
        var status: String
        var estimatedArrival: Date
        var driverName: String
    }

    var orderNumber: String    // Static data (set once)
}
```

### Start Activity

```swift
let attributes = DeliveryAttributes(orderNumber: "12345")
let state = DeliveryAttributes.ContentState(
    status: "On the way",
    estimatedArrival: Date().addingTimeInterval(1800),
    driverName: "John"
)

let activity = try Activity.request(
    attributes: attributes,
    content: .init(state: state, staleDate: nil),
    pushType: nil    // Use .token for push updates from server
)

// Get push token for server-driven updates
if let pushToken = activity.pushToken {
    sendTokenToServer(pushToken)
}
```

### Update Activity

```swift
let newState = DeliveryAttributes.ContentState(
    status: "Arriving",
    estimatedArrival: Date().addingTimeInterval(300),
    driverName: "John"
)
await activity.update(.init(state: newState, staleDate: nil))
```

### End Activity

```swift
// Dismissal policies: .default, .immediate, .after(Date)
await activity.end(.init(state: finalState, staleDate: nil), dismissalPolicy: .default)
```

### Observe Active Activities

```swift
// List all active activities of a type
for activity in Activity<DeliveryAttributes>.activities {
    print("Order: \(activity.attributes.orderNumber), state: \(activity.content.state.status)")
}

// Check if Live Activities are enabled
let authInfo = ActivityAuthorizationInfo()
if authInfo.areActivitiesEnabled {
    // Start activity
}
```

### Live Activity View

```swift
struct DeliveryLiveActivity: Widget {
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: DeliveryAttributes.self) { context in
            // Lock Screen / banner view
            VStack {
                Text("Order #\(context.attributes.orderNumber)")
                    .font(.headline)
                Text(context.state.status)
                Text(context.state.estimatedArrival, style: .timer)
            }
            .padding()
        } dynamicIsland: { context in
            DynamicIsland {
                DynamicIslandExpandedRegion(.leading) {
                    Image(systemName: "box.truck.fill")
                }
                DynamicIslandExpandedRegion(.trailing) {
                    Text(context.state.estimatedArrival, style: .timer)
                }
                DynamicIslandExpandedRegion(.bottom) {
                    Text(context.state.status)
                }
            } compactLeading: {
                Image(systemName: "box.truck.fill")
            } compactTrailing: {
                Text(context.state.estimatedArrival, style: .timer)
            } minimal: {
                Image(systemName: "box.truck.fill")
            }
        }
    }
}
```

### Content State Size Limit

Live Activity content state is limited to **4KB** encoded. Keep data minimal:

```swift
// ❌ Too much data
struct ContentState: Codable, Hashable {
    var fullOrderDetails: [OrderItem]    // Could exceed 4KB
    var allMessages: [String]
}

// ✅ Minimal data
struct ContentState: Codable, Hashable {
    var status: String
    var eta: Date
    var itemCount: Int
}
```

## Control Center Widgets (iOS 18+)

Buttons and Toggles for Control Center, Lock Screen, and Action button:

```swift
import WidgetKit
import AppIntents

// Toggle control
struct CaffeineControl: ControlWidget {
    var body: some ControlWidgetConfiguration {
        StaticControlConfiguration(kind: "CaffeineToggle") {
            ControlWidgetToggle(
                "Caffeine",
                isOn: CaffeineValueProvider.shared.isEnabled,
                action: ToggleCaffeineIntent()
            ) { isOn in
                Image(systemName: isOn ? "cup.and.saucer.fill" : "cup.and.saucer")
            }
        }
        .displayName("Caffeine Mode")
    }
}

// Button control
struct TimerControl: ControlWidget {
    var body: some ControlWidgetConfiguration {
        StaticControlConfiguration(kind: "StartTimer") {
            ControlWidgetButton(action: StartTimerIntent()) {
                Label("Start Timer", systemImage: "timer")
            }
        }
    }
}
```

## Anti-Patterns

| Anti-Pattern                                                  | Fix                                             |
| ------------------------------------------------------------- | ----------------------------------------------- |
| Network calls in widget view                                  | Fetch data in `TimelineProvider.getTimeline()`  |
| `UserDefaults.standard` in widget                             | Use `UserDefaults(suiteName: "group.xxx")`      |
| Missing `WidgetCenter.reloadAllTimelines()` after data change | Always call after updating shared data          |
| Missing `.containerBackground`                                | Required for iOS 17+ widgets                    |
| Heavy images in widget                                        | Keep assets small, use SF Symbols when possible |
| Forgetting App Groups entitlement on widget target            | Must be on BOTH main app AND widget extension   |
| Live Activity ContentState > 4KB                              | Keep only essential data in ContentState        |
