---
index: true
description: Device compatibility matrix, simulator placeholders, tap-to-place, measure tool
---

# AR Patterns, Recipes & Device Compatibility

---

## Device Compatibility Matrix

| Feature                        | Minimum Device        | iOS     |
| ------------------------------ | --------------------- | ------- |
| Basic AR (planes, raycasting)  | iPhone 6S (A9)        | iOS 11+ |
| Face tracking                  | iPhone X (TrueDepth)  | iOS 11+ |
| Body tracking / Motion capture | iPhone XS (A12)       | iOS 13+ |
| Person segmentation/occlusion  | iPhone XS (A12)       | iOS 13+ |
| Scene reconstruction (mesh)    | iPhone 12 Pro (LiDAR) | iOS 14+ |
| Object Capture on-device       | iPhone 12 Pro (LiDAR) | iOS 17+ |
| RoomPlan                       | iPhone 12 Pro (LiDAR) | iOS 16+ |
| Image detection                | iPhone 6S (A9)        | iOS 11+ |
| Location anchors               | iPhone (GPS)          | iOS 14+ |

---

## What's Practical for Code Generation

### Highly Practical (pure Swift code, no external assets)

| Feature                             | Why                                    | Complexity |
| ----------------------------------- | -------------------------------------- | ---------- |
| Plane detection + object placement  | Core ARKit, no assets needed           | Low        |
| Raycasting / hit testing            | Tap-to-place interactions              | Low        |
| Programmatic 3D shapes              | Box, sphere, plane, text — built-in    | Low        |
| Custom materials (colors, metallic) | SimpleMaterial is trivial              | Low        |
| Measurement / distance tool         | Math + raycasting + text               | Medium     |
| Face tracking + blend shapes        | Access 52 parameters, no assets needed | Medium     |
| AR coaching overlay                 | Drop-in Apple UI component             | Low        |
| Light estimation                    | Automatic in RealityKit                | Zero       |
| Physics simulation                  | Add components to entities             | Medium     |
| Person segmentation                 | Config flag, automatic rendering       | Low        |
| RoomPlan (with built-in UI)         | RoomCaptureView is turnkey             | Medium     |
| Scene reconstruction visualization  | Enable mesh + debug options            | Low-Medium |

### Possible But Requires Assets

| Feature                         | Limitation                                                                                         |
| ------------------------------- | -------------------------------------------------------------------------------------------------- |
| Loading USDZ models             | Use `generate3DAsset` / `generate3DHumanoid` to generate from text, or bundle .usdz files with app |
| Image detection                 | Need reference images in asset catalog                                                             |
| Body-driven character animation | Need rigged character model                                                                        |
| RoomPlan custom model export    | Need 3D furniture model catalog                                                                    |
| Object detection                | Need pre-scanned reference objects                                                                 |

### Not Practical for Code Generation

| Feature                         | Why                                        |
| ------------------------------- | ------------------------------------------ |
| Object Capture / Photogrammetry | Complex pipeline, requires extensive UI/UX |
| Custom Metal shaders            | Too complex for generated code             |
| Multi-user collaborative AR     | Requires networking infrastructure         |
| Geo-anchored AR                 | Limited to specific cities, complex setup  |

---

## Simulator / Cloud Placeholder Pattern

AR requires real hardware — ARKit tracking is unsupported on the simulator
even though plain camera capture works there via camera injection (see
camera-vision-particles.md). Always wrap AR views with a device check:

```swift
struct ARProxyView: View {
    var body: some View {
        Group {
            #if targetEnvironment(simulator)
            ARUnavailablePlaceholder()
            #else
            if ARWorldTrackingConfiguration.isSupported {
                ActualARView()
            } else {
                ARUnavailablePlaceholder()
            }
            #endif
        }
    }
}

struct ARUnavailablePlaceholder: View {
    var body: some View {
        VStack(spacing: 20) {
            Image(systemName: "arkit")
                .font(.system(size: 48))
                .foregroundStyle(.secondary)
            Text("AR Experience")
                .font(.title2)
                .fontWeight(.semibold)
            Text("Install this app on your device\nvia the Rork App for the AR experience.")
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(.systemGroupedBackground))
    }
}
```

For RoomPlan specifically:

```swift
struct RoomScanProxyView: View {
    var body: some View {
        #if targetEnvironment(simulator)
        RoomScanUnavailablePlaceholder()
        #else
        if RoomCaptureSession.isSupported {
            ActualRoomScanView()
        } else {
            RoomScanUnavailablePlaceholder()
        }
        #endif
    }
}
```

---

## Measurement / Distance Calculation

```swift
// 1. Raycast from tap point to find 3D position
let results = arView.raycast(from: tapLocation, allowing: .estimatedPlane, alignment: .any)
guard let result = results.first else { return }

// 2. Store 3D position
let position = SIMD3<Float>(
    result.worldTransform.columns.3.x,
    result.worldTransform.columns.3.y,
    result.worldTransform.columns.3.z
)

// 3. Calculate distance between two points (Euclidean)
let distance = simd_distance(point1, point2)  // returns meters

// 4. Convert to human-readable
let cm = distance * 100
let inches = distance * 39.3701
let text = String(format: "%.1f cm", cm)

// 5. Display as 3D text in the scene
let textMesh = MeshResource.generateText(text, extrusionDepth: 0.001, font: .systemFont(ofSize: 0.02))
let textEntity = ModelEntity(mesh: textMesh, materials: [UnlitMaterial(color: .white)])
textEntity.position = (point1 + point2) / 2
```

### AR Measure Tool Pattern

```swift
class MeasureCoordinator {
    var points: [SIMD3<Float>] = []

    func addPoint(at worldTransform: simd_float4x4, in arView: ARView) {
        let position = SIMD3<Float>(
            worldTransform.columns.3.x,
            worldTransform.columns.3.y,
            worldTransform.columns.3.z
        )

        let dot = ModelEntity(
            mesh: .generateSphere(radius: 0.005),
            materials: [SimpleMaterial(color: .green, isMetallic: false)]
        )
        let anchor = AnchorEntity(world: worldTransform)
        anchor.addChild(dot)
        arView.scene.addAnchor(anchor)

        points.append(position)

        if points.count == 2 {
            let distance = simd_distance(points[0], points[1])
            let cm = distance * 100

            let midpoint = (points[0] + points[1]) / 2
            let textMesh = MeshResource.generateText(
                String(format: "%.1f cm", cm),
                extrusionDepth: 0.001,
                font: .systemFont(ofSize: 0.015)
            )
            let textEntity = ModelEntity(mesh: textMesh, materials: [UnlitMaterial(color: .white)])
            let textAnchor = AnchorEntity(world: midpoint)
            textAnchor.addChild(textEntity)
            arView.scene.addAnchor(textAnchor)

            points.removeAll()
        }
    }
}
```

---

## Full Recipe: Plane Detection + Tap to Place Box

```swift
import SwiftUI
import RealityKit
import ARKit

struct ContentView: View {
    var body: some View {
        ARViewContainer().edgesIgnoringSafeArea(.all)
    }
}

struct ARViewContainer: UIViewRepresentable {
    func makeUIView(context: Context) -> ARView {
        let arView = ARView(frame: .zero)

        let config = ARWorldTrackingConfiguration()
        config.planeDetection = [.horizontal]
        config.environmentTexturing = .automatic
        arView.session.run(config)

        // Coaching overlay
        let coaching = ARCoachingOverlayView()
        coaching.session = arView.session
        coaching.goal = .horizontalPlane
        coaching.activatesAutomatically = true
        coaching.translatesAutoresizingMaskIntoConstraints = false
        arView.addSubview(coaching)
        NSLayoutConstraint.activate([
            coaching.topAnchor.constraint(equalTo: arView.topAnchor),
            coaching.bottomAnchor.constraint(equalTo: arView.bottomAnchor),
            coaching.leadingAnchor.constraint(equalTo: arView.leadingAnchor),
            coaching.trailingAnchor.constraint(equalTo: arView.trailingAnchor)
        ])

        let tap = UITapGestureRecognizer(target: context.coordinator,
                                         action: #selector(Coordinator.handleTap(_:)))
        arView.addGestureRecognizer(tap)

        return arView
    }

    func updateUIView(_ uiView: ARView, context: Context) {}
    func makeCoordinator() -> Coordinator { Coordinator() }

    class Coordinator {
        @objc func handleTap(_ sender: UITapGestureRecognizer) {
            guard let arView = sender.view as? ARView else { return }
            let location = sender.location(in: arView)

            let results = arView.raycast(from: location, allowing: .estimatedPlane, alignment: .horizontal)
            guard let result = results.first else { return }

            let anchor = AnchorEntity(world: result.worldTransform)
            let box = ModelEntity(
                mesh: .generateBox(size: 0.1, cornerRadius: 0.005),
                materials: [SimpleMaterial(color: .systemBlue, roughness: 0.3, isMetallic: true)]
            )
            box.generateCollisionShapes(recursive: true)
            anchor.addChild(box)
            arView.scene.addAnchor(anchor)

            arView.installGestures([.translation, .rotation, .scale], for: box)
        }
    }
}
```

---

## Combination Patterns

### Pattern 1: Classic AR App (ARKit + RealityKit)

Object placement, AR games, product preview, training overlays.

- ARKit: plane detection + raycasts + optional people occlusion/mesh
- RealityKit: entities + physics + gestures + materials
- Start with ARView, run ARWorldTrackingConfiguration, raycast to place anchors/entities
- Add occlusion/mesh only where it provides visible value (costs CPU/GPU)

### Pattern 2: Room Scanning App (RoomPlan as product feature)

Floor plans, measurements, interior design baseline, real estate capture.

- Use `RoomCaptureView` for fastest shipping path
- Use `RoomCaptureSession` + custom UI for custom visualization, guidance, or analytics
- Export to USDZ for sharing/viewing

### Pattern 3: Interactive Scanned Spaces (RoomPlan + ARKit + RealityKit)

Interior design, virtual staging, interactive walkthrough.

1. RoomPlan scans the room → `CapturedRoom` / USDZ
2. RealityKit loads the scanned model and renders it
3. ARKit + RealityKit handles:
   - Raycast placement of new furniture on scanned surfaces
   - Occlusion so placed items appear behind real objects/people
   - Physics so items "sit" on detected surfaces
4. Custom ARSession (iOS 17+) enables combining RoomPlan with ARKit scene geometry for immersive interactions

---

## Common Gotchas

**Always feature-detect:** Many capabilities depend on hardware (LiDAR, TrueDepth, A12+). Use `isSupported` / `supportsFrameSemantics` / `supportsSceneReconstruction` checks and provide fallbacks.

**Coordinate systems:** World origin is "session start" unless you relocalize or persist. For multi-room: either keep one continuous ARSession or relocalize via ARWorldMap.

**Performance:**

- `MeshInstancesComponent` is a big win for repeated geometry
- Keep interactive physics entities bounded
- Use debug overlays (`arView.debugOptions`) while tuning
- Cull or level-of-detail distant entities

**RoomPlan accuracy:** Treat output as parametric, not centimeter-perfect. Use confidence values and allow user correction.

**Scan conditions:** 50+ lux lighting, avoid mirrors/glass, avoid overly long sessions (thermals), keep rooms static.

---

## Key Imports Reference

```swift
import ARKit       // Tracking, configurations, anchors, session
import RealityKit  // Rendering, entities, materials, physics
import RoomPlan    // Room scanning (iOS 16+, LiDAR only)
```

---

## What Makes a Great AR Showcase App

1. **Use ARCoachingOverlay** — always. Guides users through setup.
2. **Programmatic geometry** — boxes, spheres, text work great without USDZ files.
3. **Plane detection + raycasting** — foundation for "place object in real world."
4. **SimpleMaterial with metallic/color** — impressive visuals with one line.
5. **Physics** — dropping/bouncing objects = instant wow factor.
6. **Face tracking** — 52 blend shapes + face mesh = selfie filters without assets.
7. **Light estimation** — automatic in RealityKit, makes objects look real.
8. **Measurement** — universally useful, pure math + raycasting.
9. **RoomPlan** — turnkey room scanning with built-in UI (LiDAR only).
10. **Scene reconstruction** — mesh visualization + classification (LiDAR only).

**The sweet spot:** Features that work from pure Swift code, demonstrate native iOS power, and produce visually impressive results without requiring bundled 3D model files.
