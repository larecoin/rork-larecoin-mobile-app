# RealityKit — Playing Meshy Animations

**Full wiring reference lives in `.rork/skills/swift/generated-3d-animations.md`.** Read that doc before writing animation code — it documents the self-written `GeneratedModelAnimationPlayer` pattern, the holder/state-machine patterns, and the RealityKit `System` driver. This page covers only the bundled-filename contract and pitfalls specific to Meshy outputs.

Write the player pattern from that doc into app code and route all playback through it — do not hand-roll extraction of `AnimationResource` from generated Meshy animation files, and do not use `entity.availableAnimations` on the base model (it only finds animations inside the same USDZ, so it cannot see the bundled `-anim-` files).

## Bundled Filename Contract

Meshy's auto-rigged animation pipeline emits the animated character as a **pair of USDZ
files** bundled into the Swift app's `Resources/`:

- `<model_slug>.usdz` — the base model with a humanoid skeleton.
- `<model_slug>-anim-<animation_slug>.usdz` — one file per accepted animation, each
  carrying a full animated model entity with one usable animation resource.

The bundled filenames are produced by a two-step pipeline in the saver:

1. **Model name → file stem** via `slugifyFileStem` (the same helper applied to every
   asset name before it's written to disk): lowercased, every run of non-alphanumeric
   characters collapsed into a single `_`, leading/trailing underscores trimmed, capped at
   80 characters. Examples: `Hero v2` → `hero_v2`; `Knight (Dragon)` → `knight_dragon`;
   `Sword's Edge` → `sword_s_edge`.
2. **Stem + animation name → animation file** via `animationFileName`: takes the already-
   slugified stem and the raw animation name. The animation name is lowercased and every
   non-alphanumeric run is collapsed to a single `-`, with leading/trailing hyphens
   trimmed. The stem keeps underscores; the separator between stem and animation slug is
   `-anim-`.

Examples (full pipeline, model name → bundled filename):

- model `Hero`, animation `Idle` → `hero-anim-idle.usdz`
- model `Hero`, animation `Walking_Woman` → `hero-anim-walking-woman.usdz`
- model `Robot Guy`, animation `BackLeft_run` → `robot_guy-anim-backleft-run.usdz`
- model `Knight (Dragon)`, animation `Attack 3` → `knight_dragon-anim-attack-3.usdz`

Always reuse the **exact resource name** that the animation `waitTask` (for
`generate3DHumanoid` / `append3DAnimations` generations) reports in
`savedAnimationResources[].resourceName` rather than re-deriving the slug yourself — the
rule above can drift if Meshy changes naming conventions.

## Common pitfalls

- **Materials differ between base model and animation files.** Animation USDZs come from Meshy's FBX→USDZ post-conversion, which can lose or replace PBR materials (a character can turn shiny/metallic while animating). When that happens, transfer the base model's materials onto the animation clone inside your player's `play` step (match `ModelEntity` parts by name and copy `model?.materials`) — keep the fix in the player, not scattered across scene code.
- **Synchronous loading.** `Entity(named:)` is async; never use the synchronous
  `Entity.load(named:)`, which blocks the main thread. Strip the `.usdz` extension —
  RealityKit resolves it in the app bundle automatically.
- **Loading from a remote URL.** `Entity(named:)` only reads from the app bundle. For
  accepted Meshy animations the animation wait task bundles them into `Resources/`;
  do **not** try to fetch the animation USDZ from R2 at runtime — use the
  bundled file.
- **Retargeting generated animation clips onto the base model.** For generated Meshy
  animation USDZs, attach the full animation entity via the player. Extracting a
  clip and playing it on the base USDZ can silently do nothing.
- **Resetting or placing the animated root.** Meshy animation USDZs can carry an
  import-time root transform that keeps the rig upright, and clips can animate
  that root. Keep scene scale/orientation/anchor on the player's wrapper transform
  (copied from the base visual), and do not zero the loaded animation entity's
  position/orientation/scale; otherwise a running humanoid can flip upside down
  or run vertically.
- **Forgetting `transitionDuration`.** A zero transition snaps the character between
  poses and looks broken at speed. 0.2–0.4 s is a good default for locomotion.
- **Loading the same animation every frame.** Call `animationPlayer.preload(...)`
  once and switch only when state changes.
