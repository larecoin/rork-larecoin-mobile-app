---
index: true
description: URLSession WebSocket, SSE, streaming HTTP, toolkit proxy URLs, realtime lifecycle, send/receive error handling
---

# Swift WebSocket and SSE Streams

Read this before generating native Swift code that uses WebSocket, Server-Sent Events (SSE), streaming HTTP, realtime AI sessions, or long-lived `URLSession` connections.

## Choose the Right Transport

| Requirement                                                        | Use                                              | Avoid                                             |
| ------------------------------------------------------------------ | ------------------------------------------------ | ------------------------------------------------- |
| Client and server both send messages after connect                 | `URLSessionWebSocketTask`                        | SSE, polling                                      |
| Server streams text events after one client request                | SSE over `URLSession.bytes(for:)`                | WebSocket unless the client must send later       |
| Plain JSON request/response                                        | `URLSession.data(for:)`                          | WebSocket/SSE                                     |
| Browser-compatible AI SDK realtime                                 | Server/JS bridge when available                  | Reimplementing an SDK codec from memory           |
| Realtime audio media with device routing and interruption handling | Maintained provider SDK or WebRTC when available | Ad hoc socket code without buffering/backpressure |

Native Swift cannot import the Vercel AI SDK codec. If a generated Swift app must speak an AI realtime protocol directly, keep the wire event names explicit and follow provider/toolkit docs exactly.

## Toolkit and Proxy URLs

Use the toolkit URL exactly as the generated environment provides it. It may already include a path:

```text
https://<worktree>.rorkdev.link/__rork/toolkit
```

Append paths to that base path. Do not strip to the host root unless the API explicitly says to.

For WebSocket URLs:

- Parse with `URLComponents`.
- Convert `https` to `wss` and `http` to `ws`.
- Preserve existing base path segments such as `/__rork/toolkit`.
- Put model/provider options in query parameters, not string interpolation.

## WebSocket Pattern

Use `URLSessionWebSocketTask` for native Swift WebSocket clients.

Rules:

- Retain a dedicated `URLSession`, `URLSessionWebSocketDelegate`, and `URLSessionWebSocketTask` for the socket lifetime.
- `resume()` starts the handshake. It does not mean the socket is open.
- Send the first application message only after `urlSession(_:webSocketTask:didOpenWithProtocol:)`.
- Keep one receive loop alive until user close, task cancellation, or socket close.
- Surface send errors, receive errors, close code, close reason, and whether the socket ever opened.
- Suppress duplicate terminal errors after intentional user close.
- Do not log generated app secrets, auth subprotocol payloads, or bearer tokens.

Bad:

```swift
let task = URLSession.shared.webSocketTask(with: url, protocols: protocols)
task.resume()
task.send(.string(initialMessage)) { _ in }
```

Good:

```swift
@MainActor
final class RealtimeSocket {
    private var session: URLSession?
    private var delegate: SocketDelegate?
    private var task: URLSessionWebSocketTask?
    private var receiveTask: Task<Void, Never>?
    private var isClosing = false

    func connect(url: URL, protocols: [String]) {
        let delegate = SocketDelegate()
        delegate.onOpen = { [weak self] in
            Task { @MainActor in self?.sendInitialMessage() }
        }
        delegate.onClose = { [weak self] code, reason in
            Task { @MainActor in self?.handleClose(code: code, reason: reason) }
        }

        let session = URLSession(configuration: .default, delegate: delegate, delegateQueue: nil)
        let task = session.webSocketTask(with: url, protocols: protocols)
        self.session = session
        self.delegate = delegate
        self.task = task
        task.resume()
        startReceiving(from: task)
    }

    func close() {
        isClosing = true
        receiveTask?.cancel()
        task?.cancel(with: .goingAway, reason: nil)
        session?.invalidateAndCancel()
        receiveTask = nil
        task = nil
        delegate = nil
        session = nil
    }

    private func startReceiving(from task: URLSessionWebSocketTask) {
        receiveTask = Task { [weak self] in
            do {
                while !Task.isCancelled {
                    let message = try await task.receive()
                    await self?.handle(message)
                }
            } catch {
                await self?.handleReceiveError(error, closeCode: task.closeCode)
            }
        }
    }

    private func sendInitialMessage() {
        task?.send(.string("{\"type\":\"session-update\"}")) { [weak self] error in
            guard let error else { return }
            Task { @MainActor in self?.handleSendError(error) }
        }
    }

    private func handle(_ message: URLSessionWebSocketTask.Message) async {}
    private func handleClose(code: URLSessionWebSocketTask.CloseCode, reason: String?) {}
    private func handleReceiveError(_ error: Error, closeCode: URLSessionWebSocketTask.CloseCode) {}
    private func handleSendError(_ error: Error) {}
}

private final class SocketDelegate: NSObject, URLSessionWebSocketDelegate {
    var onOpen: (() -> Void)?
    var onClose: ((URLSessionWebSocketTask.CloseCode, String?) -> Void)?

    func urlSession(
        _ session: URLSession,
        webSocketTask: URLSessionWebSocketTask,
        didOpenWithProtocol protocol: String?
    ) {
        onOpen?()
    }

    func urlSession(
        _ session: URLSession,
        webSocketTask: URLSessionWebSocketTask,
        didCloseWith closeCode: URLSessionWebSocketTask.CloseCode,
        reason: Data?
    ) {
        onClose?(closeCode, reason.flatMap { String(data: $0, encoding: .utf8) })
    }
}
```

For audio WebSockets:

- Start microphone capture after the server acknowledges the realtime session, not merely after socket open.
- Decide whether to queue or drop microphone frames while the upstream session is not ready.
- Keep audio engine lifecycle separate from socket lifecycle so reconnects do not leak capture/playback state.

## SSE Pattern

Foundation does not provide the browser `EventSource` API. Implement native SSE with `URLSession.bytes(for:)` or use a maintained SPM package when the app needs reconnection and parsing behavior beyond a small controlled stream.

Request rules:

- Use `GET`.
- Set `Accept: text/event-stream`.
- Add auth headers on the initial request when needed.
- Treat non-200 responses as failures.
- Treat a response whose `Content-Type` does not include `text/event-stream` as a failure.
- Cancel the owning task to close the stream.

Parsing rules:

- Event streams are UTF-8.
- A blank line dispatches the current event.
- `data:` lines append payload lines and are joined with `\n`.
- `event:` sets the event type; default is `message`.
- `id:` updates the last event ID for reconnect.
- `retry:` may update the reconnect delay.
- Lines beginning with `:` are comments.
- HTTP 204 means the client should stop reconnecting.

Minimal shape:

```swift
struct ServerSentEvent: Sendable, Equatable {
    var event: String
    var data: String
    var id: String?
}

func eventStream(from request: URLRequest) -> AsyncThrowingStream<ServerSentEvent, Error> {
    AsyncThrowingStream { continuation in
        let task = Task {
            do {
                let (bytes, response) = try await URLSession.shared.bytes(for: request)
                guard let http = response as? HTTPURLResponse, http.statusCode == 200 else {
                    throw URLError(.badServerResponse)
                }

                let contentType = http.value(forHTTPHeaderField: "Content-Type") ?? ""
                guard contentType.localizedCaseInsensitiveContains("text/event-stream") else {
                    throw URLError(.cannotParseResponse)
                }

                var eventType = "message"
                var dataLines: [String] = []
                var eventId: String?

                for try await line in bytes.lines {
                    if line.isEmpty {
                        if !dataLines.isEmpty {
                            continuation.yield(
                                ServerSentEvent(event: eventType, data: dataLines.joined(separator: "\n"), id: eventId)
                            )
                        }
                        eventType = "message"
                        dataLines.removeAll(keepingCapacity: true)
                        eventId = nil
                        continue
                    }

                    if line.hasPrefix(":") {
                        continue
                    }

                    let parts = line.split(separator: ":", maxSplits: 1, omittingEmptySubsequences: false)
                    let field = String(parts[0])
                    let value = parts.count > 1 ? String(parts[1]).trimmingCharacters(in: .whitespaces) : ""

                    switch field {
                    case "event":
                        eventType = value.isEmpty ? "message" : value
                    case "data":
                        dataLines.append(value)
                    case "id":
                        eventId = value
                    default:
                        break
                    }
                }

                continuation.finish()
            } catch {
                continuation.finish(throwing: error)
            }
        }

        continuation.onTermination = { _ in task.cancel() }
    }
}
```

For production SSE:

- Preserve `Last-Event-ID` and send it on reconnect.
- Honor server `retry:` with a cap and jitter.
- Parse JSON only after assembling the full SSE payload.
- Keep streamed event logs bounded in SwiftUI state.

## References

- Apple `URLSessionWebSocketTask`: https://developer.apple.com/documentation/foundation/urlsessionwebsockettask
- Apple `URLSessionWebSocketDelegate`: https://developer.apple.com/documentation/foundation/urlsessionwebsocketdelegate
- Apple `URLSession.bytes(for:delegate:)`: https://developer.apple.com/documentation/foundation/urlsession/bytes%28for%3Adelegate%3A%29
- WHATWG HTML Server-Sent Events: https://html.spec.whatwg.org/multipage/server-sent-events.html#server-sent-events
