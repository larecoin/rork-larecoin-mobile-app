---
index: true
description: Authentication, leaderboards, achievements, multiplayer
---

# Game Center — Leaderboards, Achievements, Multiplayer

Authentication, GKAccessPoint, score submission, achievements, real-time and turn-based multiplayer.

---

## Authentication

Must happen at app launch. Call this from your App init or root view's `.onAppear`.

```swift
import GameKit

func authenticatePlayer() {
    GKLocalPlayer.local.authenticateHandler = { viewController, error in
        if let vc = viewController {
            if let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
               let rootVC = windowScene.keyWindow?.rootViewController {
                rootVC.present(vc, animated: true)
            }
        } else if GKLocalPlayer.local.isAuthenticated {
            print("Signed in as \(GKLocalPlayer.local.displayName)")
        } else if let error {
            print("Game Center auth failed: \(error.localizedDescription)")
        }
    }
}
```

### SwiftUI App-Level Auth

```swift
import SwiftUI
import GameKit

@main
struct MyGameApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .onAppear {
                    authenticatePlayer()
                }
        }
    }
}
```

### Check Auth State

```swift
guard GKLocalPlayer.local.isAuthenticated else {
    // Show "Sign in to Game Center" prompt
    return
}
```

---

## GKAccessPoint — Floating Game Center Button

System-provided button that opens Game Center dashboard.

```swift
// Show on main menu
GKAccessPoint.shared.location = .topLeading
GKAccessPoint.shared.showHighlights = true
GKAccessPoint.shared.isActive = true

// Hide during gameplay
GKAccessPoint.shared.isActive = false

// Open to a specific state
GKAccessPoint.shared.trigger(state: .leaderboards) { }
GKAccessPoint.shared.trigger(state: .achievements) { }
GKAccessPoint.shared.trigger(leaderboardID: "com.app.highscore", playerScope: .global, timeScope: .allTime) { }
```

---

## Leaderboards

Configure leaderboard IDs in App Store Connect first.

### Submit Score

```swift
func submitScore(_ score: Int, leaderboardID: String) async throws {
    guard GKLocalPlayer.local.isAuthenticated else { return }
    try await GKLeaderboard.submitScore(
        score,
        context: 0,
        player: GKLocalPlayer.local,
        leaderboardIDs: [leaderboardID]
    )
}
```

### Load Entries

```swift
func loadLeaderboard(id: String) async throws -> (localEntry: GKLeaderboard.Entry?, topEntries: [GKLeaderboard.Entry]) {
    let leaderboards = try await GKLeaderboard.loadLeaderboards(IDs: [id])
    guard let lb = leaderboards.first else { return (nil, []) }

    let (local, entries, _) = try await lb.loadEntries(
        for: .global,
        timeScope: .allTime,
        range: 1...10
    )
    return (local, entries)
}
```

### Load Friend Scores

```swift
let (local, friendEntries, count) = try await leaderboard.loadEntries(
    for: .friendsOnly,
    timeScope: .week,
    range: 1...25
)
```

### Display Entry Data

```swift
for entry in topEntries {
    let name = entry.player.displayName ?? "Unknown"
    let score = entry.formattedScore
    let rank = entry.rank
    // entry.player.loadPhoto(for: .small) for avatar
}
```

### Show Leaderboard UI

```swift
GKAccessPoint.shared.trigger(leaderboardID: "com.app.highscore", playerScope: .global, timeScope: .allTime) { }
```

---

## Achievements

Configure achievement IDs in App Store Connect. Progress is 0-100%.

### Report Progress

```swift
func reportAchievement(id: String, percentComplete: Double) async throws {
    guard GKLocalPlayer.local.isAuthenticated else { return }
    let achievement = GKAchievement(identifier: id)
    achievement.percentComplete = percentComplete
    achievement.showsCompletionBanner = true
    try await GKAchievement.report([achievement])
}

// One-shot achievement
try await reportAchievement(id: "com.app.first_win", percentComplete: 100.0)

// Incremental achievement (collect 50 coins)
let progress = Double(coinsCollected) / 50.0 * 100.0
try await reportAchievement(id: "com.app.coin_collector", percentComplete: min(progress, 100.0))
```

### Report Multiple at Once

```swift
let achievements = [
    ("com.app.first_win", 100.0),
    ("com.app.coin_collector", 60.0),
    ("com.app.speed_demon", 100.0)
].map { id, pct -> GKAchievement in
    let a = GKAchievement(identifier: id)
    a.percentComplete = pct
    a.showsCompletionBanner = true
    return a
}
try await GKAchievement.report(achievements)
```

### Load Current Progress

```swift
let achievements = try await GKAchievement.loadAchievements()
for achievement in achievements {
    print("\(achievement.identifier): \(achievement.percentComplete)%")
}
```

### Reset (Development Only)

```swift
try await GKAchievement.resetAchievements()
```

---

## Real-Time Multiplayer

For action games where all players are connected simultaneously.

### Find Match with UI

```swift
class MatchManager: NSObject, GKMatchmakerViewControllerDelegate, GKMatchDelegate {
    var match: GKMatch?

    func presentMatchmaker(from viewController: UIViewController) {
        let request = GKMatchRequest()
        request.minPlayers = 2
        request.maxPlayers = 4

        guard let matchmakerVC = GKMatchmakerViewController(matchRequest: request) else { return }
        matchmakerVC.matchmakerDelegate = self
        viewController.present(matchmakerVC, animated: true)
    }

    func matchmakerViewControllerWasCancelled(_ viewController: GKMatchmakerViewController) {
        viewController.dismiss(animated: true)
    }

    func matchmakerViewController(_ viewController: GKMatchmakerViewController, didFailWithError error: Error) {
        viewController.dismiss(animated: true)
        print("Matchmaking failed: \(error.localizedDescription)")
    }

    func matchmakerViewController(_ viewController: GKMatchmakerViewController, didFind match: GKMatch) {
        viewController.dismiss(animated: true)
        self.match = match
        match.delegate = self
        startGame()
    }

    func startGame() {
        // Begin gameplay
    }
}
```

### Auto-Match (No UI)

```swift
func findMatchAutomatically() async throws -> GKMatch {
    let request = GKMatchRequest()
    request.minPlayers = 2
    request.maxPlayers = 2
    return try await GKMatchmaker.shared().findMatch(for: request)
}
```

### Send and Receive Data

```swift
nonisolated struct GameState: Codable {
    var playerX: Float
    var playerY: Float
    var score: Int
    var action: String
}

// Send to all players
func sendState(_ state: GameState) throws {
    guard let match else { return }
    let data = try JSONEncoder().encode(state)
    try match.sendData(toAllPlayers: data, with: .reliable)
}

// Send unreliable for frequent updates (position)
func sendPosition(x: Float, y: Float) throws {
    guard let match else { return }
    var bytes: [Float] = [x, y]
    let data = Data(bytes: &bytes, count: MemoryLayout<Float>.size * 2)
    try match.sendData(toAllPlayers: data, with: .unreliable)
}

// Receive
extension MatchManager: GKMatchDelegate {
    func match(_ match: GKMatch, didReceive data: Data, fromRemotePlayer player: GKPlayer) {
        if let state = try? JSONDecoder().decode(GameState.self, from: data) {
            DispatchQueue.main.async {
                self.handleReceivedState(state, from: player)
            }
        }
    }

    func match(_ match: GKMatch, player: GKPlayer, didChange state: GKPlayerConnectionState) {
        switch state {
        case .connected:
            print("\(player.displayName) connected")
        case .disconnected:
            print("\(player.displayName) disconnected")
            handlePlayerDisconnect(player)
        default:
            break
        }
    }

    func handleReceivedState(_ state: GameState, from player: GKPlayer) {
        // Update remote player in game
    }

    func handlePlayerDisconnect(_ player: GKPlayer) {
        // Pause or end game
    }
}
```

---

## Turn-Based Multiplayer

For games where players take turns (chess, word games).

```swift
class TurnBasedManager: NSObject, GKTurnBasedMatchmakerViewControllerDelegate {
    func presentTurnBasedMatchmaker(from viewController: UIViewController) {
        let request = GKMatchRequest()
        request.minPlayers = 2
        request.maxPlayers = 2

        let matchmakerVC = GKTurnBasedMatchmakerViewController(matchRequest: request)
        matchmakerVC.turnBasedMatchmakerDelegate = self
        viewController.present(matchmakerVC, animated: true)
    }

    func turnBasedMatchmakerViewControllerWasCancelled(_ viewController: GKTurnBasedMatchmakerViewController) {
        viewController.dismiss(animated: true)
    }

    func turnBasedMatchmakerViewController(_ viewController: GKTurnBasedMatchmakerViewController, didFailWithError error: Error) {
        viewController.dismiss(animated: true)
    }
}

// Take a turn
func takeTurn(match: GKTurnBasedMatch, gameData: Data) async throws {
    let nextParticipants = match.participants.filter {
        $0.player != GKLocalPlayer.local
    }
    try await match.endTurn(
        withNextParticipants: nextParticipants,
        turnTimeout: GKTurnTimeoutDefault,
        match: gameData
    )
}

// End match
func endMatch(match: GKTurnBasedMatch, finalData: Data) async throws {
    for participant in match.participants {
        participant.matchOutcome = participant.player == GKLocalPlayer.local ? .won : .lost
    }
    try await match.endMatchInTurn(withMatch: finalData)
}
```

---

## SwiftUI Game Center Views

```swift
import SwiftUI
import GameKit

struct GameCenterView: UIViewControllerRepresentable {
    let viewState: GKGameCenterViewControllerState

    func makeUIViewController(context: Context) -> GKGameCenterViewController {
        let gc = GKGameCenterViewController(state: viewState)
        gc.gameCenterDelegate = context.coordinator
        return gc
    }

    func updateUIViewController(_ uiViewController: GKGameCenterViewController, context: Context) {}

    func makeCoordinator() -> Coordinator { Coordinator() }

    class Coordinator: NSObject, GKGameCenterControllerDelegate {
        func gameCenterViewControllerDidFinish(_ gameCenterViewController: GKGameCenterViewController) {
            gameCenterViewController.dismiss(animated: true)
        }
    }
}

// Usage
struct MainMenuView: View {
    @State private var showLeaderboard = false

    var body: some View {
        Button("Leaderboard") {
            showLeaderboard = true
        }
        .sheet(isPresented: $showLeaderboard) {
            GameCenterView(viewState: .leaderboards)
        }
    }
}
```

---

## Common Mistakes

```swift
// ❌ Submitting scores without checking auth
try await GKLeaderboard.submitScore(100, context: 0, player: GKLocalPlayer.local, leaderboardIDs: ["lb"])

// ✅ Always check authentication first
guard GKLocalPlayer.local.isAuthenticated else { return }
try await GKLeaderboard.submitScore(100, context: 0, player: GKLocalPlayer.local, leaderboardIDs: ["lb"])

// ❌ Calling authenticateHandler outside app launch
// Auth should happen once at startup, not on button press

// ✅ Call in App.init or root view .onAppear
@main
struct MyApp: App {
    init() { authenticatePlayer() }
    var body: some Scene { WindowGroup { ContentView() } }
}

// ❌ Sending large data packets in real-time multiplayer
// GKMatch has ~87KB limit per message, and unreliable drops large packets

// ✅ Send minimal state, compress if needed
nonisolated struct CompactState: Codable {
    var x: Int16 // not Float
    var y: Int16
    var flags: UInt8 // pack booleans into bits
}
```

---

## Related Skills

- **game-core.md** — GameManager that triggers achievement/leaderboard updates
- **game-multiplayer-patterns.md** — Advanced multiplayer state sync beyond Game Center basics
