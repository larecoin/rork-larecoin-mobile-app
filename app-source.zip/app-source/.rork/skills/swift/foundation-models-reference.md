# Foundation Models Reference (iOS 26+)

> On-device AI with Apple Intelligence. All code requires `@available(iOS 26.0, *)` or `if #available(iOS 26.0, *)`.

## Availability Check

```swift
import FoundationModels

@available(iOS 26.0, *)
struct AvailabilityExample: View {
    private let model = SystemLanguageModel.default

    var body: some View {
        switch model.availability {
        case .available:
            Text("Model is available")
        case .unavailable(let reason):
            Text("Unavailable: \(reason)")
        }
    }
}
```

Always check `SystemLanguageModel.default.availability` before creating a session. Convenience: `SystemLanguageModel.default.isAvailable` returns `Bool`.

## Private Cloud Compute (PCC)

PCC-backed Foundation Models features require OS 27/Xcode 27 APIs plus Apple's managed entitlement:

```xml
<key>com.apple.developer.private-cloud-compute</key>
<true/>
```

Add the key to the app target's `.entitlements` file and make sure `CODE_SIGN_ENTITLEMENTS` points at that file for Debug and Release. PCC is also service, network, quota, platform, and provisioning-profile gated, so always keep a system-model fallback or a clear unavailable state.

## Basic Text Generation

```swift
@available(iOS 26.0, *)
func generate(prompt: String) async throws -> String {
    let session = LanguageModelSession()
    let response = try await session.respond(to: prompt)
    return response.content    // response is Response<String>
}
```

`session.respond(to:)` returns `Response<T>` — access `.content` for the generated value.

## Multi-Turn Conversations

Reuse the same session for context continuity. The session keeps a `transcript` of all exchanges:

```swift
@available(iOS 26.0, *)
@MainActor
@Observable
final class ChatViewModel {
    private var session = LanguageModelSession()
    var messages: [ChatMessage] = []

    func send(_ text: String) async {
        messages.append(ChatMessage(role: .user, content: text))

        do {
            let response = try await session.respond(to: text)
            messages.append(ChatMessage(role: .assistant, content: response.content))
        } catch {
            messages.append(ChatMessage(role: .assistant, content: "Error: \(error.localizedDescription)"))
        }
    }

    func reset() {
        session = LanguageModelSession()
        messages.removeAll()
    }
}
```

### Session Properties

```swift
// Full conversation history
print(session.transcript)

// Check if model is currently generating
.disabled(session.isResponding)

// Prewarm for lower latency on first request
session.prewarm()
```

## @Generable — Structured Output

Use `@Generable` to receive typed Swift objects directly from the model:

```swift
@available(iOS 26.0, *)
@Generable
struct RecipeSuggestion {
    @Guide(description: "Name of the recipe")
    var name: String

    @Guide(description: "Difficulty: easy, medium, or hard")
    var difficulty: String

    @Guide(description: "Estimated cooking time in minutes")
    var cookingTime: Int

    var ingredients: [String]
    var steps: [String]
}

let response = try await session.respond(
    to: "Suggest a quick pasta recipe",
    generating: RecipeSuggestion.self
)
let recipe = response.content    // RecipeSuggestion
```

### @Guide Constraints

Use the static constraint methods to control array sizes and value ranges:

```swift
@Generable
struct SearchSuggestions {
    @Guide(description: "A list of suggested search terms", .count(4))
    var searchTerms: [String]
}

@Generable
struct Top3Result {
    @Guide(.maximumCount(3))
    var actions: [String]

    @Guide(.maximumCount(3))
    var emotions: [String]
}

@Generable
struct Rating {
    @Guide(description: "Score from 1-10", .range(1...10))
    var score: Int

    @Guide(.anyOf(["low", "medium", "high"]))
    var priority: String
}
```

Available constraint methods: `.count(n)`, `.maximumCount(n)`, `.minimumCount(n)`, `.range(ClosedRange)`, `.anyOf([values])`, `.minimum(n)`, `.maximum(n)`, `.pattern(Regex)`, `.element(Guide)`, `.constant(String)`.

### Nested Generable Types

```swift
@Generable
struct Itinerary {
    @Guide(description: "A creative and catchy title for the trip")
    var title: String
    var description: String

    @Guide(.count(3))
    var days: [DayPlan]
}

@Generable
struct DayPlan {
    var day: Int
    var activities: [String]
}
```

### Generable Enums

Simple enums work directly with `@Generable`. Adding `String` raw value and `CaseIterable` is optional:

```swift
@Generable
enum Category {
    case restaurant
    case museum
    case landmark
    case hiking
}
```

Enums with associated values do NOT need String/CaseIterable:

```swift
@Generable
enum Encounter {
    case orderCoffee(String)
    case wantToTalkToManager(complaint: String)
}
```

### Supported Types in @Generable

- `String`, `Int`, `Float`, `Double`, `Bool`
- `[T]` where T is also Generable or a primitive
- Optional types
- Nested `@Generable` structs and enums
- Enums with associated values
- Recursive `@Generable` types (e.g. `var children: [TreeNode]`)

## Instructions (System Prompt)

```swift
let session = LanguageModelSession(
    instructions: "You are a cooking assistant. Keep responses concise."
)
```

## Prompt Builder with Few-Shot Examples

Use the `Prompt { }` result builder to include `@Generable` instances as examples:

```swift
let prompt = Prompt {
    "Generate a 3-day itinerary for the Grand Canyon."
    "Here is an example of the desired format:"

    Itinerary(
        title: "Perfect Tokyo Getaway",
        description: "Experience modern and traditional Japan",
        days: [
            DayPlan(day: 1, activities: ["Visit Senso-ji Temple"]),
            DayPlan(day: 2, activities: ["Mount Fuji day trip"]),
            DayPlan(day: 3, activities: ["Tsukiji Market"])
        ]
    )
}

let response = try await session.respond(to: prompt, generating: Itinerary.self)
let itinerary = response.content
```

## Streaming Responses

```swift
// Streaming text
for try await partial in session.streamResponse(to: prompt) {
    self.currentText = partial.content
}

// Streaming structured output — uses Type.PartiallyGenerated
let stream = session.streamResponse(
    to: "Create a quiz about space",
    generating: QuizQuestion.self
)

for try await snapshot in stream {
    // snapshot.content is QuizQuestion.PartiallyGenerated — all properties optional
    self.currentQuestion = snapshot.content
}
```

### PartiallyGenerated in SwiftUI

```swift
@State private var itinerary: Itinerary.PartiallyGenerated?

var body: some View {
    VStack {
        if let title = itinerary?.title {
            Text(title).transition(.opacity)
        }
        if let days = itinerary?.days {
            ForEach(days) { day in
                DayPlanView(day: day)
            }
        }
    }
    .animation(.easeIn, value: itinerary)
}
```

## Tool Calling

Let the model call your functions. Implement the `Tool` protocol:

```swift
@available(iOS 26.0, *)
final class PointOfInterestTool: Tool {
    let name = "fetch_points_of_interest"
    let description = "Fetches relevant points of interest for a landmark"

    let landmark: String

    @Generable
    struct Arguments {
        @Guide(description: "The category to search for")
        var category: String
        var naturalLanguageQuery: String
    }

    func call(arguments: Arguments) async throws -> ToolOutput {
        let request = MKLocalSearch.Request()
        request.naturalLanguageQuery = arguments.naturalLanguageQuery
        let results = try await MKLocalSearch(request: request).start()

        return ToolOutput("\(results.mapItems.count) results found")
    }
}

// Register tools with session
let tool = PointOfInterestTool(landmark: "Joshua Tree")
let session = LanguageModelSession(tools: [tool])
let response = try await session.respond(
    to: "Find the best restaurants nearby",
    generating: Itinerary.self
)
let itinerary = response.content
```

### ToolOutput

```swift
// Natural language output
ToolOutput("The temperature is 72°F")

// Structured Generable output — pass a @Generable instance
ToolOutput(WeatherResult(temperature: 72.0))
```

## Content Tagging

Use the specialized content-tagging adapter for entity extraction and topic detection:

```swift
let session = LanguageModelSession(
    model: SystemLanguageModel(useCase: .contentTagging),
    instructions: "Tag the 3 most important actions and emotions."
)
let result = try await session.respond(to: articleText, generating: Top3Result.self)
let tags = result.content
```

## Generation Options

Pass `GenerationOptions` per-request to control generation behavior:

```swift
let response = try await session.respond(
    to: "Write a creative poem",
    options: GenerationOptions(temperature: 1.2)
)
```

## Error Handling

```swift
@available(iOS 26.0, *)
func safeGenerate(prompt: String) async -> String {
    guard SystemLanguageModel.default.isAvailable else {
        return "AI features require a supported device with iOS 26."
    }

    do {
        let session = LanguageModelSession()
        let response = try await session.respond(to: prompt)
        return response.content
    } catch let error as LanguageModelSession.GenerationError {
        switch error {
        case .guardrailViolation(_):
            return "This request cannot be processed."
        case .refusal(_, _):
            return "The model declined this request."
        case .exceededContextWindowSize:
            return "The input is too long. Please shorten it."
        case .unsupportedLanguageOrLocale:
            return "This language is not supported."
        case .assetsUnavailable(_):
            return "The AI model is not yet downloaded on this device."
        case .rateLimited(_):
            return "Too many requests. Please wait and try again."
        default:
            return "Generation failed. Please try again."
        }
    } catch {
        return "An error occurred: \(error.localizedDescription)"
    }
}
```

## SwiftUI Integration Pattern

```swift
@available(iOS 26.0, *)
struct AIView: View {
    @State private var viewModel = AIViewModel()
    @State private var prompt = ""

    var body: some View {
        VStack {
            ScrollView {
                Text(viewModel.response)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }

            HStack {
                TextField("Ask something...", text: $prompt)
                    .textFieldStyle(.roundedBorder)

                Button("Send") {
                    Task { await viewModel.generate(prompt: prompt) }
                    prompt = ""
                }
                .disabled(prompt.isEmpty || viewModel.session.isResponding)
            }
        }
        .padding()
    }
}

@available(iOS 26.0, *)
@MainActor
@Observable
final class AIViewModel {
    let session = LanguageModelSession()
    var response = ""

    func generate(prompt: String) async {
        guard SystemLanguageModel.default.isAvailable else {
            response = "AI not available on this device."
            return
        }

        do {
            let result = try await session.respond(to: prompt)
            response = result.content
        } catch {
            response = "Error: \(error.localizedDescription)"
        }
    }
}
```

## Anti-Patterns

| Anti-Pattern                                   | Fix                                                                    |
| ---------------------------------------------- | ---------------------------------------------------------------------- |
| Missing `@available(iOS 26.0, *)`              | ALWAYS wrap — app targets iOS 18+                                      |
| Manual JSON parsing from model output          | Use `@Generable` structs                                               |
| Accessing response directly without `.content` | `respond()` returns `Response<T>` — use `.content`                     |
| Forgetting `@Generable` on nested enum types   | All enum types used in a `@Generable` struct must also be `@Generable` |
| Not checking availability                      | Use `SystemLanguageModel.default.isAvailable` or check `.availability` |
| New session for each message in chat           | Reuse session for multi-turn context                                   |
| Using for tasks that need internet data        | Foundation Models is offline-only, no web access                       |
| Blocking UI during generation                  | Use `session.isResponding` to disable buttons, use streaming           |
