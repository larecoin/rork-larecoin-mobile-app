---
index: true
description: MTLDevice, render/compute pipelines, buffers, textures, SwiftUI shaders
---

# Metal — GPU Rendering & Compute

Metal is Apple's low-level GPU framework for high-performance rendering and parallel computation. Use it for custom visual effects, particle systems, image processing, and any rendering beyond what SwiftUI/Core Animation can handle.

**Import:** `import Metal`, `import MetalKit`

---

## Core Architecture

```
MTLDevice (GPU)
├── MTLCommandQueue
│   └── MTLCommandBuffer (one per frame)
│       ├── MTLRenderCommandEncoder  — draw triangles/points
│       └── MTLComputeCommandEncoder — run compute kernels
├── MTLRenderPipelineState  — compiled vertex + fragment shaders
├── MTLComputePipelineState — compiled compute kernel
├── MTLBuffer  — GPU-accessible data (vertices, particles, uniforms)
├── MTLTexture — GPU-accessible images (input textures, render targets)
└── MTLLibrary — compiled shader functions (.metal files)
```

## Minimal Setup

```swift
import Metal
import MetalKit

let device = MTLCreateSystemDefaultDevice()!
let commandQueue = device.makeCommandQueue()!
let library = device.makeDefaultLibrary()! // compiles .metal files in project
```

## MTKView in SwiftUI (UIViewRepresentable)

```swift
import SwiftUI
import MetalKit

struct MetalView: UIViewRepresentable {
    func makeUIView(context: Context) -> MTKView {
        let view = MTKView()
        view.device = MTLCreateSystemDefaultDevice()
        view.delegate = context.coordinator
        view.preferredFramesPerSecond = 60
        view.clearColor = MTLClearColor(red: 0, green: 0, blue: 0, alpha: 0)
        view.isOpaque = false           // transparent background
        view.layer.isOpaque = false
        view.backgroundColor = .clear
        view.enableSetNeedsDisplay = false // continuous rendering
        return view
    }

    func updateUIView(_ uiView: MTKView, context: Context) {}

    func makeCoordinator() -> Renderer {
        Renderer()
    }
}

class Renderer: NSObject, MTKViewDelegate {
    var device: MTLDevice!
    var commandQueue: MTLCommandQueue!

    override init() {
        super.init()
        device = MTLCreateSystemDefaultDevice()!
        commandQueue = device.makeCommandQueue()!
    }

    func draw(in view: MTKView) {
        guard let drawable = view.currentDrawable,
              let descriptor = view.currentRenderPassDescriptor,
              let commandBuffer = commandQueue.makeCommandBuffer() else { return }

        let encoder = commandBuffer.makeRenderCommandEncoder(descriptor: descriptor)!
        // draw commands here
        encoder.endEncoding()

        commandBuffer.present(drawable)
        commandBuffer.commit()
    }

    func mtkView(_ view: MTKView, drawableSizeWillChange size: CGSize) {}
}
```

## Render Pipeline (Drawing)

### Creating a Render Pipeline

```swift
let vertexFunction = library.makeFunction(name: "vertexShader")!
let fragmentFunction = library.makeFunction(name: "fragmentShader")!

let pipelineDescriptor = MTLRenderPipelineDescriptor()
pipelineDescriptor.vertexFunction = vertexFunction
pipelineDescriptor.fragmentFunction = fragmentFunction
pipelineDescriptor.colorAttachments[0].pixelFormat = .bgra8Unorm

// Enable alpha blending
pipelineDescriptor.colorAttachments[0].isBlendingEnabled = true
pipelineDescriptor.colorAttachments[0].sourceRGBBlendFactor = .sourceAlpha
pipelineDescriptor.colorAttachments[0].destinationRGBBlendFactor = .oneMinusSourceAlpha
pipelineDescriptor.colorAttachments[0].sourceAlphaBlendFactor = .sourceAlpha
pipelineDescriptor.colorAttachments[0].destinationAlphaBlendFactor = .oneMinusSourceAlpha

let renderPipeline = try! device.makeRenderPipelineState(descriptor: pipelineDescriptor)
```

### Drawing Primitives

```swift
let encoder = commandBuffer.makeRenderCommandEncoder(descriptor: renderPassDescriptor)!
encoder.setRenderPipelineState(renderPipeline)
encoder.setVertexBuffer(vertexBuffer, offset: 0, index: 0)
encoder.setFragmentTexture(texture, index: 0)

// Draw triangles
encoder.drawPrimitives(type: .triangle, vertexStart: 0, vertexCount: vertexCount)

// Draw points (particles)
encoder.drawPrimitives(type: .point, vertexStart: 0, vertexCount: particleCount)

// Draw indexed
encoder.drawIndexedPrimitives(type: .triangle, indexCount: indexCount,
                               indexType: .uint16, indexBuffer: indexBuffer, indexBufferOffset: 0)

encoder.endEncoding()
```

### Primitive Types

| Type             | Description                          |
| ---------------- | ------------------------------------ |
| `.point`         | Individual points (particle systems) |
| `.line`          | Line segments (pairs of vertices)    |
| `.lineStrip`     | Connected line segments              |
| `.triangle`      | Filled triangles (3 vertices each)   |
| `.triangleStrip` | Connected triangles (shared edges)   |

## Compute Pipeline (GPU Computation)

For particle updates, physics, image processing — any massively parallel work.

### Creating a Compute Pipeline

```swift
let computeFunction = library.makeFunction(name: "myComputeKernel")!
let computePipeline = try! device.makeComputePipelineState(function: computeFunction)
```

### Dispatching Compute Work

```swift
let computeEncoder = commandBuffer.makeComputeCommandEncoder()!
computeEncoder.setComputePipelineState(computePipeline)
computeEncoder.setBuffer(dataBuffer, offset: 0, index: 0)
computeEncoder.setTexture(inputTexture, index: 0)

// Thread configuration
let threadsPerGroup = MTLSize(width: 256, height: 1, depth: 1)
let threadGroups = MTLSize(width: (elementCount + 255) / 256, height: 1, depth: 1)
computeEncoder.dispatchThreadgroups(threadGroups, threadsPerThreadgroup: threadsPerGroup)

computeEncoder.endEncoding()
```

### 2D Dispatch (for image/texture processing)

```swift
let w = computePipeline.threadExecutionWidth
let h = computePipeline.maxTotalThreadsPerThreadgroup / w
let threadsPerGroup = MTLSize(width: w, height: h, depth: 1)
let threadGroups = MTLSize(
    width: (textureWidth + w - 1) / w,
    height: (textureHeight + h - 1) / h,
    depth: 1
)
computeEncoder.dispatchThreadgroups(threadGroups, threadsPerThreadgroup: threadsPerGroup)
```

## Buffers

```swift
// Create from data
var vertices: [SIMD4<Float>] = [...]
let buffer = device.makeBuffer(bytes: &vertices,
                                length: MemoryLayout<SIMD4<Float>>.stride * vertices.count,
                                options: .storageModeShared)!

// Create empty buffer
let buffer = device.makeBuffer(length: size, options: .storageModeShared)!

// Read back from GPU
let pointer = buffer.contents().bindMemory(to: Float.self, capacity: count)
let result = Array(UnsafeBufferPointer(start: pointer, count: count))
```

### Storage Modes

| Mode                  | CPU Access          | GPU Access | Best For                                        |
| --------------------- | ------------------- | ---------- | ----------------------------------------------- |
| `.storageModeShared`  | Read/Write          | Read/Write | Data updated from CPU each frame                |
| `.storageModePrivate` | None                | Read/Write | GPU-only data (render targets, compute results) |
| `.storageModeManaged` | Read/Write (synced) | Read/Write | macOS only                                      |

## Textures

### Creating a Texture

```swift
let descriptor = MTLTextureDescriptor.texture2DDescriptor(
    pixelFormat: .rgba8Unorm,
    width: 512,
    height: 512,
    mipmapped: false
)
descriptor.usage = [.shaderRead, .shaderWrite, .renderTarget]
let texture = device.makeTexture(descriptor: descriptor)!
```

### Uploading Data to a Texture

```swift
let region = MTLRegionMake2D(0, 0, width, height)
texture.replace(region: region, mipmapLevel: 0,
                withBytes: pixelData,
                bytesPerRow: width * 4) // 4 bytes per RGBA pixel
```

### Loading Texture from Image

```swift
let textureLoader = MTKTextureLoader(device: device)
let texture = try textureLoader.newTexture(name: "myImage", scaleFactor: 1.0,
                                            bundle: nil, options: nil)
```

### Common Pixel Formats

| Format         | Channels         | Use Case                         |
| -------------- | ---------------- | -------------------------------- |
| `.rgba8Unorm`  | 4 × 8-bit        | Standard color textures          |
| `.bgra8Unorm`  | 4 × 8-bit        | Drawable textures (default)      |
| `.r32Float`    | 1 × 32-bit float | Single-channel data (heightmaps) |
| `.rg32Float`   | 2 × 32-bit float | Two-channel data (wind U/V)      |
| `.rgba32Float` | 4 × 32-bit float | HDR data                         |
| `.r8Unorm`     | 1 × 8-bit        | Masks, single-channel            |

## Metal Shading Language (MSL) Basics

Metal shader files use `.metal` extension. They're C++-based.

### Vertex + Fragment Shader

```metal
#include <metal_stdlib>
using namespace metal;

struct VertexIn {
    float4 position [[attribute(0)]];
    float2 texCoord [[attribute(1)]];
};

struct VertexOut {
    float4 position [[position]];
    float2 texCoord;
};

vertex VertexOut vertexShader(VertexIn in [[stage_in]]) {
    VertexOut out;
    out.position = in.position;
    out.texCoord = in.texCoord;
    return out;
}

fragment float4 fragmentShader(VertexOut in [[stage_in]],
                                texture2d<float> tex [[texture(0)]]) {
    constexpr sampler s(filter::linear, address::clamp_to_edge);
    return tex.sample(s, in.texCoord);
}
```

### Compute Kernel

```metal
kernel void myKernel(
    device float *data [[buffer(0)]],
    texture2d<float, access::read> inputTex [[texture(0)]],
    texture2d<float, access::write> outputTex [[texture(1)]],
    uint id [[thread_position_in_grid]]
) {
    // id is the thread index — process data[id]
    data[id] = data[id] * 2.0;
}
```

### Key MSL Qualifiers

| Qualifier                     | Meaning                                    |
| ----------------------------- | ------------------------------------------ |
| `[[position]]`                | Output clip-space position (vertex shader) |
| `[[stage_in]]`                | Input from previous stage                  |
| `[[vertex_id]]`               | Current vertex index                       |
| `[[thread_position_in_grid]]` | Compute thread index                       |
| `[[buffer(N)]]`               | Buffer at index N                          |
| `[[texture(N)]]`              | Texture at index N                         |
| `device`                      | Read/write GPU memory                      |
| `constant`                    | Read-only GPU memory                       |
| `thread`                      | Per-thread local memory                    |

### MSL Types

| Type                         | Description                     |
| ---------------------------- | ------------------------------- |
| `float2`, `float3`, `float4` | Vectors                         |
| `float4x4`                   | 4×4 matrix                      |
| `half`, `half4`              | 16-bit float (faster on mobile) |
| `uint`, `int`                | 32-bit integers                 |
| `texture2d<float>`           | 2D float texture                |
| `sampler`                    | Texture sampler                 |

## SwiftUI Shader Effects (iOS 17+)

For simple per-pixel effects without full Metal setup, SwiftUI can apply `.metal` shaders directly:

```swift
// In .metal file:
[[stitchable]] float2 wave(float2 position, float time) {
    return position + float2(sin(position.y * 0.05 + time) * 5.0, 0);
}

[[stitchable]] half4 colorShift(float2 position, half4 color, float time) {
    float shift = sin(position.x * 0.01 + time) * 0.5 + 0.5;
    return half4(color.r * shift, color.g, color.b * (1.0 - shift), color.a);
}
```

```swift
// In SwiftUI:
let time = Date.now.timeIntervalSince1970

Text("Wavy")
    .distortionEffect(ShaderLibrary.wave(.float(time)), maxSampleOffset: .init(width: 10, height: 0))

Image("photo")
    .colorEffect(ShaderLibrary.colorShift(.float(time)))

RoundedRectangle(cornerRadius: 12)
    .layerEffect(ShaderLibrary.myEffect(.float(time)), maxSampleOffset: .zero)
```

### SwiftUI Shader Types

| Modifier              | Use Case                                    |
| --------------------- | ------------------------------------------- |
| `.colorEffect()`      | Per-pixel color transformation              |
| `.distortionEffect()` | Per-pixel position displacement             |
| `.layerEffect()`      | Full layer access (read neighboring pixels) |

## Particle System Pattern (Compute + Render)

Common pattern for wind visualization, fire, smoke, etc.:

```swift
struct Particle {
    var position: SIMD2<Float>
    var velocity: SIMD2<Float>
    var age: Float
    var maxAge: Float
}

// 1. Create buffer with initial particles
var particles = (0..<count).map { _ in
    Particle(position: .init(Float.random(in: 0...1), Float.random(in: 0...1)),
             velocity: .zero, age: 0, maxAge: Float.random(in: 50...200))
}
let buffer = device.makeBuffer(bytes: &particles,
                                length: MemoryLayout<Particle>.stride * count)!

// 2. Compute shader updates particles each frame
// 3. Render shader draws particles as points or short lines
```

## Render-to-Texture (Trail Effect)

For fading trails (wind flow, comet tails), render to an offscreen texture:

```swift
// Create offscreen texture
let trailDescriptor = MTLTextureDescriptor.texture2DDescriptor(
    pixelFormat: .bgra8Unorm,
    width: Int(viewSize.width),
    height: Int(viewSize.height),
    mipmapped: false
)
trailDescriptor.usage = [.renderTarget, .shaderRead, .shaderWrite]
trailDescriptor.storageMode = .private
let trailTexture = device.makeTexture(descriptor: trailDescriptor)!

// Each frame:
// 1. Fade previous trail (multiply by 0.97) via compute shader or fullscreen quad
// 2. Draw new particles onto trail texture
// 3. Composite trail texture onto screen
```

## drawingGroup() — Easy Metal Acceleration

For complex SwiftUI views that are slow, wrap in `drawingGroup()` to render via Metal:

```swift
ZStack {
    ForEach(0..<500) { i in
        Circle()
            .fill(colors[i])
            .frame(width: 20, height: 20)
            .offset(x: offsets[i].x, y: offsets[i].y)
    }
}
.drawingGroup() // renders entire ZStack via Metal in one pass
```

No shader code needed — Metal handles the compositing automatically. Use when you have hundreds of overlapping shapes.

## Performance Tips

- Use `.storageModePrivate` for GPU-only resources
- Prefer `half` over `float` in shaders where precision allows (2x throughput on Apple GPUs)
- Batch draw calls — minimize `setRenderPipelineState` changes
- Triple-buffer dynamic data (3 copies of uniform/vertex buffers, rotate each frame)
- Use `MTLCommandBuffer.addCompletedHandler` for async GPU→CPU readback
- Apple GPUs fully support non-power-of-two textures with no penalty
- Profile with Instruments → Metal System Trace and GPU Counters
