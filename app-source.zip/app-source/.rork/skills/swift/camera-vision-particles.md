---
index: true
description: Camera feed + Vision/CoreML detection + Canvas particle systems
---

# Camera + Vision + Particle Effects — Building "Smart Camera" UIs

How to build camera screens where floating particles react to detected objects — the "phone understands what it sees" effect. Combines AVFoundation camera, Vision/CoreML detection, and animated particle overlay.

---

## Architecture Overview

```
┌─────────────────────────────────────┐
│  SwiftUI View (ZStack)              │
│  ┌───────────────────────────────┐  │
│  │ Camera Preview Layer (bottom) │  │
│  │ AVCaptureVideoPreviewLayer    │  │
│  ├───────────────────────────────┤  │
│  │ Particle Overlay (top)        │  │
│  │ TimelineView + Canvas         │  │
│  │ OR SpriteKit SKView           │  │
│  └───────────────────────────────┘  │
└─────────────────────────────────────┘

Data flow:
Camera frames → AVCaptureVideoDataOutput → Vision/CoreML → detected regions
                                                              ↓
                                          Particle system ← attraction points
```

---

## 1. Camera Preview in SwiftUI

```swift
import SwiftUI
import AVFoundation

class CameraManager: NSObject {
    let captureSession = AVCaptureSession()
    private let sessionQueue = DispatchQueue(label: "cameraQueue")
    private let videoOutput = AVCaptureVideoDataOutput()

    var frameHandler: ((CMSampleBuffer) -> Void)?

    func configure() {
        sessionQueue.async { [weak self] in
            self?.setupSession()
        }
    }

    private func setupSession() {
        captureSession.beginConfiguration()
        captureSession.sessionPreset = .high

        guard let camera = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back),
              let input = try? AVCaptureDeviceInput(device: camera) else { return }

        if captureSession.canAddInput(input) {
            captureSession.addInput(input)
        }

        videoOutput.setSampleBufferDelegate(self, queue: DispatchQueue(label: "videoQueue"))
        if captureSession.canAddOutput(videoOutput) {
            captureSession.addOutput(videoOutput)
        }
        videoOutput.connection(with: .video)?.videoRotationAngle = 90  // portrait

        captureSession.commitConfiguration()
        captureSession.startRunning()
    }

    func stop() {
        sessionQueue.async { [weak self] in
            self?.captureSession.stopRunning()
        }
    }
}

extension CameraManager: AVCaptureVideoDataOutputSampleBufferDelegate {
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer,
                       from connection: AVCaptureConnection) {
        frameHandler?(sampleBuffer)
    }
}

struct CameraPreview: UIViewRepresentable {
    let session: AVCaptureSession

    func makeUIView(context: Context) -> UIView {
        let view = UIView(frame: .zero)
        let previewLayer = AVCaptureVideoPreviewLayer(session: session)
        previewLayer.videoGravity = .resizeAspectFill
        view.layer.addSublayer(previewLayer)
        context.coordinator.previewLayer = previewLayer
        return view
    }

    func updateUIView(_ uiView: UIView, context: Context) {
        context.coordinator.previewLayer?.frame = uiView.bounds
    }

    func makeCoordinator() -> Coordinator { Coordinator() }

    class Coordinator {
        var previewLayer: AVCaptureVideoPreviewLayer?
    }
}
```

---

## 2. Real-Time Object Detection with Vision

Two approaches for detecting food/objects in camera frames:

### Approach A: CoreML Food Classifier

Classifies what the food IS (apple, pizza, salad). Use a food-specific model like Food101 or MobileNetV2 fine-tuned on food.

```swift
import Vision
import CoreML

@Observable
class FoodDetector {
    var detectedFood: String = ""
    var confidence: Float = 0

    private lazy var classificationRequest: VNCoreMLRequest? = {
        // Add a .mlmodel file to your project (e.g. Food101.mlmodel)
        guard let model = try? VNCoreMLModel(for: MobileNetV2().model) else { return nil }
        let request = VNCoreMLRequest(model: model) { [weak self] request, error in
            guard let results = request.results as? [VNClassificationObservation],
                  let top = results.first else { return }
            Task { @MainActor in
                self?.detectedFood = top.identifier
                self?.confidence = top.confidence
            }
        }
        request.imageCropAndScaleOption = .centerCrop
        return request
    }()

    func classify(sampleBuffer: CMSampleBuffer) {
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer),
              let request = classificationRequest else { return }
        let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: .right)
        try? handler.perform([request])
    }
}
```

### Approach B: Saliency Detection (No Custom Model Needed)

Finds "interesting regions" in the frame — objects that stand out. Works with any content, no training needed.

```swift
import Vision

@Observable
class SaliencyDetector {
    var salientRegions: [CGRect] = []

    func detectSaliency(sampleBuffer: CMSampleBuffer) {
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }

        let request = VNGenerateObjectnessBasedSaliencyImageRequest { [weak self] request, error in
            guard let results = request.results as? [VNSaliencyImageObservation],
                  let observation = results.first,
                  let objects = observation.salientObjects else { return }

            let rects = objects.map { $0.boundingBox }
            Task { @MainActor in
                self?.salientRegions = rects
            }
        }

        let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: .right)
        try? handler.perform([request])
    }
}
```

### Approach C: Full Object Detection with Bounding Boxes

Detects AND localizes objects in the frame with bounding rectangles.

```swift
import Vision

@Observable
class ObjectDetector {
    var detectedObjects: [DetectedObject] = []

    struct DetectedObject {
        let label: String
        let confidence: Float
        let boundingBox: CGRect  // normalized 0-1, origin bottom-left
    }

    private lazy var detectionRequest: VNCoreMLRequest? = {
        guard let model = try? VNCoreMLModel(for: YOLOv3().model) else { return nil }
        let request = VNCoreMLRequest(model: model) { [weak self] request, error in
            guard let results = request.results as? [VNRecognizedObjectObservation] else { return }
            let objects = results.compactMap { obs -> DetectedObject? in
                guard let label = obs.labels.first else { return nil }
                return DetectedObject(
                    label: label.identifier,
                    confidence: label.confidence,
                    boundingBox: obs.boundingBox
                )
            }
            Task { @MainActor in
                self?.detectedObjects = objects
            }
        }
        return request
    }()

    func detect(sampleBuffer: CMSampleBuffer) {
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer),
              let request = detectionRequest else { return }
        let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: .right)
        try? handler.perform([request])
    }
}
```

### Converting Vision Coordinates to Screen

Vision uses normalized coordinates (0-1, origin bottom-left). Convert to screen coordinates:

```swift
func visionRectToScreen(_ visionRect: CGRect, in viewSize: CGSize) -> CGRect {
    CGRect(
        x: visionRect.origin.x * viewSize.width,
        y: (1 - visionRect.origin.y - visionRect.height) * viewSize.height,
        width: visionRect.width * viewSize.width,
        height: visionRect.height * viewSize.height
    )
}
```

---

## 3. Particle System — Two Approaches

### Approach A: SwiftUI Canvas + TimelineView (Recommended)

Pure SwiftUI, no UIKit bridging needed, great performance with Canvas.

```swift
import SwiftUI

struct Particle: Identifiable {
    let id = UUID()
    var x: CGFloat
    var y: CGFloat
    var vx: CGFloat
    var vy: CGFloat
    var size: CGFloat
    var opacity: Double
    var hue: Double
}

@Observable
class ParticleSystem {
    var particles: [Particle] = []
    var attractionPoints: [CGPoint] = []
    private let particleCount = 80

    func setup(in size: CGSize) {
        guard particles.isEmpty else { return }
        particles = (0..<particleCount).map { _ in
            Particle(
                x: CGFloat.random(in: 0...size.width),
                y: CGFloat.random(in: 0...size.height),
                vx: CGFloat.random(in: -0.5...0.5),
                vy: CGFloat.random(in: -0.5...0.5),
                size: CGFloat.random(in: 3...8),
                opacity: Double.random(in: 0.3...0.8),
                hue: Double.random(in: 0.45...0.55)
            )
        }
    }

    func update(in size: CGSize) {
        for i in particles.indices {
            // Base drift
            particles[i].x += particles[i].vx
            particles[i].y += particles[i].vy

            // Random wandering
            particles[i].vx += CGFloat.random(in: -0.1...0.1)
            particles[i].vy += CGFloat.random(in: -0.1...0.1)

            // Damping
            particles[i].vx *= 0.98
            particles[i].vy *= 0.98

            // Attraction toward detected objects
            for point in attractionPoints {
                let dx = point.x - particles[i].x
                let dy = point.y - particles[i].y
                let distance = sqrt(dx * dx + dy * dy)
                if distance > 5 {
                    let force: CGFloat = min(2.0, 150.0 / (distance + 1))
                    particles[i].vx += (dx / distance) * force * 0.05
                    particles[i].vy += (dy / distance) * force * 0.05
                }
                // Glow when near attraction point
                if distance < 100 {
                    particles[i].opacity = min(1.0, particles[i].opacity + 0.02)
                    particles[i].size = min(12, particles[i].size + 0.1)
                } else {
                    particles[i].opacity = max(0.3, particles[i].opacity - 0.01)
                    particles[i].size = max(3, particles[i].size - 0.05)
                }
            }

            // Wrap around edges
            if particles[i].x < -10 { particles[i].x = size.width + 10 }
            if particles[i].x > size.width + 10 { particles[i].x = -10 }
            if particles[i].y < -10 { particles[i].y = size.height + 10 }
            if particles[i].y > size.height + 10 { particles[i].y = -10 }
        }
    }
}

struct ParticleOverlay: View {
    let system: ParticleSystem

    var body: some View {
        TimelineView(.animation) { timeline in
            Canvas { context, size in
                system.setup(in: size)
                system.update(in: size)

                for particle in system.particles {
                    let rect = CGRect(
                        x: particle.x - particle.size / 2,
                        y: particle.y - particle.size / 2,
                        width: particle.size,
                        height: particle.size
                    )
                    context.opacity = particle.opacity
                    context.fill(
                        Circle().path(in: rect),
                        with: .color(Color(hue: particle.hue, saturation: 0.7, brightness: 1.0))
                    )
                }
            }
        }
        .allowsHitTesting(false)
    }
}
```

### Approach B: SpriteKit Overlay

More powerful physics (gravity fields, collisions), better for complex particle behaviors.

```swift
import SpriteKit
import SwiftUI

class ParticleScene: SKScene {
    private var dots: [SKShapeNode] = []
    private var gravityFields: [SKFieldNode] = []

    override func didMove(to view: SKView) {
        backgroundColor = .clear
        physicsWorld.gravity = .zero

        // Spawn floating dots
        for _ in 0..<80 {
            let dot = SKShapeNode(circleOfRadius: CGFloat.random(in: 2...5))
            dot.fillColor = UIColor(hue: CGFloat.random(in: 0.45...0.55),
                                    saturation: 0.7, brightness: 1.0, alpha: 0.6)
            dot.strokeColor = .clear
            dot.position = CGPoint(x: CGFloat.random(in: 0...size.width),
                                   y: CGFloat.random(in: 0...size.height))
            dot.physicsBody = SKPhysicsBody(circleOfRadius: 3)
            dot.physicsBody?.mass = 0.01
            dot.physicsBody?.linearDamping = 2.0
            dot.physicsBody?.categoryBitMask = 0x1
            dot.physicsBody?.collisionBitMask = 0
            // Random initial velocity
            dot.physicsBody?.velocity = CGVector(
                dx: CGFloat.random(in: -20...20),
                dy: CGFloat.random(in: -20...20)
            )
            addChild(dot)
            dots.append(dot)
        }
    }

    func updateAttractionPoints(_ points: [CGPoint]) {
        // Remove old fields
        gravityFields.forEach { $0.removeFromParent() }
        gravityFields.removeAll()

        // Create new gravity fields at detected object positions
        for point in points {
            let field = SKFieldNode.radialGravityField()
            // Convert from UIKit coordinates (top-left origin) to SpriteKit (bottom-left)
            field.position = CGPoint(x: point.x, y: size.height - point.y)
            field.strength = 3.0
            field.falloff = 1.0
            field.region = SKRegion(radius: Float(min(size.width, size.height) * 0.4))
            field.categoryBitMask = 0x1
            addChild(field)
            gravityFields.append(field)
        }
    }

    override func update(_ currentTime: TimeInterval) {
        // Add random perturbation to keep dots alive
        for dot in dots {
            dot.physicsBody?.applyForce(CGVector(
                dx: CGFloat.random(in: -0.3...0.3),
                dy: CGFloat.random(in: -0.3...0.3)
            ))
            // Wrap around screen edges
            if dot.position.x < -20 { dot.position.x = size.width + 20 }
            if dot.position.x > size.width + 20 { dot.position.x = -20 }
            if dot.position.y < -20 { dot.position.y = size.height + 20 }
            if dot.position.y > size.height + 20 { dot.position.y = -20 }
        }
    }
}

struct SpriteKitOverlay: UIViewRepresentable {
    let scene: ParticleScene

    func makeUIView(context: Context) -> SKView {
        let skView = SKView()
        skView.backgroundColor = .clear
        skView.allowsTransparency = true
        scene.scaleMode = .resizeFill
        scene.backgroundColor = .clear
        skView.presentScene(scene)
        return skView
    }

    func updateUIView(_ uiView: SKView, context: Context) {}
}
```

---

## 4. Wiring It All Together

```swift
import SwiftUI

struct SmartCameraView: View {
    @State private var cameraManager = CameraManager()
    @State private var particleSystem = ParticleSystem()
    @State private var detectedFood = ""
    @State private var confidence: Float = 0
    @State private var viewSize: CGSize = .zero

    @State private var saliencyDetector = SaliencyDetector()

    var body: some View {
        ZStack {
            // Layer 1: Camera feed
            CameraPreview(session: cameraManager.captureSession)
                .edgesIgnoringSafeArea(.all)

            // Layer 2: Particle overlay
            ParticleOverlay(system: particleSystem)
                .edgesIgnoringSafeArea(.all)

            // Layer 3: UI overlay
            VStack {
                Spacer()
                if !detectedFood.isEmpty {
                    Text(detectedFood)
                        .font(.title2.bold())
                        .foregroundStyle(.white)
                        .padding(.horizontal, 20)
                        .padding(.vertical, 10)
                        .background(.ultraThinMaterial, in: .capsule)
                }

                Button("Capture") {
                    // Freeze frame, classify, log calories
                }
                .buttonStyle(.borderedProminent)
                .controlSize(.large)
                .padding(.bottom, 40)
            }
        }
        .onGeometryChange(for: CGSize.self) { proxy in
            proxy.size
        } action: { viewSize = $0 }
        .onAppear {
            cameraManager.configure()
            cameraManager.frameHandler = { sampleBuffer in
                // Throttle: process every 5th frame
                saliencyDetector.detectSaliency(sampleBuffer: sampleBuffer)
            }
        }
        .onDisappear {
            cameraManager.stop()
        }
        .onChange(of: saliencyDetector.salientRegions) { _, regions in
            // Convert Vision normalized rects to screen center points
            particleSystem.attractionPoints = regions.map { rect in
                CGPoint(
                    x: (rect.origin.x + rect.width / 2) * viewSize.width,
                    y: (1 - rect.origin.y - rect.height / 2) * viewSize.height
                )
            }
        }
    }
}
```

---

## 5. Frame Throttling

Processing every camera frame is expensive. Throttle Vision requests:

```swift
private var frameCount = 0

func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer,
                   from connection: AVCaptureConnection) {
    frameCount += 1
    guard frameCount % 5 == 0 else { return }  // Process every 5th frame
    frameHandler?(sampleBuffer)
}
```

---

## 6. Food Recognition Strategy

### Option 1: On-Device CoreML (No Network)

Bundle a `.mlmodel` file (Food101, MobileNetV2 fine-tuned on food). Classifies food type but doesn't estimate calories directly. Map classification labels to a local nutrition database.

### Option 2: Saliency + Capture + API (Recommended for Rork)

1. Use saliency detection for the live particle effect (no model needed)
2. When user taps "Capture", take a still photo
3. Send to an API (OpenAI Vision, Google Gemini, etc.) for food identification + calorie estimation
4. Display results and let user confirm/edit before logging

This avoids bundling large ML models and gives better accuracy.

### Option 3: On-Device FoundationModels (iOS 26+)

```swift
import FoundationModels

@available(iOS 26.0, *)
func estimateCalories(from description: String) async throws -> MealEstimate {
    let session = LanguageModelSession()
    return try await session.respond(
        to: "Estimate calories and macros for: \(description)",
        generating: MealEstimate.self
    ).content
}
```

---

## 7. Calorie Tracking Data Model

```swift
import SwiftData

@Model
final class MealEntry {
    var foodName: String
    var calories: Int
    var protein: Double
    var carbs: Double
    var fat: Double
    var imageData: Data?
    var timestamp: Date
    var mealType: String  // breakfast, lunch, dinner, snack

    init(foodName: String, calories: Int, protein: Double = 0,
         carbs: Double = 0, fat: Double = 0, mealType: String = "snack") {
        self.foodName = foodName
        self.calories = calories
        self.protein = protein
        self.carbs = carbs
        self.fat = fat
        self.timestamp = .now
        self.mealType = mealType
    }
}
```

---

## 8. Camera on the Cloud Simulator

The cloud simulator injects a real camera device (it appears like an external
camera, e.g. "LimCam Back Camera"): when the app starts an `AVCaptureSession`,
the preview in the user's browser asks for their webcam and streams it into
the simulator. Do NOT hide the camera behind `#if targetEnvironment(simulator)`
— run the real `AVCaptureSession` flow everywhere.

Discover devices with a discovery session that includes external cameras, so
the injected device is found alongside built-in ones:

```swift
func bestCamera() -> AVCaptureDevice? {
    // Order is deliberate: DiscoverySession returns devices in deviceTypes
    // order, so real devices prefer their built-in camera; the simulator has
    // no built-in, so discovery falls through to the injected external one.
    var types: [AVCaptureDevice.DeviceType] = [.builtInWideAngleCamera]
    if #available(iOS 17.0, *) {
        types.append(.external)
    }
    return AVCaptureDevice.DiscoverySession(
        deviceTypes: types,
        mediaType: .video,
        position: .unspecified
    ).devices.first
}
```

- Request permission with `AVCaptureDevice.requestAccess(for: .video)` as on
  a real device. Show a distinct permission-denied state (offer a Settings
  link) separate from the no-device empty state.
- If the user denies the _browser_ webcam prompt, the injected device keeps
  delivering black frames — the app must keep working, not crash.
- Keep a runtime "camera unavailable" empty state for when discovery returns
  no device, but never a compile-time simulator branch.

### Migrating existing projects

Projects generated before camera injection contain the old guard: a
`CameraProxyView` with `#if targetEnvironment(simulator)` that renders a
"Camera unavailable / install on your device" placeholder. When working on
camera-related code in such a project, remove the compile-time branch and the
placeholder view, and wire the real `AVCaptureSession` flow with the discovery
pattern above so the camera also works in the simulator preview.

---

## Required Permissions

Add to `project.pbxproj`:

```
INFOPLIST_KEY_NSCameraUsageDescription = "Camera access for food scanning";
```

## Key Imports

```swift
import AVFoundation  // Camera capture
import Vision        // Object detection, saliency
import CoreML        // ML model inference (if using on-device model)
import SpriteKit     // Particle physics (if using SpriteKit approach)
import SwiftData     // Meal logging persistence
```
