---
index: true
description: "@Model, @Query, @Relationship, ModelContainer, predicates, batch operations"
---

# SwiftData Reference

> Apple's native persistence framework using @Model classes and declarative @Query in SwiftUI. Built on Core Data, designed for SwiftUI.

## @Model Definition

`@Model` classes do not need `final`. On iOS 26+, `@Model` supports class inheritance. On iOS 18, subclassing `@Model` classes is not supported — keep them standalone.

```swift
import SwiftData

@Model
class Task {
    var title: String
    var isCompleted: Bool
    var createdAt: Date
    var notes: String?

    init(title: String, isCompleted: Bool = false, notes: String? = nil) {
        self.title = title
        self.isCompleted = isCompleted
        self.createdAt = Date()
        self.notes = notes
    }
}
```

### @Attribute Options

```swift
@Model
class User {
    @Attribute(.unique) var email: String
    @Attribute(.externalStorage) var profileImage: Data?
    @Attribute(.transformable(by: "ColorTransformer")) var favoriteColor: UIColor?
    @Attribute(.spotlight) var name: String
    @Attribute(.preserveValueOnDeletion) var deletedAt: Date?

    init(email: String, name: String) {
        self.email = email
        self.name = name
    }
}
```

| Attribute                  | Effect                                           |
| -------------------------- | ------------------------------------------------ |
| `.unique`                  | Upsert on conflict (NOT supported with CloudKit) |
| `.externalStorage`         | Store large data (images) as separate file       |
| `.spotlight`               | Index for Spotlight search                       |
| `.preserveValueOnDeletion` | Keep value in history after delete (iOS 18+)     |
| `.originalName("oldName")` | Rename property without migration                |

### @Transient — Excluded from Persistence

```swift
@Model
class Item {
    var name: String
    @Transient var isSelected: Bool = false    // Not saved to disk

    init(name: String) { self.name = name }
}
```

## Model Inheritance (iOS 26+)

Subclass `@Model` classes for shared properties:

```swift
@Model
class MediaItem {
    var title: String
    var dateAdded: Date

    init(title: String) {
        self.title = title
        self.dateAdded = Date()
    }
}

@Model
class Song: MediaItem {
    var artist: String
    var duration: TimeInterval

    init(title: String, artist: String, duration: TimeInterval) {
        self.artist = artist
        self.duration = duration
        super.init(title: title)
    }
}

@Model
class Podcast: MediaItem {
    var host: String
    var episodeNumber: Int

    init(title: String, host: String, episodeNumber: Int) {
        self.host = host
        self.episodeNumber = episodeNumber
        super.init(title: title)
    }
}
```

Register all model types explicitly — subclasses are NOT included automatically:

```swift
.modelContainer(for: [MediaItem.self, Song.self, Podcast.self])
```

Query by base class returns all subclasses. Query by subclass returns only that type.

## Relationships

### One-to-Many

```swift
@Model
class Folder {
    var name: String
    @Relationship(deleteRule: .cascade) var notes: [Note] = []

    init(name: String) {
        self.name = name
    }
}

@Model
class Note {
    var title: String
    var content: String
    var folder: Folder?    // Inverse is automatic

    init(title: String, content: String, folder: Folder? = nil) {
        self.title = title
        self.content = content
        self.folder = folder
    }
}
```

### Delete Rules

| Rule        | Behavior                                                  |
| ----------- | --------------------------------------------------------- |
| `.cascade`  | Delete parent → delete all children                       |
| `.nullify`  | Delete parent → set children's reference to nil (default) |
| `.deny`     | Prevent deletion if children exist                        |
| `.noAction` | Delete parent, leave orphaned children                    |

### Many-to-Many

```swift
@Model
class Tag {
    var name: String
    var items: [Item] = []

    init(name: String) { self.name = name }
}

@Model
class Item {
    var title: String
    var tags: [Tag] = []

    init(title: String) { self.title = title }
}
```

## #Unique — Compound Unique Constraints (iOS 18+)

```swift
@Model
class Flight {
    #Unique<Flight>([\.airline, \.flightNumber, \.date])

    var airline: String
    var flightNumber: Int
    var date: Date
    var gate: String?
}
```

On conflict, SwiftData upserts (updates existing record instead of inserting a duplicate).

## ModelContainer Setup

### In SwiftUI App

```swift
@main
struct MyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
        .modelContainer(for: [Task.self, Folder.self, Note.self])
    }
}
```

### Custom Configuration

```swift
let config = ModelConfiguration(
    "MyStore",
    schema: Schema([Task.self]),
    isStoredInMemoryOnly: false,
    allowsSave: true,
    groupContainer: .identifier("group.com.myapp.shared")
)
let container = try ModelContainer(for: Task.self, configurations: config)
```

### In-Memory for Previews

```swift
#Preview {
    ContentView()
        .modelContainer(for: Task.self, inMemory: true)
}
```

## @Query in SwiftUI

### Basic Query

```swift
struct TaskListView: View {
    @Query var tasks: [Task]

    var body: some View {
        List(tasks) { task in
            TaskRow(task: task)
        }
    }
}
```

### Sorted Query

```swift
@Query(sort: \Task.createdAt, order: .reverse) var tasks: [Task]

// Multiple sort descriptors
@Query(sort: [
    SortDescriptor(\Task.isCompleted),
    SortDescriptor(\Task.createdAt, order: .reverse)
]) var tasks: [Task]
```

### Filtered Query with #Predicate

```swift
@Query(filter: #Predicate<Task> { !$0.isCompleted })
var activeTasks: [Task]

// With parameter — use init
struct FolderNotesView: View {
    @Query var notes: [Note]

    init(folder: Folder) {
        let folderName = folder.name
        _notes = Query(
            filter: #Predicate<Note> { $0.folder?.name == folderName },
            sort: \Note.title
        )
    }
}
```

### #Expression — Reusable Predicate Components (iOS 18+)

```swift
let isActive = #Expression<Task, Bool> { task in
    !task.isCompleted
}

let activeTasks = #Predicate<Task> { task in
    isActive.evaluate(task)
}
```

### Animation

```swift
@Query(sort: \Task.createdAt, animation: .default) var tasks: [Task]
```

## ModelContext Operations

### Insert

```swift
@Environment(\.modelContext) private var modelContext

func addTask(title: String) {
    let task = Task(title: title)
    modelContext.insert(task)
}
```

### Delete

```swift
func deleteTask(_ task: Task) {
    modelContext.delete(task)
}
```

### Fetch with Descriptor

```swift
func fetchActiveTasks() throws -> [Task] {
    let descriptor = FetchDescriptor<Task>(
        predicate: #Predicate { !$0.isCompleted },
        sortBy: [SortDescriptor(\.createdAt, order: .reverse)]
    )
    return try modelContext.fetch(descriptor)
}

// With limit
var descriptor = FetchDescriptor<Task>()
descriptor.fetchLimit = 10
descriptor.fetchOffset = 20
```

### Batch Delete

```swift
func deleteCompleted() throws {
    try modelContext.delete(model: Task.self, where: #Predicate { $0.isCompleted })
    try modelContext.save()    // Batch delete requires explicit save
}
```

**Note:** Unlike single-object `delete()`, batch deletion only applies to the database after `save()` is called. Only batch delete is supported natively — no batch insert or update.

### Count Without Fetching

```swift
let count = try modelContext.fetchCount(FetchDescriptor<Task>(
    predicate: #Predicate { !$0.isCompleted }
))
```

### Enumerate for Large Datasets

Use `enumerate()` to process large result sets in batches without loading all objects at once:

```swift
let descriptor = FetchDescriptor<Task>()
try modelContext.enumerate(descriptor, batchSize: 500) { task in
    if task.isCompleted { totalCompleted += 1 }
}
```

Parameters: `batchSize` (default 5000), `allowEscapingMutations: true` to permit changes during enumeration.

## #Index — Faster Queries (iOS 18+)

```swift
@Model
class Note {
    #Index<Note>([\.createdAt], [\.folder, \.createdAt])

    var title: String
    var createdAt: Date
    var folder: Folder?
}
```

Add `#Index` on properties used frequently in `#Predicate` or `SortDescriptor`.

## History Tracking (iOS 18+)

Track inserts, updates, and deletions across transactions:

```swift
var historyDescriptor = HistoryDescriptor<DefaultHistoryTransaction>()
if let lastToken {
    historyDescriptor.predicate = #Predicate { transaction in
        transaction.token > lastToken
    }
}
let transactions = try modelContext.fetchHistory(historyDescriptor)

for transaction in transactions {
    for change in transaction.changes {
        let modelID = change.changedPersistentIdentifier

        switch change {
        case .insert(_ as DefaultHistoryInsert<Task>):
            print("Inserted: \(modelID)")
        case .update(_ as DefaultHistoryUpdate<Task>):
            print("Updated: \(modelID)")
        case .delete(_ as DefaultHistoryDelete<Task>):
            print("Deleted: \(modelID)")
        default: break
        }
    }
}

// Save token for next fetch
if let newToken = transactions.last?.token {
    // persist newToken for incremental history fetching
}
```

Use with `.preserveValueOnDeletion` to access property values after deletion.

## Preventing N+1 Queries

```swift
// ❌ SLOW: 1 query + N queries for each relationship access
let notes = try modelContext.fetch(FetchDescriptor<Note>())
for note in notes {
    print(note.folder?.name)    // Separate query each time
}

// ✅ FAST: Prefetch relationships
var descriptor = FetchDescriptor<Note>()
descriptor.relationshipKeyPathsForPrefetching = [\.folder]
let notes = try modelContext.fetch(descriptor)
```

## CloudKit Integration

### Enable Sync

```swift
let config = ModelConfiguration(
    cloudKitDatabase: .automatic
)
let container = try ModelContainer(for: Task.self, configurations: config)
```

### CloudKit Constraints

All properties MUST have a default value or be optional:

```swift
// ❌ Won't sync — non-optional without default
@Model class Item {
    var name: String
}

// ✅ Works with CloudKit
@Model class Item {
    var name: String = ""
    var count: Int = 0
    var details: String?
}
```

### Unique constraints (`@Attribute(.unique)`) are NOT supported with CloudKit sync.

## Common Patterns

### ViewModel with SwiftData

```swift
@MainActor
@Observable
final class TaskViewModel {
    private let modelContext: ModelContext

    var searchText = ""

    init(modelContext: ModelContext) {
        self.modelContext = modelContext
    }

    func addTask(title: String) {
        let task = Task(title: title)
        modelContext.insert(task)
    }

    func deleteTask(_ task: Task) {
        modelContext.delete(task)
    }
}
```

### Passing ModelContext to ViewModel

```swift
struct ContentView: View {
    @Environment(\.modelContext) private var modelContext
    @State private var viewModel: TaskViewModel?

    var body: some View {
        Group {
            if let viewModel {
                TaskListView(viewModel: viewModel)
            }
        }
        .onAppear {
            viewModel = TaskViewModel(modelContext: modelContext)
        }
    }
}
```

## Anti-Patterns

| Anti-Pattern                              | Fix                                                                                         |
| ----------------------------------------- | ------------------------------------------------------------------------------------------- |
| Creating ModelContainer in every view     | Create once at app root with `.modelContainer(for:)`                                        |
| Using `@Query` in ViewModel               | `@Query` is SwiftUI-only. Use `modelContext.fetch()` in ViewModels                          |
| Forgetting default values for CloudKit    | All properties need defaults or optionals                                                   |
| Explicit `modelContext.save()` everywhere | SwiftData auto-saves. Only call save() for batch ops or when you need immediate persistence |
| `@Attribute(.unique)` with CloudKit       | Not supported. Use manual deduplication                                                     |
| Heavy computation in `#Predicate`         | Keep predicates simple. Filter complex logic in Swift after fetch                           |
| Always marking @Model as `final`          | Not required. Omit `final` if you need inheritance (iOS 26+)                                |
