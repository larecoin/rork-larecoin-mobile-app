---
index: true
description: Crash prevention, GameManager, entity protocols, save/load, audio, game polish (hitstop, squash-stretch, coyote time, trails, combos, juice), physics tuning, accessibility
---

# Game Core — Architecture, Crash Prevention, Save/Load, Audio, Scenes

Foundation for all game types. Related files: `game-2d.md` (SpriteKit), `game-3d.md` (RealityKit), `game-world-layout.md` (world scale, ground, cameras, level layouts), `game-ui-patterns.md` (menus/HUD), `game-audio-advanced.md` (AVAudioEngine), `realitykit-materials.md` and `realitykit-environment.md` (3D worlds), `game-asset-integration.md` (bundled assets).

## Routing a Game Request

Decide the stack FIRST, then read the matching docs — do not mix the pipelines:

- **2D (SpriteKit)**: platformers, match-3/puzzle, top-down shooters/RPGs, vertical runners, card/board, one-tap hypercasual. Read game-2d.md + this doc. Assets: `generateImageAsset` only — never 3D tools.
- **3D (RealityKit)**: racing, FPS/TPS, open-world/adventure, 3D endless runners, arena combat, flight. Read game-3d.md + game-world-layout.md + this doc. Assets: `generate3DAsset` / `generate3DHumanoid` (orientation metadata arrives in the tool output); sounds via `generateAudio` either way.
- Ambiguous request ("make a fun game")? Default 2D for casual/puzzle phrasing, 3D when the prompt names vehicles, weapons, worlds, or camera perspective. Do not stop to ask.
- Genre extras: procedural levels → game-procedural-generation.md; gamepad → game-controller-reference.md; leaderboards → game-center-reference.md; multiplayer → game-multiplayer-patterns.md.

---

## Critical Crash Prevention

| Crash                                  | Fix                                                   |
| -------------------------------------- | ----------------------------------------------------- |
| `Entity(contentsOf: https://...)`      | Use `Entity(named:)` for bundled, download for remote |
| `Bundle.main.url(...)!`                | Use `guard let` with fallback                         |
| `removeFromParent()` in `didBegin`     | Queue in `nodesToRemove`, process in `update()`       |
| `node.physicsBody!`                    | Use optional chaining `?.`                            |
| `Codable` struct without `nonisolated` | Add `nonisolated` keyword                             |
| `removeAllChildren()` restart          | Use `view.presentScene(newScene)`                     |
| Large `deltaTime` after stall          | Clamp to `1/30`                                       |
| `AVAudioPlayer` not retained           | Store in array property                               |
| System stops ticking                   | Use `updatingSystemWhen: .rendering`                  |

### #1 Entity(contentsOf:) with Remote URL

`Entity(contentsOf:)` only accepts local `file://` URLs — passing `https://` crashes immediately.

```swift
// ❌ CRASH
let entity = try await Entity(contentsOf: URL(string: "https://example.com/model.usdz")!)

// ✅ Use bundled asset (auto-saved by the 3D generation tools)
let entity = try await Entity(named: "player_character")

// ✅ Download to local cache first
func loadRemoteModel(from url: URL) async throws -> Entity {
    let cache = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0]
    let local = cache.appendingPathComponent(url.lastPathComponent)
    if !FileManager.default.fileExists(atPath: local.path) {
        let (temp, _) = try await URLSession.shared.download(from: url)
        try FileManager.default.moveItem(at: temp, to: local)
    }
    return try await Entity(contentsOf: local)
}
```

### #4 Removing Nodes Inside Physics Contact Callback

`didBegin(_:)` runs during the physics step. Removing nodes here causes undefined behavior.

```swift
// ❌ CRASH
func didBegin(_ contact: SKPhysicsContact) { contact.bodyA.node?.removeFromParent() }

// ✅ Queue for removal in update()
var nodesToRemove: Set<SKNode> = []

nonisolated func didBegin(_ contact: SKPhysicsContact) {
    Task { @MainActor in
        if let node = contact.bodyB.node { nodesToRemove.insert(node) }
    }
}

override func update(_ currentTime: TimeInterval) {
    for node in nodesToRemove { node.removeFromParent() }
    nodesToRemove.removeAll()
}
```

### #6 MainActor Isolation (Swift 6)

With `SWIFT_DEFAULT_ACTOR_ISOLATION = MainActor`, data models and delegate methods need `nonisolated`.

```swift
// ❌ Codable synthesis requires nonisolated
struct GameSave: Codable { var level: Int; var score: Int }
// ✅
nonisolated struct GameSave: Codable { var level: Int; var score: Int }

// ❌ Delegate called from physics thread
extension GameScene: SKPhysicsContactDelegate {
    func didBegin(_ contact: SKPhysicsContact) { }
}
// ✅
extension GameScene: SKPhysicsContactDelegate {
    nonisolated func didBegin(_ contact: SKPhysicsContact) {
        Task { @MainActor in handleContact(contact) }
    }
}
```

### #8 DeltaTime Spikes

When the app returns from background, `deltaTime` can spike to 0.5s+. Objects teleport through walls.

```swift
// ❌ object moves 500 units in one frame during stall
entity.position.y -= speed * Float(context.deltaTime)
// ✅ clamp deltaTime
let dt = min(Float(context.deltaTime), 1.0 / 30.0)
entity.position.y -= speed * dt
```

### #9 Scene Restart via removeAllChildren()

`removeAllChildren()` + `didMove(to:)` leaks memory and corrupts state.

```swift
// ❌ MEMORY LEAK
func restart() { removeAllChildren(); removeAllActions(); didMove(to: view!) }

// ✅ Create a fresh scene
func restart() {
    guard let view else { return }
    let newScene = GameScene(size: size)
    newScene.scaleMode = scaleMode
    view.presentScene(newScene, transition: .fade(withDuration: 0.3))
}
```

### Remaining Crashes (one-liner fixes)

```swift
// #2 Force unwrap on Bundle resources
// ❌ let url = Bundle.main.url(forResource: "bgm", withExtension: "mp3")!
// ✅ guard let url = Bundle.main.url(forResource: "bgm", withExtension: "mp3") else { return }

// #3 Entity(named:) fails silently in RealityView
// ❌ let entity = try await Entity(named: "player")
// ✅ let entity = (try? await Entity(named: "player")) ?? ModelEntity(mesh: .generateBox(size: 0.3), materials: [SimpleMaterial(color: .blue, isMetallic: false)])

// #5 Force unwrap on physicsBody
// ❌ enemy.physicsBody!.velocity = .zero
// ✅ guard enemy.parent != nil else { return }; enemy.physicsBody?.velocity = .zero

// #7 Memory warning crashes — register for UIApplication.didReceiveMemoryWarningNotification and shed resources
// #10 AVAudioPlayer not retained — store in array property, don't create as local var
// #11 RealityKit System stops ticking — use updatingSystemWhen: .rendering in System.update()
// #12 Texture/asset not found — UIImage(named:) returns nil (safe), Entity(named:) throws (use try?)
```

---

## GameManager + GKStateMachine

A puzzle game needs different states than an action game.

### GKState Subclasses

```swift
import GameplayKit

class MenuState: GKState {
    unowned let gameManager: GameManager
    init(gameManager: GameManager) { self.gameManager = gameManager }

    override func isValidNextState(_ stateClass: AnyClass) -> Bool {
        stateClass == PlayingState.self
    }
    override func didEnter(from previousState: GKState?) {
        gameManager.scene?.isPaused = true
    }
}

class PlayingState: GKState {
    unowned let gameManager: GameManager
    init(gameManager: GameManager) { self.gameManager = gameManager }

    override func isValidNextState(_ stateClass: AnyClass) -> Bool {
        stateClass == PausedState.self || stateClass == GameOverState.self
    }
    override func didEnter(from previousState: GKState?) {
        gameManager.scene?.isPaused = false
    }
    override func update(deltaTime seconds: TimeInterval) {
        // Per-frame game logic: spawn enemies, check win conditions
    }
}

class PausedState: GKState {
    override func isValidNextState(_ stateClass: AnyClass) -> Bool {
        stateClass == PlayingState.self || stateClass == MenuState.self
    }
}

class GameOverState: GKState {
    unowned let gameManager: GameManager
    init(gameManager: GameManager) { self.gameManager = gameManager }

    override func isValidNextState(_ stateClass: AnyClass) -> Bool {
        stateClass == PlayingState.self || stateClass == MenuState.self
    }
    override func didEnter(from previousState: GKState?) {
        if gameManager.score > gameManager.highScore { gameManager.highScore = gameManager.score }
    }
}
```

### @Observable GameManager

```swift
import SpriteKit
import GameplayKit

@Observable
class GameManager {
    var score: Int = 0
    var lives: Int = 3
    var level: Int = 1
    var isPaused: Bool = false
    weak var scene: SKScene?
    var isGameOver: Bool { lives <= 0 }

    var highScore: Int {
        didSet { UserDefaults.standard.set(highScore, forKey: "highScore") }
    }

    private(set) var stateMachine: GKStateMachine?

    init() {
        highScore = UserDefaults.standard.integer(forKey: "highScore")
        let menu = MenuState(gameManager: self)
        let playing = PlayingState(gameManager: self)
        let paused = PausedState()
        let gameOver = GameOverState(gameManager: self)
        stateMachine = GKStateMachine(states: [menu, playing, paused, gameOver])
        stateMachine?.enter(MenuState.self)
    }

    func startGame() {
        score = 0; lives = 3; level = 1; isPaused = false
        stateMachine?.enter(PlayingState.self)
    }

    func pause() { isPaused = true; stateMachine?.enter(PausedState.self) }
    func resume() { isPaused = false; stateMachine?.enter(PlayingState.self) }

    func loseLife() {
        lives -= 1
        if isGameOver { stateMachine?.enter(GameOverState.self) }
    }

    func addScore(_ points: Int) { score += points }
}
```

```swift
// ❌ WRONG — game logic scattered across views
struct GameView: View {
    @State var score = 0
    @State var isGameOver = false
    @State var isPaused = false
}

// ✅ CORRECT — centralized GameManager with state machine
@Observable class GameManager {
    let stateMachine: GKStateMachine
    var score = 0
}
```

---

## SwiftUI + Scene Bridge

The scene's size can change live (Split View, Stage Manager, iPad windowing): recompute layout in `didChangeSize(_:)` from the current size instead of caching launch-time bounds. Don't rely on `UIRequiresFullScreen` — it is deprecated and ignored in iPad windowing.

```swift
struct GameContainerView: View {
    @State private var gameManager = GameManager()
    @State private var scene: GameScene?

    var body: some View {
        ZStack {
            if let scene {
                SpriteView(scene: scene).ignoresSafeArea()
            }
            GameHUDView(gameManager: gameManager)
        }
        .onAppear {
            if scene == nil {
                let s = GameScene(size: CGSize(width: 390, height: 844))
                s.scaleMode = .aspectFill
                s.gameManager = gameManager
                scene = s
            }
        }
    }
}

class GameScene: SKScene {
    var gameManager: GameManager?
    private var lastUpdateTime: TimeInterval = 0

    override func update(_ currentTime: TimeInterval) {
        let dt = lastUpdateTime == 0 ? 0 : currentTime - lastUpdateTime
        lastUpdateTime = currentTime
        gameManager?.stateMachine.update(deltaTime: dt)
    }
}
```

Store the scene in `@State` and create it once. Never create a scene inside the View body.

```swift
// ❌ WRONG — new scene every re-render
var body: some View { SpriteView(scene: GameScene(size: CGSize(width: 390, height: 844))) }

// ✅ CORRECT — scene stored in @State, created once
@State private var scene: GameScene?
```

---

## Entity Protocols

Inline protocol patterns for game entities. Define these in your project — not imported from a framework.

### Movable

```swift
protocol Movable: AnyObject {
    var moveSpeed: CGFloat { get set }
    var velocity: CGVector { get set }
    var maxSpeed: CGFloat { get }
}

extension Movable where Self: SKNode {
    func move(direction: CGVector, deltaTime: TimeInterval) {
        let dt = CGFloat(deltaTime)
        let clamp = { (v: CGFloat) in Swift.min(Swift.max(v, -self.maxSpeed), self.maxSpeed) }
        velocity = CGVector(dx: clamp(direction.dx * moveSpeed), dy: clamp(direction.dy * moveSpeed))
        position.x += velocity.dx * dt; position.y += velocity.dy * dt
    }

    func moveToward(_ target: CGPoint, speed: CGFloat, deltaTime: TimeInterval) {
        let dx = target.x - position.x, dy = target.y - position.y
        let dist = sqrt(dx * dx + dy * dy)
        guard dist > 1 else { return }
        let dt = CGFloat(deltaTime)
        position.x += (dx / dist) * speed * dt; position.y += (dy / dist) * speed * dt
    }
}
```

### Collidable

```swift
protocol Collidable {
    var categoryMask: UInt32 { get }
    var contactMask: UInt32 { get }
    var collisionMask: UInt32 { get }
    func onContactBegan(with other: SKNode, contact: SKPhysicsContact)
}

extension Collidable where Self: SKNode {
    func configurePhysicsBody(_ body: SKPhysicsBody) {
        body.categoryBitMask = categoryMask
        body.contactTestBitMask = contactMask
        body.collisionBitMask = collisionMask
        physicsBody = body
    }
}
```

### Damageable

```swift
protocol Damageable: AnyObject {
    var health: Int { get set }
    var maxHealth: Int { get }
    var isDead: Bool { get }
    var isInvincible: Bool { get set }
    func takeDamage(_ amount: Int)
    func heal(_ amount: Int)
    func onDeath()
}

extension Damageable {
    var isDead: Bool { health <= 0 }
    func takeDamage(_ amount: Int) {
        guard !isInvincible else { return }
        health = Swift.max(0, health - amount)
        if isDead { onDeath() }
    }
    func heal(_ amount: Int) { health = Swift.min(maxHealth, health + amount) }
}
```

### Collectible + Spawnable

```swift
protocol Collectible {
    var value: Int { get }
    var collectSound: String? { get }
    func onCollect(by collector: SKNode, manager: GameManager)
}

protocol Spawnable: AnyObject {
    func onSpawn(at position: CGPoint)
    func onDespawn()
    var shouldDespawn: Bool { get }
}
```

### Concrete Example: PlayerEntity

```swift
class PlayerEntity: SKSpriteNode, Movable, Collidable, Damageable {
    // Movable
    var moveSpeed: CGFloat = 200; var velocity: CGVector = .zero; var maxSpeed: CGFloat { 400 }
    // Collidable
    var categoryMask: UInt32 { PhysicsCategory.player }
    var contactMask: UInt32 { PhysicsCategory.enemy | PhysicsCategory.collectible }
    var collisionMask: UInt32 { PhysicsCategory.ground | PhysicsCategory.wall }
    func onContactBegan(with other: SKNode, contact: SKPhysicsContact) {
        if other is EnemyNode { takeDamage(1) }
    }
    // Damageable
    var health: Int = 3; var maxHealth: Int { 3 }; var isInvincible: Bool = false
    func onDeath() {
        removeAllActions()
        run(.sequence([.fadeOut(withDuration: 0.3), .run { [weak self] in self?.removeFromParent() }]))
    }

    init() {
        let tex = SKTexture(imageNamed: "player")
        super.init(texture: tex, color: .clear, size: tex.size())
        let body = SKPhysicsBody(rectangleOf: tex.size()); body.allowsRotation = false
        configurePhysicsBody(body)
    }
    required init?(coder: NSCoder) { fatalError() }
}
```

Conform game entities to these protocols as needed. For example, a player might adopt `Collidable` + `Damageable`, while a coin adopts `Collectible` + `Spawnable`.

---

## Entity-Component + Pooling

### Lightweight GameComponent

For SpriteKit games that don't need GameplayKit's full ECS.

```swift
protocol GameComponent: AnyObject { func update(deltaTime: TimeInterval) }

class HealthComponent: GameComponent {
    var current: Int
    let max: Int
    var isDead: Bool { current <= 0 }
    init(health: Int) { self.current = health; self.max = health }
    func update(deltaTime: TimeInterval) {}
    func takeDamage(_ amount: Int) { current = Swift.max(0, current - amount) }
}

class MovementComponent: GameComponent {
    var velocity: CGVector = .zero
    var speed: CGFloat = 200
    weak var node: SKNode?
    init(node: SKNode) { self.node = node }
    func update(deltaTime: TimeInterval) {
        guard let node else { return }
        node.position.x += velocity.dx * speed * CGFloat(deltaTime)
        node.position.y += velocity.dy * speed * CGFloat(deltaTime)
    }
}

class GameObject: SKSpriteNode {
    private var components: [String: GameComponent] = [:]
    func add<T: GameComponent>(_ component: T) { components[String(describing: type(of: component))] = component }
    func get<T: GameComponent>(_ type: T.Type) -> T? { components[String(describing: type)] as? T }
    func updateComponents(deltaTime: TimeInterval) {
        for c in components.values { c.update(deltaTime: deltaTime) }
    }
}
```

### NodePool (Generic Pooling)

Pre-create nodes and reuse them instead of creating/destroying.

```swift
class NodePool<T: SKNode> {
    private var available: [T] = []
    private let factory: () -> T

    init(size: Int, factory: @escaping () -> T) {
        self.factory = factory
        available = (0..<size).map { _ in let n = factory(); n.isHidden = true; return n }
    }

    func spawn() -> T {
        if let node = available.popLast() { node.isHidden = false; return node }
        return factory()
    }

    func despawn(_ node: T) {
        node.removeAllActions(); node.isHidden = true
        node.position = .zero; node.physicsBody?.velocity = .zero
        available.append(node)
    }
}

let bulletPool = NodePool(size: 50) {
    let b = SKSpriteNode(color: .yellow, size: CGSize(width: 6, height: 6))
    b.physicsBody = SKPhysicsBody(circleOfRadius: 3)
    b.physicsBody?.categoryBitMask = PhysicsCategory.projectile
    b.physicsBody?.contactTestBitMask = PhysicsCategory.enemy
    return b
}

func fire() {
    let bullet = bulletPool.spawn()
    bullet.position = player.position
    addChild(bullet)
    bullet.physicsBody?.velocity = CGVector(dx: 0, dy: 600)
    bullet.run(.sequence([.wait(forDuration: 2), .run { [weak self] in
        self?.bulletPool.despawn(bullet); bullet.removeFromParent()
    }]))
}
```

---

## Fixed Timestep + DeltaTime

```swift
class GameScene: SKScene {
    private let fixedDt: TimeInterval = 1.0 / 60.0
    private var accumulator: TimeInterval = 0
    private var previousTime: TimeInterval = 0

    override func update(_ currentTime: TimeInterval) {
        let rawDt = previousTime == 0 ? 0 : currentTime - previousTime
        previousTime = currentTime
        accumulator += min(rawDt, 0.1)  // clamp to avoid spiral of death
        while accumulator >= fixedDt {
            fixedUpdate(fixedDt)
            accumulator -= fixedDt
        }
    }

    func fixedUpdate(_ dt: TimeInterval) {
        movePlayer(dt: dt); updateEnemies(dt: dt); checkCollisions()
    }
}
```

When you don't need a full fixed timestep, clamp deltaTime directly: `let dt = min(rawDt, 1.0 / 30.0)`

---

## Adaptive Difficulty

```swift
@Observable
class DifficultyManager {
    var level: Float = 1.0  // 0.5 = easy, 1.0 = normal, 2.0 = hard
    private var recentDeaths = 0
    private var recentScoreRate: Float = 0

    func playerDied() {
        recentDeaths += 1
        if recentDeaths >= 3 { level = max(0.5, level - 0.2); recentDeaths = 0 }
    }

    func playerScoredWell() {
        recentScoreRate += 1
        if recentScoreRate >= 5 { level = min(2.0, level + 0.1); recentScoreRate = 0 }
    }

    var enemySpeedMultiplier: Float { level }
    var enemySpawnRate: TimeInterval { max(0.5, 2.0 / Double(level)) }
    var enemyHealthMultiplier: Float { level }
}
```

---

## Pause/Resume — App Lifecycle

Auto-pause when app backgrounds. Auto-resume on foreground can surprise players — a pause menu overlay is a common pattern.

```swift
class GameScene: SKScene {
    var gameManager: GameManager?

    override func didMove(to view: SKView) {
        NotificationCenter.default.addObserver(
            self, selector: #selector(appWillResignActive),
            name: UIApplication.willResignActiveNotification, object: nil
        )
    }

    @objc private func appWillResignActive() {
        gameManager?.stateMachine?.enter(PausedState.self)
        isPaused = true
    }

    deinit { NotificationCenter.default.removeObserver(self) }
}
```

---

## Save/Load

### GameSettings with UserDefaults

Use stored properties with `didSet` — NOT computed properties (computed won't trigger `@Observable`).

```swift
// ❌ WRONG — computed won't trigger observation
@Observable class Settings {
    var sound: Bool {
        get { UserDefaults.standard.bool(forKey: "sound") }
        set { UserDefaults.standard.set(newValue, forKey: "sound") }
    }
}

// ✅ CORRECT — stored property with didSet
@Observable
class GameSettings {
    var soundEnabled: Bool { didSet { UserDefaults.standard.set(soundEnabled, forKey: "soundEnabled") } }
    var musicVolume: Float { didSet { UserDefaults.standard.set(musicVolume, forKey: "musicVolume") } }
    var sfxVolume: Float { didSet { UserDefaults.standard.set(sfxVolume, forKey: "sfxVolume") } }
    var highScore: Int { didSet { UserDefaults.standard.set(highScore, forKey: "highScore") } }

    init() {
        soundEnabled = UserDefaults.standard.object(forKey: "soundEnabled") as? Bool ?? true
        musicVolume = UserDefaults.standard.object(forKey: "musicVolume") as? Float ?? 0.7
        sfxVolume = UserDefaults.standard.object(forKey: "sfxVolume") as? Float ?? 1.0
        highScore = UserDefaults.standard.integer(forKey: "highScore")
    }
}
```

### GameSaveData + SaveManager

```swift
nonisolated struct GameSaveData: Codable {
    var playerName: String
    var level: Int
    var score: Int
    var lives: Int
    var inventory: [InventoryItem]
    var unlockedLevels: Set<Int>
    var playTime: TimeInterval
    var savedAt: Date
}

nonisolated struct InventoryItem: Codable, Hashable { var id: String; var name: String; var quantity: Int }

@Observable
class SaveManager {
    private let savesDirectory: URL

    init() {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        savesDirectory = docs.appendingPathComponent("saves")
        try? FileManager.default.createDirectory(at: savesDirectory, withIntermediateDirectories: true)
    }

    func save(_ data: GameSaveData, slot: Int = 0) throws {
        try JSONEncoder().encode(data).write(
            to: savesDirectory.appendingPathComponent("save_\(slot).json"), options: .atomic)
    }

    func load(slot: Int = 0) -> GameSaveData? {
        guard let data = try? Data(contentsOf: savesDirectory.appendingPathComponent("save_\(slot).json")) else { return nil }
        return try? JSONDecoder().decode(GameSaveData.self, from: data)
    }

    func delete(slot: Int = 0) {
        try? FileManager.default.removeItem(at: savesDirectory.appendingPathComponent("save_\(slot).json"))
    }
}
```

### Auto-Save Pattern

```swift
extension GameManager {
    func startAutoSave(interval: TimeInterval = 30) {
        autoSaveTask = Task { @MainActor [weak self] in
            while !Task.isCancelled {
                try? await Task.sleep(for: .seconds(interval))
                guard let self else { return }
                saveData.savedAt = Date()
                try? saveManager.save(saveData)
            }
        }
    }
    func stopAutoSave() { autoSaveTask?.cancel() }
}
```

---

## Audio

### AVAudioSession Setup

```swift
import AVFoundation

func configureGameAudioSession() {
    let session = AVAudioSession.sharedInstance()
    try? session.setCategory(.ambient, options: [.mixWithOthers])
    // .ambient — respects silent switch, mixes with other apps
    // .soloAmbient — default, ducks other audio
    // .playback — ignores silent switch (music-focused games)
    try? session.setActive(true)
}
```

### SFXManager with Pooling

3 pre-created `AVAudioPlayer` instances per sound. When all 3 are playing, additional requests are dropped.

```swift
@Observable
class SFXManager {
    private var players: [String: [AVAudioPlayer]] = [:]

    func preload(_ names: [String]) {
        for name in names {
            guard let url = Bundle.main.url(forResource: name, withExtension: "mp3") else { continue }
            players[name] = (0..<3).compactMap { _ in
                let p = try? AVAudioPlayer(contentsOf: url); p?.prepareToPlay(); return p
            }
        }
    }

    func play(_ name: String, volume: Float = 1.0) {
        guard let available = players[name]?.first(where: { !$0.isPlaying }) else { return }
        available.volume = volume; available.currentTime = 0; available.play()
    }

    func stopAll() { for pool in players.values { pool.forEach { $0.stop() } } }
}
```

### MusicManager + GameAudio Wrapper

```swift
@Observable
class MusicManager {
    private var currentPlayer: AVAudioPlayer?
    var volume: Float = 0.5

    func play(_ name: String, loop: Bool = true) {
        guard let url = Bundle.main.url(forResource: name, withExtension: "mp3"),
              let player = try? AVAudioPlayer(contentsOf: url) else { return }
        player.numberOfLoops = loop ? -1 : 0; player.volume = volume
        currentPlayer?.stop(); player.play(); currentPlayer = player
    }

    func stop() { currentPlayer?.stop(); currentPlayer = nil }
    func pause() { currentPlayer?.pause() }
    func resume() { currentPlayer?.play() }
    func setVolume(_ vol: Float) { volume = vol; currentPlayer?.volume = vol }
}

@Observable
class GameAudio {
    let sfx = SFXManager()
    let music = MusicManager()

    func setup() {
        configureGameAudioSession()
        sfx.preload(["sfx_jump", "sfx_coin", "sfx_hit", "sfx_explosion", "sfx_shoot"])
    }

    func startLevel(_ level: Int) {
        let tracks = ["bgm_level1", "bgm_level2", "bgm_boss"]
        let index = max(0, min(level - 1, tracks.count - 1))
        music.play(tracks[index])
    }

    func pauseAll() { music.pause(); sfx.stopAll() }
    func resumeAll() { music.resume() }
}
```

---

## Scene Transitions + Memory

### Basic SpriteKit Transition

```swift
func goToLevel(_ level: Int) {
    guard let view else { return }
    let nextScene = GameScene(size: size)
    nextScene.scaleMode = scaleMode
    nextScene.currentLevel = level
    view.presentScene(nextScene, transition: .fade(withDuration: 0.5))
}
```

### Available Transitions

- **Fade:** `.fade(withDuration:)`, `.fade(with: .black, duration:)`, `.crossFade(withDuration:)`
- **Directional:** `.push(with: .left, duration:)`, `.moveIn(with: .right, duration:)`, `.reveal(with: .down, duration:)`
- **Effects:** `.flipHorizontal(withDuration:)`, `.flipVertical(withDuration:)`, `.doorway(withDuration:)`
- Set `transition.pausesIncomingScene = false` to start the new scene during transition.

### Scene Lifecycle

```swift
class GameScene: SKScene {
    override func didMove(to view: SKView) {
        // Scene presented — set up content
    }
    override func willMove(from view: SKView) {
        // Scene about to be removed — clean up
        removeAllActions()
    }
}
```

### Memory Cleanup

```swift
class GameScene: SKScene {
    var audioPlayers: [AVAudioPlayer] = []
    var activeEmitters: [SKEmitterNode] = []

    override func willMove(from view: SKView) {
        audioPlayers.forEach { $0.stop() }; audioPlayers.removeAll()
        activeEmitters.forEach { $0.removeFromParent() }; activeEmitters.removeAll()
        removeAllActions()
        enumerateChildNodes(withName: "//*") { node, _ in node.removeAllActions() }
    }
}
```

### Memory Pressure Handling

```swift
@Observable
class GameManager {
    var qualityLevel: QualityLevel = .high

    init() {
        NotificationCenter.default.addObserver(
            forName: UIApplication.didReceiveMemoryWarningNotification,
            object: nil, queue: .main
        ) { [weak self] _ in self?.reduceMemoryUsage() }
    }

    func reduceMemoryUsage() {
        qualityLevel = .low
        // Reduce particle birth rates by 50%, disable shadows,
        // use lower-resolution textures, unload distant level chunks
    }
}

nonisolated enum QualityLevel { case low, medium, high }
```

---

## Game Polish (Juice)

These patterns add satisfying feel to hits, jumps, pickups, and deaths. A common pattern in polished games: visual + audio + haptic fire together within 1 frame.

### Hitstop (Freeze Frames)

Pause the game for a few frames on impact. Creates a sense of weight and power.

```swift
// SpriteKit — pause specific nodes, not the whole scene
// Add this as a method on your GameScene class
func hitstop(nodes: [SKNode], duration: TimeInterval = 0.067) { // ~4 frames at 60fps
    nodes.forEach { $0.isPaused = true }
    Task { @MainActor in
        try? await Task.sleep(for: .milliseconds(Int(duration * 1000)))
        nodes.forEach { $0.isPaused = false }
    }
}
// Usage: hitstop(nodes: [playerNode, enemyNode])
```

```swift
// RealityKit — set System time scale or skip updates
nonisolated struct HitstopComponent: Component {
    var remaining: Float = 0
}

nonisolated struct HitstopSystem: System {
    static let query = EntityQuery(where: .has(HitstopComponent.self))
    init(scene: Scene) {}

    func update(context: SceneUpdateContext) {
        for entity in context.entities(matching: Self.query, updatingSystemWhen: .rendering) {
            guard var hs = entity.components[HitstopComponent.self] else { continue }
            if hs.remaining > 0 {
                hs.remaining -= Float(context.deltaTime)
                entity.components[HitstopComponent.self] = hs
                return // skip remaining entities in this system
            } else {
                entity.components.remove(HitstopComponent.self)
            }
        }
    }
}

// Trigger: entity.components.set(HitstopComponent(remaining: 0.067))
```

| Impact                  | Duration  | Frames (60fps) |
| ----------------------- | --------- | -------------- |
| Light (coin pickup)     | 0         | 0              |
| Medium (hit enemy)      | 33-67ms   | 2-4            |
| Heavy (kill, explosion) | 67-133ms  | 4-8            |
| Boss defeat             | 167-250ms | 10-15          |

### Squash & Stretch

Deform sprites on impact for cartoon-like weight. Spring back to normal.

```swift
// SpriteKit
extension SKSpriteNode {
    func squash(compressY: CGFloat = 0.7, stretchX: CGFloat = 1.3, duration: TimeInterval = 0.15) {
        let squash = SKAction.scaleX(to: stretchX, y: compressY, duration: duration * 0.3)
        squash.timingMode = .easeOut
        let restore = SKAction.scaleX(to: 1.0, y: 1.0, duration: duration * 0.7)
        restore.timingMode = .easeIn
        run(.sequence([squash, restore]))
    }

    func stretch(stretchY: CGFloat = 1.3, compressX: CGFloat = 0.8, duration: TimeInterval = 0.1) {
        let stretch = SKAction.scaleX(to: compressX, y: stretchY, duration: duration * 0.4)
        stretch.timingMode = .easeOut
        let restore = SKAction.scaleX(to: 1.0, y: 1.0, duration: duration * 0.6)
        restore.timingMode = .easeIn
        run(.sequence([stretch, restore]))
    }
}

// On landing:
player.squash()
// On jump launch:
player.stretch()
```

### Coyote Time (Platformer Forgiveness)

Allow jumping for a few frames after walking off a ledge. Without this, platformers feel unfair.

```swift
struct PlatformerComponent {
    var isOnGround = false
    var wasOnGround = false
    var coyoteTimer: Float = 0
    var jumpBufferTimer: Float = 0
    var wantsJump = false
    var verticalVelocity: Float = 0
    var speed: Float = 5.0
    var jumpForce: Float = 8.0

    static let coyoteTime: Float = 0.083      // ~5 frames at 60fps
    static let jumpBufferTime: Float = 0.1     // ~6 frames at 60fps
}
```

```swift
// SpriteKit update()
func updatePlatformer(_ player: inout PlatformerComponent, dt: Float) {
    // Track ground state transitions
    if player.isOnGround {
        player.coyoteTimer = PlatformerComponent.coyoteTime
    } else {
        player.coyoteTimer -= dt
    }

    // Jump buffer — remember jump press for a short window
    if player.wantsJump {
        player.jumpBufferTimer = PlatformerComponent.jumpBufferTime
    }
    player.jumpBufferTimer -= dt

    // Can jump if: on ground OR within coyote time
    let canJump = player.isOnGround || player.coyoteTimer > 0
    if canJump && player.jumpBufferTimer > 0 {
        player.verticalVelocity = player.jumpForce
        player.coyoteTimer = 0         // consume coyote time
        player.jumpBufferTimer = 0     // consume buffer
    }

    player.wantsJump = false
    player.wasOnGround = player.isOnGround
}
```

### Variable-Height Jump

Release button early = shorter jump. Gives the player fine control.

```swift
// On jump button RELEASE:
func onJumpRelease(_ player: inout PlatformerComponent) {
    if player.verticalVelocity > 0 {
        player.verticalVelocity *= 0.4 // cut upward velocity
    }
}
```

### Coordinated Juice (Visual + Audio + Haptic)

Fire all feedback channels together. Haptics must be prepared in advance.

```swift
class JuiceManager {
    private let impactLight = UIImpactFeedbackGenerator(style: .light)
    private let impactHeavy = UIImpactFeedbackGenerator(style: .heavy)
    private let audio = GameAudio() // from Audio section above

    init() {
        impactLight.prepare()
        impactHeavy.prepare()
    }

    func onCoinPickup(node: SKSpriteNode) {
        // Visual
        node.run(.sequence([.scale(to: 1.3, duration: 0.05), .scale(to: 0, duration: 0.15)]))
        // Audio
        audio.sfx.play("coin_pickup")
        // Haptic
        impactLight.impactOccurred()
        impactLight.prepare() // prep for next
    }

    func onEnemyHit(player: SKSpriteNode, enemy: SKSpriteNode, scene: GameScene) {
        // Hitstop
        scene.hitstop(nodes: [player, enemy], duration: 0.067)
        // Visual — screen shake + enemy flash
        scene.shakeCamera(duration: 0.2, intensity: 8)
        enemy.run(.sequence([
            .colorize(with: .white, colorBlendFactor: 1.0, duration: 0.05),
            .colorize(withColorBlendFactor: 0.0, duration: 0.1)
        ]))
        // Audio
        audio.sfx.play("hit_impact")
        // Haptic
        impactHeavy.impactOccurred(intensity: 0.8)
        impactHeavy.prepare()
    }

    func onPlayerDeath(player: SKSpriteNode, scene: GameScene) {
        // Long hitstop
        scene.hitstop(nodes: [player], duration: 0.15)
        // Screen shake
        scene.shakeCamera(duration: 0.4, intensity: 15)
        // Slow motion
        scene.speed = 0.3
        Task { @MainActor in
            try? await Task.sleep(for: .milliseconds(600))
            scene.speed = 1.0
        }
        // Haptic
        impactHeavy.impactOccurred(intensity: 1.0)
        // Audio
        audio.sfx.play("death")
    }
}
```

---

## Physics Tuning Reference

Recommended starting values by game type. Tune from here — don't start from scratch.

### SpriteKit Physics Presets

| Parameter            | Platformer (Snappy) | Platformer (Floaty) | Top-Down | Space Shooter | Ball Physics |
| -------------------- | ------------------- | ------------------- | -------- | ------------- | ------------ |
| `gravity` (dy)       | -20 to -25          | -9.8 to -12         | 0        | 0             | -9.8         |
| Jump impulse (dy)    | 60-80               | 40-55               | N/A      | N/A           | N/A          |
| Max H-speed          | 300                 | 250                 | 200      | 400           | varies       |
| H-force (per frame)  | 500-800             | 300-500             | 400      | 600           | N/A          |
| Player friction      | 0                   | 0                   | 0.3      | 0             | 0.2-0.5      |
| Player restitution   | 0                   | 0                   | 0        | 0             | 0.5-0.9      |
| Player linearDamping | 0                   | 0.1                 | 3.0      | 0.5           | 0.5          |
| allowsRotation       | false               | false               | false    | false         | true         |

```swift
// Snappy platformer preset
func applyPlatformerPreset(_ body: SKPhysicsBody) {
    body.friction = 0
    body.restitution = 0
    body.linearDamping = 0
    body.angularDamping = 0
    body.allowsRotation = false
    body.mass = 1.0
}

// Top-down movement preset (RPG, twin-stick)
func applyTopDownPreset(_ body: SKPhysicsBody) {
    body.friction = 0.3
    body.restitution = 0
    body.linearDamping = 3.0    // stops quickly when force removed
    body.allowsRotation = false
    body.affectedByGravity = false
}
```

### RealityKit Physics Presets

See `game-3d.md` for PhysicsMaterialResource presets (ice, rubber, metal, wood) and damping values (space, air, water, mud).

| Parameter       | 3D Platformer | Racing | Space | Ball Physics |
| --------------- | ------------- | ------ | ----- | ------------ |
| Gravity Y       | -15 to -20    | -9.81  | 0     | -9.81        |
| Jump force      | 8-12          | N/A    | N/A   | N/A          |
| Move speed      | 3-5           | 10-20  | 5-8   | N/A          |
| Linear damping  | 0.1           | 0.5    | 0     | 0.5          |
| Angular damping | 0.8           | 2.0    | 0.1   | 0.5          |
| Restitution     | 0             | 0.2    | 0.3   | 0.7-0.9      |

### Forgiveness Timing

| Mechanic     | Duration   | Frames (60fps) | Notes                                   |
| ------------ | ---------- | -------------- | --------------------------------------- |
| Coyote time  | 83ms       | 5              | After leaving ledge, still can jump     |
| Jump buffer  | 100ms      | 6              | Press jump before landing, it registers |
| Input buffer | 67-133ms   | 4-8            | Buffer attack/dash during animation     |
| Hitstop      | 33-133ms   | 2-8            | Freeze on impact (see Game Polish)      |
| I-frames     | 500-1000ms | 30-60          | Invincibility after taking damage       |

### More Juice Building Blocks

Use these individually or in combination. Each is independent — mix and match per game. SpriteKit cores shown; translate to your engine as needed.

**White Flash on Hit** — sprite turns white for 1-2 frames on damage:
`sprite.run(.sequence([.colorize(with: .white, colorBlendFactor: 1, duration: 0), .colorize(withColorBlendFactor: 0, duration: 0.08)]))`

**Trail / Afterimage** — while dashing, each `update()` spawn a ghost `SKSpriteNode(texture: sprite.texture)` at the sprite's position (`alpha 0.4`, `zPosition - 1`, same scale) and run
`.sequence([.fadeOut(withDuration: 0.2), .removeFromParent()])`. Tune alpha/fade for trail density.

**Camera Zoom on Impact** — brief zoom-in on big hits, ease back:
`camera.run(.sequence([.scale(to: 0.95, duration: 0.05), .scale(to: 1.0, duration: 0.1)]))` (easeOut in, easeIn out). Combine with shakeCamera + hitstop for maximum impact feel.

**Speed Lines** — `SKEmitterNode` on the player with elongated particles (`particleSize: CGSize(width: 2, height: 20)`), `emissionAngle = .pi` (opposite to velocity), `particleLifetime 0.3`, `particleAlphaSpeed -2`. Toggle manually: `particleBirthRate = 80` when fast, `0` when slowing.

**Screen Flash** — full-screen `SKSpriteNode(color:, size: scene.size)` centered at `zPosition 9999`, `alpha 0.6`, then `.sequence([.fadeOut(withDuration: 0.1), .removeFromParent()])`. White for explosions, red for damage taken, gold for level up.

**Combo Counter** — tracks successive hits with escalating juice:

```swift
struct ComboTracker {
    var count = 0
    var lastHitTime: TimeInterval = 0
    let window: TimeInterval = 1.5 // seconds to keep combo alive

    mutating func registerHit(at time: TimeInterval) -> Int {
        if time - lastHitTime < window {
            count += 1
        } else {
            count = 1
        }
        lastHitTime = time
        return count
    }

    mutating func checkExpiry(at time: TimeInterval) {
        if time - lastHitTime >= window { count = 0 }
    }
}

// In update(): combo.checkExpiry(at: currentTime)
// On hit: let comboLevel = combo.registerHit(at: currentTime)
// Scale juice by comboLevel:
//   shakeIntensity = CGFloat(min(comboLevel, 10)) * 2
//   particleBirthRate = Float(comboLevel) * 50
//   pitch shift SFX by comboLevel * 20 cents
```

---

## What Makes Games Memorable

Observations from successful indie games about what sets them apart.

**Visual consistency** — Games that feel polished tend to use a small, deliberate set of colors derived from the game's world rather than arbitrary defaults. Centralizing colors (e.g., a `GamePalette` enum) helps maintain consistency across UI, particles, and game objects.

**Difficulty that breathes** — The most engaging games alternate between challenge and relief. A hard section followed by a calm moment, then a harder section. Flat difficulty is forgettable. A `DifficultyManager` that ties spawn rates, enemy speed, and health to progression can help:

```swift
struct DifficultyManager {
    var level: Int = 1

    var enemySpeed: Float { 1.0 + Float(level) * 0.15 }
    var spawnInterval: TimeInterval { max(0.5, 2.0 - Double(level) * 0.1) }
    var enemyHealth: Int { 1 + level / 3 }

    mutating func advance() { level += 1 }
}
```

**Emotional pacing** — Memorable levels mix tension (narrow platforms, ticking timer), relief (open space, ambient music), surprise (hidden area, mechanic twist), and reward (particles + sound + haptic). The rhythm between these creates engagement.

**Layered feedback** — The best game moments fire multiple feedback channels together: a hit that triggers visual effect + screen shake + sound + haptic simultaneously feels 10x more satisfying than any one of those alone. See Game Polish above for building blocks.

---

## Accessibility

Game menus use SwiftUI overlays — they get VoiceOver, Dynamic Type, and Switch Control support automatically. Add these patterns for the gameplay itself.

### Reduced Motion

Check `UIAccessibility.isReduceMotionEnabled` and swap intense effects for subtle alternatives: screen shake → brief screen flash, parallax scrolling → static background (`backgroundSpeed = 0`), particle trails → reduced birth rate (`emitter.particleBirthRate *= 0.3`).

```swift
if UIAccessibility.isReduceMotionEnabled {
    screenFlash(color: .white, duration: 0.1, scene: scene)
} else {
    scene.shakeCamera(duration: 0.3, intensity: 10)
}
```

### Touch Targets

Target at least 44×44 points for interactive elements (Apple HIG minimum). For small SpriteKit sprites, expand the hit area instead of the visual:

```swift
class GameButton: SKSpriteNode {
    override func contains(_ p: CGPoint) -> Bool {
        let minSize: CGFloat = 44
        return frame.insetBy(
            dx: -max(0, (minSize - frame.width) / 2),
            dy: -max(0, (minSize - frame.height) / 2)
        ).contains(p)
    }
}
```

### VoiceOver for Game State

SwiftUI HUD overlays are automatically accessible. Label dynamic values — `.accessibilityLabel("Score")` plus `.accessibilityValue("\(score) points")` — and announce important events (level complete, game over) with `UIAccessibility.post(notification: .announcement, argument: message)`.
