---
index: true
description: SwiftUI Map, annotations, styles, camera, tile overlays, local search
---

# MapKit — Maps & Overlays

MapKit provides map views, annotations, overlays, search, and directions. Use it as a base map with custom weather/data overlays on top.

**Import:** `import MapKit`

---

## SwiftUI Map (iOS 17+)

```swift
import SwiftUI
import MapKit

struct MapView: View {
    @State private var position: MapCameraPosition = .automatic

    var body: some View {
        Map(position: $position) {
            // Annotations
            Marker("San Francisco", coordinate: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194))

            // Custom annotation
            Annotation("Home", coordinate: homeCoordinate) {
                Image(systemName: "house.fill")
                    .padding(6)
                    .background(.blue)
                    .foregroundStyle(.white)
                    .clipShape(Circle())
            }

            // Polyline
            MapPolyline(coordinates: routeCoordinates)
                .stroke(.blue, lineWidth: 3)

            // Polygon
            MapPolygon(coordinates: areaCoordinates)
                .foregroundStyle(.red.opacity(0.3))
                .stroke(.red, lineWidth: 2)

            // Circle
            MapCircle(center: epicenter, radius: 5000)
                .foregroundStyle(.orange.opacity(0.2))
                .stroke(.orange, lineWidth: 1)

            // User location
            UserAnnotation()
        }
        .mapStyle(.imagery) // satellite
    }
}
```

## Map Styles

```swift
.mapStyle(.standard)                    // default Apple Maps
.mapStyle(.imagery)                     // satellite
.mapStyle(.hybrid)                      // satellite + labels
.mapStyle(.standard(elevation: .realistic)) // 3D terrain
.mapStyle(.imagery(elevation: .realistic))  // 3D satellite
```

## Camera Control

```swift
// Center on location
position = .region(MKCoordinateRegion(
    center: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194),
    span: MKCoordinateSpan(latitudeDelta: 5, longitudeDelta: 5)
))

// Specific camera angle
position = .camera(MapCamera(
    centerCoordinate: coordinate,
    distance: 50000,  // meters from ground
    heading: 0,       // rotation in degrees
    pitch: 45         // tilt angle
))

// Follow user
position = .userLocation(fallback: .automatic)

// Show all annotations
position = .automatic
```

## MKMapView (UIViewRepresentable) — For Tile Overlays

The SwiftUI `Map` doesn't support tile overlays directly. Use `MKMapView` wrapped in `UIViewRepresentable`:

```swift
struct MapViewWithOverlays: UIViewRepresentable {
    let overlays: [MKOverlay]

    func makeUIView(context: Context) -> MKMapView {
        let mapView = MKMapView()
        mapView.delegate = context.coordinator
        mapView.showsUserLocation = true

        // Prefer satellite for weather apps
        mapView.preferredConfiguration = MKImageryMapConfiguration()

        for overlay in overlays {
            mapView.addOverlay(overlay, level: .aboveLabels)
        }
        return mapView
    }

    func updateUIView(_ uiView: MKMapView, context: Context) {
        // Update overlays when data changes
        uiView.removeOverlays(uiView.overlays)
        for overlay in overlays {
            uiView.addOverlay(overlay, level: .aboveLabels)
        }
    }

    func makeCoordinator() -> Coordinator { Coordinator() }

    class Coordinator: NSObject, MKMapViewDelegate {
        func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
            if let tileOverlay = overlay as? MKTileOverlay {
                return MKTileOverlayRenderer(overlay: tileOverlay)
            }
            if let polyline = overlay as? MKPolyline {
                let renderer = MKPolylineRenderer(overlay: polyline)
                renderer.strokeColor = .systemBlue
                renderer.lineWidth = 2
                return renderer
            }
            if let polygon = overlay as? MKPolygon {
                let renderer = MKPolygonRenderer(overlay: polygon)
                renderer.fillColor = .systemRed.withAlphaComponent(0.3)
                renderer.strokeColor = .systemRed
                renderer.lineWidth = 1
                return renderer
            }
            return MKOverlayRenderer(overlay: overlay)
        }
    }
}
```

## Tile Overlays (Radar/Weather Tiles)

### Standard Web Tile Overlay

```swift
// Standard tile URL template (z/x/y)
let tileOverlay = MKTileOverlay(urlTemplate: "https://tile.openstreetmap.org/{z}/{x}/{y}.png")
tileOverlay.canReplaceMapContent = false // overlay, don't replace base map
tileOverlay.minimumZ = 2
tileOverlay.maximumZ = 12
mapView.addOverlay(tileOverlay, level: .aboveLabels)
```

### Custom Tile Overlay (e.g., Radar)

```swift
class RadarTileOverlay: MKTileOverlay {
    let timestamp: Int

    init(timestamp: Int) {
        self.timestamp = timestamp
        super.init(urlTemplate: nil)
        self.canReplaceMapContent = false
        self.minimumZ = 2
        self.maximumZ = 12
    }

    override func url(forTilePath path: MKTileOverlayPath) -> URL {
        // RainViewer radar tiles
        URL(string: "https://tilecache.rainviewer.com/v2/radar/\(timestamp)/256/\(path.z)/\(path.x)/\(path.y)/2/1_1.png")!
    }
}
```

### Custom Tile Loading (non-URL sources)

```swift
class CustomTileOverlay: MKTileOverlay {
    override func loadTile(at path: MKTileOverlayPath,
                            result: @escaping (Data?, Error?) -> Void) {
        // Generate tile data programmatically or fetch from custom source
        Task {
            let tileData = try? await fetchTileData(z: path.z, x: path.x, y: path.y)
            result(tileData, nil)
        }
    }
}
```

## Overlay Levels

| Level          | Description                             |
| -------------- | --------------------------------------- |
| `.aboveLabels` | On top of everything (weather overlays) |
| `.aboveRoads`  | Above roads but below labels            |

## Search

### Location Search

```swift
let request = MKLocalSearch.Request()
request.naturalLanguageQuery = "coffee shops"
request.region = mapView.region

let search = MKLocalSearch(request: request)
let response = try await search.start()
for item in response.mapItems {
    let name = item.name
    let coordinate = item.placemark.coordinate
}
```

### Typeahead Search Completer

```swift
@MainActor
@Observable
class SearchCompleter: NSObject, MKLocalSearchCompleterDelegate {
    var results: [MKLocalSearchCompletion] = []

    private let completer = MKLocalSearchCompleter()

    override init() {
        super.init()
        completer.delegate = self
        completer.resultTypes = [.address, .pointOfInterest]
    }

    func search(_ query: String) {
        completer.queryFragment = query
    }

    nonisolated func completerDidUpdateResults(_ completer: MKLocalSearchCompleter) {
        Task { @MainActor in
            self.results = completer.results
        }
    }

    nonisolated func completer(_ completer: MKLocalSearchCompleter, didFailWithError error: Error) {}
}
```

## Useful Map Properties (MKMapView)

```swift
mapView.showsUserLocation = true
mapView.userTrackingMode = .follow       // .none, .follow, .followWithHeading
mapView.showsCompass = true
mapView.showsScale = true
mapView.isRotateEnabled = true
mapView.isPitchEnabled = true
mapView.pointOfInterestFilter = .excludingAll  // hide POIs for cleaner weather map
```

## Getting Visible Region

```swift
// From MKMapView
let region = mapView.region // MKCoordinateRegion with center + span
let visibleRect = mapView.visibleMapRect

// Convert screen point to coordinate
let coordinate = mapView.convert(tapPoint, toCoordinateFrom: mapView)
```
