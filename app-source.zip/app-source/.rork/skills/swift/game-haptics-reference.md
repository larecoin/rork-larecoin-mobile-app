---
index: true
description: CoreHaptics, UIFeedbackGenerator, game patterns
---

# Game Haptics — CoreHaptics & UIFeedbackGenerator

Tactile feedback for game events: collisions, pickups, explosions, UI interactions.

---

## UIFeedbackGenerator — Simple Haptics

No engine setup required. Use for discrete game events.

```swift
import UIKit

// Light tap — coin pickup, menu selection
UIImpactFeedbackGenerator(style: .light).impactOccurred()

// Medium — jump landing, hit
UIImpactFeedbackGenerator(style: .medium).impactOccurred()

// Heavy — explosion, crash
UIImpactFeedbackGenerator(style: .heavy).impactOccurred()

// Rigid — sharp metallic feel
UIImpactFeedbackGenerator(style: .rigid).impactOccurred()

// Soft — cushioned feel
UIImpactFeedbackGenerator(style: .soft).impactOccurred()

// Custom intensity (0.0–1.0)
let generator = UIImpactFeedbackGenerator(style: .rigid)
generator.impactOccurred(intensity: 0.7)

// Selection tick — scrolling through items, snapping
UISelectionFeedbackGenerator().selectionChanged()

// Notification types
let notification = UINotificationFeedbackGenerator()
notification.notificationOccurred(.success) // level complete, achievement
notification.notificationOccurred(.warning) // low health, timer running out
notification.notificationOccurred(.error)   // game over, invalid action
```

### Prepare for Low Latency

Call `prepare()` ahead of time to eliminate startup delay.

```swift
let impactGenerator = UIImpactFeedbackGenerator(style: .medium)

// Call when you know a haptic is coming soon (e.g., player starts jumping)
impactGenerator.prepare()

// Later, the haptic fires instantly
impactGenerator.impactOccurred()
```

---

## CHHapticEngine — Custom Patterns

For complex, game-specific haptic sequences.

```swift
import CoreHaptics

class HapticManager {
    private var engine: CHHapticEngine?

    init() {
        guard CHHapticEngine.capabilitiesForHardware().supportsHaptics else { return }
        do {
            engine = try CHHapticEngine()
            engine?.stoppedHandler = { _ in }
            engine?.resetHandler = { [weak self] in
                try? self?.engine?.start()
            }
            try engine?.start()
        } catch {
            print("Haptic engine failed: \(error.localizedDescription)")
        }
    }

    func stop() {
        engine?.stop(completionHandler: nil)
    }
}
```

### Transient Events (Single Tap)

Sharp, brief haptic. Two parameters: intensity (strength) and sharpness (crispness).

```swift
extension HapticManager {
    func playTransient(intensity: Float, sharpness: Float) {
        guard let engine else { return }
        do {
            let event = CHHapticEvent(
                eventType: .hapticTransient,
                parameters: [
                    CHHapticEventParameter(parameterID: .hapticIntensity, value: intensity),
                    CHHapticEventParameter(parameterID: .hapticSharpness, value: sharpness)
                ],
                relativeTime: 0
            )
            let pattern = try CHHapticPattern(events: [event], parameters: [])
            let player = try engine.makePlayer(with: pattern)
            try player.start(atTime: 0)
        } catch {
            print("Haptic playback failed: \(error.localizedDescription)")
        }
    }
}
```

### Continuous Events (Sustained Vibration)

```swift
extension HapticManager {
    func playEngineRumble(duration: TimeInterval) {
        guard let engine else { return }
        do {
            let event = CHHapticEvent(
                eventType: .hapticContinuous,
                parameters: [
                    CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.4),
                    CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.2)
                ],
                relativeTime: 0,
                duration: duration
            )
            let pattern = try CHHapticPattern(events: [event], parameters: [])
            let player = try engine.makePlayer(with: pattern)
            try player.start(atTime: 0)
        } catch {
            print("Haptic playback failed: \(error.localizedDescription)")
        }
    }
}
```

---

## Game-Specific Patterns

### Explosion — Escalating Burst

```swift
extension HapticManager {
    func playExplosion() {
        guard let engine else { return }
        do {
            var events: [CHHapticEvent] = []
            let count = 8
            for i in 0..<count {
                let time = TimeInterval(i) * 0.04
                let intensity = Float(count - i) / Float(count)
                events.append(CHHapticEvent(
                    eventType: .hapticTransient,
                    parameters: [
                        CHHapticEventParameter(parameterID: .hapticIntensity, value: intensity),
                        CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.8)
                    ],
                    relativeTime: time
                ))
            }
            let pattern = try CHHapticPattern(events: events, parameters: [])
            let player = try engine.makePlayer(with: pattern)
            try player.start(atTime: 0)
        } catch {
            print("Haptic playback failed: \(error.localizedDescription)")
        }
    }
}
```

### Heartbeat — Two Pulses

```swift
extension HapticManager {
    func playHeartbeat() {
        guard let engine else { return }
        do {
            let beat1 = CHHapticEvent(
                eventType: .hapticTransient,
                parameters: [
                    CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.8),
                    CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.4)
                ],
                relativeTime: 0
            )
            let beat2 = CHHapticEvent(
                eventType: .hapticTransient,
                parameters: [
                    CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.5),
                    CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.3)
                ],
                relativeTime: 0.15
            )
            let pattern = try CHHapticPattern(events: [beat1, beat2], parameters: [])
            let player = try engine.makePlayer(with: pattern)
            try player.start(atTime: 0)
        } catch {
            print("Haptic playback failed: \(error.localizedDescription)")
        }
    }
}
```

### Sword Slash — Sharp Transient with Decay

```swift
extension HapticManager {
    func playSwordSlash() {
        guard let engine else { return }
        do {
            let slash = CHHapticEvent(
                eventType: .hapticTransient,
                parameters: [
                    CHHapticEventParameter(parameterID: .hapticIntensity, value: 1.0),
                    CHHapticEventParameter(parameterID: .hapticSharpness, value: 1.0)
                ],
                relativeTime: 0
            )
            let trail = CHHapticEvent(
                eventType: .hapticContinuous,
                parameters: [
                    CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.3),
                    CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.6)
                ],
                relativeTime: 0.02,
                duration: 0.15
            )
            let pattern = try CHHapticPattern(events: [slash, trail], parameters: [])
            let player = try engine.makePlayer(with: pattern)
            try player.start(atTime: 0)
        } catch {
            print("Haptic playback failed: \(error.localizedDescription)")
        }
    }
}
```

### Coin Pickup — Light Tap

```swift
extension HapticManager {
    func playCoinPickup() {
        guard let engine else { return }
        do {
            let tap = CHHapticEvent(
                eventType: .hapticTransient,
                parameters: [
                    CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.4),
                    CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.9)
                ],
                relativeTime: 0
            )
            let pattern = try CHHapticPattern(events: [tap], parameters: [])
            let player = try engine.makePlayer(with: pattern)
            try player.start(atTime: 0)
        } catch {
            print("Haptic playback failed: \(error.localizedDescription)")
        }
    }
}
```

### Damage Taken — Quick Burst

```swift
extension HapticManager {
    func playDamageTaken() {
        guard let engine else { return }
        do {
            var events: [CHHapticEvent] = []
            for i in 0..<3 {
                events.append(CHHapticEvent(
                    eventType: .hapticTransient,
                    parameters: [
                        CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.9),
                        CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.5)
                    ],
                    relativeTime: TimeInterval(i) * 0.06
                ))
            }
            let pattern = try CHHapticPattern(events: events, parameters: [])
            let player = try engine.makePlayer(with: pattern)
            try player.start(atTime: 0)
        } catch {
            print("Haptic playback failed: \(error.localizedDescription)")
        }
    }
}
```

---

## Dynamic Haptic Parameters

Modify intensity/sharpness of a running continuous pattern in real-time.

```swift
extension HapticManager {
    func playDynamicEngine() throws -> CHHapticAdvancedPatternPlayer? {
        guard let engine else { return nil }
        let event = CHHapticEvent(
            eventType: .hapticContinuous,
            parameters: [
                CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.3),
                CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.2)
            ],
            relativeTime: 0,
            duration: 30.0
        )
        let pattern = try CHHapticPattern(events: [event], parameters: [])
        let player = try engine.makeAdvancedPlayer(with: pattern)
        try player.start(atTime: 0)
        return player
    }

    func updateEngineSpeed(_ player: CHHapticAdvancedPatternPlayer, speed: Float) throws {
        // speed 0.0–1.0 maps to intensity
        let intensityParam = CHHapticDynamicParameter(
            parameterID: .hapticIntensityControl,
            value: speed,
            relativeTime: 0
        )
        let sharpnessParam = CHHapticDynamicParameter(
            parameterID: .hapticSharpnessControl,
            value: speed * 0.5,
            relativeTime: 0
        )
        try player.sendParameters([intensityParam, sharpnessParam], atTime: 0)
    }
}
```

---

## Common Mistakes

```swift
// ❌ Not checking hardware support
let engine = try CHHapticEngine() // crashes on unsupported devices

// ✅ Always check first
guard CHHapticEngine.capabilitiesForHardware().supportsHaptics else { return }

// ❌ Creating a new generator every frame
func update() {
    UIImpactFeedbackGenerator(style: .light).impactOccurred() // allocates each call
}

// ✅ Reuse generators
let generator = UIImpactFeedbackGenerator(style: .light)
func update() {
    generator.impactOccurred()
}

// ❌ Playing haptics on every collision frame
// Rapid fire haptics feel like buzzing and drain battery

// ✅ Throttle haptic events
var lastHapticTime: TimeInterval = 0
func onCollision(time: TimeInterval) {
    guard time - lastHapticTime > 0.1 else { return }
    lastHapticTime = time
    hapticManager.playTransient(intensity: 0.6, sharpness: 0.5)
}

// ❌ Not handling engine reset
// Engine can stop due to audio session interruptions, app backgrounding

// ✅ Set resetHandler to restart
engine?.resetHandler = { [weak self] in
    try? self?.engine?.start()
}
```

---

## Related Skills

- **game-2d.md** — Physics contact events that trigger haptics
- **game-core.md** — GameManager that coordinates haptic feedback
