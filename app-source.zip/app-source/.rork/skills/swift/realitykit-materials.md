---
index: true
description: PBR channels, TextureResource loading/tiling, CustomMaterial Metal shaders (dissolve, shield, toon, scrolling)
---

# RealityKit Materials & Textures

Complete reference for materials, textures, and custom Metal shaders in RealityKit games. For environment setup (terrain, skybox, lighting, fog, water): `realitykit-environment.md`. For ECS and game logic: `game-3d.md`. For performance: `game-performance-reference.md`.

---

## PhysicallyBasedMaterial — Full Channel Reference

PBR material with realistic lighting response. Every channel accepts a scalar value, a texture, or both (scalar tints the texture).

```swift
var material = PhysicallyBasedMaterial()
```

### Base Color (Diffuse)

```swift
// Solid color
material.baseColor = .init(tint: .white, texture: nil)

// Texture from bundle
let tex = try await TextureResource(named: "wood_diffuse")
material.baseColor = .init(tint: .white, texture: .init(tex))

// Tinted texture — tint multiplies texture color
material.baseColor = .init(tint: .init(red: 0.8, green: 0.6, blue: 0.4, alpha: 1), texture: .init(tex))
```

### Normal Map

Adds surface detail without extra geometry. Use tangent-space normal maps (blue-purple images).

```swift
let normalTex = try await TextureResource(named: "stone_normal", options: .init(semantic: .normal))
material.normal = .init(texture: .init(normalTex))

// Scale normal intensity (default 1.0, lower = flatter)
material.normal = .init(texture: .init(normalTex), scale: 0.5)
```

**IMPORTANT:** Load normal maps with `semantic: .normal` — this prevents RealityKit from applying sRGB gamma correction, which would distort the normals.

### Roughness

Controls surface smoothness. 0 = mirror, 1 = matte.

```swift
// Scalar
material.roughness = .init(floatLiteral: 0.3)

// Texture (grayscale — white = rough, black = smooth)
let roughTex = try await TextureResource(named: "metal_roughness", options: .init(semantic: .raw))
material.roughness = .init(texture: .init(roughTex))
```

### Metallic

0 = dielectric (plastic, wood, skin), 1 = metal (gold, chrome, steel). Usually binary — 0 or 1.

```swift
material.metallic = .init(floatLiteral: 1.0)

// Texture (grayscale — white = metal, black = non-metal)
let metalTex = try await TextureResource(named: "armor_metallic", options: .init(semantic: .raw))
material.metallic = .init(texture: .init(metalTex))
```

### Emissive (Glow)

Self-illuminated areas — does NOT cast light on other objects. Combine with bloom post-processing for glow effect.

```swift
material.emissiveColor = .init(color: .init(red: 0, green: 0.5, blue: 1, alpha: 1))
material.emissiveIntensity = 3.0

// Emissive texture (colored areas glow)
let emTex = try await TextureResource(named: "lava_emissive")
material.emissiveColor = .init(color: .white, texture: .init(emTex))
material.emissiveIntensity = 5.0
```

### Ambient Occlusion

Darkens crevices and corners for depth. Grayscale texture — white = fully lit, black = fully shadowed.

```swift
let aoTex = try await TextureResource(named: "character_ao", options: .init(semantic: .raw))
material.ambientOcclusion = .init(texture: .init(aoTex))
```

### Opacity (Transparency)

```swift
// Uniform transparency
material.opacity = .init(floatLiteral: 0.5)
material.blending = .transparent(opacity: 1.0)

// Opacity texture (grayscale — white = opaque, black = transparent)
let opacityTex = try await TextureResource(named: "leaves_alpha", options: .init(semantic: .raw))
material.opacity = .init(texture: .init(opacityTex))
material.blending = .transparent(opacity: 1.0)

// Cutout (binary — fully opaque or fully transparent, no blending)
material.opacityThreshold = 0.5
```

### Clearcoat

Second specular layer on top — like car paint, lacquered wood, wet surfaces.

```swift
material.clearcoat = .init(floatLiteral: 1.0)
material.clearcoatRoughness = .init(floatLiteral: 0.1)
```

### Sheen

Soft highlight at grazing angles — fabric, velvet, cloth.

```swift
material.sheen = .init(tint: .init(red: 0.3, green: 0.2, blue: 0.1, alpha: 1))
```

### Specular

Override Fresnel specular intensity for non-metallic surfaces. Default derived from metallic/roughness.

```swift
material.specular = .init(floatLiteral: 0.8)
```

### Anisotropy

Directional reflections — brushed metal, hair, carbon fiber.

```swift
material.anisotropyLevel = .init(floatLiteral: 0.7)
material.anisotropyAngle = .init(floatLiteral: 0.0) // radians, 0 = horizontal

// Anisotropy direction map
let anisoTex = try await TextureResource(named: "brushed_direction", options: .init(semantic: .raw))
material.anisotropyAngle = .init(texture: .init(anisoTex))
```

### Material Starting Points

Starting configurations — adjust tint, roughness, and intensity to match your game's art direction.

```swift
// Gold
var gold = PhysicallyBasedMaterial()
gold.baseColor = .init(tint: .init(red: 1.0, green: 0.84, blue: 0.0, alpha: 1))
gold.metallic = .init(floatLiteral: 1.0)
gold.roughness = .init(floatLiteral: 0.3)

// Glass
var glass = PhysicallyBasedMaterial()
glass.baseColor = .init(tint: .init(red: 0.9, green: 0.95, blue: 1.0, alpha: 1))
glass.metallic = .init(floatLiteral: 0.0)
glass.roughness = .init(floatLiteral: 0.05)
glass.blending = .transparent(opacity: 0.3)
glass.clearcoat = .init(floatLiteral: 1.0)
glass.clearcoatRoughness = .init(floatLiteral: 0.0)

// Lava
var lava = PhysicallyBasedMaterial()
lava.baseColor = .init(tint: .init(red: 0.15, green: 0.02, blue: 0.0, alpha: 1))
lava.roughness = .init(floatLiteral: 0.9)
lava.emissiveColor = .init(color: .init(red: 1.0, green: 0.3, blue: 0.0, alpha: 1))
lava.emissiveIntensity = 8.0

// Ice
var ice = PhysicallyBasedMaterial()
ice.baseColor = .init(tint: .init(red: 0.7, green: 0.85, blue: 0.95, alpha: 1))
ice.roughness = .init(floatLiteral: 0.1)
ice.clearcoat = .init(floatLiteral: 1.0)
ice.clearcoatRoughness = .init(floatLiteral: 0.05)
ice.blending = .transparent(opacity: 0.85)

// Fabric/Cloth
var cloth = PhysicallyBasedMaterial()
cloth.baseColor = .init(tint: .init(red: 0.6, green: 0.1, blue: 0.1, alpha: 1))
cloth.roughness = .init(floatLiteral: 0.9)
cloth.sheen = .init(tint: .init(red: 0.8, green: 0.3, blue: 0.3, alpha: 1))
```

---

## TextureResource — Loading & Creation

### From App Bundle (Xcode Asset Catalog or Loose Files)

```swift
// Async (preferred)
let texture = try await TextureResource(named: "grass_diffuse")

// Sync (blocks main thread — avoid in game loops)
let texture = try TextureResource.load(named: "grass_diffuse")
```

### From CGImage (Runtime-Generated)

```swift
let cgImage: CGImage = ... // from Core Graphics, UIKit, or Core Image

// semantic: .color for diffuse/emissive, .normal for normal maps, .raw for roughness/metallic/AO
let texture = try await TextureResource(image: cgImage, options: .init(semantic: .color))
```

### From File URL

```swift
guard let fileURL = Bundle.main.url(forResource: "terrain_texture", withExtension: "png") else { return }

let texture = try await TextureResource(contentsOf: fileURL)
```

### Semantic Options

Always set the correct semantic when loading non-color textures:

| Semantic    | Use For                          | Effect                       |
| ----------- | -------------------------------- | ---------------------------- |
| `.color`    | Base color, emissive             | sRGB gamma applied (default) |
| `.normal`   | Normal maps                      | Linear, no gamma correction  |
| `.raw`      | Roughness, metallic, AO, opacity | Linear, no gamma correction  |
| `.hdrColor` | HDR environment maps             | HDR color space              |

```swift
let normalTex = try await TextureResource(named: "stone_normal", options: .init(semantic: .normal))
let roughTex = try await TextureResource(named: "stone_rough", options: .init(semantic: .raw))
```

---

## Texture Tiling

RealityKit has no wrap mode API. Use `textureCoordinateTransform` to tile textures by scaling UVs.

```swift
var material = PhysicallyBasedMaterial()
let tex = try await TextureResource(named: "grass")
material.baseColor = .init(tint: .white, texture: .init(tex))

// Tile 4×4 across the surface
material.textureCoordinateTransform = .init(scale: SIMD2<Float>(4, 4), rotation: 0, offset: .zero)
```

This scales UV coordinates by 4, so the texture repeats 4 times in each direction.

To tile normal/roughness maps the same way, apply the same transform:

```swift
material.secondaryTextureCoordinateTransform = material.textureCoordinateTransform
```

For `CustomMaterial`, tile in the Metal shader:

```metal
float2 uv = params.geometry().uv0() * float2(4.0, 4.0); // tile 4×4
half4 color = tex.base_color().sample(textureSampler, uv);
```

---

## CustomMaterial — Metal Shaders for Games

`CustomMaterial` uses Metal shader functions for custom rendering. Two shader types:

- **SurfaceShader** — controls surface appearance (color, roughness, metallic, emissive, etc.)
- **GeometryModifier** — displaces vertices (waves, terrain, wind)

### Setup

```swift
let device = MTLCreateSystemDefaultDevice()!
let library = device.makeDefaultLibrary()!

let surfaceShader = CustomMaterial.SurfaceShader(named: "mySurface", in: library)
let geometryModifier = CustomMaterial.GeometryModifier(named: "myGeometry", in: library)

var material = try CustomMaterial(
    surfaceShader: surfaceShader,
    geometryModifier: geometryModifier,
    lightingModel: .lit
)
```

### Passing Data to Shaders

```swift
// custom.value — a float4 vector
material.custom.value = [time, waveHeight, tileScale, 0]

// custom.texture — a single texture
let tex = try await TextureResource(named: "noise")
material.custom.texture = .init(tex)
```

Access in Metal:

```metal
float4 params_value = params.uniforms().custom_parameter();
float time = params_value[0];

auto noise = params.textures().custom().sample(sampler, uv);
```

### Metal Shader Basics

Create a `.metal` file in your Xcode project:

```metal
#include <metal_stdlib>
#include <RealityKit/RealityKit.h>
using namespace metal;

constexpr sampler textureSampler(address::repeat, filter::linear);

[[visible]]
void mySurface(realitykit::surface_parameters params) {
    float2 uv = params.geometry().uv0();
    uv.y = 1.0 - uv.y; // flip for USDZ models

    // Set PBR properties
    params.surface().set_base_color(half3(0.5, 0.7, 0.3));
    params.surface().set_roughness(0.5);
    params.surface().set_metallic(0.0);
}

[[visible]]
void myGeometry(realitykit::geometry_parameters params) {
    float3 pos = params.geometry().model_position();
    float3 offset = float3(0, sin(pos.x * 3.0) * 0.1, 0);
    params.geometry().set_model_position_offset(offset);
}
```

### Surface Shader API

```metal
// Read
params.geometry().uv0()                    // UV coordinates
params.geometry().uv1()                    // secondary UVs
params.geometry().model_position()          // vertex position (model space)
params.geometry().world_position()          // vertex position (world space)
params.geometry().normal()                  // surface normal
params.uniforms().custom_parameter()        // custom.value float4
params.uniforms().time()                    // seconds since scene start
params.textures().custom()                  // custom.texture

// Write
params.surface().set_base_color(half3)
params.surface().set_roughness(half)
params.surface().set_metallic(half)
params.surface().set_emissive_color(half3)
params.surface().set_normal(half3)
params.surface().set_opacity(half)
params.surface().set_ambient_occlusion(half)
params.surface().set_specular(half)
params.surface().set_clearcoat(half)
params.surface().set_clearcoat_roughness(half)
```

### Geometry Modifier API

```metal
params.geometry().model_position()              // current vertex position
params.geometry().set_model_position_offset(float3) // displace vertex
params.geometry().normal()                       // vertex normal
params.geometry().set_normal(float3)             // override normal
params.uniforms().time()                         // animation time
params.uniforms().custom_parameter()             // custom.value
```

---

## Game Shader Recipes

### Dissolve Effect

Object dissolves into particles. Pass dissolve progress (0→1) via `custom.value[0]`, noise texture via `custom.texture`.

```metal
constexpr sampler textureSampler(address::repeat, filter::linear);

[[visible]]
void dissolveSurface(realitykit::surface_parameters params) {
    float progress = params.uniforms().custom_parameter()[0];
    float2 uv = params.geometry().uv0();

    half noise = params.textures().custom().sample(textureSampler, uv).r;

    if (float(noise) < progress) {
        discard_fragment();
    }

    // Glow at dissolve edge
    float edge = smoothstep(progress - 0.05, progress, float(noise));
    half3 baseColor = half3(0.5, 0.5, 0.5);
    half3 edgeGlow = half3(1.0, 0.3, 0.0);
    params.surface().set_base_color(mix(edgeGlow, baseColor, half(edge)));
    params.surface().set_emissive_color(edgeGlow * half(1.0 - edge) * 3.0);
}
```

### Shield / Force Field

Transparent sphere with Fresnel glow at edges.

```metal
[[visible]]
void shieldSurface(realitykit::surface_parameters params) {
    float time = params.uniforms().time();
    float3 normal = float3(params.geometry().normal());
    float3 viewDir = normalize(float3(params.geometry().world_position()));

    // Fresnel — stronger glow at edges
    float fresnel = pow(1.0 - abs(dot(normal, viewDir)), 3.0);

    half3 shieldColor = half3(0.2, 0.5, 1.0);
    float pulse = sin(time * 3.0) * 0.3 + 0.7;

    params.surface().set_base_color(shieldColor * half(fresnel));
    params.surface().set_emissive_color(shieldColor * half(fresnel * pulse) * 2.0);
    params.surface().set_opacity(half(fresnel * 0.6 + 0.1));
    params.surface().set_roughness(0.1);
    params.surface().set_metallic(0.0);
}
```

### Pulsing Emissive (Power-ups, Collectibles)

```metal
[[visible]]
void pulseSurface(realitykit::surface_parameters params) {
    float time = params.uniforms().time();
    half3 color = half3(params.uniforms().custom_parameter()[0],
                        params.uniforms().custom_parameter()[1],
                        params.uniforms().custom_parameter()[2]);

    float pulse = sin(time * 4.0) * 0.5 + 0.5;
    params.surface().set_base_color(color);
    params.surface().set_emissive_color(color * half(pulse) * 3.0);
    params.surface().set_roughness(0.4);
    params.surface().set_metallic(0.0);
}
```

### Scrolling Texture (Conveyor Belt, River)

```metal
constexpr sampler textureSampler(address::repeat, filter::linear);

[[visible]]
void scrollSurface(realitykit::surface_parameters params) {
    float time = params.uniforms().time();
    float speed = params.uniforms().custom_parameter()[0];

    float2 uv = params.geometry().uv0();
    uv.y += time * speed; // scroll along V

    half4 color = params.textures().custom().sample(textureSampler, uv);
    params.surface().set_base_color(half3(color.rgb));
    params.surface().set_roughness(0.5);
}
```

### Toon / Cel Shading

Flat lighting with hard steps instead of smooth gradients.

```metal
[[visible]]
void toonSurface(realitykit::surface_parameters params) {
    half3 color = half3(params.uniforms().custom_parameter()[0],
                        params.uniforms().custom_parameter()[1],
                        params.uniforms().custom_parameter()[2]);

    // Quantize color to create cel-shading bands
    // RealityKit handles lighting — we just set the material flat
    params.surface().set_base_color(color);
    params.surface().set_roughness(1.0);  // fully matte = flat shading
    params.surface().set_metallic(0.0);
    params.surface().set_specular(0.0);   // no specular highlight
}
```

For true cel shading with discrete light bands, use `lightingModel: .unlit` and compute lighting manually in the surface shader using `params.geometry().normal()` and a known light direction.

---

## Other Material Types (Quick Reference)

### SimpleMaterial

Fast prototyping. Subset of PBR — color, roughness, metallic only.

```swift
let material = SimpleMaterial(color: .blue, roughness: 0.3, isMetallic: true)
```

### UnlitMaterial

No lighting — flat color or texture. Use for UI elements, HUD markers, skybox planes.

```swift
var unlit = UnlitMaterial()
unlit.color = .init(tint: .white, texture: .init(try await TextureResource(named: "hud_icon")))
```

### VideoMaterial

Plays video on a surface. Use for in-game screens, cutscenes on 3D surfaces.

```swift
guard let url = Bundle.main.url(forResource: "intro", withExtension: "mp4") else { return }
let player = AVPlayer(url: url)
let videoMat = VideoMaterial(avPlayer: player)
let screen = ModelEntity(mesh: .generatePlane(width: 1.6, height: 0.9), materials: [videoMat])
player.play()
```

### OcclusionMaterial

Invisible but hides objects behind it. Use for invisible walls, masking geometry.

```swift
let occluder = ModelEntity(mesh: .generateBox(size: 1), materials: [OcclusionMaterial()])
```
