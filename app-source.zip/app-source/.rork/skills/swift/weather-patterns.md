---
index: true
description: Apple Weather-style layout, map + bottom sheet, radar tiles
---

# Weather & Maps Patterns, Recipes & Practical Guidance

---

## Apple Weather-Style Layout: Map + Bottom Sheet

The standard weather app pattern: full-screen map underneath, draggable bottom sheet with forecast content on top. Use `.sheet` with `.presentationBackgroundInteraction(.enabled)` so the user can interact with the map while the sheet is open.

### Recommended Approach: Sheet with Background Interaction

```swift
import SwiftUI
import MapKit
import WeatherKit
import CoreLocation

struct WeatherMapView: View {
    @State private var viewModel = WeatherMapViewModel()
    @State private var showSheet = true
    @State private var sheetDetent: PresentationDetent = .fraction(0.4)
    @State private var mapPosition: MapCameraPosition = .userLocation(fallback: .automatic)

    var body: some View {
        Map(position: $mapPosition) {
            if let location = viewModel.userLocation {
                Annotation("", coordinate: location) {
                    Image(systemName: viewModel.current?.symbolName ?? "cloud")
                        .symbolRenderingMode(.multicolor)
                        .font(.title)
                        .padding(8)
                        .background(.ultraThinMaterial, in: .circle)
                }
            }
        }
        .mapStyle(.standard(elevation: .realistic))
        .ignoresSafeArea()
        .sheet(isPresented: $showSheet) {
            WeatherSheetContent(viewModel: viewModel)
                .presentationDetents([.fraction(0.15), .fraction(0.4), .large], selection: $sheetDetent)
                .presentationDragIndicator(.visible)
                .presentationBackgroundInteraction(.enabled(upThrough: .fraction(0.4)))
                .presentationCornerRadius(20)
                .presentationBackground(.ultraThinMaterial)
                .interactiveDismissDisabled()
        }
        .task { await viewModel.load() }
    }
}
```

### Sheet Content

```swift
struct WeatherSheetContent: View {
    let viewModel: WeatherMapViewModel

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                if let weather = viewModel.current {
                    VStack(spacing: 4) {
                        Text(viewModel.locationName)
                            .font(.title2.bold())
                        Text(weather.temperature.formatted())
                            .font(.system(size: 52, weight: .thin))
                        Text(weather.condition.description)
                            .foregroundStyle(.secondary)
                    }
                    .frame(maxWidth: .infinity)

                    if let hourly = viewModel.hourly {
                        VStack(alignment: .leading, spacing: 8) {
                            Label("Hourly Forecast", systemImage: "clock")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                            ScrollView(.horizontal) {
                                HStack(spacing: 20) {
                                    ForEach(Array(hourly.prefix(24)), id: \.date) { hour in
                                        VStack(spacing: 6) {
                                            Text(hour.date.formatted(.dateTime.hour()))
                                                .font(.caption)
                                            Image(systemName: hour.symbolName)
                                                .symbolRenderingMode(.multicolor)
                                            Text(hour.temperature.formatted())
                                                .font(.subheadline.bold())
                                        }
                                    }
                                }
                            }
                            .scrollIndicators(.hidden)
                        }
                        .padding()
                        .background(.ultraThinMaterial, in: .rect(cornerRadius: 12))
                    }

                    if let daily = viewModel.daily {
                        VStack(alignment: .leading, spacing: 8) {
                            Label("10-Day Forecast", systemImage: "calendar")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                            ForEach(daily, id: \.date) { day in
                                HStack {
                                    Text(day.date.formatted(.dateTime.weekday(.abbreviated)))
                                        .frame(width: 36, alignment: .leading)
                                    Image(systemName: day.symbolName)
                                        .symbolRenderingMode(.multicolor)
                                        .frame(width: 28)
                                    Spacer()
                                    Text(day.lowTemperature.formatted())
                                        .foregroundStyle(.secondary)
                                    TemperatureBar(
                                        low: day.lowTemperature.value,
                                        high: day.highTemperature.value,
                                        rangeLow: viewModel.weekLow,
                                        rangeHigh: viewModel.weekHigh
                                    )
                                    .frame(width: 100, height: 4)
                                    Text(day.highTemperature.formatted())
                                }
                            }
                        }
                        .padding()
                        .background(.ultraThinMaterial, in: .rect(cornerRadius: 12))
                    }

                    LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                        WeatherDetailCard(title: "Feels Like", value: weather.apparentTemperature.formatted(), icon: "thermometer")
                        WeatherDetailCard(title: "Humidity", value: "\(Int(weather.humidity * 100))%", icon: "humidity.fill")
                        WeatherDetailCard(title: "Wind", value: weather.wind.speed.formatted(), icon: "wind")
                        WeatherDetailCard(title: "UV Index", value: "\(weather.uvIndex.value)", icon: "sun.max.fill")
                    }
                } else if viewModel.isLoading {
                    ProgressView()
                        .frame(maxWidth: .infinity, minHeight: 200)
                }
            }
            .padding(.horizontal)
            .padding(.top, 8)
        }
    }
}
```

### Weather Detail Card

```swift
struct WeatherDetailCard: View {
    let title: String
    let value: String
    let icon: String

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Label(title, systemImage: icon)
                .font(.caption)
                .foregroundStyle(.secondary)
            Text(value)
                .font(.title2.bold())
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding()
        .background(.ultraThinMaterial, in: .rect(cornerRadius: 12))
    }
}
```

### Temperature Bar (Apple Weather-style range indicator)

```swift
struct TemperatureBar: View {
    let low: Double
    let high: Double
    let rangeLow: Double
    let rangeHigh: Double

    private var normalizedLow: Double {
        guard rangeHigh > rangeLow else { return 0 }
        return (low - rangeLow) / (rangeHigh - rangeLow)
    }

    private var normalizedHigh: Double {
        guard rangeHigh > rangeLow else { return 1 }
        return (high - rangeLow) / (rangeHigh - rangeLow)
    }

    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .leading) {
                Capsule()
                    .fill(.quaternary)
                Capsule()
                    .fill(
                        LinearGradient(
                            colors: [.blue, .green, .yellow, .orange],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                    .frame(width: geo.size.width * (normalizedHigh - normalizedLow))
                    .offset(x: geo.size.width * normalizedLow)
            }
        }
    }
}
```

### ViewModel

```swift
@MainActor
@Observable
class WeatherMapViewModel {
    var current: CurrentWeather?
    var hourly: Forecast<HourWeather>?
    var daily: Forecast<DayWeather>?
    var locationName = ""
    var isLoading = false
    var userLocation: CLLocationCoordinate2D?

    var weekLow: Double {
        daily?.map(\.lowTemperature.value).min() ?? 0
    }

    var weekHigh: Double {
        daily?.map(\.highTemperature.value).max() ?? 100
    }

    private let weatherService = WeatherService.shared

    func load() async {
        isLoading = true
        defer { isLoading = false }

        do {
            let manager = CLLocationManager()
            manager.requestWhenInUseAuthorization()

            var location: CLLocation?
            for try await update in CLLocationUpdate.liveUpdates() {
                if let loc = update.location {
                    location = loc
                    break
                }
            }
            guard let location else { return }
            userLocation = location.coordinate

            let (current, hourly, daily) = try await weatherService.weather(
                for: location,
                including: .current, .hourly, .daily
            )
            self.current = current
            self.hourly = hourly
            self.daily = daily

            let placemarks = try await CLGeocoder().reverseGeocodeLocation(location)
            locationName = placemarks.first?.locality ?? "Current Location"
        } catch {
            print("Weather load error: \(error)")
        }
    }
}
```

### Key Points for Map + Bottom Sheet

1. **Use `.presentationBackgroundInteraction(.enabled(upThrough:))`** — Lets users pan/zoom the map while the sheet is at or below the specified detent
2. **Use `.interactiveDismissDisabled()`** — Prevents the sheet from being fully dismissed (weather sheet should always be visible)
3. **Use `.presentationBackground(.ultraThinMaterial)`** — Glass-like sheet that shows the map through
4. **Use multiple detents** — Small peek (15%), medium (40%), and full (.large) for progressive disclosure
5. **Put ScrollView inside the sheet** — The sheet's drag gesture and scroll gesture coordinate automatically
6. **Map ignores safe area, sheet handles its own** — `Map.ignoresSafeArea()` fills the screen, sheet content uses default safe area

### Common Bugs to Avoid

- **Don't build a custom draggable sheet** — Use the native `.sheet` with `presentationDetents`. Custom implementations break scroll-vs-drag coordination
- **Don't use `.overlay` for the sheet** — Native sheets handle keyboard avoidance, safe areas, and gesture disambiguation correctly
- **Don't set `.presentationBackgroundInteraction(.enabled)` without `upThrough:`** — Without the limit, the map is always interactive, which can conflict with sheet scrolling at large detent
- **Don't forget `.interactiveDismissDisabled()`** — Without it, dragging down past the smallest detent dismisses the sheet entirely

---

## What's Practical for Code Generation

### Highly Practical (pure Swift, no external assets)

| Feature                         | Why                              | Complexity |
| ------------------------------- | -------------------------------- | ---------- |
| WeatherKit current conditions   | 3 lines of code, auto-formats    | Low        |
| Hourly/daily forecast display   | WeatherKit + ScrollView          | Low        |
| Location permission + geocoding | CLLocationManager pattern        | Low        |
| MapKit with annotations         | SwiftUI Map or MKMapView         | Low        |
| Radar tile overlay              | MKTileOverlay + external URL     | Medium     |
| Severe weather alerts           | WeatherKit alerts API            | Low        |
| Location search typeahead       | MKLocalSearchCompleter           | Medium     |
| Weather condition SF Symbols    | symbolName property auto-maps    | Low        |
| Minute-by-minute precipitation  | WeatherKit minute forecast       | Low        |
| SwiftUI shader effects          | .colorEffect / .distortionEffect | Medium     |
| Color-mapped data overlay       | Metal fragment shader            | Medium     |

### Possible But Complex

| Feature                      | Limitation                                                   |
| ---------------------------- | ------------------------------------------------------------ |
| Wind particle flow animation | Full Metal pipeline (compute + render), needs wind grid data |
| Isobar/contour lines         | Marching squares algorithm, pressure grid data               |
| Temperature heatmap overlay  | Grid interpolation + color mapping + tile rendering          |
| Custom weather widgets       | WidgetKit boilerplate, limited interactivity                 |
| Background weather updates   | Requires Always location + background modes                  |

### Not Practical for Code Generation

| Feature                          | Why                                                                        |
| -------------------------------- | -------------------------------------------------------------------------- |
| Full Windy-grade particle system | Production quality needs extensive GPU optimization, triple-buffering, LOD |
| Custom weather model ingestion   | GRIB2/NetCDF parsing is extremely complex                                  |
| Real-time radar animation        | Requires backend to serve timed tile sequences                             |
| Offline map tiles                | Requires tile download + storage management                                |

---

## Complete Recipe: Weather App (WeatherKit + CoreLocation)

```swift
import SwiftUI
import WeatherKit
import CoreLocation

struct WeatherAppView: View {
    @State private var viewModel = WeatherViewModel()

    var body: some View {
        NavigationStack {
            ScrollView {
                if let weather = viewModel.current {
                    VStack(spacing: 24) {
                        Text(viewModel.locationName)
                            .font(.title2)

                        Text(weather.temperature.formatted())
                            .font(.system(size: 64, weight: .thin))

                        HStack {
                            Image(systemName: weather.symbolName)
                                .symbolRenderingMode(.multicolor)
                                .font(.title)
                            Text(weather.condition.description)
                        }

                        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 16) {
                            WeatherDetailCard(title: "Feels Like", value: weather.apparentTemperature.formatted(), icon: "thermometer")
                            WeatherDetailCard(title: "Humidity", value: "\(Int(weather.humidity * 100))%", icon: "humidity.fill")
                            WeatherDetailCard(title: "Wind", value: weather.wind.speed.formatted(), icon: "wind")
                            WeatherDetailCard(title: "Pressure", value: weather.pressure.formatted(), icon: "barometer")
                            WeatherDetailCard(title: "UV Index", value: "\(weather.uvIndex.value)", icon: "sun.max.fill")
                            WeatherDetailCard(title: "Visibility", value: weather.visibility.formatted(), icon: "eye.fill")
                        }
                        .padding(.horizontal)

                        if let hourly = viewModel.hourly {
                            VStack(alignment: .leading) {
                                Text("Hourly Forecast").font(.headline).padding(.horizontal)
                                ScrollView(.horizontal) {
                                    HStack(spacing: 16) {
                                        ForEach(Array(hourly.prefix(24)), id: \.date) { hour in
                                            VStack(spacing: 8) {
                                                Text(hour.date.formatted(.dateTime.hour()))
                                                    .font(.caption)
                                                Image(systemName: hour.symbolName)
                                                    .symbolRenderingMode(.multicolor)
                                                Text(hour.temperature.formatted())
                                                    .font(.subheadline.bold())
                                            }
                                        }
                                    }
                                    .padding(.horizontal)
                                }
                                .scrollIndicators(.hidden)
                            }
                        }

                        if let daily = viewModel.daily {
                            VStack(alignment: .leading, spacing: 12) {
                                Text("10-Day Forecast").font(.headline)
                                ForEach(daily, id: \.date) { day in
                                    HStack {
                                        Text(day.date.formatted(.dateTime.weekday(.abbreviated)))
                                            .frame(width: 40, alignment: .leading)
                                        Image(systemName: day.symbolName)
                                            .symbolRenderingMode(.multicolor)
                                            .frame(width: 30)
                                        Spacer()
                                        Text(day.lowTemperature.formatted())
                                            .foregroundStyle(.secondary)
                                        Text(day.highTemperature.formatted())
                                    }
                                }
                            }
                            .padding(.horizontal)
                        }
                    }
                    .padding(.vertical)
                } else if viewModel.isLoading {
                    ProgressView("Loading weather...")
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    ContentUnavailableView("No Weather Data",
                        systemImage: "cloud.sun",
                        description: Text("Enable location to see weather"))
                }
            }
            .navigationTitle("Weather")
            .task { await viewModel.loadWeather() }
        }
    }
}

// Reuse WeatherDetailCard from above.
// WeatherViewModel follows the same pattern as WeatherMapViewModel
// but without the map-specific state (userLocation, mapPosition).
```

---

## Complete Recipe: Radar Map with Tile Overlay

```swift
import SwiftUI
import MapKit

struct RadarMapView: View {
    var body: some View {
        ZStack(alignment: .bottom) {
            RadarMapRepresentable()
                .ignoresSafeArea()

            // Layer toggle
            HStack {
                ForEach(["Radar", "Satellite", "Temperature"], id: \.self) { layer in
                    Button(layer) {}
                        .buttonStyle(.bordered)
                }
            }
            .padding()
            .background(.ultraThinMaterial)
            .clipShape(Capsule())
            .padding(.bottom)
        }
    }
}

struct RadarMapRepresentable: UIViewRepresentable {
    func makeUIView(context: Context) -> MKMapView {
        let mapView = MKMapView()
        mapView.delegate = context.coordinator
        mapView.preferredConfiguration = MKStandardMapConfiguration(emphasisStyle: .muted)
        mapView.pointOfInterestFilter = .excludingAll
        mapView.showsUserLocation = true

        // Add radar overlay
        let radarOverlay = RadarTileOverlay()
        mapView.addOverlay(radarOverlay, level: .aboveRoads)

        return mapView
    }

    func updateUIView(_ uiView: MKMapView, context: Context) {}
    func makeCoordinator() -> Coordinator { Coordinator() }

    class Coordinator: NSObject, MKMapViewDelegate {
        func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
            if let tileOverlay = overlay as? MKTileOverlay {
                let renderer = MKTileOverlayRenderer(overlay: tileOverlay)
                renderer.alpha = 0.6
                return renderer
            }
            return MKOverlayRenderer(overlay: overlay)
        }
    }
}

class RadarTileOverlay: MKTileOverlay {
    init() {
        // OpenWeatherMap radar tiles (requires API key)
        super.init(urlTemplate: "https://tile.openweathermap.org/map/precipitation_new/{z}/{x}/{y}.png?appid=YOUR_KEY")
        self.canReplaceMapContent = false
        self.minimumZ = 1
        self.maximumZ = 12
    }
}
```

### Free Radar/Weather Tile Sources

| Source         | URL Pattern                                                                | Notes                                                                                               |
| -------------- | -------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------- |
| RainViewer     | `https://tilecache.rainviewer.com/v2/radar/{ts}/256/{z}/{x}/{y}/2/1_1.png` | Free, needs timestamp from their API                                                                |
| OpenWeatherMap | `https://tile.openweathermap.org/map/{layer}/{z}/{x}/{y}.png?appid={key}`  | Free tier (1000 calls/day), layers: clouds_new, precipitation_new, pressure_new, wind_new, temp_new |
| Open-Meteo     | Custom integration via their API                                           | Free, no key needed, model data not tiles                                                           |

---

## Wind Particle Flow — Technique Overview

The signature Windy-style flowing particles need these steps:

1. **Get wind grid data** — Array of U (east-west) and V (north-south) velocity components across a lat/lon grid
2. **Upload as Metal texture** — Two-channel texture (R=U, G=V), each pixel = one grid cell
3. **GPU particle system** — Compute shader advances ~65K particles through the velocity field each frame
4. **Trail accumulation** — Render to offscreen texture, fade previous frame by ~3%, draw new particle positions on top → creates flowing trails
5. **Color by speed** — Particle color maps from wind magnitude: calm (blue) → moderate (green/yellow) → strong (orange/red) → extreme (purple)
6. **Composite** — Overlay the trail texture (with transparency) on top of MapKit base map

This is a complex feature requiring full Metal setup (compute + render pipelines, MSL shaders, triple-buffered particle buffers). See `metal-reference.md` for the Metal API details.

---

## Key Imports Reference

```swift
import WeatherKit       // Weather data (current, forecast, alerts)
import MapKit           // Maps, overlays, search, directions
import CoreLocation     // User location, geocoding
import Metal            // GPU rendering and compute
import MetalKit         // MTKView, texture loading
import simd             // Vector/matrix math for shaders
import WidgetKit        // Home screen widgets
```

---

## Permissions Reference

| Permission             | Key                                                          | Example Value                    |
| ---------------------- | ------------------------------------------------------------ | -------------------------------- |
| Location (When In Use) | `INFOPLIST_KEY_NSLocationWhenInUseUsageDescription`          | "Show weather for your location" |
| Location (Always)      | `INFOPLIST_KEY_NSLocationAlwaysAndWhenInUseUsageDescription` | "Update weather in background"   |

---

## External APIs for Weather Data

### WeatherKit Limitations

WeatherKit provides point forecasts (one location at a time), not gridded data. For map-wide visualizations (wind fields, temperature heatmaps, pressure contours), you need gridded data from:

### Open-Meteo (Recommended, Free for Non-Commercial)

```swift
// Current weather for a point
let url = URL(string: "https://api.open-meteo.com/v1/forecast?latitude=52.52&longitude=13.41&current=temperature_2m,wind_speed_10m,wind_direction_10m,pressure_msl&hourly=temperature_2m,precipitation")!

// Response includes:
// current.temperature_2m, current.wind_speed_10m, current.wind_direction_10m
// hourly arrays for each variable
```

No API key needed for reasonable usage. Has Swift SDK: `https://github.com/open-meteo/open-meteo`

### RainViewer (Radar Tiles)

```swift
// Get available radar timestamps
let timestampsURL = URL(string: "https://api.rainviewer.com/public/weather-maps.json")!
// Returns JSON with available radar frame timestamps
// Use timestamps to build tile URLs
```
