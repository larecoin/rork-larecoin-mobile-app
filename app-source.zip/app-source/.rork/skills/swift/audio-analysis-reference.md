---
index: true
description: SoundAnalysis, ShazamKit, SpeechAnalyzer/SpeechDetector, Speech framework, vDSP
---

# Audio Analysis — SoundAnalysis, ShazamKit, Speech & Accelerate/vDSP

Frameworks for analyzing, classifying, recognizing, and visualizing audio.

---

## SoundAnalysis — ML Sound Classification

Classifies sounds from audio buffers or files using built-in or custom CoreML models. Identifies 300+ built-in sound categories (speech, music, laughter, dog bark, siren, etc.).

**Import:** `import SoundAnalysis`

### Classify Sounds from Microphone (Real-time)

```swift
import SoundAnalysis
import AVFoundation

class SoundClassifier {
    let engine = AVAudioEngine()
    var analyzer: SNAudioStreamAnalyzer?

    func startClassifying() throws {
        let inputNode = engine.inputNode
        let format = inputNode.outputFormat(forBus: 0)

        analyzer = SNAudioStreamAnalyzer(format: format)

        let request = try SNClassifySoundRequest(classifierIdentifier: .version1)
        try analyzer?.add(request, withObserver: self)

        inputNode.installTap(onBus: 0, bufferSize: 8192, format: format) { [weak self] buffer, time in
            self?.analyzer?.analyze(buffer, atAudioFramePosition: time.sampleTime)
        }

        try engine.start()
    }

    func stopClassifying() {
        engine.inputNode.removeTap(onBus: 0)
        engine.stop()
        analyzer?.removeAllRequests()
    }
}

extension SoundClassifier: SNResultsObserving {
    func request(_ request: SNRequest, didProduce result: SNResult) {
        guard let classificationResult = result as? SNClassificationResult else { return }
        guard let topResult = classificationResult.classifications.first else { return }

        if topResult.confidence > 0.5 {
            Task { @MainActor in
                print("\(topResult.identifier): \(Int(topResult.confidence * 100))%")
            }
        }
    }

    func request(_ request: SNRequest, didFailWithError error: Error) {
        print("Classification error: \(error)")
    }
}
```

### Classify Sounds from Audio File

```swift
func classifyFile(url: URL) throws {
    let request = try SNClassifySoundRequest(classifierIdentifier: .version1)
    let analyzer = try SNAudioFileAnalyzer(url: url)
    try analyzer.add(request, withObserver: self)
    analyzer.analyze() // async — results come via SNResultsObserving
}
```

### Custom Sound Model (CreateML)

Train a custom model in CreateML using labeled sound files, then use it:

```swift
let customModel = try MLModel(contentsOf: modelURL)
let request = try SNClassifySoundRequest(mlModel: customModel)
```

### Common Built-in Sound Categories

`speech`, `music`, `laughter`, `applause`, `cough`, `sneeze`, `snoring`, `crying_baby`, `dog_bark`, `cat_meow`, `bird`, `siren`, `car_horn`, `doorbell`, `door_knock`, `water`, `wind`, `thunder`, `piano`, `guitar`, `drums`, `whistling`, `clapping`, `footsteps`, `typing`, `alarm`, `glass_breaking`

---

## ShazamKit — Audio Recognition

Matches audio against Shazam's music catalog or custom audio catalogs.

**Import:** `import ShazamKit`

### Setup Requirements

1. Enable ShazamKit in Certificates, Identifiers & Profiles
2. Add microphone permission to `Info.plist`
3. Add `ShazamKit` capability to your app

### Recognize Music (iOS 17+, Simplified API)

```swift
import ShazamKit

class MusicRecognizer {
    let session = SHManagedSession()

    func match() async {
        let result = await session.result()
        switch result {
        case .match(let match):
            guard let mediaItem = match.mediaItems.first else { return }
            let title = mediaItem.title ?? "Unknown"
            let artist = mediaItem.artist ?? "Unknown"
            let artworkURL = mediaItem.artworkURL
            let appleMusicURL = mediaItem.appleMusicURL
            print("\(title) by \(artist)")
        case .noMatch:
            print("No match found")
        case .error(let error, _):
            print("Error: \(error)")
        }
    }
}
```

### Recognize Music (Pre-iOS 17, Buffer-based)

```swift
class MusicRecognizer: NSObject {
    let session = SHSession()
    let engine = AVAudioEngine()

    override init() {
        super.init()
        session.delegate = self
    }

    func startListening() throws {
        let audioSession = AVAudioSession.sharedInstance()
        try audioSession.setCategory(.record)
        try audioSession.setActive(true)

        let inputNode = engine.inputNode
        let format = inputNode.outputFormat(forBus: 0)

        inputNode.installTap(onBus: 0, bufferSize: 2048, format: format) { [weak self] buffer, time in
            self?.session.matchStreamingBuffer(buffer, at: time)
        }

        try engine.start()
    }

    func stopListening() {
        engine.inputNode.removeTap(onBus: 0)
        engine.stop()
    }
}

extension MusicRecognizer: SHSessionDelegate {
    func session(_ session: SHSession, didFind match: SHMatch) {
        guard let item = match.mediaItems.first else { return }
        Task { @MainActor in
            print("Found: \(item.title ?? "") by \(item.artist ?? "")")
        }
    }

    func session(_ session: SHSession, didNotFindMatchFor signature: SHSignature, error: Error?) {
        print("No match")
    }
}
```

### SHMediaItem Properties

| Property        | Type       | Description                           |
| --------------- | ---------- | ------------------------------------- |
| `title`         | `String?`  | Song title                            |
| `artist`        | `String?`  | Artist name                           |
| `artworkURL`    | `URL?`     | Album artwork                         |
| `appleMusicURL` | `URL?`     | Apple Music link                      |
| `appleMusicID`  | `String?`  | Apple Music identifier                |
| `genres`        | `[String]` | Genre list                            |
| `isrc`          | `String?`  | International Standard Recording Code |
| `videoURL`      | `URL?`     | Music video URL                       |

### Custom Catalog (Match Your Own Audio)

```swift
// Generate signature from audio file
let signatureGenerator = SHSignatureGenerator()
let audioFile = try AVAudioFile(forReading: audioURL)
let buffer = AVAudioPCMBuffer(pcmFormat: audioFile.processingFormat,
                               frameCapacity: AVAudioFrameCount(audioFile.length))!
try audioFile.read(into: buffer)
try signatureGenerator.append(buffer, at: nil)
let signature = signatureGenerator.signature()

// Build catalog
let catalog = SHCustomCatalog()
let referenceItem = SHMediaItem(properties: [
    .title: "My Track",
    .artist: "My Artist"
])
try catalog.addReferenceSignature(signature, representing: [referenceItem])

// Match against custom catalog
let session = SHSession(catalog: catalog)
```

### Shazam Library

```swift
// Add a recognized song to the user's Shazam library
SHMediaLibrary.default.add([mediaItem]) { error in
    if let error { print("Failed: \(error)") }
}
```

---

## Speech — Speech Recognition & Synthesis

### Speech Recognition

For native Swift speech-to-text apps, check the modern Speech framework APIs first. `SpeechAnalyzer`,
`SpeechTranscriber`, and `SpeechDetector` are especially useful for on-device transcription, streaming
analysis, and voice activity detection on supported OS versions.

What these APIs enable:

- `SpeechAnalyzer` — session coordinator for modern speech analysis. Use it to connect audio input with
  one or more analysis modules, choose a compatible audio format, stream `AnalyzerInput` values, and
  finish or finalize analysis.
- `SpeechTranscriber` — general-purpose speech-to-text module. Use it for voice notes, meeting
  transcriptions, lecture recorders, searchable audio, subtitles, and other normal conversation
  transcription features.
- `DictationTranscriber` — dictation-style fallback module. Use it when the newer transcriber is not
  available for the device, OS, or locale.
- `SpeechDetector` — voice activity detection module. Use it to detect speech regions, avoid
  transcribing silence, drive voice-activated recording, and identify when speech starts or ends.
  It is especially useful for telephone-style assistants, live voice agents, hands-free command apps,
  and voice-note tools that should keep a microphone session ready while only uploading actual
  utterances.
- `AssetInventory` and `AssetInstallationRequest` — model availability and installation. Use them before
  starting analysis so required on-device models are installed and so the UI can show download progress.
- `AnalyzerInput` and `SpeechModuleResult` — input and output contracts. Use `AnalyzerInput` for
  time-coded audio buffers, and read module result ranges/finality to build live captions without
  duplicating volatile text.
- `AnalysisContext` and `SFCustomLanguageModelData` — contextual vocabulary. Use them for product names,
  jargon, names, commands, or domain-specific phrases that recognition should bias toward.
- `SFSpeechRecognizer` and related request/task/result types — legacy Speech API. Use these for older OS
  support or simpler file/live recognition when SpeechAnalyzer is unavailable.
- `SFTranscription`, `SFTranscriptionSegment`, and `SFVoiceAnalytics` — transcript metadata. Use them for
  word-level timing, confidence, alternative interpretations, and voice analytics when available.

This unlocks app ideas such as on-device dictation, AI meeting notes, searchable call or voice memos,
voice command interfaces, speech-driven journaling, subtitle/caption tools, pronunciation practice, and
privacy-preserving audio transcription with Apple Intelligence summaries.

For VAD-driven product patterns such as sending detected utterances to ElevenLabs Scribe and then to an
AI agent, read `.rork/skills/audio/idea.md`.

Useful Apple documentation:

- https://developer.apple.com/documentation/speech/
- https://developer.apple.com/documentation/speech/bringing-advanced-speech-to-text-capabilities-to-your-app
- https://developer.apple.com/documentation/speech/speechanalyzer
- https://developer.apple.com/documentation/speech/assetinventory
- https://developer.apple.com/documentation/speech/speechtranscriber
- https://developer.apple.com/documentation/speech/dictationtranscriber
- https://developer.apple.com/documentation/speech/speechdetector
- https://developer.apple.com/documentation/speech/speechdetector/detectionoptions
- https://developer.apple.com/documentation/speech/speechdetector/sensitivitylevel
- https://developer.apple.com/documentation/speech/speechdetector/result
- https://developer.apple.com/documentation/speech/speechmodule
- https://developer.apple.com/documentation/speech/localedependentspeechmodule
- https://developer.apple.com/documentation/speech/analyzerinput
- https://developer.apple.com/documentation/speech/speechmoduleresult
- https://developer.apple.com/documentation/speech/analysiscontext
- https://developer.apple.com/documentation/speech/sfspeechlanguagemodel
- https://developer.apple.com/documentation/speech/sfspeechlanguagemodel/configuration
- https://developer.apple.com/documentation/speech/sfcustomlanguagemodeldata
- https://developer.apple.com/documentation/speech/assetinstallationrequest
- https://developer.apple.com/documentation/speech/speechmodels
- https://developer.apple.com/documentation/speech/recognizing-speech-in-live-audio
- https://developer.apple.com/documentation/speech/sfspeechrecognizer
- https://developer.apple.com/documentation/speech/sfspeechrecognitionrequest
- https://developer.apple.com/documentation/speech/sfspeechaudiobufferrecognitionrequest
- https://developer.apple.com/documentation/speech/sfspeechurlrecognitionrequest
- https://developer.apple.com/documentation/speech/sfspeechrecognitiontask
- https://developer.apple.com/documentation/speech/sfspeechrecognitionresult
- https://developer.apple.com/documentation/speech/sftranscription
- https://developer.apple.com/documentation/speech/sftranscriptionsegment
- https://developer.apple.com/documentation/speech/sfvoiceanalytics

```swift
import Speech

class SpeechRecognizer {
    let recognizer = SFSpeechRecognizer(locale: Locale(identifier: "en-US"))
    var recognitionTask: SFSpeechRecognitionTask?

    func requestAuthorization() {
        SFSpeechRecognizer.requestAuthorization { status in
            switch status {
            case .authorized: break    // ready
            case .denied: break        // user denied
            case .restricted: break    // device restricted
            case .notDetermined: break
            @unknown default: break
            }
        }
    }

    // Transcribe from file
    func transcribe(url: URL) {
        let request = SFSpeechURLRecognitionRequest(url: url)
        recognitionTask = recognizer?.recognitionTask(with: request) { result, error in
            guard let result else { return }
            let text = result.bestTranscription.formattedString
            if result.isFinal {
                print("Final: \(text)")
            }
        }
    }

    // Real-time transcription from microphone
    func startLiveTranscription(engine: AVAudioEngine) throws {
        let request = SFSpeechAudioBufferRecognitionRequest()
        request.shouldReportPartialResults = true

        let inputNode = engine.inputNode
        let format = inputNode.outputFormat(forBus: 0)

        inputNode.installTap(onBus: 0, bufferSize: 1024, format: format) { buffer, _ in
            request.append(buffer)
        }

        try engine.start()

        recognitionTask = recognizer?.recognitionTask(with: request) { result, error in
            guard let result else { return }
            let text = result.bestTranscription.formattedString
            print(text)
        }
    }
}
```

### Speech Synthesis (Text-to-Speech)

```swift
import AVFoundation

let synthesizer = AVSpeechSynthesizer()

func speak(_ text: String) {
    let utterance = AVSpeechUtterance(string: text)
    utterance.rate = AVSpeechUtteranceDefaultSpeechRate  // default 0.5; range 0.0-1.0
    utterance.pitchMultiplier = 1.0  // 0.5 to 2.0
    utterance.volume = 1.0
    utterance.voice = AVSpeechSynthesisVoice(language: "en-US")
    synthesizer.speak(utterance)
}

// Available voices
let voices = AVSpeechSynthesisVoice.speechVoices()
```

### Permissions

Speech recognition:

```
INFOPLIST_KEY_NSSpeechRecognitionUsageDescription = "Transcribe your audio recordings";
INFOPLIST_KEY_NSMicrophoneUsageDescription = "Record audio for transcription";
```

---

## Accelerate / vDSP — Audio DSP & Visualization

The Accelerate framework provides hardware-optimized DSP functions for audio analysis and visualization.

**Import:** `import Accelerate`

### FFT (Fast Fourier Transform) — Frequency Analysis

```swift
import Accelerate

class FFTAnalyzer {
    let fftSize = 2048
    private var fftSetup: FFTSetup?

    init() {
        fftSetup = vDSP_create_fftsetup(vDSP_Length(log2(Float(fftSize))), FFTRadix(kFFTRadix2))
    }

    deinit {
        if let setup = fftSetup {
            vDSP_destroy_fftsetup(setup)
        }
    }

    func analyze(buffer: AVAudioPCMBuffer) -> [Float] {
        guard let channelData = buffer.floatChannelData else { return [] }
        let frameCount = Int(buffer.frameLength)
        let samples = Array(UnsafeBufferPointer(start: channelData[0], count: min(frameCount, fftSize)))

        // Apply Hann window to reduce spectral leakage
        var windowedSamples = [Float](repeating: 0, count: fftSize)
        var window = [Float](repeating: 0, count: fftSize)
        vDSP_hann_window(&window, vDSP_Length(fftSize), Int32(vDSP_HANN_NORM))
        vDSP_vmul(samples, 1, window, 1, &windowedSamples, 1, vDSP_Length(fftSize))

        // Split complex setup
        var realPart = [Float](repeating: 0, count: fftSize / 2)
        var imagPart = [Float](repeating: 0, count: fftSize / 2)

        realPart.withUnsafeMutableBufferPointer { realPtr in
            imagPart.withUnsafeMutableBufferPointer { imagPtr in
                var splitComplex = DSPSplitComplex(realp: realPtr.baseAddress!, imagp: imagPtr.baseAddress!)

                windowedSamples.withUnsafeBufferPointer { samplesPtr in
                    samplesPtr.baseAddress!.withMemoryRebound(to: DSPComplex.self, capacity: fftSize / 2) { complexPtr in
                        vDSP_ctoz(complexPtr, 2, &splitComplex, 1, vDSP_Length(fftSize / 2))
                    }
                }

                // Perform FFT
                vDSP_fft_zrip(fftSetup!, &splitComplex, 1, vDSP_Length(log2(Float(fftSize))), FFTDirection(FFT_FORWARD))
            }
        }

        // Calculate magnitudes
        var magnitudes = [Float](repeating: 0, count: fftSize / 2)
        realPart.withUnsafeMutableBufferPointer { realPtr in
            imagPart.withUnsafeMutableBufferPointer { imagPtr in
                var splitComplex = DSPSplitComplex(realp: realPtr.baseAddress!, imagp: imagPtr.baseAddress!)
                vDSP_zvmags(&splitComplex, 1, &magnitudes, 1, vDSP_Length(fftSize / 2))
            }
        }

        // Convert to decibels
        var dbMagnitudes = [Float](repeating: 0, count: fftSize / 2)
        var one: Float = 1.0
        vDSP_vdbcon(magnitudes, 1, &one, &dbMagnitudes, 1, vDSP_Length(fftSize / 2), 0)

        return dbMagnitudes
    }
}
```

### RMS Level Metering

```swift
func calculateRMS(buffer: AVAudioPCMBuffer) -> Float {
    guard let channelData = buffer.floatChannelData else { return 0 }
    let frameCount = Int(buffer.frameLength)

    var rms: Float = 0
    vDSP_rmsqv(channelData[0], 1, &rms, vDSP_Length(frameCount))

    return rms
}

func rmsToDecibels(_ rms: Float) -> Float {
    guard rms > 0 else { return -160 }
    return 20 * log10(rms)
}
```

### Peak Detection

```swift
func findPeakFrequency(magnitudes: [Float], sampleRate: Float, fftSize: Int) -> Float {
    var maxValue: Float = 0
    var maxIndex: vDSP_Length = 0
    vDSP_maxvi(magnitudes, 1, &maxValue, &maxIndex, vDSP_Length(magnitudes.count))

    let frequencyResolution = sampleRate / Float(fftSize)
    return Float(maxIndex) * frequencyResolution
}
```

### SwiftUI Audio Waveform Visualization

```swift
import SwiftUI
import Charts

struct WaveformView: View {
    let magnitudes: [Float]
    let barCount: Int = 32

    var bars: [Float] {
        guard !magnitudes.isEmpty else { return Array(repeating: 0, count: barCount) }
        let chunkSize = magnitudes.count / barCount
        return stride(from: 0, to: magnitudes.count, by: max(chunkSize, 1)).prefix(barCount).map { start in
            let end = min(start + chunkSize, magnitudes.count)
            let chunk = Array(magnitudes[start..<end])
            var avg: Float = 0
            vDSP_meanv(chunk, 1, &avg, vDSP_Length(chunk.count))
            return max(0, (avg + 80) / 80) // normalize from dB
        }
    }

    var body: some View {
        Chart {
            ForEach(Array(bars.enumerated()), id: \.offset) { index, value in
                BarMark(
                    x: .value("Freq", index),
                    y: .value("Level", value)
                )
                .foregroundStyle(.blue.gradient)
            }
        }
        .chartYScale(domain: 0...1)
        .frame(height: 120)
    }
}
```

### Useful vDSP Functions for Audio

| Function           | Purpose                      |
| ------------------ | ---------------------------- |
| `vDSP_rmsqv`       | RMS (root mean square) level |
| `vDSP_maxv`        | Maximum value in array       |
| `vDSP_meanv`       | Mean value                   |
| `vDSP_vdbcon`      | Convert to decibels          |
| `vDSP_hann_window` | Generate Hann window         |
| `vDSP_vmul`        | Element-wise multiply        |
| `vDSP_fft_zrip`    | In-place real FFT            |
| `vDSP_zvmags`      | Complex magnitudes squared   |
| `vDSP_normalize`   | Normalize an array           |
| `vDSP_vclip`       | Clip values to range         |
| `vDSP_maxvi`       | Maximum value and index      |
| `vDSP_desamp`      | Downsample/average           |
