---
name: play-store-publish
description: Orchestrate deterministic Google Play publishing through Rork's typed Android Publisher operations. Read this for internal testing, closed or open testing, production promotion, staged rollout, halt, resume, or completion.
---

# Play Store Publish

Use project-bound Rork tools for every Google Play mutation. The backend owns package resolution, version selection, project authorization, and the current user's OAuth token.

## Hard Boundaries

- Never install or invoke a third-party Play Console CLI or place shared Google credentials in the sandbox.
- Never pass an arbitrary bundle URL, local bundle path, version code, source track, or OAuth token.
- Google requires the user to create the first public app record in Play Console. Some new apps also require a first manual upload or draft release setup before API automation can begin.
- Internal testing proves the build and upload path only. It does not prove production readiness.
- Do not mutate a track without explicit user intent. Validate first when the exact destination or rollout action has not already been confirmed.
- Do not claim custom-track, rollback, or full review-lifecycle automation until a typed backend tool exists for it.

## Determine Intent

- "Internal testing", "send to testers quickly", or "test on device" -> Internal Testing.
- "Closed testing" or "12 testers for 14 days" -> promote a committed internal release to `alpha` only when that is the user's intended standard closed track.
- "Open testing" -> promote a committed release to `beta` only when that is the user's intended standard open track.
- "Production", "public launch", or "staged rollout" -> promote a committed release to `production`.
- "Increase", "halt", "resume", or "complete rollout" -> use the latest committed production submission.
- "Store listing" or "description" -> use the metadata skill and the project-bound listing tools.
- "Screenshots" -> Capture Screenshots.
- "Feature graphic" -> use the assets skill and its project-bound listing image tools.
- Ambiguous "publish my Android app" -> ask whether the user wants internal, closed, open, or production.

## Shared Setup

1. Read `.rork/skills/play-store-connect/SKILL.md`.
2. Call `setupGooglePlay` and stop if the user is not connected.
3. Call `ensurePlayAppRecord` and stop if Play Console requires initial manual setup.
4. Read `.rork/skills/play-store-preflight/SKILL.md` and collect the evidence required for the target track.

## Internal Testing

1. Call `listPublishablePlayBuilds` and select the build matching the current `snapshotId`, `sourceHash`, `appPath`, framework, and package name.
2. If none matches, call `generatePlayAab({ snapshotId, sourceHash, appPath, framework })`, wait, then list again before publishing.
3. If the regenerated list still has no exact match, stop and report the missing Play AAB instead of publishing.
4. Call `publishInternalBuild` with `validateOnly: true` unless the user already explicitly requested the exact publish.
5. If validation succeeds and confirmation is still needed, show the package, internal track, and release copy.
6. Call `publishInternalBuild` with `validateOnly: false` after confirmation.
7. Keep the committed result's `submissionId` and report package, track, release name, and version code.
8. Tell the user to add or confirm internal testers in Play Console, then copy and share the tester opt-in link. Testers must open it with the eligible Google account they use on their Android device. If they need testers, point them to the Rork Discord action in the publishing result.

Do not describe internal testing as satisfying the 12-testers-for-14-days production requirement. Qualifying newer personal developer accounts must complete that requirement on a separate closed test.

## Capture Screenshots

1. Start from a committed Internal Testing `submissionId`. Call `listPlayListingImages` for the target language and `phoneScreenshots` before proposing any capture or replacement.
2. If the slot contains screenshots, ask the user:

> "You already have Google Play screenshots. Would you like to generate new ones, or keep the current set?"

3. If the user keeps the current set, stop without capturing or replacing anything.
4. If the user wants new screenshots, try to read `.rork/skills/screenshots-v2/screenshots.md`. When it is available, follow it and call `captureAppScreenshots` with `device: "android"`. When it is unavailable, Android capture is not enabled for this session; ask the user to supply prepared screenshots instead of calling the iOS-only fallback with an Android device.
5. After the user accepts new screenshots, read `.rork/skills/play-store-assets/SKILL.md`. Reinspect the current slot, validate the complete ordered replacement, then commit it with `replacePlayListingImages` only after the required confirmation.

Do not replace the existing screenshot set when the user chose to keep it.

## Closed Or Open Testing

1. Start from a successful non-validation submission returned by `publishInternalBuild` or a prior promotion.
2. Use `alpha` for the standard closed track or `beta` for the standard open track only when that mapping matches the user's Play Console intent.
3. Call `promotePlayRelease` with `validateOnly: true`, then commit the same source submission after explicit confirmation.
4. Keep the committed promotion's new `submissionId` for future controls.

Custom testing tracks are not yet supported by the typed tool. Do not silently substitute alpha or beta when the user names a different track.

## Production And Staged Rollout

Release status semantics:

- `inProgress`: staged rollout serving the returned `userFraction`.
- `completed`: serving all eligible users on the production track.
- `halted`: no longer serving new users; existing installs are unaffected.

Steps:

1. Start from a successful committed submission and confirm production readiness evidence.
2. Call `checkAndroidDeveloperVerification` with that submission. Stop when `productionBlocked` is true. If the check is unavailable, report readiness as unknown and ask whether to proceed without verification. Set `allowUnavailableDeveloperVerification: true` only after the user explicitly confirms; never set it proactively. This is a package-name check, not proof that the app-signing certificate matches.
3. Before September 30, 2026, warn about an unregistered package before continuing. From the cutoff, the backend blocks a deterministically invalid production promotion.
4. For full rollout, call `promotePlayRelease` with `targetTrack: "production"` and no fraction.
5. For staged rollout, pass a decimal `userFraction` between 0 and 1, such as `0.05` for 5%.
6. Validate first unless the user already explicitly confirmed the target and fraction. Use the original published source ID for the commit, not the validation result ID.
7. Keep the committed production `submissionId`.
8. Use `updatePlayRollout` with that latest committed ID to increase, halt, resume, or complete the rollout. Recheck developer verification before increasing, resuming, or completing, and require the same explicit confirmation before proceeding while it is unavailable. Halt remains available even when verification is blocked or unavailable.
9. Never lower a rollout fraction. Halt the rollout or publish a corrective release instead.

There is no typed rollback operation yet. Do not simulate rollback by inventing track state or a previous version code.

## Reporting

Always separate:

- what the typed backend operation committed
- what was only validated
- what still requires Play Console setup or policy work
- what is not yet supported by a typed operation

Use the Google Play chat widget as the primary status surface. Preserve the returned production rollout state in prose: say staged rollout with its fraction for `inProgress`, halted rollout for `halted`, and fully rolled out for `completed`. For non-production tracks, say internal test, closed test, or open test. Add only the next user action.
