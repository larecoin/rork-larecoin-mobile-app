---
name: apple-intelligence
description: On-device Apple Intelligence APIs — Foundation Models, Writing Tools, Image Playground, and Genmoji. All run locally with no internet or credits required. Read when adding on-device or offline AI features to Swift apps.
aliases:
  - on-device ai
  - offline ai
  - foundation models
  - writing tools
  - image playground
  - genmoji
  - local llm
---

# Apple Intelligence (On-Device AI)

Apple Intelligence provides on-device AI capabilities that run locally without internet or credits. Three main API areas:

| API               | File                   | iOS Version | Purpose                                                     |
| ----------------- | ---------------------- | ----------- | ----------------------------------------------------------- |
| Foundation Models | `foundation-models.md` | iOS 26+     | Text generation, structured output, streaming, tool calling |
| Writing Tools     | `writing-tools.md`     | iOS 18+     | System text rewriting, proofreading, summarisation          |
| Image Playground  | `image-playground.md`  | iOS 18.1+   | On-device image generation, Genmoji                         |

Read the relevant file for detailed API documentation and code examples.

## On-Device AI vs Cloud AI (`ai` skill)

| Criterion          | Apple Intelligence (on-device)                            | Cloud AI (`ai` skill)                                      |
| ------------------ | --------------------------------------------------------- | ---------------------------------------------------------- |
| Execution          | On-device                                                 | Cloud (Vercel AI Gateway)                                  |
| Internet           | Not required                                              | Required                                                   |
| Privacy            | Data never leaves device                                  | Data sent to cloud providers                               |
| Accuracy / Quality | **Low** — small model, prone to errors on complex tasks   | **High** — state-of-the-art models (GPT-5, Claude, Gemini) |
| Reasoning          | Weak — struggles with multi-step logic, nuance, ambiguity | Strong — handles complex analysis and creative tasks       |
| Speed              | Fast (no network latency)                                 | Depends on network and model                               |
| Cost               | Free (no credits)                                         | Costs credits per request                                  |
| Image styles       | Cartoon/illustration only                                 | Any style including photorealistic                         |
| Availability       | iOS 18+/26+, Apple Silicon only                           | Any platform with v2 toolkit                               |

### Advantages of On-Device (Apple Intelligence)

- **Privacy**: Data never leaves the device — ideal for health, finance, personal data
- **Offline**: Works without internet
- **Free**: No per-request credits
- **Low latency**: No network round-trip
- **System integration**: Writing Tools is automatic in standard text views

### Disadvantages of On-Device (Apple Intelligence)

- **Low accuracy**: The on-device model is small and NOT state-of-the-art. It frequently produces incorrect, shallow, or repetitive output on anything beyond simple tasks
- **Limited reasoning**: Cannot handle multi-step logic, complex analysis, nuanced instructions, or long-form creative writing
- **No photorealistic images**: Image Playground only produces cartoon/illustration styles
- **No embeddings, audio, or video**: Use `ai` skill for these
- **Language support**: Primarily English — other languages have significantly degraded quality
- **Small context window**: Cannot process long documents
- **Device restriction**: iPhone 15 Pro+, iPad/Mac with M1+, Apple Intelligence must be enabled

### When to Use Which

**Use Apple Intelligence (on-device) for:**

- Simple classification (sentiment, category, yes/no)
- Short text extraction (names, dates, keywords from a paragraph)
- Form auto-fill from short context
- System-level text proofreading (Writing Tools — handled automatically)
- Cartoon/illustration image creation where exact quality doesn't matter

**Use Cloud AI (`ai` skill) for everything else**, especially:

- Complex reasoning, analysis, or summarisation
- Long-form text generation (articles, stories, detailed responses)
- Photorealistic or high-quality image generation
- Embeddings and semantic search
- Multi-modal input (images, audio)
- When accuracy matters — the cloud models are significantly more capable
