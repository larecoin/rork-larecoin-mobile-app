# Image Playground (iOS 18.1+)

On-device AI image generation powered by Apple Intelligence. Two approaches: system sheet UI or programmatic `ImageCreator`. Produces cartoon/illustration styles only — for photorealistic images, use the `ai` skill (cloud).

## Availability Checking

### SwiftUI

```swift
@Environment(\.supportsImagePlayground) private var supportsImagePlayground

if supportsImagePlayground {
    Button("Create Image") { isPresented = true }
}
```

### UIKit

```swift
if ImagePlaygroundViewController.isAvailable {
    // present Image Playground
}
```

## Concepts

`ImagePlaygroundConcept` describes what to generate:

```swift
import ImagePlayground

// Short text description
ImagePlaygroundConcept.text("a red cat wearing blue gloves")

// Extract concepts from long-form text
ImagePlaygroundConcept.extracted(from: storyText, title: "Chapter 1")

// From an image
ImagePlaygroundConcept.image(cgImage)       // CGImage
ImagePlaygroundConcept.image(fileURL)       // URL

// From a PencilKit drawing
ImagePlaygroundConcept.drawing(pkDrawing)
```

Use `.text()` for short prompts. For longer text, `.extracted(from:title:)` lets the system extract the most relevant concepts automatically.

## SwiftUI — imagePlaygroundSheet

```swift
import ImagePlayground

struct ContentView: View {
    @Environment(\.supportsImagePlayground) private var supportsImagePlayground
    @State private var isPresented = false
    @State private var generatedImageURL: URL?

    var body: some View {
        VStack {
            if let url = generatedImageURL {
                AsyncImage(url: url)
            }

            if supportsImagePlayground {
                Button("Create Image") {
                    isPresented = true
                }
            }
        }
        .imagePlaygroundSheet(
            isPresented: $isPresented,
            concept: "a mountain landscape at sunset"
        ) { url in
            generatedImageURL = url
        }
    }
}
```

### Multiple Concepts

```swift
.imagePlaygroundSheet(
    isPresented: $isPresented,
    concepts: [
        .text("a cozy cabin"),
        .extracted(from: storyText, title: "Scene"),
    ],
    sourceImageURL: referenceImageURL
) { url in
    generatedImageURL = url
} onCancellation: {
    // user cancelled
}
```

### Style and Personalisation Modifiers

Chain these **after** `.imagePlaygroundSheet()`:

```swift
.imagePlaygroundSheet(isPresented: $isPresented, concept: "sunset") { url in
    generatedImageURL = url
}
.imagePlaygroundGenerationStyle(.sketch)              // .animation, .illustration, .sketch
.imagePlaygroundPersonalizationPolicy(.disabled)      // disable user photo/contact personalisation
```

## UIKit — ImagePlaygroundViewController

```swift
import ImagePlayground

guard ImagePlaygroundViewController.isAvailable else { return }

let playground = ImagePlaygroundViewController()
playground.delegate = self
playground.concepts = [.text("a mountain at sunset")]
// playground.sourceImageURL = referenceURL
present(playground, animated: true)
```

### Delegate

```swift
extension MyViewController: ImagePlaygroundViewController.Delegate {
    func imagePlaygroundViewController(
        _ controller: ImagePlaygroundViewController,
        didCreateImageAt imageURL: URL
    ) {
        imageView.image = UIImage(contentsOfFile: imageURL.path)
        dismiss(animated: true)
    }

    func imagePlaygroundViewControllerDidCancel(
        _ controller: ImagePlaygroundViewController
    ) {
        dismiss(animated: true)
    }
}
```

## ImageCreator — Programmatic Generation (iOS 18.4+)

Generate images without the system sheet UI — build your own custom interface:

```swift
import ImagePlayground

@available(iOS 18.4, *)
func generateImage(prompt: String) async throws -> CGImage? {
    let creator = try await ImageCreator()

    guard let style = creator.availableStyles.first else { return nil }

    let images = creator.images(
        for: [.text(prompt)],
        style: style,
        limit: 1
    )

    for try await image in images {
        return image.cgImage
    }
    return nil
}
```

### ImagePlaygroundStyle

```swift
ImagePlaygroundStyle.animation     // 3D animated-movie look
ImagePlaygroundStyle.illustration  // Flat 2D illustrated style
ImagePlaygroundStyle.sketch        // Hand-drawn sketch style
```

### Error Handling

```swift
do {
    let creator = try await ImageCreator()
    // ...
} catch ImageCreator.Error.notSupported {
    // Device does not support Apple Intelligence
} catch ImageCreator.Error.unavailable {
    // Temporarily unavailable
} catch ImageCreator.Error.unsupportedLanguage {
    // Input language not supported
} catch {
    // Other errors: .creationCancelled, .faceInImageTooSmall,
    // .unsupportedInputImage, .backgroundCreationForbidden, .creationFailed
}
```

## Genmoji — NSAdaptiveImageGlyph (iOS 18.0+)

Genmoji is surfaced through the system keyboard — not a generation API you call directly. The public API is `NSAdaptiveImageGlyph` for handling inline image glyphs in attributed text.

### Enabling Genmoji in UITextView

```swift
let textView = UITextView()
textView.isEditable = true
textView.allowsEditingTextAttributes = true
textView.supportsAdaptiveImageGlyph = true   // Shows Genmoji keyboard button
```

### Handling Genmoji in Attributed Strings

```swift
// Create attributed string from a glyph
let glyph: NSAdaptiveImageGlyph = // received from text system
let attrString = NSAttributedString(
    adaptiveImageGlyph: glyph,
    attributes: [.font: UIFont.systemFont(ofSize: 17)]
)
```

### NSAdaptiveImageGlyph Properties

```swift
glyph.imageContent          // Raw image Data
glyph.contentIdentifier     // Stable unique ID
glyph.contentDescription    // Accessibility description
glyph.contentType           // UTType
```

### Serialisation

```swift
// Save to RTFD
let data = try attributedString.data(
    from: NSRange(location: 0, length: attributedString.length),
    documentAttributes: [.documentType: NSAttributedString.DocumentType.rtfd]
)

// Restore
let restored = try NSAttributedString(data: data, documentAttributes: nil)
```

## Anti-Patterns

| Anti-Pattern                                            | Fix                                                                       |
| ------------------------------------------------------- | ------------------------------------------------------------------------- |
| Not checking availability                               | Always check `supportsImagePlayground` (SwiftUI) or `isAvailable` (UIKit) |
| Testing on Simulator                                    | Image Playground requires a physical Apple Silicon device                 |
| Expecting photorealistic output                         | Image Playground only produces cartoon/illustration styles                |
| Not copying generated URL immediately                   | The URL is temporary — copy the image data if persistence is needed       |
| Using `ImageCreator` on iOS < 18.4                      | `ImageCreator` requires iOS 18.4+; use the sheet for iOS 18.1+            |
| Not enabling `supportsAdaptiveImageGlyph` on text views | Genmoji keyboard button won't appear without it                           |
