# Writing Tools (iOS 18+)

System-level AI text rewriting, proofreading, and summarisation powered by Apple Intelligence. Automatic in standard text views — you only need to configure behaviour or opt out.

## UIKit — UITextView

Standard `UITextView` gets Writing Tools automatically. Configure with properties:

```swift
let textView = UITextView()

// Control the experience level
textView.writingToolsBehavior = .complete  // Full inline editing with animations
textView.writingToolsBehavior = .limited   // Overlay panel only
textView.writingToolsBehavior = .none      // Disable completely

// Control what content types Writing Tools may produce
textView.allowedWritingToolsResultOptions = [.plainText]
textView.allowedWritingToolsResultOptions = [.plainText, .richText, .list]

// Check if Writing Tools is currently active
if textView.isWritingToolsActive {
    // pause cloud sync, etc.
}
```

### UIWritingToolsBehavior

| Case        | Description                                              |
| ----------- | -------------------------------------------------------- |
| `.default`  | System chooses the best experience                       |
| `.complete` | Full inline editing with animations (requires TextKit 2) |
| `.limited`  | Results shown in overlay panel, not inline               |
| `.none`     | Writing Tools disabled                                   |

### UIWritingToolsResultOptions

| Option                | Description                                                                     |
| --------------------- | ------------------------------------------------------------------------------- |
| `.plainText`          | Plain text only                                                                 |
| `.richText`           | Rich text with style attributes                                                 |
| `.list`               | List formatting (`NSTextList`)                                                  |
| `.table`              | Table layout — **not allowed on UITextView**                                    |
| `.presentationIntent` | Semantic markup via `NSPresentationIntent` (headings, blockquotes, code blocks) |

### UITextViewDelegate Methods

```swift
// Pause features (cloud sync, spell check) while Writing Tools is active
func textViewWritingToolsWillBegin(_ textView: UITextView) {
    cloudSyncService.pause()
}

func textViewWritingToolsDidEnd(_ textView: UITextView) {
    cloudSyncService.resume()
}

// Protect ranges from modification (code blocks, quotes, etc.)
func textView(
    _ textView: UITextView,
    writingToolsIgnoredRangesInEnclosingRange enclosingRange: NSRange
) -> [NSValue] {
    return codeBlockRanges.map { NSValue(range: $0) }
}
```

## SwiftUI

Use the `.writingToolsBehavior(_:)` modifier on `TextEditor`, `TextField`, or selectable `Text`:

```swift
// Full inline experience
TextEditor(text: $draft)
    .writingToolsBehavior(.complete)

// Disable for code editors
TextEditor(text: $code)
    .writingToolsBehavior(.disabled)

// Disable for entire subtree
VStack {
    TextField("Name", text: $name)
    TextEditor(text: $bio)
}
.writingToolsBehavior(.limited)
```

### SwiftUI WritingToolsBehavior Values

| Value        | Description                                          |
| ------------ | ---------------------------------------------------- |
| `.automatic` | System chooses (equivalent to UIKit `.default`)      |
| `.complete`  | Full inline editing                                  |
| `.limited`   | Overlay panel only                                   |
| `.disabled`  | Writing Tools disabled (equivalent to UIKit `.none`) |

**Naming difference:** SwiftUI uses `.automatic`/`.disabled` where UIKit uses `.default`/`.none`.

## UIWritingToolsCoordinator — Custom Text Views (iOS 18.2+)

Use this only for **custom text views** that do not use `UITextView`, `UITextField`, or SwiftUI text components. Standard text views handle Writing Tools automatically.

### Setup

```swift
func configureWritingTools() {
    guard UIWritingToolsCoordinator.isWritingToolsAvailable else { return }

    let coordinator = UIWritingToolsCoordinator(delegate: self)
    coordinator.preferredBehavior = .complete
    coordinator.preferredResultOptions = [.richText, .presentationIntent]
    myCustomView.addInteraction(coordinator)
}
```

### Key Properties

```swift
// Class-level availability check
UIWritingToolsCoordinator.isWritingToolsAvailable  // Bool

// Behaviour configuration
coordinator.preferredBehavior       // what you request
coordinator.behavior                // what the system actually provides

coordinator.preferredResultOptions  // what you request
coordinator.resultOptions           // what the system actually provides

// State
coordinator.state                   // .inactive, .noninteractive, .interactiveResting, .interactiveStreaming

// Views for visual effects
coordinator.effectContainerView     // for shimmer/animation effects
coordinator.decorationContainerView // for proofreading marks
```

### Delegate — Required Methods

```swift
extension MyCustomTextView: UIWritingToolsCoordinator.Delegate {
    // 1. Provide text content to Writing Tools
    func writingToolsCoordinator(
        _ coordinator: UIWritingToolsCoordinator,
        requestsContextsFor scope: UIWritingToolsCoordinator.ContextScope,
        completion: ([UIWritingToolsCoordinator.Context]) -> Void
    ) {
        let context = UIWritingToolsCoordinator.Context(
            attributedString: self.attributedText,
            range: self.selectedRange
        )
        completion([context])
    }

    // 2. Apply text replacements
    func writingToolsCoordinator(
        _ coordinator: UIWritingToolsCoordinator,
        replace range: NSRange,
        in context: UIWritingToolsCoordinator.Context,
        proposedText: NSAttributedString,
        reason: UIWritingToolsCoordinator.TextReplacementReason,
        animationParameters: UIWritingToolsCoordinator.AnimationParameters?,
        completion: (NSAttributedString?) -> Void
    ) {
        self.replaceText(in: range, with: proposedText)
        completion(nil) // nil = accept the proposed text as-is
    }

    // 3. Update text selection
    func writingToolsCoordinator(
        _ coordinator: UIWritingToolsCoordinator,
        select ranges: [NSValue],
        in context: UIWritingToolsCoordinator.Context,
        completion: () -> Void
    ) {
        if let range = ranges.first?.rangeValue {
            self.selectedRange = range
        }
        completion()
    }

    // 4. Provide preview for inline animations
    func writingToolsCoordinator(
        _ coordinator: UIWritingToolsCoordinator,
        requestsPreviewFor animation: UIWritingToolsCoordinator.TextAnimation,
        of range: NSRange,
        in context: UIWritingToolsCoordinator.Context,
        completion: (UITargetedPreview?) -> Void
    ) {
        let preview = UITargetedPreview(view: self.textRenderingView)
        completion(preview)
    }

    // 5-8: prepareFor/finish animation, bounding/underline paths
    // ... implement as needed for your custom layout
}
```

### Coordinator State

| State                   | Description                                  |
| ----------------------- | -------------------------------------------- |
| `.inactive`             | Writing Tools not running                    |
| `.noninteractive`       | Running via system panel (no inline changes) |
| `.interactiveResting`   | Inline mode, idle between streaming bursts   |
| `.interactiveStreaming` | Actively streaming text changes              |

### ContextScope

| Scope            | Description                     |
| ---------------- | ------------------------------- |
| `.userSelection` | Only the current text selection |
| `.visibleArea`   | Only the visible portion        |
| `.fullDocument`  | The entire document             |

## Excluding Content from Writing Tools

Use the attributed string key to protect specific ranges:

```swift
let protectedString = NSMutableAttributedString(string: text)
protectedString.addAttribute(
    .excludeFromWritingTools,
    value: true,
    range: codeBlockRange
)
```

## Opt-Out Patterns

Disable Writing Tools for sensitive or inappropriate fields:

```swift
// Password fields — UIKit
passwordField.writingToolsBehavior = .none

// Code editors — SwiftUI
TextEditor(text: $code)
    .writingToolsBehavior(.disabled)

// Read-only displays
textView.writingToolsBehavior = .none
```

## iOS 26 Updates

- **Follow-up requests**: Users can enter natural-language follow-ups after a rewrite ("make it warmer", "more encouraging")
- **ChatGPT integration**: Users can generate content via ChatGPT from within Writing Tools
- **Shortcuts actions**: Proofread, Rewrite, and Summarise are available as Shortcuts automation actions
- **Custom menu placement**: Use `automaticallyInsertsWritingToolsItems = false` and `writingToolsItems` to place Writing Tools items manually in context menus

## Anti-Patterns

| Anti-Pattern                                            | Fix                                                                                          |
| ------------------------------------------------------- | -------------------------------------------------------------------------------------------- |
| Using `UIWritingToolsCoordinator` with `UITextView`     | Standard `UITextView` handles Writing Tools automatically — just set `.writingToolsBehavior` |
| Not pausing cloud sync during active session            | Use `textViewWritingToolsWillBegin`/`DidEnd` delegate methods                                |
| Enabling `.complete` with TextKit 1                     | `.complete` requires TextKit 2; system falls back to `.limited` with TextKit 1               |
| Not checking `isWritingToolsAvailable` for custom views | Always check before creating a coordinator                                                   |
| Forgetting to call completion handlers in delegate      | All delegate methods require calling the completion handler                                  |
