---
name: app-store-connect
description: Manage App Store Connect via the `asc` CLI — builds, TestFlight,
  app metadata, submissions, signing, analytics, and more.
---

# App Store Connect CLI Skill

You can help users manage their App Store Connect account using the `asc` CLI tool installed in the sandbox.

## Setup

To inspect connection state without side effects, call `appStoreConnectDoctor` — it reports whether an App Store Connect API key is connected and lists the configured teams/keys. It does not configure the CLI.

**Before the first authenticated `asc` operation in the current sandbox, call `setupAsc`.** This fetches the user's API credentials from the database and configures the CLI. Local command discovery with `--help` does not need authentication.

Pass `requireAppleSession: true` only when you need to publish builds or manage signing. For read-only operations (pulling metadata, uploading screenshots, preflight checks), pass `requireAppleSession: false` to skip the session check and avoid prompting the user to re-authenticate.

- If `setupAsc` returns `{status: "ready"}`, you're good — run `asc` commands via `bash`.
- If `setupAsc` returns `{status: "session_expired"}`, the Apple session has expired. Only returned when `requireAppleSession: true`. Call `connectAppleDeveloper` to re-authenticate.
- If `setupAsc` returns `{status: "no_api_key"}`, the user has no App Store Connect API key. Call the `connectAppleDeveloper` tool to prompt the user to set one up.
- If `setupAsc` returns `{status: "error"}`, something went wrong (e.g., backend not deployed, network issue). Tell the user about the error — do NOT call `connectAppleDeveloper` for errors.


Reuse successful setup in the current sandbox; do not repeat it on every turn. If a replacement sandbox reports missing local authentication, run `setupAsc` again. Missing local CLI configuration does not by itself mean the user's Apple session expired.

## App Context

When `setupAsc` succeeds, it returns an `app` field with the project's App Store Connect app information (if the user has previously published this project):

- `app.ascAppId` — the numeric App Store Connect app ID (use this with `--app` flags)
- `app.bundleId` — the app's bundle identifier
- `app.appName` — the app name


If `app` is `null`, the user hasn't published this project yet. In that case, run `asc apps --output table` to list all apps in their account and ask which one they want to work with.

## CLI Basics

- Run `asc` directly with `--output json` and read the result. JSON is already the non-interactive default; `jq` is not required to read it.
- Treat the installed CLI as the source of truth. Run `asc <command> --help` before using an unfamiliar command or flag.
- Use `asc search --output table "WORKFLOW"` when you know the workflow but not its current command path.
- Add `--output table` for human-readable display when showing results to the user.
- Add `--pretty` for indented JSON when debugging.
- Use supported target filters, `--sort`, and `--limit` to fetch only what the task needs. Use `--paginate` when all matching records are required.
- Use `--sort` to sort results (prefix `-` for descending).
- Use explicit flags in agent workflows; do not rely on interactive prompts.
- Use `--confirm` for destructive operations (expire, delete, submit).


### Reading results and handling failures

- Do not append `jq`, `head`, or `tail` just to inspect or prettify ASC output. Read returned IDs and states directly; do not rerun a command merely to reformat its result.
- Use `jq` only for a specific shell extraction or to reduce a large response after applying supported CLI filters. Save stdout once, check ASC's exit code, then parse that saved JSON; use the observed response shape rather than assuming every command returns `.data`.
- Keep stdout, stderr, and ASC's exit code separate. Bash already shows all three. Never feed `2>&1` into a JSON parser, discard diagnostic stderr, or append unrelated commands that hide ASC's failure status. Successful commands may write informational messages to stderr.
- If a parser fails, inspect the saved output and original diagnostics. A parser failure does not prove an ASC mutation failed: read the current App Store state before retrying a create, update, upload, or submission.
- Retry a failed mutation only after verifying that its reported prerequisite or configuration changed. If the same failure remains after repair, stop and report the blocker. After a timeout, inspect remote state before retrying; the operation may have partially succeeded.


## Initial App Availability

Use `asc pricing availability create` as the only initial availability path:

```bash
asc pricing availability create --app "APP_ID" --territory "USA" --available true --available-in-new-territories true
```

`asc pricing availability edit` requires an existing availability record. If
`create` fails, state only that availability was not configured and preserve the
`asc version`, exact command with sensitive inputs redacted, stdout/stderr, and
exit code. Run it directly so a pipeline cannot mask the exit status. Do not retry
with invented payloads or switch to `edit`.

## Resolving IDs

Most commands need IDs. Always resolve them explicitly — never assume or guess.

```bash
# App ID — by bundle ID or name
asc apps list --bundle-id "com.example.app"
asc apps list --name "My App"

# Build ID — latest valid build for a version and platform
asc builds list --app "APP_ID" --version "1.2.3" --platform IOS --processing-state VALID --sort=-uploadedDate --limit 1

# Build ID — recent builds sorted by date
asc builds list --app "APP_ID" --sort=-uploadedDate --limit 5

# Version ID
asc versions list --app "APP_ID" --paginate

# Version ID from a version string (no listing needed)
asc versions view --app "APP_ID" --version "1.2.3" --platform IOS

# Live version per platform — the API can report old versions as READY_FOR_SALE too,
# so a state filter alone does not identify what is live; --latest keeps the newest per platform
asc versions list --app "APP_ID" --state READY_FOR_SALE --latest

# Beta group IDs
asc testflight groups list --app "APP_ID" --paginate

# Exact internal group lookup (used by the invite fallback)
asc testflight groups list --app "APP_ID" --internal --name "Internal Testing" --paginate --output json

# Beta tester IDs
asc testflight testers list --app "APP_ID" --paginate
```

Use `--paginate` for a complete inventory; keep explicit limits for recent or latest-record lookups.

## Key Commands Reference

### Apps & Builds

```bash
# List all apps
asc apps --output table

# Get build details and processing state
asc builds info --build-id "BUILD_ID"

# Get the latest valid build for a version and platform
asc builds list --app "APP_ID" --version "1.2.3" --platform IOS --processing-state VALID --sort=-uploadedDate --limit 1

# Expire old builds (preview first with --dry-run)
asc builds expire-all --app "APP_ID" --older-than 90d --dry-run
asc builds expire-all --app "APP_ID" --older-than 90d --confirm
```

### End-to-End Release (Preferred)

Use `asc publish` for uploads and TestFlight releases. Follow the `app-store-publish` skill and use its `submitReview` tool for final App Store review submission.

```bash
# Upload + distribute to TestFlight in one step
asc publish testflight --app "APP_ID" --ipa "app.ipa" --group "GROUP_ID" --wait --notify

# Upload + distribute + submit external TestFlight review
asc publish testflight --app "APP_ID" --ipa "app.ipa" --group "External Testers" --wait --submit --confirm

# Upload and prepare an App Store build
asc publish appstore --app "APP_ID" --ipa "app.ipa" --version "1.2.3" --wait

# Upload and apply canonical metadata
asc publish appstore --app "APP_ID" --ipa "app.ipa" --version "1.2.3" --metadata-dir "./metadata" --wait
```

### Manual Release Steps (When More Control Is Needed)

```bash
# 1. Upload build
asc builds upload --app "APP_ID" --ipa "app.ipa" --wait

# 2. Find the build ID
asc builds list --app "APP_ID" --version "VERSION" --platform "PLATFORM" --sort=-uploadedDate --limit 1

# 3a. TestFlight: add build to group
asc builds add-groups --build-id "BUILD_ID" --group "GROUP_ID"

# 3b. App Store: reconcile monetization, attach the build, and submit
Complete the App Review details and pre-submission checks below, then follow the
`app-store-publish` skill and call `submitReview` with the project-owned submission ID
returned by `submitBuild`. When reusing an existing valid build, call that skill's
`resolveReviewSubmission` tool with its ASC app, version, build number, and platform
first. If no project-owned record matches, upload through `submitBuild` instead.
```

### TestFlight

```bash
# List beta groups
asc testflight groups list --app "APP_ID" --paginate

# List internal or external groups
asc testflight groups list --app "APP_ID" --internal --paginate
asc testflight groups list --app "APP_ID" --external --paginate

# Find an existing group by its exact name
asc testflight groups list --app "APP_ID" --internal --name "Internal Testing" --paginate --output json

# List beta testers
asc testflight testers list --app "APP_ID"

# Add a tester to a group
asc testflight testers add --app "APP_ID" --email "tester@example.com" --group "Beta"

# Remove a tester
asc testflight testers remove --app "APP_ID" --email "tester@example.com"

# Create a beta group
asc testflight groups create --app "APP_ID" --name "Beta Testers"

# Get beta feedback
asc testflight feedback list --app "APP_ID" --output table

# Get crash reports
asc testflight crashes list --app "APP_ID" --output table
```

### App Store Versions

```bash
# List versions
asc versions list --app "APP_ID"

# Create a new version
asc versions create --app "APP_ID" --version "2.0.0" --platform IOS

# Attach a build to a version
asc versions attach-build --version-id "VERSION_ID" --build-id "BUILD_ID"

# Release a pending version
asc versions release --version-id "VERSION_ID" --confirm
```

### App Metadata & Info

```bash
# Get app info
asc apps info view --app "APP_ID"

# Update short single-line fields for a locale
asc apps info edit --app "APP_ID" --version "VERSION" --platform "PLATFORM" --locale "en-US" --keywords "app,tool" --promotional-text "Limited-time launch offer"
asc apps info edit --app "APP_ID" --version "VERSION" --platform "PLATFORM" --locale "en-US" --support-url "https://example.com/support" --marketing-url "https://example.com"

# Pull existing metadata before editing, then validate and inspect the plan
asc metadata pull --app "APP_ID" --version "VERSION" --platform "PLATFORM" --dir "./metadata"
# Edit the pulled files, preserving unrelated locales and fields
asc metadata validate --dir "./metadata" --check-urls
asc metadata push --app "APP_ID" --version "VERSION" --platform "PLATFORM" --dir "./metadata" --dry-run
asc metadata push --app "APP_ID" --version "VERSION" --platform "PLATFORM" --dir "./metadata"

# Set categories
asc categories set --app "APP_ID" --primary GAMES --secondary ENTERTAINMENT

# Download/upload localizations
asc localizations download --version "VERSION_ID" --path "./localizations"
asc localizations upload --version "VERSION_ID" --path "./localizations"
asc localizations supported-locales --version "VERSION_ID" --output table
```

Use `asc metadata` for multi-locale updates and multiline text (including descriptions and release notes), even for one locale. Pull existing metadata, edit the canonical JSON files with WriteFile or MultiEdit, then validate and inspect the dry-run diff before pushing. Preserve unrelated fields and encode line breaks as JSON `\n` escapes. The Bash tool runs `sh`; do not pass multiline metadata through Bash-specific `$'...'` shell quoting.

Canonical files cover app-info localizations (`name`, `subtitle`, privacy URLs/text) and version localizations (`description`, `keywords`, `marketingUrl`, `promotionalText`, `supportUrl`, `whatsNew`). Reserve `asc apps info edit` for short single-line fields such as keywords and URLs.

Missing locales can produce delete operations; omitted fields are no-ops. If the plan includes unintended deletes, restore the missing canonical files instead of adding `--allow-deletes` to bypass the guard.

### Customer Reviews

For drafting or posting public review replies, read `.rork/skills/app-store-reviews/SKILL.md` first. It has the approval gate and bulk response workflow.

```bash
# List reviews
asc reviews --app "APP_ID" --output table

# Filter by rating
asc reviews --app "APP_ID" --stars 1

# Respond to a review
asc reviews respond --review-id "REVIEW_ID" --response "Thanks for your feedback!"
```

### Pre-submission Checks

Before submitting, always verify these:

```bash
# 1. Check build processing state — must be VALID
asc builds info --build-id "BUILD_ID"

# 2. Check encryption compliance
asc encryption declarations list --app "APP_ID"

# 3. Validate version metadata, screenshots, age rating
asc validate --app "APP_ID" --version-id "VERSION_ID"

# 4. Validate subscriptions and in-app purchases
asc validate subscriptions --app "APP_ID" --strict
asc validate iap --app "APP_ID" --strict

# 5. Check submission status
asc submit status --version-id "VERSION_ID"
```

A RevenueCat product mapping is not evidence of ASC readiness. If a subscription
remains `MISSING_METADATA`, rerun the same `asc subscriptions setup` inputs with
`--repair`, then repeat subscription validation.

When the app source contains a paywall, subscription, or in-app purchase, list the
App Store Connect catalogs before submission. If both `asc subscriptions groups list --app "APP_ID"` and `asc iap list --app "APP_ID"` are empty, stop and create or
configure the products instead of treating an empty catalog as valid.

Do not require a sandbox purchase before review submission. Instead, require the user to
confirm that the submitted App Store app's **In-App Purchase Key** in RevenueCat shows
**Valid credentials**. This is separate from the App Store Connect API key, and the
RevenueCat public API cannot report its credential status. Stop when that confirmation is
missing.

Before running `asc validate`, fetch the version's App Review details:

```bash
asc review details-for-version --version-id "VERSION_ID"
```

Create them when absent, or update the returned detail ID when they already exist:

If any current App Review contact value is missing, call `requestAppReviewContact` with
`existingContact` containing only the exact first name, last name, email, and phone returned
by `details-for-version`. Omit missing fields and never infer a value. The widget pre-populates
the existing values and asks the user to complete or confirm all four before you update ASC.
Do not ask for these values in chat prose, and do not show the widget when all four values are
already present.

```bash
asc review details-create \
  --version-id "VERSION_ID" \
  --contact-first-name "REAL_FIRST_NAME" \
  --contact-last-name "REAL_LAST_NAME" \
  --contact-email "REAL_CONTACT_EMAIL" \
  --contact-phone "REAL_CONTACT_PHONE" \
  --notes "HOW_TO_REVIEW_THE_APP"

asc review details-update \
  --id "DETAIL_ID" \
  --contact-first-name "REAL_FIRST_NAME" \
  --contact-last-name "REAL_LAST_NAME" \
  --contact-email "REAL_CONTACT_EMAIL" \
  --contact-phone "REAL_CONTACT_PHONE" \
  --notes "HOW_TO_REVIEW_THE_APP"
```

Review notes must give Apple a direct path to the core feature and identify where to find
subscriptions or in-app purchases. Also disclose external services or AI behavior,
sensitive permission prerequisites, and any region-specific behavior that affects review.
When login is required, set `--demo-account-required=true` with working demo credentials.
Never invent contact details or credentials. Use `requestAppReviewContact` for missing
review contact details; ask the user for the smallest missing fact in other cases.

If `usesNonExemptEncryption` is true on the build, create an encryption declaration:

```bash
asc encryption declarations create \
  --app "APP_ID" \
  --app-description "Uses standard HTTPS/TLS" \
  --contains-proprietary-cryptography=false \
  --contains-third-party-cryptography=true \
  --available-on-french-store=true

asc encryption declarations assign-builds --id "DECLARATION_ID" --build-id "BUILD_ID"
```

### Review Submissions

```bash
# Check submission status
asc submit status --version-id "VERSION_ID"

# Cancel a submission
asc submit cancel --version-id "VERSION_ID" --confirm
```

Follow the `app-store-publish` skill and use its complete `submitReview` call shape for final
App Store review submission. Do not use raw review creation, item attachment, or submission
commands because they bypass the server-owned deterministic gate.

### Screenshots & Previews

```bash
# Inspect the target set
asc screenshots list --version-localization "LOC_ID" --output json

# Validate local assets before any App Store Connect mutation
asc screenshots validate --path "./screenshots/" --device-type IPHONE_65

# Preview and then upload only files whose checksums are not already present
asc screenshots upload --version-localization "LOC_ID" --path "./screenshots/" --device-type IPHONE_65 --skip-existing --dry-run
asc screenshots upload --version-localization "LOC_ID" --path "./screenshots/" --device-type IPHONE_65 --skip-existing

# Resume a partial upload from the exact failure artifact printed by the CLI.
# --resume cannot be combined with the target selectors above.
asc screenshots upload --resume "./.asc/reports/screenshots-upload/failures-123.json"

# List supported sizes
asc screenshots sizes

# Preview or perform a deliberate full replacement only when the user requests it
asc screenshots upload --version-localization "LOC_ID" --path "./screenshots/" --device-type IPHONE_65 --replace --dry-run
asc screenshots upload --version-localization "LOC_ID" --path "./screenshots/" --device-type IPHONE_65 --replace --confirm

# Delete only an explicitly identified unwanted duplicate after inspection
asc screenshots delete --id "SCREENSHOT_ID" --confirm
```

**Screenshot upload rules:**

- iPhone 6.5": use `--device-type IPHONE_65` — accepts **1242x2688** and **1284x2778** pixels
- iPhone 6.7": use `--device-type IPHONE_67` — use this when your screenshots are **1290x2796**
- iPad Pro 12.9": use `--device-type IPAD_PRO_3GEN_129` — accepts **2048x2732** and **2064x2752** pixels
- Images MUST be **RGB** (no alpha channel). If you get RGBA errors, convert with: `convert input.png -alpha remove -alpha off output.png` or re-export without transparency
- If your generated screenshots are **1284x2778**, upload them as `IPHONE_65`
- Run `--skip-existing` for normal retries; the CLI waits for an uploaded screenshot's checksum to settle before matching it.
- A partial failure writes a resumable artifact under `.asc/reports/screenshots-upload/`; use `--resume` with that exact file instead of deleting records blindly.
- If checksum matching is ambiguous, the CLI stops without changing remote assets. Inspect the target set, delete only an unwanted duplicate by its exact ID with explicit confirmation, then retry with `--skip-existing`.
- `--replace` deletes every existing screenshot in the target set. Use it only for an intentional replacement, preview with `--replace --dry-run`, and pass `--confirm` only after the user approves the deletion.


### Signing (Certificates, Profiles, Bundle IDs)

```bash
# List certificates
asc certificates list

# List provisioning profiles, including active and invalid states
asc profiles list --profile-state ACTIVE,INVALID --paginate --output json

# List bundle IDs
asc bundle-ids list

# Fetch signing files
asc signing fetch --bundle-id "com.example.app" --profile-type IOS_APP_STORE --output "./signing"
```

Apple `profileState` is not a complete expiration signal. Some profiles can have a past
`expirationDate` while still reporting `ACTIVE`, so for true expired-profile audits parse
JSON and compare `attributes.expirationDate` with the current date instead of relying only on
`INVALID`.

### Subscriptions & In-App Purchases

```bash
# List subscription groups
asc subscriptions groups list --app "APP_ID"

# List subscriptions in a group
asc subscriptions list --group-id "GROUP_ID"

# List in-app purchases
asc iap list --app "APP_ID"

# Get pricing info
asc subscriptions pricing summary --app "APP_ID"
asc iap pricing summary --app "APP_ID"

# Update the review note and submit a prepared subscription version for review
asc subscriptions update --id "SUB_ID" --review-note "Same paywall structure, design may differ"
asc subscriptions versions list --subscription-id "SUB_ID" --state PREPARE_FOR_SUBMISSION
asc review submissions-create --app "APP_ID" --platform IOS
asc review items add --submission "SUBMISSION_ID" --item-type subscriptionVersions --item-id "SUBSCRIPTION_VERSION_ID"
asc review submissions-submit --id "SUBMISSION_ID" --confirm
```

### Analytics & Sales

```bash
# Download sales report
asc analytics sales --vendor "VENDOR_NUMBER" --type SALES --subtype SUMMARY --frequency DAILY --date "2024-01-20" --decompress

# Create analytics report request
asc analytics request --app "APP_ID" --access-type ONGOING --reuse-existing

# Get analytics data
asc analytics view --request-id "REQUEST_ID"
```

### CLI Coverage

```bash
# Check whether a workflow is CLI-supported, partial, web-only, or blocked by Apple's public API
asc capabilities --area release,monetization --output table
```

### Devices

```bash
# List registered devices
asc devices list --output table

# Register a new device
asc devices register --name "My iPhone" --udid "UDID" --platform IOS
```

## Publishing to App Store

When the user asks to publish their app, follow this flow. All data (appName, bundleId, version, platform, teamId) comes from the chat message payload — do NOT read app.json, Info.plist, or project.pbxproj for this data.

### Standard publishing flow

1. **Setup App Store Connect** — call `setupAsc({ requireAppleSession: true })` with the teamId from the publish payload. Publishing requires a valid Apple session.
  - If `status: "ready"` → proceed (App Store Connect configured, session is valid).
  - If `status: "session_expired"` → App Store Connect is configured but the Apple Developer session has expired. Call `connectAppleDeveloper` to re-authenticate, then call `setupAsc` again.
  - If `status: "no_api_key"` → call `connectAppleDeveloper` to set up authentication.
2. **Ensure certificate** — call `ensureCertificate({ teamId })`.
  - If `status: "ok"` → certificate is ready (stored server-side, you don't need to pass it to submitBuild).
  - If `status: "error"` with `code: "UNKNOWN_CERT_EXISTS"` → explain to user: a distribution certificate exists in their Apple account but we don't have its private key. They need to revoke it at https://developer.apple.com/account/resources/certificates/list and then try again. **STOP here.**
  - If `status: "error"` with `code: "CERT_LIMIT_REACHED"` → explain: their account has too many distribution certificates. They need to revoke one at https://developer.apple.com/account/resources/certificates/list. **STOP here.**
  - If `status: "error"` with `code: "NO_SESSION"` → explain: no valid Apple Developer session. They need to authenticate first.
3. **Ensure app** — call `ensureApp({ teamId, bundleId, appName, platform, version })`.
4. **Sync capabilities** — call `syncCapabilities({ teamId, bundleId, xcodeProjectPath })`. This reads the project entitlements and enables the matching capabilities in the Apple Developer Portal.
**PLA / Agreement errors**: If ANY step above (ensureCertificate, ensureApp, syncCapabilities) returns an error mentioning "PLA Update available", "Program License Agreement", or "Access forbidden" with agreement-related text, STOP immediately. Do NOT proceed to `submitBuild`. Explain to the user that they need to accept the latest Apple Developer Program License Agreement at https://developer.apple.com/account before publishing. This cannot be done programmatically.
  - **For Swift projects**: same as `submitBuild` — if `rork.json` specifies a non-root `path` for the Swift app, pass it as `xcodeProjectPath` so capability sync can locate the `.xcodeproj` and entitlements files.
  - **For React Native projects**: if `rork.json` specifies a non-root app `path` (e.g. `"expo"` or `"apps/mobile"`), pass it as `xcodeProjectPath` so capability sync reads entitlements from the same app directory that the build uses.
  - If the result returns `status: "unsupported"`, stop and tell the user these capabilities are not handled by our automatic sync yet. They need to remove those features for now or complete the required Apple-side manual setup/approval before publishing.
5. **Enable additional capabilities** (if needed) — use `asc` commands for standard capabilities:
```bash
asc bundle-ids capabilities add --bundle "BUNDLE_ID" --capability CAPABILITY_TYPE
```
6. **Submit build** — call `submitBuild({ teamId, bundleId, appName, version, platform, xcodeProjectPath, ascAppId })`. The certificate is looked up server-side.
  - Pass `ascAppId` from the `ensureApp` result (step 3). This is needed for the automatic TestFlight invite after the build succeeds.
  - **For Swift projects**: before calling, read `rork.json` at the project root. If the Swift app entry has a `path` value other than `"."` (e.g. `"ios"`), pass it as `xcodeProjectPath`. This tells the build where to find the `.xcodeproj`/`.xcworkspace`.
  - **For React Native projects**: before calling, read `rork.json` at the project root. If the app entry has a `path` value other than `"."` (e.g. `"expo"` or `"apps/mobile"`), pass it as `xcodeProjectPath`. This tells the build where to find the React Native app project.
  - `submitBuild` triggers the build and **waits for it to complete**. Build progress is streamed to the user in real-time. The tool returns the final result (success or failure) directly.
  - If the tool returns `{ status: "ok" }`, retain its `submissionId`, continue to TestFlight handling and, for App Store intent, the review submission step.
  - If the tool returns `{ status: "error" }`, analyze the `message` and `details` fields and decide:
    - **Capability mismatch** → fix via `syncCapabilities` or `asc` commands, retry
    - **Unsupported/manual capability** → explain which entitlement is unsupported by our automation and stop unless the user removes it or confirms they have completed the required Apple-side setup
    - **Metadata error** → fix the issue, retry
    - **Compilation error** → explain to user, do NOT retry (code issue)
    - **Certificate error** → explain to user, do NOT retry (must resolve manually)
    - **PLA / Agreement error** (message contains "PLA Update available", "Program License Agreement", or "agree to the latest") → do NOT retry. Explain to the user: (1) Apple requires them to accept an updated Program License Agreement before any builds can be submitted, (2) go to https://developer.apple.com/account and sign in, (3) a banner about the updated agreement will appear — accept it, (4) then tell the agent to retry the build. This is NOT fixable by the agent — do not attempt to retry or work around it.
  - Follow the `submitBuild` tool's retry policy. On `RETRY_LIMIT_REACHED`, explain the persistent failure and stop.
7. **TestFlight invite** — after `submitBuild` returns `{ status: "ok" }`, do **not** manually create groups or add testers by default. The backend automatically sends the TestFlight invite using the `ascAppId` passed to `submitBuild`.
  - Treat the backend invite as the source of truth.
  - Tell the user the build was uploaded and the TestFlight invite is being handled automatically when they only asked for TestFlight.
  - Only use `asc` CLI as a fallback if the user explicitly says the invite did not arrive or asks you to debug it.
  - If you need the fallback flow, first run `asc testflight groups list --app "APP_ID" --internal --name "Internal Testing" --paginate --output json` and reuse an existing exact-name group. Never create a new group blindly. The filtered lookup returns all matching pages only when `--paginate` is set.
8. **Submit for App Store review** — when the user asked to publish to the App Store, complete the App Review details above, run `asc validate`, and follow the `app-store-publish` skill. For a monetized iOS app using RevenueCat, ask the user to confirm the matching app's bundle ID and that its In-App Purchase Key shows Valid credentials, then call `submitReview({ submissionId, compliance, revenueCatAppStoreCredentialsConfirmed: true })`. Never set the confirmation flag from inference or dashboard troubleshooting; if confirmation is missing, ask and stop. The server resolves and validates the App Store app, version, platform, and build from that project-owned record.
  - When reusing an existing valid build, call `resolveReviewSubmission({ ascAppId, version, buildNumber, platform })` first and use its `submissionId`.
  - If the resolver returns `not_found`, do not submit the external build directly. Upload a new project-owned build through `submitBuild`.
  - If `status: "submitted"` or `status: "already_submitted"`, report the review submission state.
  - If `status: "blocked"` with `REVENUECAT_APP_STORE_CREDENTIALS_UNCONFIRMED`, ask for the missing confirmation and retry once with `revenueCatAppStoreCredentialsConfirmed: true`; do not report that the credentials are invalid.
  - For any other `status: "blocked"`, fix the listed monetization issues before retrying.
  - If `status: "reauthentication_required"`, reconnect Apple and retry.
  - Do not create or submit review submissions with raw `asc` commands because that bypasses the server-owned monetization gate.


### Session errors

- Missing local ASC authentication: rerun `setupAsc` in the current sandbox and follow its result handling above.
- A session restoration or network error alone does not prove expiry. Inspect the tool's diagnostics and use `checkAppleSession` when Apple-session validity is uncertain.
- When the tool explicitly reports an expired or missing Apple Developer session, call `connectAppleDeveloper`, then retry the failed step after re-authentication completes.


### Error recovery

- Only retry for infrastructure/configuration errors that you can fix (capabilities, metadata, session re-auth).
- Never retry for code compilation errors or certificate issues.
- Never retry for PLA/agreement errors — the user must accept the agreement in their browser at https://developer.apple.com/account first.
- After fixing an issue, call `submitBuild` again — it tracks attempt count automatically.
- If you've exhausted retries, explain what went wrong and suggest manual steps.


## Tips

- The `setupAsc` response includes the app ID for the current project — use it directly with `--app` flags instead of listing apps first.
- If the app context is not available, run `asc apps --output table` to find the right app ID.
- Use `--output table` when presenting results to the user for readability.
- Prefer `asc publish testflight` for TestFlight and `asc publish appstore` for App Store uploads. Follow the `app-store-publish` skill for final App Store review submission.
- Before submitting, always check build state is `VALID` (not processing) and run `asc validate`.
- When the user asks about "my app" and you have the app ID from `setupAsc`, use it directly. If they have multiple apps or no app context, list apps and confirm.
- For sorting: prefix the field with `-` and use `=` so the CLI does not parse it as another flag (e.g., `--sort=-uploadedDate`).
- Bash times out after 60 seconds. Bound CLI waits below that deadline; for build processing use `asc builds wait --build-id "BUILD_ID" --timeout 50s --poll-interval 10s --fail-on-invalid`. Report a bounded timeout instead of starting another wait in the same turn; stop processing polls on `VALID`, `FAILED`, or `INVALID`.


## Available tools

### appStoreConnectDoctor

Read-only check of the user's App Store Connect setup: reports whether an App Store
Connect API key is connected and lists the configured teams/keys.
Use it to inspect ASC connection state (e.g. before a publishing flow). It does NOT
configure the CLI or touch any Apple session — call `setupAsc` for that.

```json
{"type":"object","properties":{}}
```

### setupAsc

Set up App Store Connect for the current user.
This fetches the user's API credentials and configures the `asc` CLI in the sandbox.
Call this tool before the first authenticated `asc` operation in the current sandbox. Local `--help` does not need it.
Reuse successful setup in the current sandbox; do not repeat it every turn.
If a replacement sandbox reports missing local CLI authentication, call this tool again.

Set `requireAppleSession` to `true` only when you need to publish builds or manage signing.
For read-only operations (pulling metadata, screenshots, preflight checks), set it to `false`.

Returns:
- `{status: "ready"}` — App Store Connect is configured (and session is valid if required).
- `{status: "session_expired"}` — configured, but Apple session expired. Call `connectAppleDeveloper` to re-authenticate.
- `{status: "no_api_key"}` — user has no API key. Call `connectAppleDeveloper` to set one up.

```json
{"type":"object","properties":{"teamId":{"description":"Defaults to the project's prior team or latest authentication.","type":"string"},"requireAppleSession":{"default":false,"description":"Whether a fresh Apple Developer session is required. Set to true only for publishing builds or managing signing. Defaults to false.","type":"boolean"}}}
```

### connectAppleDeveloper

Trigger the Apple Developer login flow.
The user will see an inline widget to enter their Apple Developer credentials, complete 2FA,
and select their team. The tool blocks until the user completes authentication.
After it returns successfully, call `setupAsc` again with the `teamId` returned by this tool.

Use when `setupAsc` returns `{status: "no_api_key"}` or `{status: "session_expired"}`.
Do NOT use when `setupAsc` returns `{status: "error"}` — errors mean something else went wrong.

```json
{"type":"object","properties":{}}
```

### requestAppReviewContact

Request the real contact information Apple requires for App Review.
Before calling, read the exact current App Store version with
`asc review details-for-version --version-id "VERSION_ID"`. If any contact field is
missing, pass only the values returned by ASC in `existingContact`; omit missing values.
Never infer or invent a prefill value. The user sees one inline form with separate first-name,
last-name, email, and phone fields. Existing ASC values are prefilled and remain editable.
The tool blocks until the user explicitly submits all four fields and returns Apple-ready values.

Use this instead of asking for App Review contact information in chat prose.
Do not update ASC before this tool returns. Do not call it when all four current App Review
contact values are already present.

```json
{"type":"object","properties":{"existingContact":{"description":"Exact contact values read from the current App Store version. Omit missing fields.","type":"object","properties":{"contactFirstName":{"type":"string"},"contactLastName":{"type":"string"},"contactEmail":{"type":"string"},"contactPhone":{"type":"string"}}}}}
```

### checkAppleSession

Check if a valid Apple Developer session exists for a team.
Call this at the start of the publishing flow, BEFORE ensureCertificate or syncCapabilities.
If the session is expired, call `connectAppleDeveloper` to re-authenticate.

```json
{"type":"object","properties":{"teamId":{"type":"string","description":"Apple Developer Team ID"}},"required":["teamId"]}
```

### ensureCertificate

Ensure a valid distribution certificate exists for a team.
Checks the database for a stored cert, validates it against Apple, and creates a new one if needed.
The certificate is stored server-side — you do NOT receive it. Call `submitBuild` after this succeeds.
If the certificate limit is reached or an unknown cert exists, returns a structured error.

```json
{"type":"object","properties":{"teamId":{"type":"string","description":"Apple Developer Team ID"}},"required":["teamId"]}
```

### ensureApp

Ensure an app record exists in App Store Connect for the given bundle ID.
Creates the app if it doesn't exist. Uses the stored Apple Developer session.

```json
{"type":"object","properties":{"teamId":{"type":"string","description":"Apple Developer Team ID"},"bundleId":{"type":"string","description":"App bundle identifier"},"appName":{"type":"string","description":"App name for App Store (30 characters or fewer)"},"platform":{"type":"string","enum":["IOS","TV_OS","VISION_OS"],"description":"Target platform"},"version":{"description":"App version string","type":"string"}},"required":["teamId","bundleId","appName","platform"]}
```

### syncCapabilities

Sync the bundle ID capabilities in Apple Developer Portal with the project's entitlements.
Reads entitlements from the current project snapshot and enables/disables capabilities accordingly.
Also handles extension bundle IDs and their capabilities.

For Swift projects: check `rork.json` at the project root. If the Swift app has a
non-root `path` (e.g. `"ios"`), pass it as `xcodeProjectPath` so the sync can
locate the `.xcodeproj` and entitlements files.

For React Native projects: check `rork.json` at the project root. If the app has a
non-root `path` (e.g. `"expo"`), pass it as `xcodeProjectPath`
so sync reads entitlements from the same app directory the build uses.

`xcodeProjectPath` is REQUIRED when `rork.json` lists more than one React Native
or Swift app; the sync is rejected before upload otherwise.

```json
{"type":"object","properties":{"teamId":{"type":"string","description":"Apple Developer Team ID"},"bundleId":{"type":"string","description":"App bundle identifier"},"xcodeProjectPath":{"description":"Relative path from project root to the native app directory or Xcode project directory (e.g. 'expo' or 'ios'). Read from rork.json app path for React Native and Swift projects.","type":"string","minLength":1,"maxLength":120}},"required":["teamId","bundleId"]}
```

### submitBuild

Trigger an App Store build on the macOS runner and wait for it to complete.
The distribution certificate is looked up server-side — you do NOT need to pass it.
Call `ensureCertificate` first to make sure a valid cert exists, then call this.
The server repeats capability and provisioning-profile checks before dispatch.
If Apple approval is required, stop and wait for the user to confirm approval before retrying.

Build progress is streamed to the user in real-time. The tool returns the final
result (success or failure) directly — do NOT poll or send follow-up messages.

RETRY POLICY — STRICTLY ENFORCED:
- You may retry AT MOST ONCE after a failure (2 total attempts maximum).
- After 2 failed submissions, STOP IMMEDIATELY. Report the errors to the user
  and ask them to resolve the issues manually.
- Do NOT attempt a third submission under any circumstances.
- Do NOT rationalize additional retries. The build environment is deterministic —
  if it failed twice with the same type of error, retrying will not help.
- "CI might use stale stuff" is NOT a valid reason to retry — builds use the
  server-pinned project snapshot captured for the submission.

For Swift projects: check `rork.json` at the project root. If the Swift app has a
non-root `path` (e.g. `"ios"`), pass it as `xcodeProjectPath` so the build can
locate the `.xcodeproj`/`.xcworkspace`.

For React Native projects: pass the selected app's non-root `rork.json` path
(e.g. `"expo"`) as `xcodeProjectPath` so the build uses that app directory.

`xcodeProjectPath` is REQUIRED when `rork.json` lists more than one React Native
or Swift app (e.g. an Expo app plus a Swift app); the submission is rejected before
upload otherwise and does not count as an attempt.

```json
{"type":"object","properties":{"teamId":{"type":"string","description":"Apple Developer Team ID"},"bundleId":{"type":"string","description":"App bundle identifier"},"appName":{"type":"string","description":"App name"},"version":{"type":"string","description":"App version (x.y.z)"},"buildId":{"description":"Immutable source identifier from the preceding App Store preflight, when available","type":"string"},"buildNumber":{"description":"Build number explicitly requested by the user or already set in the project","type":"integer","exclusiveMinimum":0,"maximum":9007199254740991},"platform":{"type":"string","enum":["IOS","TV_OS","VISION_OS"],"description":"Target platform"},"xcodeProjectPath":{"description":"Relative path from project root to the selected React Native or Swift app directory (e.g. 'expo' or 'ios'). Read from rork.json.","type":"string","minLength":1,"maxLength":120},"ascAppId":{"type":"string","description":"App Store Connect app ID from ensureApp result. Required so release tracking and the automatic TestFlight invite keep working after the build succeeds."}},"required":["teamId","bundleId","appName","version","platform","ascAppId"]}
```
