---
name: play-store-preflight
description: Run Google Play readiness checks before Android testing or production release. Read this before package validation, publishing, promotion, staged rollout, metadata, screenshots, signing, tester requirements, or policy-sensitive apps.
---

# Play Store Preflight

Use this before any Google Play release or production-readiness answer. Gather evidence from project-bound Rork tools and Play Console state; never install a third-party CLI or request shared credentials.

## Evidence To Collect

1. Package name from app config and the selected build.
2. Current signed Play build from `listPublishablePlayBuilds`, or a `generatePlayAab` run started for the current `snapshotId`, `sourceHash`, `appPath`, and framework when no matching build exists yet.
3. OAuth connection from `setupGooglePlay`.
4. Package access from `ensurePlayAppRecord`.
5. Intended target: internal, closed, open, production, staged rollout, promotion, halt, resume, or completion.
6. Version code and release name returned by a successful publish or control operation.
7. Release notes locale and text.
8. Listing metadata and assets when the target can be public or discoverable.
9. Whether Play Console completed the initial app setup and any required first manual upload or draft release.
10. Policy-sensitive traits: AI, health, finance, kids, UGC, marketplace, location, camera, contacts, microphone, purchases, subscriptions, ads, or user-data export and deletion.

## Checks

- The package name in the selected project build matches the intended Play app.
- The selected artifact is a completed Play build returned by the backend, not an arbitrary local path or URL.
- The selected artifact's `snapshotId`, `sourceHash`, `appPath`, and framework match the current app source. Generate a new Play AAB before publishing if they do not.
- The current user has a connected Google Play OAuth account.
- Play package access succeeds before any mutation.
- First-submission setup is not being skipped. If Google reports a draft app, missing first upload, or another initial-setup limitation, route the user to Play Console.
- The upload signing key matches the Play Console app's expected upload certificate.
- The version code is greater than active versions for the package when that evidence is available.
- Release notes are present when the target requires them.
- Metadata is accurate and not keyword-stuffed.
- Required screenshots and feature graphics exist for targeted device classes.
- Legal and support URLs exist when required by the app behavior.
- Data Safety, content rating, target audience, ads, and policy declarations are complete in Play Console when applicable.

If version, signing, listing, policy, or account evidence cannot be read through a typed operation, mark it unknown or manually verified. Never infer a pass.

## Track-Specific Gates

Internal testing:

- Good for trusted-tester and on-device validation.
- Does not prove production readiness.

Closed testing:

- Required before production access for newly created personal developer accounts.
- Before claiming readiness to apply for production access, confirm Play Console shows at least 12 testers opted in for the last 14 days continuously.
- Testers who opt out before 14 consecutive days do not count.

Open testing:

- Can be visible on Google Play.
- Requires listing and assets acceptable for public viewing.
- May require production access depending on developer account state.

Production:

- Requires listing, assets, policy declarations, country availability, release notes, signing evidence, and a deliberate rollout plan.
- For staged rollout, require an explicit decimal fraction and a halt or corrective-release plan.
- Validate the exact promotion or rollout transition before committing unless the user already explicitly confirmed it.

## Result Format

Return one of:

- `ready_for_internal_testing`
- `ready_for_closed_testing_plan`
- `ready_for_open_testing_plan`
- `ready_for_production_plan`
- `blocked_manual_play_console_setup`
- `blocked_build_or_signing`
- `blocked_metadata_or_assets`
- `blocked_policy`
- `blocked_missing_typed_operation`

Include the evidence, unknowns, and next safest action.
