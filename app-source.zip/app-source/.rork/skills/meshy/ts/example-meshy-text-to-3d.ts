// Example: Meshy text-to-3D through Rork Toolkit V2
//
// Usage:
//   EXPO_PUBLIC_RORK_TOOLKIT_SECRET_KEY=rork_sk_xxx bun example-meshy-text-to-3d.ts
//   bun example-meshy-text-to-3d.ts <TOOLKIT_URL> <SECRET_KEY> [PROMPT]
//
// Meshy currently exposes REST endpoints, so TypeScript uses fetch directly.
// If Meshy ships an official TypeScript SDK later, use it only if it can target
// <TOOLKIT_URL>/v2/meshy and send the Rork toolkit secret as Bearer auth.

const toolkitURL = (process.argv[2] ?? process.env["RORK_TOOLKIT_URL"] ?? "https://toolkit.rork.com").replace(/\/+$/, "");
const secretKey = process.argv[3] ?? process.env["EXPO_PUBLIC_RORK_TOOLKIT_SECRET_KEY"];
const prompt = process.argv[4] ?? "a cute robot";

if (!secretKey) {
  console.log("Usage: EXPO_PUBLIC_RORK_TOOLKIT_SECRET_KEY=rork_sk_xxx bun example-meshy-text-to-3d.ts");
  console.log("   or: bun example-meshy-text-to-3d.ts <TOOLKIT_URL> <SECRET_KEY> [PROMPT]");
  process.exit(1);
}

const link = (url: string | undefined) => url ?? "<missing>";

class MeshyRequestError extends Error {
  constructor(
    readonly status: number,
    readonly body: string,
  ) {
    super(`Meshy request failed (${status}): ${body}`);
  }
}

type MeshyTaskStatus = "PENDING" | "IN_PROGRESS" | "SUCCEEDED" | "FAILED" | "CANCELED" | "EXPIRED" | string;

type MeshyTask = {
  status: MeshyTaskStatus;
  progress?: number;
  consumed_credits?: number;
  thumbnail_url?: string;
  model_urls?: {
    glb?: string;
    usdz?: string;
    fbx?: string;
  };
  task_error?: {
    message?: string;
  };
};

function getMeshyUserMessage(error: MeshyRequestError): string {
  switch (error.status) {
    case 401:
      return "Meshy is unavailable. Please restart the app.";
    case 402:
      return "Meshy generation is temporarily unavailable. Please try again later.";
    case 429:
      return "Too many Meshy requests. Please wait and try again.";
    default:
      return `Meshy request failed (${error.status}): ${error.body}`;
  }
}

async function requestMeshy<T>(path: string, init: RequestInit = {}): Promise<T> {
  const headers = new Headers(init.headers);
  headers.set("Authorization", `Bearer ${secretKey}`);
  if (!(init.body instanceof FormData) && !headers.has("Content-Type")) {
    headers.set("Content-Type", "application/json");
  }

  const response = await fetch(`${toolkitURL}/v2/meshy${path}`, {
    ...init,
    headers,
  });

  if (!response.ok) {
    throw new MeshyRequestError(response.status, await response.text());
  }

  return (await response.json()) as T;
}

async function createTextTo3DTask(body: Record<string, unknown>): Promise<string> {
  const json = await requestMeshy<{ result?: unknown }>("/openapi/v2/text-to-3d", {
    method: "POST",
    body: JSON.stringify(body),
  });
  if (typeof json.result !== "string") {
    throw new Error(`Unexpected Meshy task response: ${JSON.stringify(json)}`);
  }
  return json.result;
}

async function waitForTextTo3DTask(taskId: string, timeoutMs = 10 * 60_000): Promise<MeshyTask> {
  const deadline = Date.now() + timeoutMs;

  while (Date.now() < deadline) {
    const task = await requestMeshy<MeshyTask>(`/openapi/v2/text-to-3d/${taskId}`, { method: "GET" });
    console.log(`Task ${taskId}: ${task.status} ${task.progress ?? 0}%`);

    if (task.status === "SUCCEEDED") return task;
    if (["FAILED", "CANCELED", "EXPIRED"].includes(task.status)) {
      throw new Error(`Meshy task ${taskId} ended with ${task.status}: ${task.task_error?.message ?? "unknown error"}`);
    }

    await new Promise((resolve) => setTimeout(resolve, 5_000));
  }

  throw new Error(`Timed out waiting for Meshy task ${taskId}`);
}

try {
  console.log(`POST ${toolkitURL}/v2/meshy/openapi/v2/text-to-3d`);
  const previewTaskId = await createTextTo3DTask({
    mode: "preview",
    prompt,
    ai_model: "meshy-7",
  });
  console.log("task:", previewTaskId);
  console.log(`GET  ${toolkitURL}/v2/meshy/openapi/v2/text-to-3d/${previewTaskId}`);

  const previewTask = await waitForTextTo3DTask(previewTaskId);

  console.log("consumed_credits:", previewTask.consumed_credits ?? "<unknown>");
  console.log("thumbnail:", link(previewTask.thumbnail_url));
  console.log("model glb:", link(previewTask.model_urls?.glb));
} catch (error) {
  if (error instanceof MeshyRequestError) {
    console.error(getMeshyUserMessage(error));
    process.exit(1);
  }
  throw error;
}
