// Example: Meshy text-to-3D through Rork Toolkit V2
//
// Usage:
//   EXPO_PUBLIC_RORK_TOOLKIT_SECRET_KEY=rork_sk_xxx swift example-meshy-text-to-3d.swift
//   swift example-meshy-text-to-3d.swift <TOOLKIT_URL> <SECRET_KEY> [PROMPT]
//
// Meshy currently exposes REST endpoints, so Swift uses URLSession directly.
// If Meshy ships an official Swift SDK later, use it only if it can target
// <TOOLKIT_URL>/v2/meshy and send the Rork toolkit secret as Bearer auth.

import Foundation

let environment = ProcessInfo.processInfo.environment
let toolkitURL = (CommandLine.arguments.count >= 2 ? CommandLine.arguments[1] : environment["RORK_TOOLKIT_URL"] ?? "https://toolkit.rork.com")
    .trimmingCharacters(in: CharacterSet(charactersIn: "/"))
let secretKey = CommandLine.arguments.count >= 3 ? CommandLine.arguments[2] : environment["EXPO_PUBLIC_RORK_TOOLKIT_SECRET_KEY"]
let prompt = CommandLine.arguments.count >= 4 ? CommandLine.arguments[3] : "a cute robot"

guard let secretKey, !secretKey.isEmpty else {
    print("Usage: EXPO_PUBLIC_RORK_TOOLKIT_SECRET_KEY=rork_sk_xxx swift example-meshy-text-to-3d.swift")
    print("   or: swift example-meshy-text-to-3d.swift <TOOLKIT_URL> <SECRET_KEY> [PROMPT]")
    exit(1)
}

enum MeshyError: LocalizedError {
    case authError
    case insufficientBalance
    case rateLimited
    case serverError(Int, String)
    case invalidResponse(String)
    case nonHTTPResponse
    case taskFailed(String)
    case timedOut(String)

    var errorDescription: String? {
        switch self {
        case .authError: "Meshy is unavailable. Please restart the app."
        case .insufficientBalance: "Meshy generation is temporarily unavailable. Please try again later."
        case .rateLimited: "Too many Meshy requests. Please wait and try again."
        case .serverError(let status, let body): "Meshy request failed (\(status)): \(body)"
        case .invalidResponse(let message): "Unexpected Meshy response: \(message)"
        case .nonHTTPResponse: "Unexpected non-HTTP Meshy response."
        case .taskFailed(let message): "Meshy task failed: \(message)"
        case .timedOut(let taskId): "Meshy task timed out: \(taskId)"
        }
    }
}

struct TaskIdResponse: Decodable {
    let result: String
}

struct MeshyTask: Decodable {
    let id: String?
    let status: String
    let progress: Int?
    let consumedCredits: Int?
    let thumbnailURL: String?
    let taskError: TaskError?
    let modelURLs: ModelURLs?

    enum CodingKeys: String, CodingKey {
        case id
        case status
        case progress
        case consumedCredits = "consumed_credits"
        case thumbnailURL = "thumbnail_url"
        case taskError = "task_error"
        case modelURLs = "model_urls"
    }

    struct TaskError: Decodable {
        let message: String?
    }

    struct ModelURLs: Decodable {
        let glb: String?
        let usdz: String?
        let fbx: String?
    }
}

func link(_ url: String?) -> String {
    url ?? "<missing>"
}

func meshyURL(_ path: String) throws -> URL {
    guard let url = URL(string: "\(toolkitURL)/v2/meshy\(path)") else {
        throw URLError(.badURL)
    }
    return url
}

func decodeErrorBody(_ data: Data) -> String {
    String(data: data, encoding: .utf8) ?? ""
}

func handleStatus(_ status: Int, data: Data) throws {
    switch status {
    case 200..<300:
        return
    case 401:
        throw MeshyError.authError
    case 402:
        throw MeshyError.insufficientBalance
    case 429:
        throw MeshyError.rateLimited
    default:
        throw MeshyError.serverError(status, decodeErrorBody(data))
    }
}

func postJSON<Response: Decodable>(_ path: String, body: [String: Any]) async throws -> Response {
    var request = URLRequest(url: try meshyURL(path))
    request.httpMethod = "POST"
    request.setValue("application/json", forHTTPHeaderField: "Content-Type")
    request.setValue("Bearer \(secretKey)", forHTTPHeaderField: "Authorization")
    request.httpBody = try JSONSerialization.data(withJSONObject: body)
    request.timeoutInterval = 120

    let (data, response) = try await URLSession.shared.data(for: request)
    guard let httpResponse = response as? HTTPURLResponse else {
        throw MeshyError.nonHTTPResponse
    }
    try handleStatus(httpResponse.statusCode, data: data)
    return try JSONDecoder().decode(Response.self, from: data)
}

func getJSON<Response: Decodable>(_ path: String) async throws -> Response {
    var request = URLRequest(url: try meshyURL(path))
    request.httpMethod = "GET"
    request.setValue("Bearer \(secretKey)", forHTTPHeaderField: "Authorization")
    request.timeoutInterval = 60

    let (data, response) = try await URLSession.shared.data(for: request)
    guard let httpResponse = response as? HTTPURLResponse else {
        throw MeshyError.nonHTTPResponse
    }
    try handleStatus(httpResponse.statusCode, data: data)
    return try JSONDecoder().decode(Response.self, from: data)
}

func waitForTextTo3DTask(_ taskId: String, timeoutSeconds: TimeInterval = 600) async throws -> MeshyTask {
    let deadline = Date().addingTimeInterval(timeoutSeconds)

    while Date() < deadline {
        let task: MeshyTask = try await getJSON("/openapi/v2/text-to-3d/\(taskId)")
        print("Task \(taskId): \(task.status) \(task.progress ?? 0)%")

        switch task.status {
        case "SUCCEEDED":
            return task
        case "FAILED":
            throw MeshyError.taskFailed(task.taskError?.message ?? "Unknown Meshy error")
        case "CANCELED", "EXPIRED":
            throw MeshyError.taskFailed(task.status)
        default:
            try await Task.sleep(nanoseconds: 5_000_000_000)
        }
    }

    throw MeshyError.timedOut(taskId)
}

let previewRequest: [String: Any] = [
    "mode": "preview",
    "prompt": prompt,
    "ai_model": "meshy-7",
]

print("POST \(toolkitURL)/v2/meshy/openapi/v2/text-to-3d")
let previewResponse: TaskIdResponse = try await postJSON("/openapi/v2/text-to-3d", body: previewRequest)
print("task: \(previewResponse.result)")
print("GET  \(toolkitURL)/v2/meshy/openapi/v2/text-to-3d/\(previewResponse.result)")

let previewTask = try await waitForTextTo3DTask(previewResponse.result)

print("consumed_credits: \(previewTask.consumedCredits.map(String.init) ?? "<unknown>")")
print("thumbnail: \(link(previewTask.thumbnailURL))")
print("model glb: \(link(previewTask.modelURLs?.glb))")
