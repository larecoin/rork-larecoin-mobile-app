import { gateway } from "@ai-sdk/gateway";
import { writeFileSync } from "node:fs";
import WebSocket from "ws";

const toolkitURL = process.env["TOOLKIT_URL"] ?? "http://localhost:3003";
const secretKey = process.env["RORK_TOOLKIT_SECRET"];
const modelId = process.env["REALTIME_MODEL_ID"] ?? "openai/gpt-realtime-2";
const prompt = process.argv.slice(2).join(" ") || "Say hello in one sentence.";
const outputPath = process.env["REALTIME_OUTPUT_PATH"] ?? "reply.wav";

if (!secretKey) {
  throw new Error("Set RORK_TOOLKIT_SECRET to the generated app Toolkit secret before running this smoke test.");
}

function buildToolkitRealtimeUrl(toolkitURL: string, modelId: string): string {
  const url = new URL("/v2/vercel/v4/ai/realtime-model", toolkitURL);
  url.protocol = url.protocol === "https:" ? "wss:" : "ws:";
  url.searchParams.set("ai-model-id", modelId);
  return url.toString();
}

const model = gateway.experimental_realtime(modelId);
const config = model.getWebSocketConfig({
  token: secretKey,
  url: buildToolkitRealtimeUrl(toolkitURL, modelId),
});
const socket = new WebSocket(config.url, config.protocols);
const audioChunks: Buffer[] = [];

type ClientEvent = Parameters<typeof model.serializeClientEvent>[0];

async function send(event: ClientEvent): Promise<void> {
  socket.send(JSON.stringify(await model.serializeClientEvent(event)));
}

socket.on("open", async () => {
  await send({
    type: "conversation-item-create",
    item: {
      type: "text-message",
      role: "user",
      text: prompt,
    },
  });
  await send({ type: "response-create" });
});

socket.on("message", (data) => {
  const parsed = model.parseServerEvent(JSON.parse(data.toString()));
  const events = Array.isArray(parsed) ? parsed : [parsed];

  for (const event of events) {
    switch (event.type) {
      case "audio-transcript-delta":
        process.stdout.write(event.delta);
        break;
      case "audio-delta":
        audioChunks.push(Buffer.from(event.delta, "base64"));
        break;
      case "response-done":
        writeFileSync(outputPath, toWav(Buffer.concat(audioChunks), 24000));
        process.stdout.write(`\nSaved ${outputPath}\n`);
        socket.close();
        break;
      case "error":
        console.error(event.message);
        socket.close();
        break;
    }
  }
});

socket.on("error", (error) => {
  console.error(error);
});

function toWav(pcm: Buffer, sampleRate: number): Buffer {
  const header = Buffer.alloc(44);
  header.write("RIFF", 0);
  header.writeUInt32LE(36 + pcm.length, 4);
  header.write("WAVE", 8);
  header.write("fmt ", 12);
  header.writeUInt32LE(16, 16);
  header.writeUInt16LE(1, 20);
  header.writeUInt16LE(1, 22);
  header.writeUInt32LE(sampleRate, 24);
  header.writeUInt32LE(sampleRate * 2, 28);
  header.writeUInt16LE(2, 32);
  header.writeUInt16LE(16, 34);
  header.write("data", 36);
  header.writeUInt32LE(pcm.length, 40);

  return Buffer.concat([header, pcm]);
}
