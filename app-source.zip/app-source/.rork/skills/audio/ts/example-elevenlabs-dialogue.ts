// @ts-nocheck
// Example: Multi-speaker dialogue via Rork proxy (ElevenLabs)
//
// The Vercel AI SDK has no model for ElevenLabs text-to-dialogue, so this
// endpoint always uses raw fetch — works identically on web and React Native.
//
// Usage: bun example-elevenlabs-dialogue.ts <TOOLKIT_URL> <SECRET_KEY> <VOICE_ID_1> <VOICE_ID_2>

const toolkitURL = process.argv[2];
const secretKey = process.argv[3];
const voiceId1 = process.argv[4];
const voiceId2 = process.argv[5];
const elevenlabsV1URL = `${toolkitURL}/v2/elevenlabs/v1`;

if (!toolkitURL || !secretKey || !voiceId1 || !voiceId2) {
  console.log("Usage: bun example-elevenlabs-dialogue.ts <TOOLKIT_URL> <SECRET_KEY> <VOICE_ID_1> <VOICE_ID_2>");
  process.exit(1);
}

const response = await fetch(`${elevenlabsV1URL}/text-to-dialogue`, {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
    Authorization: `Bearer ${secretKey}`,
  },
  body: JSON.stringify({
    inputs: [
      { text: "Hello, how are you today?", voice_id: voiceId1 },
      { text: "I'm doing great, thanks for asking!", voice_id: voiceId2 },
    ],
    model_id: "eleven_v3",
  }),
});

if (!response.ok) {
  console.error(`Error: ${response.status} ${await response.text()}`);
  process.exit(1);
}

const audioData = await response.arrayBuffer();
await Bun.write("output-dialogue.mp3", audioData);
console.log(`Dialogue audio saved to: output-dialogue.mp3 (${audioData.byteLength} bytes)`);
