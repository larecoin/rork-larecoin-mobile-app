// @ts-nocheck
// Example: Text-to-speech via Rork proxy (ElevenLabs)
//
// Usage: bun example-elevenlabs-tts.ts <TOOLKIT_URL> <SECRET_KEY> <VOICE_ID> [TEXT]

const toolkitURL = process.argv[2];
const secretKey = process.argv[3];
const voiceId = process.argv[4];
const text = process.argv[5] ?? "Hello world";
const elevenlabsV1URL = `${toolkitURL}/v2/elevenlabs/v1`;

if (!toolkitURL || !secretKey || !voiceId) {
  console.log("Usage: bun example-elevenlabs-tts.ts <TOOLKIT_URL> <SECRET_KEY> <VOICE_ID> [TEXT]");
  process.exit(1);
}

const response = await fetch(`${elevenlabsV1URL}/text-to-speech/${voiceId}`, {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
    Authorization: `Bearer ${secretKey}`,
  },
  body: JSON.stringify({
    text,
    model_id: "eleven_v3",
  }),
});

if (!response.ok) {
  console.error(`Error: ${response.status} ${await response.text()}`);
  process.exit(1);
}

const audioData = await response.arrayBuffer();
await Bun.write("output.mp3", audioData);
console.log(`Audio saved to: output.mp3 (${audioData.byteLength} bytes)`);
