type GatewayTranscriptionOptions = {
  toolkitURL: string;
  secretKey: string;
  audioBase64: string;
  mediaType: string;
  model?: "xai/grok-stt" | "openai/gpt-4o-mini-transcribe";
};

type GatewayTranscriptionResult = {
  text: string;
  segments?: unknown[];
  language?: string;
  durationInSeconds?: number;
  warnings?: unknown[];
};

export async function transcribeWithGateway({
  toolkitURL,
  secretKey,
  audioBase64,
  mediaType,
  model = "xai/grok-stt",
}: GatewayTranscriptionOptions): Promise<GatewayTranscriptionResult> {
  const response = await fetch(`${toolkitURL}/v2/vercel/v4/ai/transcription-model`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${secretKey}`,
      "Content-Type": "application/json",
      "ai-model-id": model,
      "ai-gateway-protocol-version": "0.0.1",
    },
    body: JSON.stringify({
      audio: audioBase64,
      mediaType,
    }),
  });

  if (!response.ok) {
    throw new Error(`Gateway transcription failed: ${response.status}`);
  }

  return await response.json();
}
