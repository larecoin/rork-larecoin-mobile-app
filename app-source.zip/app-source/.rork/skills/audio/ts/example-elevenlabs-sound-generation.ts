// @ts-nocheck
// Example: Sound effect generation via Rork proxy (ElevenLabs)
//
// The Vercel AI SDK has no model for ElevenLabs sound-generation, so this
// endpoint always uses raw fetch — works identically on web and React Native.
//
// Usage: bun example-elevenlabs-sound-generation.ts <TOOLKIT_URL> <SECRET_KEY> [DESCRIPTION]

const toolkitURL = process.argv[2];
const secretKey = process.argv[3];
const description = process.argv[4] ?? "A gentle rain falling on a tin roof";
const elevenlabsV1URL = `${toolkitURL}/v2/elevenlabs/v1`;

if (!toolkitURL || !secretKey) {
  console.log("Usage: bun example-elevenlabs-sound-generation.ts <TOOLKIT_URL> <SECRET_KEY> [DESCRIPTION]");
  process.exit(1);
}

const response = await fetch(`${elevenlabsV1URL}/sound-generation`, {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
    Authorization: `Bearer ${secretKey}`,
  },
  body: JSON.stringify({
    text: description,
    duration_seconds: 5,
  }),
});

if (!response.ok) {
  console.error(`Error: ${response.status} ${await response.text()}`);
  process.exit(1);
}

const audioData = await response.arrayBuffer();
await Bun.write("output-sound.mp3", audioData);
console.log(`Sound saved to: output-sound.mp3 (${audioData.byteLength} bytes)`);
