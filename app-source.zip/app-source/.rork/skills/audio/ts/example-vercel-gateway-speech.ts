type GatewaySpeechModel = "xai/grok-tts" | "openai/tts-1";

export const GATEWAY_SPEECH_VOICE_OPTIONS = {
  "xai/grok-tts": {
    defaultVoice: "eve",
    docsURL: "https://docs.x.ai/developers/model-capabilities/audio/text-to-speech#choosing-the-right-voice",
    voices: ["eve", "ara", "rex", "sal", "leo"],
  },
  "openai/tts-1": {
    defaultVoice: "alloy",
    docsURL: "https://developers.openai.com/api/docs/guides/text-to-speech",
    voices: ["alloy", "ash", "coral", "echo", "fable", "onyx", "nova", "sage", "shimmer"],
  },
} as const satisfies Record<
  GatewaySpeechModel,
  {
    defaultVoice: string;
    docsURL: string;
    voices: readonly string[];
  }
>;

type GatewaySpeechOptions = {
  toolkitURL: string;
  secretKey: string;
  text: string;
  model?: GatewaySpeechModel;
  voice?: string;
  outputFormat?: "mp3" | "wav";
};

type GatewaySpeechResult = {
  audio: string;
  warnings?: unknown[];
};

function defaultVoiceForGatewaySpeech(model: GatewaySpeechModel): string {
  return GATEWAY_SPEECH_VOICE_OPTIONS[model].defaultVoice;
}

export async function generateGatewaySpeech({
  toolkitURL,
  secretKey,
  text,
  model = "xai/grok-tts",
  voice,
  outputFormat = "mp3",
}: GatewaySpeechOptions): Promise<GatewaySpeechResult> {
  const selectedVoice = voice ?? defaultVoiceForGatewaySpeech(model);

  const response = await fetch(`${toolkitURL}/v2/vercel/v4/ai/speech-model`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${secretKey}`,
      "Content-Type": "application/json",
      "ai-model-id": model,
      "ai-gateway-protocol-version": "0.0.1",
    },
    body: JSON.stringify({
      text,
      voice: selectedVoice,
      outputFormat,
    }),
  });

  if (!response.ok) {
    throw new Error(`Gateway speech failed: ${response.status}`);
  }

  return await response.json();
}
