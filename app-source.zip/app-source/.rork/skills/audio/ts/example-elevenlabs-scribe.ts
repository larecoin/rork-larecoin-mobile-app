// @ts-nocheck
// Example: Speech-to-text via Rork proxy (ElevenLabs Scribe)
//
// Usage: bun example-elevenlabs-scribe.ts <TOOLKIT_URL> <SECRET_KEY> <AUDIO_FILE_OR_URL> [LANGUAGE_CODE]

const toolkitURL = process.argv[2];
const secretKey = process.argv[3];
const audioInput = process.argv[4];
const languageCode = process.argv[5];
const elevenlabsV1URL = `${toolkitURL}/v2/elevenlabs/v1`;

if (!toolkitURL || !secretKey || !audioInput) {
  console.log("Usage: bun example-elevenlabs-scribe.ts <TOOLKIT_URL> <SECRET_KEY> <AUDIO_FILE_OR_URL> [LANGUAGE_CODE]");
  process.exit(1);
}

const body = new FormData();
body.append("model_id", "scribe_v2");
body.append("diarize", "true");
if (languageCode) body.append("language_code", languageCode);

if (audioInput.startsWith("http://") || audioInput.startsWith("https://")) {
  body.append("source_url", audioInput);
} else {
  body.append("file", Bun.file(audioInput));
}

const response = await fetch(`${elevenlabsV1URL}/speech-to-text`, {
  method: "POST",
  headers: {
    Authorization: `Bearer ${secretKey}`,
  },
  body,
});

if (!response.ok) {
  console.error(`Error: ${response.status} ${await response.text()}`);
  process.exit(1);
}

const transcript = await response.json();
console.log(JSON.stringify(transcript, null, 2));
