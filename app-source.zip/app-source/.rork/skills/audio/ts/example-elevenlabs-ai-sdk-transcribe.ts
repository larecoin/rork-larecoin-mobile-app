// @ts-nocheck
// Example: Speech-to-text via the AI SDK ElevenLabs provider through the Rork proxy
//
// Usage: bun example-elevenlabs-ai-sdk-transcribe.ts <TOOLKIT_URL> <SECRET_KEY> <AUDIO_FILE> [LANGUAGE_CODE]
//
// Requires:
//   pnpm add ai @ai-sdk/elevenlabs

import { createElevenLabs, type ElevenLabsTranscriptionModelOptions } from "@ai-sdk/elevenlabs";
import { experimental_transcribe as transcribe } from "ai";

const toolkitURL = process.argv[2];
const secretKey = process.argv[3];
const audioPath = process.argv[4];
const languageCode = process.argv[5];

if (!toolkitURL || !secretKey || !audioPath) {
  console.log("Usage: bun example-elevenlabs-ai-sdk-transcribe.ts <TOOLKIT_URL> <SECRET_KEY> <AUDIO_FILE> [LANGUAGE_CODE]");
  process.exit(1);
}

const proxyFetch: typeof fetch = async (input, init) => {
  const request = new Request(input, init);
  const url = new URL(request.url);

  if (url.hostname === "api.elevenlabs.io") {
    const proxyBase = new URL(toolkitURL);
    url.protocol = proxyBase.protocol;
    url.host = proxyBase.host;
    url.pathname = `/v2/elevenlabs${url.pathname}`;
  }

  const headers = new Headers(request.headers);
  headers.set("Authorization", `Bearer ${secretKey}`);
  headers.delete("xi-api-key");

  return fetch(url, {
    method: request.method,
    headers,
    body: request.body,
    signal: request.signal,
    duplex: "half",
  });
};

const elevenlabs = createElevenLabs({
  apiKey: secretKey,
  fetch: proxyFetch,
});

const audio = new Uint8Array(await Bun.file(audioPath).arrayBuffer());

const result = await transcribe({
  model: elevenlabs.transcription("scribe_v2"),
  audio,
  providerOptions: {
    elevenlabs: {
      diarize: true,
      timestampsGranularity: "word",
      ...(languageCode ? { languageCode } : {}),
    } satisfies ElevenLabsTranscriptionModelOptions,
  },
});

console.log(JSON.stringify(result, null, 2));
