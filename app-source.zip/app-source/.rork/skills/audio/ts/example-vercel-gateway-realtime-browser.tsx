"use client";

import { getGatewayRealtimeProtocols } from "@ai-sdk/gateway";
import { experimental_useRealtime as useRealtime } from "@ai-sdk/react";
import type {
  Experimental_RealtimeClientEvent as RealtimeClientEvent,
  Experimental_RealtimeModel as RealtimeModel,
  Experimental_RealtimeServerEvent as RealtimeServerEvent,
  Experimental_RealtimeSessionConfig as RealtimeSessionConfig,
  UIMessage,
} from "ai";
import { FormEvent, useEffect, useMemo, useRef, useState } from "react";

const defaultRealtimeModelId = "openai/gpt-realtime-2";

const realtimeModelOptions = [
  { id: "openai/gpt-realtime-1.5", label: "GPT-Realtime 1.5" },
  { id: "openai/gpt-realtime-2", label: "GPT-Realtime 2" },
  { id: "openai/gpt-realtime-mini", label: "GPT-Realtime mini" },
  { id: "xai/grok-voice-think-fast-1.0", label: "Grok Voice Think Fast 1.0" },
];

const openAiRealtimeVoiceOptions = [
  { id: "alloy", label: "Alloy" },
  { id: "ash", label: "Ash" },
  { id: "ballad", label: "Ballad" },
  { id: "coral", label: "Coral" },
  { id: "echo", label: "Echo" },
  { id: "sage", label: "Sage" },
  { id: "shimmer", label: "Shimmer" },
  { id: "verse", label: "Verse" },
];

const xaiRealtimeVoiceOptions = [
  { id: "ara", label: "Ara" },
  { id: "eve", label: "Eve" },
  { id: "leo", label: "Leo" },
  { id: "rex", label: "Rex" },
  { id: "sal", label: "Sal" },
];

function createToolkitRealtimeModel(modelId: string): RealtimeModel {
  return {
    specificationVersion: "v4",
    provider: "rork-toolkit.vercel-realtime",
    modelId,
    async doCreateClientSecret() {
      throw new Error("Use the Toolkit realtime setup endpoint instead of minting a Gateway token.");
    },
    getWebSocketConfig(options) {
      return {
        url: options.url,
        protocols: getGatewayRealtimeProtocols(options.token),
      };
    },
    parseServerEvent(raw) {
      return raw as RealtimeServerEvent;
    },
    serializeClientEvent(event: RealtimeClientEvent) {
      return event;
    },
    buildSessionConfig(config: RealtimeSessionConfig) {
      return config;
    },
  };
}

function getVoiceOptions(modelId: string) {
  if (modelId.startsWith("xai/")) return xaiRealtimeVoiceOptions;
  return openAiRealtimeVoiceOptions;
}

function getDefaultVoiceId(modelId: string) {
  if (modelId.startsWith("xai/")) return "eve";
  return "alloy";
}

function getMessageText(message: UIMessage): string {
  return message.parts
    .map((part) => {
      if (part.type === "text") return part.text;
      if (part.type === "reasoning") return part.text;
      return "";
    })
    .filter(Boolean)
    .join(" ");
}

export function RealtimeVoiceControl({
  setupEndpoint = "/api/realtime/setup",
  instructions = "You are a helpful voice assistant. Keep replies brief.",
}: {
  setupEndpoint?: string;
  instructions?: string;
}) {
  const [selectedModelId, setSelectedModelId] = useState(defaultRealtimeModelId);
  const [selectedVoiceId, setSelectedVoiceId] = useState(() => getDefaultVoiceId(defaultRealtimeModelId));
  const [text, setText] = useState("");
  const [error, setError] = useState<string | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const voiceOptions = useMemo(() => getVoiceOptions(selectedModelId), [selectedModelId]);
  const model = useMemo(() => createToolkitRealtimeModel(selectedModelId), [selectedModelId]);
  const api = useMemo(
    () => ({ token: `${setupEndpoint}?model=${encodeURIComponent(selectedModelId)}` }),
    [selectedModelId, setupEndpoint],
  );
  const sessionConfig = useMemo<Partial<RealtimeSessionConfig>>(
    () => ({
      instructions,
      ...(selectedModelId.startsWith("xai/") ? {} : { inputAudioTranscription: {} }),
      voice: selectedVoiceId,
      turnDetection: { type: "server-vad" },
    }),
    [instructions, selectedModelId, selectedVoiceId],
  );
  const realtime = useRealtime({
    model,
    api,
    sessionConfig,
    onError(nextError) {
      setError(nextError.message);
    },
  });

  useEffect(() => {
    return () => {
      stopLocalStream();
    };
  }, []);

  function stopLocalStream(): void {
    streamRef.current?.getTracks().forEach((track) => track.stop());
    streamRef.current = null;
  }

  async function connect(): Promise<void> {
    setError(null);
    await realtime.connect();
  }

  async function startMic(): Promise<void> {
    setError(null);

    if (realtime.status !== "connected") {
      await realtime.connect();
    }

    const stream = await navigator.mediaDevices.getUserMedia({
      audio: {
        autoGainControl: true,
        echoCancellation: true,
        noiseSuppression: true,
      },
    });

    stopLocalStream();
    streamRef.current = stream;
    realtime.startAudioCapture(stream);
  }

  function stopMic(): void {
    realtime.stopAudioCapture();
    stopLocalStream();
  }

  function disconnect(): void {
    stopMic();
    realtime.stopPlayback();
    realtime.disconnect();
  }

  function sendText(event: FormEvent<HTMLFormElement>): void {
    event.preventDefault();
    const trimmedText = text.trim();
    if (!trimmedText || realtime.status !== "connected") return;

    realtime.sendTextMessage(trimmedText);
    setText("");
  }

  return (
    <section>
      <label>
        Model
        <select
          disabled={realtime.status !== "disconnected" && realtime.status !== "error"}
          value={selectedModelId}
          onChange={(event) => {
            const nextModelId = event.currentTarget.value;
            setSelectedModelId(nextModelId);
            setSelectedVoiceId(getDefaultVoiceId(nextModelId));
          }}
        >
          {realtimeModelOptions.map((option) => (
            <option key={option.id} value={option.id}>
              {option.label}
            </option>
          ))}
        </select>
      </label>

      <label>
        Voice
        <select
          disabled={realtime.status !== "disconnected" && realtime.status !== "error"}
          value={selectedVoiceId}
          onChange={(event) => setSelectedVoiceId(event.currentTarget.value)}
        >
          {voiceOptions.map((option) => (
            <option key={option.id} value={option.id}>
              {option.label}
            </option>
          ))}
        </select>
      </label>

      <p>Realtime status: {realtime.status}</p>

      <button type="button" onClick={connect} disabled={realtime.status === "connected"}>
        Connect
      </button>
      <button type="button" onClick={disconnect} disabled={realtime.status === "disconnected"}>
        Disconnect
      </button>
      <button type="button" onClick={startMic} disabled={realtime.isCapturing}>
        Start mic
      </button>
      <button type="button" onClick={stopMic} disabled={!realtime.isCapturing}>
        Stop mic
      </button>

      <form onSubmit={sendText}>
        <input value={text} onChange={(event) => setText(event.currentTarget.value)} />
        <button type="submit" disabled={realtime.status !== "connected" || !text.trim()}>
          Send
        </button>
      </form>

      {realtime.messages.map((message) => (
        <p key={message.id}>
          <strong>{message.role}:</strong> {getMessageText(message)}
        </p>
      ))}

      {error ? <p role="alert">{error}</p> : null}
    </section>
  );
}
