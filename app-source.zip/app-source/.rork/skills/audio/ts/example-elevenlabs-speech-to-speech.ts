// @ts-nocheck
// Example: Speech-to-speech via Rork proxy (ElevenLabs Voice Changer)
//
// Usage: bun example-elevenlabs-speech-to-speech.ts <TOOLKIT_URL> <SECRET_KEY> <VOICE_ID> <AUDIO_FILE> [OUTPUT_FILE]

const toolkitURL = process.argv[2];
const secretKey = process.argv[3];
const voiceId = process.argv[4];
const audioFile = process.argv[5];
const outputFile = process.argv[6] ?? "output.mp3";
const elevenlabsV1URL = `${toolkitURL}/v2/elevenlabs/v1`;

if (!toolkitURL || !secretKey || !voiceId || !audioFile) {
  console.log(
    "Usage: bun example-elevenlabs-speech-to-speech.ts <TOOLKIT_URL> <SECRET_KEY> <VOICE_ID> <AUDIO_FILE> [OUTPUT_FILE]",
  );
  process.exit(1);
}

const body = new FormData();
body.append("audio", Bun.file(audioFile));
body.append("model_id", "eleven_multilingual_sts_v2");

const response = await fetch(
  `${elevenlabsV1URL}/speech-to-speech/${voiceId}?output_format=mp3_44100_128`,
  {
    method: "POST",
    headers: {
      Authorization: `Bearer ${secretKey}`,
    },
    body,
  },
);

if (!response.ok) {
  console.error(`Error: ${response.status} ${await response.text()}`);
  process.exit(1);
}

const audioData = await response.arrayBuffer();
await Bun.write(outputFile, audioData);
console.log(`Audio saved to: ${outputFile} (${audioData.byteLength} bytes)`);
