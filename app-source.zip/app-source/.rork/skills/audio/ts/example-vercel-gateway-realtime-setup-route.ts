import type { Experimental_RealtimeSetupResponse as RealtimeSetupResponse } from "ai";

const defaultRealtimeModelId = "openai/gpt-realtime-2";
const browserDelegatedTokenPlaceholder = "rork_web_delegated_auth";

export async function POST(request: Request): Promise<Response> {
  const toolkitURL = process.env["RORK_TOOLKIT_URL"] ?? process.env["EXPO_PUBLIC_RORK_TOOLKIT_URL"];

  if (!toolkitURL) {
    return Response.json({ error: "Toolkit realtime is not configured." }, { status: 500 });
  }

  const requestUrl = new URL(request.url);
  const body = (await request.json().catch(() => ({}))) as { model?: unknown };
  const modelId =
    typeof body.model === "string" && body.model.trim()
      ? body.model.trim()
      : requestUrl.searchParams.get("model")?.trim() || defaultRealtimeModelId;

  const response: RealtimeSetupResponse = {
    // The Rork browser runtime replaces this non-secret placeholder with the
    // origin-bound delegated token before opening the Toolkit WebSocket.
    token: browserDelegatedTokenPlaceholder,
    url: buildToolkitRealtimeUrl(toolkitURL, modelId),
    tools: [],
  };

  return Response.json(response);
}

function buildToolkitRealtimeUrl(toolkitURL: string, modelId: string): string {
  const url = new URL("/v2/vercel/v4/ai/realtime-model", toolkitURL);
  url.protocol = url.protocol === "https:" ? "wss:" : "ws:";
  url.searchParams.set("ai-model-id", modelId);
  return url.toString();
}
