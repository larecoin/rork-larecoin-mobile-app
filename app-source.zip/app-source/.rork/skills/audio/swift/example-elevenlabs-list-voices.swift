// Example: List available voices via Rork proxy (ElevenLabs)
//
// Usage: swift example-elevenlabs-list-voices.swift <TOOLKIT_URL> <SECRET_KEY>
//
// Lists available ElevenLabs voices with their IDs, names, and labels.
// Use this to find voice IDs before calling text-to-speech or dialogue.

import Foundation

guard CommandLine.arguments.count >= 3 else {
    print("Usage: swift example-elevenlabs-list-voices.swift <TOOLKIT_URL> <SECRET_KEY>")
    exit(1)
}

let toolkitURL = CommandLine.arguments[1]
let secretKey = CommandLine.arguments[2]
let elevenlabsV1URL = "\(toolkitURL)/v2/elevenlabs/v1"

// --- Response types ---

struct VoicesResponse: Codable {
    let voices: [Voice]

    struct Voice: Codable {
        let voice_id: String
        let name: String
        let labels: [String: String]?
    }
}

// --- Request ---

let url = URL(string: "\(elevenlabsV1URL)/voices?page_size=100")!
var request = URLRequest(url: url)
request.httpMethod = "GET"
request.setValue("Bearer \(secretKey)", forHTTPHeaderField: "Authorization")

let (data, response) = try await URLSession.shared.data(for: request)
let httpResponse = response as! HTTPURLResponse

guard httpResponse.statusCode == 200 else {
    print("Error: HTTP \(httpResponse.statusCode)")
    exit(1)
}

let result = try JSONDecoder().decode(VoicesResponse.self, from: data)

print("Found \(result.voices.count) voices:\n")
for voice in result.voices {
    let labels = voice.labels?.map { "\($0.key): \($0.value)" }.joined(separator: ", ") ?? ""
    print("  \(voice.voice_id)  \(voice.name)  [\(labels)]")
}
