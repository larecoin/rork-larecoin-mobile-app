// Example: Text-to-speech via Vercel AI Gateway through the Rork proxy
//
// Usage: swift example-vercel-gateway-speech.swift <TOOLKIT_URL> <SECRET_KEY> <TEXT> <OUTPUT_FILE> [MODEL] [VOICE]

import Foundation

guard CommandLine.arguments.count >= 5 else {
    print("Usage: swift example-vercel-gateway-speech.swift <TOOLKIT_URL> <SECRET_KEY> <TEXT> <OUTPUT_FILE> [MODEL] [VOICE]")
    exit(1)
}

let gatewaySpeechVoiceOptions: [String: (defaultVoice: String, docsURL: String, voices: [String])] = [
    "xai/grok-tts": (
        defaultVoice: "eve",
        docsURL: "https://docs.x.ai/developers/model-capabilities/audio/text-to-speech#choosing-the-right-voice",
        voices: ["eve", "ara", "rex", "sal", "leo"]
    ),
    "openai/tts-1": (
        defaultVoice: "alloy",
        docsURL: "https://developers.openai.com/api/docs/guides/text-to-speech",
        voices: ["alloy", "ash", "coral", "echo", "fable", "onyx", "nova", "sage", "shimmer"]
    ),
]

let toolkitURL = CommandLine.arguments[1]
let secretKey = CommandLine.arguments[2]
let text = CommandLine.arguments[3]
let outputPath = CommandLine.arguments[4]
let model = CommandLine.arguments.count >= 6 ? CommandLine.arguments[5] : "xai/grok-tts"

guard let voiceOptions = gatewaySpeechVoiceOptions[model] else {
    let knownModels = gatewaySpeechVoiceOptions.keys.sorted().joined(separator: ", ")
    print("Unsupported model '\(model)'. Known speech models: \(knownModels)")
    exit(1)
}

let voice = CommandLine.arguments.count >= 7 ? CommandLine.arguments[6] : voiceOptions.defaultVoice

if !voiceOptions.voices.contains(voice) {
    let knownVoices = voiceOptions.voices.joined(separator: ", ")
    print("Using custom or provider-specific voice '\(voice)'. Built-in voices for \(model): \(knownVoices). Docs: \(voiceOptions.docsURL)")
}

struct GatewaySpeechRequest: Encodable {
    let text: String
    let voice: String
    let outputFormat: String
}

struct GatewaySpeechResponse: Decodable {
    let audio: String
}

enum GatewaySpeechError: LocalizedError {
    case authError
    case insufficientBalance
    case rateLimited
    case invalidAudio
    case serverError(Int)

    var errorDescription: String? {
        switch self {
        case .authError:           "AI audio is currently unavailable. Please restart the app."
        case .insufficientBalance: "AI audio is temporarily unavailable. Please try again later."
        case .rateLimited:         "Too many requests. Please wait a moment and try again."
        case .invalidAudio:        "The speech response could not be decoded."
        case .serverError:         "Something went wrong. Please try again."
        }
    }
}

let url = URL(string: "\(toolkitURL)/v2/vercel/v4/ai/speech-model")!
var request = URLRequest(url: url)
request.httpMethod = "POST"
request.setValue("Bearer \(secretKey)", forHTTPHeaderField: "Authorization")
request.setValue("application/json", forHTTPHeaderField: "Content-Type")
request.setValue(model, forHTTPHeaderField: "ai-model-id")
request.setValue("0.0.1", forHTTPHeaderField: "ai-gateway-protocol-version")
request.httpBody = try JSONEncoder().encode(
    GatewaySpeechRequest(text: text, voice: voice, outputFormat: "mp3")
)
request.timeoutInterval = 120

let (data, response) = try await URLSession.shared.data(for: request)
let httpResponse = response as! HTTPURLResponse

switch httpResponse.statusCode {
case 200:  break
case 401:  throw GatewaySpeechError.authError
case 402:  throw GatewaySpeechError.insufficientBalance
case 429:  throw GatewaySpeechError.rateLimited
default:   throw GatewaySpeechError.serverError(httpResponse.statusCode)
}

let result = try JSONDecoder().decode(GatewaySpeechResponse.self, from: data)
guard let audioData = Data(base64Encoded: result.audio) else {
    throw GatewaySpeechError.invalidAudio
}

try audioData.write(to: URL(fileURLWithPath: outputPath))
print("Wrote speech audio to \(outputPath)")
