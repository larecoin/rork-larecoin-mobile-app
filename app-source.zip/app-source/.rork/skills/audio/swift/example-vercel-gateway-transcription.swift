// Example: Speech-to-text via Vercel AI Gateway through the Rork proxy
//
// Usage: swift example-vercel-gateway-transcription.swift <TOOLKIT_URL> <SECRET_KEY> <AUDIO_FILE_PATH>

import Foundation

guard CommandLine.arguments.count >= 4 else {
    print("Usage: swift example-vercel-gateway-transcription.swift <TOOLKIT_URL> <SECRET_KEY> <AUDIO_FILE_PATH>")
    exit(1)
}

let toolkitURL = CommandLine.arguments[1]
let secretKey = CommandLine.arguments[2]
let audioFilePath = CommandLine.arguments[3]

struct GatewayTranscriptionRequest: Encodable {
    let audio: String
    let mediaType: String
}

struct GatewayTranscriptionResponse: Decodable {
    let text: String
    let language: String?
    let durationInSeconds: Double?
}

enum GatewayTranscriptionError: LocalizedError {
    case fileNotFound
    case authError
    case insufficientBalance
    case rateLimited
    case serverError(Int)

    var errorDescription: String? {
        switch self {
        case .fileNotFound:        "Audio file not found."
        case .authError:           "AI audio is currently unavailable. Please restart the app."
        case .insufficientBalance: "AI audio is temporarily unavailable. Please try again later."
        case .rateLimited:         "Too many requests. Please wait a moment and try again."
        case .serverError:         "Something went wrong. Please try again."
        }
    }
}

func mediaType(for url: URL) -> String {
    switch url.pathExtension.lowercased() {
    case "mp3":  "audio/mpeg"
    case "wav":  "audio/wav"
    case "m4a":  "audio/mp4"
    case "ogg":  "audio/ogg"
    case "flac": "audio/flac"
    case "webm": "audio/webm"
    default:     "application/octet-stream"
    }
}

let audioURL = URL(fileURLWithPath: audioFilePath)
guard FileManager.default.fileExists(atPath: audioFilePath) else {
    throw GatewayTranscriptionError.fileNotFound
}

let audioData = try Data(contentsOf: audioURL)
let url = URL(string: "\(toolkitURL)/v2/vercel/v4/ai/transcription-model")!
var request = URLRequest(url: url)
request.httpMethod = "POST"
request.setValue("Bearer \(secretKey)", forHTTPHeaderField: "Authorization")
request.setValue("application/json", forHTTPHeaderField: "Content-Type")
request.setValue("xai/grok-stt", forHTTPHeaderField: "ai-model-id")
request.setValue("0.0.1", forHTTPHeaderField: "ai-gateway-protocol-version")
request.httpBody = try JSONEncoder().encode(
    GatewayTranscriptionRequest(
        audio: audioData.base64EncodedString(),
        mediaType: mediaType(for: audioURL)
    )
)
request.timeoutInterval = 120

let (data, response) = try await URLSession.shared.data(for: request)
let httpResponse = response as! HTTPURLResponse

switch httpResponse.statusCode {
case 200:  break
case 401:  throw GatewayTranscriptionError.authError
case 402:  throw GatewayTranscriptionError.insufficientBalance
case 429:  throw GatewayTranscriptionError.rateLimited
default:   throw GatewayTranscriptionError.serverError(httpResponse.statusCode)
}

let result = try JSONDecoder().decode(GatewayTranscriptionResponse.self, from: data)
print("Text: \(result.text)")
if let language = result.language {
    print("Language: \(language)")
}
if let duration = result.durationInSeconds {
    print("Duration: \(duration)s")
}
