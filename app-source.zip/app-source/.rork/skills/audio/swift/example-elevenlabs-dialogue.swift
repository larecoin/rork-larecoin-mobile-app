// Example: Multi-speaker dialogue via Rork proxy (ElevenLabs)
//
// Usage: swift example-elevenlabs-dialogue.swift <TOOLKIT_URL> <SECRET_KEY> <VOICE_ID_1> <VOICE_ID_2>
//
// Generates multi-speaker dialogue audio using the ElevenLabs text-to-dialogue API.
// Saves the audio as output-dialogue.mp3 in the current directory.

import Foundation

guard CommandLine.arguments.count >= 5 else {
    print("Usage: swift example-elevenlabs-dialogue.swift <TOOLKIT_URL> <SECRET_KEY> <VOICE_ID_1> <VOICE_ID_2>")
    exit(1)
}

let toolkitURL = CommandLine.arguments[1]
let secretKey = CommandLine.arguments[2]
let elevenlabsV1URL = "\(toolkitURL)/v2/elevenlabs/v1"
let voiceId1 = CommandLine.arguments[3]
let voiceId2 = CommandLine.arguments[4]

// --- Error type with user-facing messages ---

enum DialogueError: LocalizedError {
    case authError
    case insufficientBalance
    case rateLimited
    case serverError(Int)
    case noAudioReturned

    var errorDescription: String? {
        switch self {
        case .authError:           "AI features are currently unavailable. Please restart the app."
        case .insufficientBalance: "AI features are temporarily unavailable. Please try again later."
        case .rateLimited:         "Too many requests. Please wait a moment and try again."
        case .serverError:         "Something went wrong. Please try again."
        case .noAudioReturned:     "No audio was returned. Please try again."
        }
    }
}

// --- Request ---

let url = URL(string: "\(elevenlabsV1URL)/text-to-dialogue")!

let body: [String: Any] = [
    "inputs": [
        ["text": "Hello, how are you today?", "voice_id": voiceId1],
        ["text": "I'm doing great, thanks for asking!", "voice_id": voiceId2],
        ["text": "That's wonderful to hear.", "voice_id": voiceId1]
    ],
    "model_id": "eleven_v3"
]

var request = URLRequest(url: url)
request.httpMethod = "POST"
request.setValue("application/json", forHTTPHeaderField: "Content-Type")
request.setValue("Bearer \(secretKey)", forHTTPHeaderField: "Authorization")
request.httpBody = try JSONSerialization.data(withJSONObject: body)
request.timeoutInterval = 60

print("Generating dialogue...")

let (data, response) = try await URLSession.shared.data(for: request)
let httpResponse = response as! HTTPURLResponse

switch httpResponse.statusCode {
case 200:  break
case 401:  throw DialogueError.authError
case 402:  throw DialogueError.insufficientBalance
case 429:  throw DialogueError.rateLimited
default:   throw DialogueError.serverError(httpResponse.statusCode)
}

guard !data.isEmpty else {
    throw DialogueError.noAudioReturned
}

let outputURL = URL(fileURLWithPath: "output-dialogue.mp3")
try data.write(to: outputURL)
print("Dialogue audio saved to: \(outputURL.path) (\(data.count) bytes)")
