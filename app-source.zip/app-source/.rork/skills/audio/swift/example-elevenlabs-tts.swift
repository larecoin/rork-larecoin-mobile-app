// Example: Text-to-speech via Rork proxy (ElevenLabs)
//
// Usage: swift example-elevenlabs-tts.swift <TOOLKIT_URL> <SECRET_KEY> <VOICE_ID> [TEXT]
//
// Generates speech audio using the ElevenLabs TTS API via the Rork proxy.
// Saves the audio as output.mp3 in the current directory.

import Foundation

guard CommandLine.arguments.count >= 4 else {
    print("Usage: swift example-elevenlabs-tts.swift <TOOLKIT_URL> <SECRET_KEY> <VOICE_ID> [TEXT]")
    exit(1)
}

let toolkitURL = CommandLine.arguments[1]
let secretKey = CommandLine.arguments[2]
let voiceId = CommandLine.arguments[3]
let text = CommandLine.arguments.count >= 5 ? CommandLine.arguments[4] : "Hello world"
let elevenlabsV1URL = "\(toolkitURL)/v2/elevenlabs/v1"

// --- Error type with user-facing messages ---

enum ElevenLabsError: LocalizedError {
    case authError
    case insufficientBalance
    case rateLimited
    case serverError(Int)
    case noAudioReturned

    var errorDescription: String? {
        switch self {
        case .authError:           "AI features are currently unavailable. Please restart the app."
        case .insufficientBalance: "AI features are temporarily unavailable. Please try again later."
        case .rateLimited:         "Too many requests. Please wait a moment and try again."
        case .serverError:         "Something went wrong. Please try again."
        case .noAudioReturned:     "No audio was returned. Please try again."
        }
    }
}

// --- Request ---

let url = URL(string: "\(elevenlabsV1URL)/text-to-speech/\(voiceId)")!

let body: [String: Any] = [
    "text": text,
    "model_id": "eleven_v3"
]

var request = URLRequest(url: url)
request.httpMethod = "POST"
request.setValue("application/json", forHTTPHeaderField: "Content-Type")
request.setValue("Bearer \(secretKey)", forHTTPHeaderField: "Authorization")
request.httpBody = try JSONSerialization.data(withJSONObject: body)

let (data, response) = try await URLSession.shared.data(for: request)
let httpResponse = response as! HTTPURLResponse

switch httpResponse.statusCode {
case 200:  break
case 401:  throw ElevenLabsError.authError
case 402:  throw ElevenLabsError.insufficientBalance
case 429:  throw ElevenLabsError.rateLimited
default:   throw ElevenLabsError.serverError(httpResponse.statusCode)
}

guard !data.isEmpty else {
    throw ElevenLabsError.noAudioReturned
}

let outputURL = URL(fileURLWithPath: "output.mp3")
try data.write(to: outputURL)
print("Audio saved to: \(outputURL.path) (\(data.count) bytes)")
