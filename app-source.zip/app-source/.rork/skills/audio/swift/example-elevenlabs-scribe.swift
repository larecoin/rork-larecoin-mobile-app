// Example: Speech-to-text via Rork proxy (ElevenLabs Scribe)
//
// Usage: swift example-elevenlabs-scribe.swift <TOOLKIT_URL> <SECRET_KEY> <AUDIO_FILE_OR_URL> [LANGUAGE_CODE]
//
// Transcribes a local audio/video file or a hosted source_url using ElevenLabs Scribe via the Rork proxy.

import Foundation

guard CommandLine.arguments.count >= 4 else {
    print("Usage: swift example-elevenlabs-scribe.swift <TOOLKIT_URL> <SECRET_KEY> <AUDIO_FILE_OR_URL> [LANGUAGE_CODE]")
    exit(1)
}

let toolkitURL = CommandLine.arguments[1]
let secretKey = CommandLine.arguments[2]
let audioInput = CommandLine.arguments[3]
let languageCode = CommandLine.arguments.count >= 5 ? CommandLine.arguments[4] : nil
let elevenlabsV1URL = "\(toolkitURL)/v2/elevenlabs/v1"

enum ScribeError: LocalizedError {
    case authError
    case insufficientBalance
    case rateLimited
    case serverError(Int, String)
    case invalidFile(String)

    var errorDescription: String? {
        switch self {
        case .authError:           "AI features are currently unavailable. Please restart the app."
        case .insufficientBalance: "AI features are temporarily unavailable. Please try again later."
        case .rateLimited:         "Too many requests. Please wait a moment and try again."
        case .serverError:         "Something went wrong. Please try again."
        case .invalidFile:         "The audio file could not be read."
        }
    }
}

func mimeType(for url: URL) -> String {
    switch url.pathExtension.lowercased() {
    case "mp3":        "audio/mpeg"
    case "wav":        "audio/wav"
    case "m4a":        "audio/mp4"
    case "ogg":        "audio/ogg"
    case "flac":       "audio/flac"
    case "mp4":        "video/mp4"
    case "mov":        "video/quicktime"
    case "webm":       "video/webm"
    default:           "application/octet-stream"
    }
}

func appendField(_ name: String, _ value: String, to body: inout Data, boundary: String) {
    body.append("--\(boundary)\r\n".data(using: .utf8)!)
    body.append("Content-Disposition: form-data; name=\"\(name)\"\r\n\r\n".data(using: .utf8)!)
    body.append("\(value)\r\n".data(using: .utf8)!)
}

func appendFile(_ name: String, fileURL: URL, to body: inout Data, boundary: String) throws {
    guard FileManager.default.fileExists(atPath: fileURL.path) else {
        throw ScribeError.invalidFile(fileURL.path)
    }

    let fileData = try Data(contentsOf: fileURL)
    body.append("--\(boundary)\r\n".data(using: .utf8)!)
    body.append("Content-Disposition: form-data; name=\"\(name)\"; filename=\"\(fileURL.lastPathComponent)\"\r\n".data(using: .utf8)!)
    body.append("Content-Type: \(mimeType(for: fileURL))\r\n\r\n".data(using: .utf8)!)
    body.append(fileData)
    body.append("\r\n".data(using: .utf8)!)
}

let url = URL(string: "\(elevenlabsV1URL)/speech-to-text")!
let boundary = "Boundary-\(UUID().uuidString)"
var body = Data()

appendField("model_id", "scribe_v2", to: &body, boundary: boundary)
appendField("diarize", "true", to: &body, boundary: boundary)
if let languageCode, !languageCode.isEmpty {
    appendField("language_code", languageCode, to: &body, boundary: boundary)
}

if audioInput.hasPrefix("http://") || audioInput.hasPrefix("https://") {
    appendField("source_url", audioInput, to: &body, boundary: boundary)
} else {
    try appendFile("file", fileURL: URL(fileURLWithPath: audioInput), to: &body, boundary: boundary)
}

body.append("--\(boundary)--\r\n".data(using: .utf8)!)

var request = URLRequest(url: url)
request.httpMethod = "POST"
request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
request.setValue("Bearer \(secretKey)", forHTTPHeaderField: "Authorization")
request.httpBody = body
request.timeoutInterval = 120

let (data, response) = try await URLSession.shared.data(for: request)
let httpResponse = response as! HTTPURLResponse

switch httpResponse.statusCode {
case 200:  break
case 401:  throw ScribeError.authError
case 402:  throw ScribeError.insufficientBalance
case 429:  throw ScribeError.rateLimited
default:
    let bodyText = String(data: data, encoding: .utf8) ?? ""
    throw ScribeError.serverError(httpResponse.statusCode, bodyText)
}

if let json = try JSONSerialization.jsonObject(with: data) as? [String: Any] {
    print("Text: \(json["text"] as? String ?? "")")
    if let duration = json["audio_duration_secs"] {
        print("Duration: \(duration)s")
    }
    if let transcriptionId = json["transcription_id"] {
        print("Transcription ID: \(transcriptionId)")
    }
} else {
    print(String(data: data, encoding: .utf8) ?? "")
}
