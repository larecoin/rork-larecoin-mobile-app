// Example: Speech-to-speech via Rork proxy (ElevenLabs Voice Changer)
//
// Usage: swift example-elevenlabs-speech-to-speech.swift <TOOLKIT_URL> <SECRET_KEY> <VOICE_ID> <AUDIO_FILE> [OUTPUT_FILE]
//
// Converts source speech audio into the selected ElevenLabs voice through the Rork proxy.

import Foundation

guard CommandLine.arguments.count >= 5 else {
    print("Usage: swift example-elevenlabs-speech-to-speech.swift <TOOLKIT_URL> <SECRET_KEY> <VOICE_ID> <AUDIO_FILE> [OUTPUT_FILE]")
    exit(1)
}

let toolkitURL = CommandLine.arguments[1]
let secretKey = CommandLine.arguments[2]
let voiceId = CommandLine.arguments[3]
let audioPath = CommandLine.arguments[4]
let outputPath = CommandLine.arguments.count >= 6 ? CommandLine.arguments[5] : "output.mp3"
let elevenlabsV1URL = "\(toolkitURL)/v2/elevenlabs/v1"

enum SpeechToSpeechError: LocalizedError {
    case authError
    case insufficientBalance
    case rateLimited
    case serverError(Int, String)
    case invalidFile(String)
    case noAudioReturned

    var errorDescription: String? {
        switch self {
        case .authError:           "AI features are currently unavailable. Please restart the app."
        case .insufficientBalance: "AI features are temporarily unavailable. Please try again later."
        case .rateLimited:         "Too many requests. Please wait a moment and try again."
        case .serverError:         "Something went wrong. Please try again."
        case .invalidFile:         "The audio file could not be read."
        case .noAudioReturned:     "No audio was returned. Please try again."
        }
    }
}

func mimeType(for url: URL) -> String {
    switch url.pathExtension.lowercased() {
    case "mp3":  "audio/mpeg"
    case "wav":  "audio/wav"
    case "m4a":  "audio/mp4"
    case "ogg":  "audio/ogg"
    case "flac": "audio/flac"
    default:     "application/octet-stream"
    }
}

func appendField(_ name: String, _ value: String, to body: inout Data, boundary: String) {
    body.append("--\(boundary)\r\n".data(using: .utf8)!)
    body.append("Content-Disposition: form-data; name=\"\(name)\"\r\n\r\n".data(using: .utf8)!)
    body.append("\(value)\r\n".data(using: .utf8)!)
}

func appendFile(_ name: String, fileURL: URL, to body: inout Data, boundary: String) throws {
    guard FileManager.default.fileExists(atPath: fileURL.path) else {
        throw SpeechToSpeechError.invalidFile(fileURL.path)
    }

    let fileData = try Data(contentsOf: fileURL)
    body.append("--\(boundary)\r\n".data(using: .utf8)!)
    body.append("Content-Disposition: form-data; name=\"\(name)\"; filename=\"\(fileURL.lastPathComponent)\"\r\n".data(using: .utf8)!)
    body.append("Content-Type: \(mimeType(for: fileURL))\r\n\r\n".data(using: .utf8)!)
    body.append(fileData)
    body.append("\r\n".data(using: .utf8)!)
}

let url = URL(string: "\(elevenlabsV1URL)/speech-to-speech/\(voiceId)?output_format=mp3_44100_128")!
let boundary = "Boundary-\(UUID().uuidString)"
var body = Data()

appendField("model_id", "eleven_multilingual_sts_v2", to: &body, boundary: boundary)
try appendFile("audio", fileURL: URL(fileURLWithPath: audioPath), to: &body, boundary: boundary)
body.append("--\(boundary)--\r\n".data(using: .utf8)!)

var request = URLRequest(url: url)
request.httpMethod = "POST"
request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
request.setValue("Bearer \(secretKey)", forHTTPHeaderField: "Authorization")
request.httpBody = body
request.timeoutInterval = 120

let (data, response) = try await URLSession.shared.data(for: request)
let httpResponse = response as! HTTPURLResponse

switch httpResponse.statusCode {
case 200:  break
case 401:  throw SpeechToSpeechError.authError
case 402:  throw SpeechToSpeechError.insufficientBalance
case 429:  throw SpeechToSpeechError.rateLimited
default:
    let bodyText = String(data: data, encoding: .utf8) ?? ""
    throw SpeechToSpeechError.serverError(httpResponse.statusCode, bodyText)
}

guard !data.isEmpty else {
    throw SpeechToSpeechError.noAudioReturned
}

let outputURL = URL(fileURLWithPath: outputPath)
try data.write(to: outputURL)
print("Audio saved to: \(outputURL.path) (\(data.count) bytes)")
