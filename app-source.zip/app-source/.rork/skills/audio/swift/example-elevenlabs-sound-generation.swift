// Example: Sound effect generation via Rork proxy (ElevenLabs)
//
// Usage: swift example-elevenlabs-sound-generation.swift <TOOLKIT_URL> <SECRET_KEY> [DESCRIPTION]
//
// Generates a sound effect from a text description using the ElevenLabs sound generation API.
// Saves the audio as output-sound.mp3 in the current directory.

import Foundation

guard CommandLine.arguments.count >= 3 else {
    print("Usage: swift example-elevenlabs-sound-generation.swift <TOOLKIT_URL> <SECRET_KEY> [DESCRIPTION]")
    exit(1)
}

let toolkitURL = CommandLine.arguments[1]
let secretKey = CommandLine.arguments[2]
let elevenlabsV1URL = "\(toolkitURL)/v2/elevenlabs/v1"
let description = CommandLine.arguments.count >= 4 ? CommandLine.arguments[3] : "A gentle rain falling on a tin roof"

// --- Error type with user-facing messages ---

enum SoundGenError: LocalizedError {
    case authError
    case insufficientBalance
    case rateLimited
    case serverError(Int)
    case noAudioReturned

    var errorDescription: String? {
        switch self {
        case .authError:           "AI features are currently unavailable. Please restart the app."
        case .insufficientBalance: "AI features are temporarily unavailable. Please try again later."
        case .rateLimited:         "Too many requests. Please wait a moment and try again."
        case .serverError:         "Something went wrong. Please try again."
        case .noAudioReturned:     "No audio was returned. Please try again."
        }
    }
}

// --- Request ---

let url = URL(string: "\(elevenlabsV1URL)/sound-generation")!

let body: [String: Any] = [
    "text": description,
    "duration_seconds": 5
]

var request = URLRequest(url: url)
request.httpMethod = "POST"
request.setValue("application/json", forHTTPHeaderField: "Content-Type")
request.setValue("Bearer \(secretKey)", forHTTPHeaderField: "Authorization")
request.httpBody = try JSONSerialization.data(withJSONObject: body)
request.timeoutInterval = 60

print("Generating sound: \(description)...")

let (data, response) = try await URLSession.shared.data(for: request)
let httpResponse = response as! HTTPURLResponse

switch httpResponse.statusCode {
case 200:  break
case 401:  throw SoundGenError.authError
case 402:  throw SoundGenError.insufficientBalance
case 429:  throw SoundGenError.rateLimited
default:   throw SoundGenError.serverError(httpResponse.statusCode)
}

guard !data.isEmpty else {
    throw SoundGenError.noAudioReturned
}

let outputURL = URL(fileURLWithPath: "output-sound.mp3")
try data.write(to: outputURL)
print("Sound saved to: \(outputURL.path) (\(data.count) bytes)")
