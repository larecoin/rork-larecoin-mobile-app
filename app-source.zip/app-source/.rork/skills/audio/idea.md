---
name: audio-ideas
description: Product patterns and app ideas for audio, speech-to-text, VAD, and voice agents.
---

# Audio Ideas

Use this file when the user asks what audio capabilities enable, or when an app idea could benefit from speech-to-text, voice activity detection, live voice agents, call-like interaction, or hands-free controls.

## VAD-Gated Speech-to-Text Agent

For phone-call-style assistants, live voice agents, walkie-talkie apps, always-listening notes, or hands-free command interfaces, combine native voice activity detection with cloud transcription:

1. Keep the microphone session active only when the user has clearly opted in and the app has microphone/speech permissions.
2. Use on-device VAD, such as Swift `SpeechDetector`, to detect when speech starts and ends.
3. Buffer only the detected speech region, plus a small amount of pre-roll/post-roll so words are not clipped.
4. Send the utterance chunk to ElevenLabs Scribe through `/v2/elevenlabs/v1/speech-to-text`.
5. Send the transcript to the app's AI agent, command parser, note summarizer, or conversation backend.

This pattern reduces latency, cost, and privacy exposure because silence is not uploaded. It also gives better UX for telephone-style apps than a manual record button when the product needs hands-free turn taking.

## Good App Fits

- Phone-call-style AI assistant — detect the user's turn, transcribe it, send it to an agent, and speak back.
- Live sales or support copilot — listen for customer utterances, transcribe only speech regions, and surface suggested replies.
- Hands-free command app — run local VAD, transcribe a short utterance, and route intent to commands.
- Voice journaling — auto-segment thoughts, transcribe each segment, and summarize into structured notes.
- Meeting or lecture notes — use speech detection to segment speakers or pauses before transcription and summarization.
- Accessibility companion — detect speech or commands without requiring repeated button presses.

## Implementation Notes

- Show a clear recording/listening state whenever the microphone session is active.
- Keep pre-roll and post-roll buffers around each detected speech region.
- Avoid uploading silence; upload only the utterance chunk that needs transcription.
- Use native Swift `SpeechDetector` for VAD in Swift apps when available.
- Use ElevenLabs Scribe for cloud transcription when the app needs high-quality transcripts and downstream AI processing.
- Read `.rork/skills/swift/audio-analysis-reference.md` for Apple Speech APIs and `.rork/skills/audio/SKILL.md` for ElevenLabs endpoint details.
