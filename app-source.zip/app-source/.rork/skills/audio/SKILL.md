---
name: audio
description: Audio features for generated apps, including Vercel AI Gateway
  speech, speech-to-text, text-to-speech, realtime voice, speech-to-speech voice
  conversion, sound effects, and dialogue. Prefer Vercel AI Gateway for
  supported speech, transcription, and realtime; use ElevenLabs for advanced
  voices/dialogue/sound effects or explicit requests.
aliases:
  - audio
  - ElevenLabs
  - 11Labs
  - text to speech
  - text-to-speech
  - tts
  - voiceover
  - narration
  - speech-to-speech
  - voice changer
  - voice conversion
  - sound effects
  - dialogue generation
  - voice synthesis
  - realtime voice
  - voice agent
  - speech to text
  - speech-to-text
  - transcription
  - transcribe
  - dictation
  - voice memo
  - voice note
  - captions
---

# Audio APIs

Use this skill for app audio features: speech-to-text, dictation, captions, voice memo transcription, natural text-to-speech, realtime voice agents, narration, character voices, dialogue, and sound effects.

Prefer Vercel AI Gateway for supported speech, transcription, and realtime voice. Gateway HTTP and WebSocket requests go through the Rork Toolkit proxy, so Rork handles browser delegated authentication, native/server credentials, billing, usage guardrails, and upstream credentials.

For recorded audio input into an AI feature, transcribe through Gateway first, then send the transcript to the chosen AI model. For live two-way voice, connect to the Toolkit WebSocket proxy and use the AI SDK realtime codec when the generated runtime supports the canary realtime APIs. Do not generate native Swift realtime WebSocket clients from scratch; Swift cannot use the AI SDK codec, and the lifecycle/audio handling needs a maintained Swift sample before it is safe to generate.

Use ElevenLabs when the app needs capabilities Gateway does not cover yet, such as richer voice catalogs, speech-to-speech voice conversion, multi-speaker dialogue, or sound effects.

## Vercel AI Gateway Audio

All Gateway audio requests go through the Rork proxy. Before using any endpoint, call `getOrCreateToolkitSecret` to provision the Toolkit API key.

Before implementing Gateway audio or realtime voice, fetch the relevant Vercel documentation page for the latest request shape, model support, and client requirements.
| Topic                     | URL                                                          |
| ------------------------- | ------------------------------------------------------------ |
| Text-to-Speech modality   | https://vercel.com/docs/ai-gateway/modalities/text-to-speech |
| Speech-to-Text modality   | https://vercel.com/docs/ai-gateway/modalities/speech-to-text |
| Realtime modality         | https://vercel.com/docs/ai-gateway/modalities/realtime       |
| Realtime getting started  | https://vercel.com/docs/ai-gateway/getting-started/realtime  |
| Speech getting started    | https://vercel.com/docs/ai-gateway/getting-started/speech    |
| Video getting started     | https://vercel.com/docs/ai-gateway/getting-started/video     |
| Vercel Function WebSocket | https://vercel.com/docs/functions/websockets                 |
| Nitro WebSocket           | https://nitro.build/docs/websocket                           |

Gateway HTTP requests MUST include:

```
Authorization: Bearer <EXPO_PUBLIC_RORK_TOOLKIT_SECRET_KEY>
Content-Type: application/json
ai-gateway-protocol-version: 0.0.1

```

### Gateway endpoints

| Method | Path                                   | Description                         |
| ------ | -------------------------------------- | ----------------------------------- |
| POST   | `/v2/vercel/v4/ai/speech-model`        | Text-to-speech, base64 audio result |
| POST   | `/v2/vercel/v4/ai/transcription-model` | Speech-to-text from base64 audio    |
| WS     | `/v2/vercel/v4/ai/realtime-model`      | Realtime voice WebSocket proxy      |

For speech and transcription, pass the model ID in the `ai-model-id` header. Useful starting points:

| Capability      | Model ID                        |
| --------------- | ------------------------------- |
| Speech          | `xai/grok-tts`                  |
| Speech fallback | `openai/tts-1`                  |
| Transcription   | `xai/grok-stt`                  |
| STT fallback    | `openai/gpt-4o-mini-transcribe` |

### Gateway voice selection

Vercel AI Gateway endpoint metadata currently does not expose a voice catalog. Fetch the live endpoint metadata as documented in the AI skill to confirm speech or realtime support, pricing, endpoints, and modalities; it does not return `voices`, `supported_voices`, or a voice enum. Do not write generated app code that tries to list Gateway voices from model specs.

Use provider docs for voice catalogs. Make `voice` configurable when the user wants a picker, and use these documented built-in voices for the picker/defaults:

| Provider / capability                       | Built-in voices                                                                                                  | Safe default       | Docs                                                                                                                    |
| ------------------------------------------- | ---------------------------------------------------------------------------------------------------------------- | ------------------ | ----------------------------------------------------------------------------------------------------------------------- |
| xAI `xai/grok-tts` speech                   | `eve`, `ara`, `rex`, `sal`, `leo`                                                                                | `eve`              | https://docs.x.ai/developers/model-capabilities/audio/text-to-speech#choosing-the-right-voice                           |
| xAI `grok-voice-latest` / realtime voice    | `eve`, `ara`, `rex`, `sal`, `leo`                                                                                | `eve`              | https://docs.x.ai/developers/model-capabilities/audio/voice-agent#available-voices                                      |
| OpenAI newer TTS models                     | `alloy`, `ash`, `ballad`, `coral`, `echo`, `fable`, `nova`, `onyx`, `sage`, `shimmer`, `verse`, `marin`, `cedar` | `marin`            | https://developers.openai.com/api/reference/resources/audio/subresources/speech/methods/create#audio-createspeech-voice |
| OpenAI `tts-1` / `tts-1-hd` speech fallback | `alloy`, `ash`, `coral`, `echo`, `fable`, `onyx`, `nova`, `sage`, `shimmer`                                      | `alloy`            | https://developers.openai.com/api/docs/guides/text-to-speech                                                            |
| OpenAI realtime                             | `alloy`, `ash`, `ballad`, `coral`, `echo`, `sage`, `shimmer`, `verse`, `marin`, `cedar`                          | `marin`            | https://developers.openai.com/api/docs/guides/realtime-conversations#voice-options                                      |
| ElevenLabs                                  | call `listVoices`                                                                                                | choose by metadata | https://elevenlabs.io/docs/api-reference/voices/get-all                                                                 |

OpenAI's current docs recommend `marin` or `cedar` for best quality on newer TTS and realtime. Keep `alloy` for the `openai/tts-1` fallback because `tts-1` supports the smaller legacy voice set. xAI voice IDs are case-insensitive, but generated code should send lowercase IDs.

Speech responses are JSON with base64 `audio`, not streamed binary audio. Transcription requests send base64 `audio` plus `mediaType`; multipart uploads are not supported by Gateway transcription.

### Gateway speech example

Read `ts/example-vercel-gateway-speech.ts` for a complete TypeScript example. Core request shape:

```ts
const response = await fetch(`${toolkitURL}/v2/vercel/v4/ai/speech-model`, {
  method: "POST",
  headers: {
    Authorization: `Bearer ${secretKey}`,
    "Content-Type": "application/json",
    "ai-model-id": "xai/grok-tts",
    "ai-gateway-protocol-version": "0.0.1",
  },
  body: JSON.stringify({
    text: "Welcome back.",
    voice: "eve",
    outputFormat: "mp3",
  }),
});

const result = await response.json();
const audioBytes = Uint8Array.from(atob(result.audio), (char) => char.charCodeAt(0));
```

### Gateway transcription example

Read `ts/example-vercel-gateway-transcription.ts` for a complete TypeScript example. Core request shape:

```ts
const response = await fetch(`${toolkitURL}/v2/vercel/v4/ai/transcription-model`, {
  method: "POST",
  headers: {
    Authorization: `Bearer ${secretKey}`,
    "Content-Type": "application/json",
    "ai-model-id": "xai/grok-stt",
    "ai-gateway-protocol-version": "0.0.1",
  },
  body: JSON.stringify({
    audio: base64Audio,
    mediaType: "audio/mpeg",
  }),
});

const transcript = await response.json();
```

### Gateway realtime voice

Realtime voice uses the same Toolkit proxy surface as HTTP Gateway requests: `/v2/vercel/<gateway-path>` forwards to the same path on AI Gateway after Toolkit auth, balance check, rate limit, and upstream credential replacement.

Use this Toolkit WebSocket URL for Vercel AI Gateway realtime:

```
wss://<toolkit-host>/v2/vercel/v4/ai/realtime-model?ai-model-id=<model-id>

```

For local development, use `ws://`:

```
ws://localhost:<toolkit-port>/v2/vercel/v4/ai/realtime-model?ai-model-id=openai/gpt-realtime-2

```

The toolkit URL already includes the toolkit base path when Rork provides one, for example `https://<worktree>.rorkdev.link/__rork/toolkit`. Append `/v2/vercel/v4/ai/realtime-model` to that base. The proxy strips `/v2/vercel` and forwards `/v4/ai/realtime-model` to AI Gateway. Do not implement another token-mint endpoint and do not store a Vercel AI Gateway key in the app client.

Browser `WebSocket` cannot send an `Authorization` header. Rork's browser runtime preloads an origin-bound delegated token and replaces the non-secret placeholder in either supported auth subprotocol:

```ts
const socket = new WebSocket(realtimeUrl, ["ai-gateway-realtime.v1", "rork-toolkit-auth.rork_web_delegated_auth"]);
```

The proxy also accepts `ai-gateway-auth.<delegated token>` from AI SDK-generated Vercel realtime configs and replaces it before connecting upstream.

Server/native WebSocket clients may continue sending `Authorization: Bearer <Toolkit secret>` when their WebSocket library supports custom headers. The proxy still replaces only the upstream credential before forwarding.

Use these examples:

| Example                              | File                                                |
| ------------------------------------ | --------------------------------------------------- |
| Browser realtime setup route         | `ts/example-vercel-gateway-realtime-setup-route.ts` |
| Browser AI SDK codec through Toolkit | `ts/example-vercel-gateway-realtime-browser.tsx`    |
| Bun/Node AI SDK codec smoke test     | `ts/example-vercel-gateway-realtime-node.ts`        |

Realtime requirements:

- Install canary AI SDK packages when using the realtime codec: `bun add ai@canary @ai-sdk/gateway@canary @ai-sdk/react@canary`. For the smoke test, also install `ws`.
- Browser apps that use `experimental_useRealtime` need a setup endpoint that returns `{ token: "rork_web_delegated_auth", url: <Toolkit WebSocket URL>, tools: [] }`. The placeholder is not a credential; Rork replaces it before the socket opens. Read `ts/example-vercel-gateway-realtime-setup-route.ts` and `ts/example-vercel-gateway-realtime-browser.tsx`.
- Lower-level Node or Bun smoke tests can use `gateway.experimental_realtime(modelId)` as the codec and call `model.getWebSocketConfig({ token: secretKey, url: toolkitRealtimeUrl })`.
- Do not call `gateway.experimental_realtime.getToken()` in generated apps. Rork supplies delegated browser auth, and Toolkit holds the Vercel Gateway key server-side.
- Start with `openai/gpt-realtime-2` for browser voice-agent UX. Use `xai/grok-voice-think-fast-1.0` only when speech-to-speech is enough; it does not handle transcription or translation.
- Realtime sessions have practical limits: 25 minute maximum duration, 5 minute idle timeout, first client message within 30 seconds, and 256 KB maximum message size.
- Reconnects start a new session. Replay any conversation context the user needs after reconnecting.
- Swift cannot use the Vercel AI SDK. Do not generate native Swift realtime WebSocket apps from scratch. For Swift, prefer Gateway speech/transcription REST calls or call a server/JS bridge that uses the AI SDK realtime codec. Use direct `URLSessionWebSocketTask` only when the user provides or requests a maintained sample that implements Gateway's realtime lifecycle, send error handling, and PCM16 audio encoding/decoding. Before writing direct native Swift WebSocket or SSE code, read `.rork/skills/swift/networking-streams.md`.


## ElevenLabs API

All requests go through the Rork proxy — a passthrough to `api.elevenlabs.io`. The path after `/v2/elevenlabs/` maps directly to the ElevenLabs API, so their documentation applies directly. Before using any endpoint, call `getOrCreateToolkitSecret` to provision the API key.

Before implementing, fetch the relevant documentation page for the latest API signatures and options.
| Topic            | URL                                                                                    |
| ---------------- | -------------------------------------------------------------------------------------- |
| Text-to-Speech   | https://elevenlabs.io/docs/api-reference/text-to-speech/convert                        |
| Speech-to-Speech | https://elevenlabs.io/docs/api-reference/speech-to-speech/convert                      |
| STS Stream       | https://elevenlabs.io/docs/api-reference/speech-to-speech/stream                       |
| Text-to-Dialogue | https://elevenlabs.io/docs/api-reference/text-to-dialogue/convert                      |
| Sound Generation | https://elevenlabs.io/docs/api-reference/sound-generation/convert                      |
| Speech-to-Text   | https://elevenlabs.io/docs/api-reference/speech-to-text/convert                        |
| AI SDK Scribe    | https://elevenlabs.io/docs/eleven-api/guides/how-to/speech-to-text/batch/vercel-ai-sdk |
| Voices           | https://elevenlabs.io/docs/api-reference/voices/get-all                                |
| Models           | https://elevenlabs.io/docs/api-reference/models/list                                   |

Always route ElevenLabs calls through the Rork proxy. Do NOT use the `elevenlabs` or `@elevenlabs/elevenlabs-js` npm packages — they are Node-only and do not work in React Native.
Do not use platform-native speech synthesis such as `AVSpeechSynthesizer`, `expo-speech`, or `react-native-tts` for user-facing natural text-to-speech, narration, character voices, or voiceovers unless the user explicitly asks for offline/on-device/system speech. Those APIs sound inconsistent across devices and are a fallback for accessibility, prototypes, or no-network requirements, not the default product voice.
For Scribe speech-to-text in TypeScript apps, prefer the ElevenLabs Vercel AI SDK cookbook pattern with `@ai-sdk/elevenlabs` and `experimental_transcribe`. The provider has no `baseURL` option, so keep the custom `fetch` wrapper that rewrites `https://api.elevenlabs.io/...` to `<TOOLKIT_URL>/v2/elevenlabs/...` and swaps `xi-api-key` for the proxy's `Authorization: Bearer ...` header. See `ts/example-elevenlabs-ai-sdk-transcribe.ts`.
Use raw `fetch` for TTS, dialogue, sound generation, Swift, and any app surface where the AI SDK is not already available.

All requests MUST include:

```
Authorization: Bearer <EXPO_PUBLIC_RORK_TOOLKIT_SECRET_KEY>

```

## Pricing and Cost Tracking

Prefer Gateway audio when it supports the requested capability. Use ElevenLabs for advanced voices, speech-to-speech, dialogue, sound effects, or explicit ElevenLabs requests.

Rork's proxy tracks cost from upstream responses when possible:

| Capability                        | Cost signal used by Rork proxy                                                   | Current fallback used by Rork                                                                     |
| --------------------------------- | -------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------- |
| Vercel Gateway speech/STT         | `usage.market_cost` or `providerMetadata.gateway.marketCost`                     | Flat fallback + cost-drift alert when Gateway omits market cost                                   |
| Vercel Gateway realtime WebSocket | pending Gateway realtime usage/cost reconciliation                               | connect-time balance/rate-limit gate plus session metadata logs; no credit charge from frames yet |
| ElevenLabs TTS, dialogue, SFX     | `character-cost` response header, converted at `$0.12 / 1000` ElevenLabs credits | request `text.length` at the same rate, then `$0.20` flat fallback if no text/header exists       |
| ElevenLabs Scribe speech-to-text  | `fiat-cost-before-overages` response header when present                         | `audio_duration_secs` at `$0.22 / audio hour`                                                     |

Do not promise realtime WebSocket credit deduction in generated-app UI or docs until the backend reconciles Gateway realtime usage. The current proxy can gate connection by balance/rate limit and log session metadata; accurate charging needs either Gateway usage/cost data in realtime events or a delayed Upstash/QStash reconciliation job keyed by a stable Gateway generation/request/session id.

For generated project audio assets, cost scales with generated duration, requested voices/dialogue length, and retries. Reuse existing assets when appropriate, keep generated clips as short as the product needs, and avoid regenerating the same voice lines or sound effects repeatedly.

## Endpoints

| Method | Path                                                   | Description             |
| ------ | ------------------------------------------------------ | ----------------------- |
| POST   | `/v2/elevenlabs/v1/text-to-speech/[voice_id]`          | Text-to-speech          |
| POST   | `/v2/elevenlabs/v1/speech-to-speech/[voice_id]`        | Speech-to-speech        |
| POST   | `/v2/elevenlabs/v1/speech-to-speech/[voice_id]/stream` | Speech-to-speech stream |
| POST   | `/v2/elevenlabs/v1/text-to-dialogue`                   | Multi-speaker dialogue  |
| POST   | `/v2/elevenlabs/v1/sound-generation`                   | Sound effects           |
| POST   | `/v2/elevenlabs/v1/speech-to-text`                     | Speech-to-text          |

**Allowed paths:** `/v1/text-to-speech/*`, `/v1/speech-to-speech/[voice_id]`, `/v1/speech-to-speech/[voice_id]/stream`, `/v1/text-to-dialogue`, `/v1/sound-generation`, `/v1/speech-to-text` (with auth), `/v1/models`, `/v1/voices` (public). Other ElevenLabs paths (music, etc.) are blocked.

## POST /v2/elevenlabs/v1/text-to-speech/[voice_id]

Returns audio as binary (MP3).

### Request body

| Field         | Type   | Required | Description            |
| ------------- | ------ | -------- | ---------------------- |
| text          | string | yes      | Text to speak          |
| model_id      | string | no       | Default: `"eleven_v3"` |
| output_format | string | no       | e.g. `"mp3_44100_128"` |

### Available TTS Models

Before choosing an ElevenLabs `model_id`, refresh the raw catalog and filter it locally:

```sh
audio_catalog_dir="$(mktemp -d /tmp/rork-audio-models.XXXXXX)"
curl -fsS https://toolkit.rork.com/v2/elevenlabs/v1/models -o "$audio_catalog_dir/elevenlabs-models.json.tmp"
jq -e 'type == "array"' "$audio_catalog_dir/elevenlabs-models.json.tmp" >/dev/null
mv "$audio_catalog_dir/elevenlabs-models.json.tmp" "$audio_catalog_dir/elevenlabs-models.json"
```

Filter `$audio_catalog_dir/elevenlabs-models.json` with `jq` or `rg`.

### Voice IDs

Call the `listVoices` tool to get available voice IDs and model compatibility metadata. Always call this before using a voice endpoint. The tool returns up to 100 raw ElevenLabs v1 voice objects without renaming fields; use `pageSize` when a smaller list is enough. Inspect `voice_id`, `name`, `labels`, `high_quality_base_model_ids`, and `verified_languages[].model_id` when choosing a voice for a selected `model_id`.

## POST /v2/elevenlabs/v1/speech-to-speech/[voice_id]

Transforms uploaded speech audio into the selected voice while preserving timing, emotion, and delivery. Use this when the user provides spoken audio and wants the same performance in another voice. Use text-to-speech instead when the input is text.

### Request body

Send `multipart/form-data` directly through the Rork proxy:

| Field                   | Type   | Required | Description                                             |
| ----------------------- | ------ | -------- | ------------------------------------------------------- |
| audio                   | file   | yes      | Source speech audio                                     |
| model_id                | string | no       | Use `"eleven_multilingual_sts_v2"` for multilingual STS |
| voice_settings          | string | no       | JSON-encoded ElevenLabs voice settings                  |
| remove_background_noise | bool   | no       | `"true"` to clean noisy input before voice conversion   |
| file_format             | string | no       | `"other"` by default; use `"pcm_s16le_16"` for raw PCM  |

### Query parameters

| Param         | Type   | Description                      |
| ------------- | ------ | -------------------------------- |
| output_format | string | e.g. `"mp3_44100_128"` (default) |

Use `/v2/elevenlabs/v1/speech-to-speech/[voice_id]/stream` for streaming audio output with the same multipart request shape.

## POST /v2/elevenlabs/v1/sound-generation

Returns audio as binary. Billed per generation.

### Request body

| Field            | Type   | Required | Description                    |
| ---------------- | ------ | -------- | ------------------------------ |
| text             | string | yes      | Describe the sound to generate |
| duration_seconds | number | no       | Desired duration in seconds    |

## POST /v2/elevenlabs/v1/text-to-dialogue

Returns audio as binary. Multi-speaker dialogue generation.

### Request body

| Field    | Type   | Required | Description                                   |
| -------- | ------ | -------- | --------------------------------------------- |
| inputs   | array  | yes      | `[{ "text": "...", "voice_id": "..." }, ...]` |
| model_id | string | no       | Default: `"eleven_v3"`                        |

### Query parameters

| Param         | Type   | Description                      |
| ------------- | ------ | -------------------------------- |
| output_format | string | e.g. `"mp3_44100_128"` (default) |

## Implementation

Pick the section that matches the app you're working in. The endpoints, auth, request shapes, and response binaries are identical across platforms — only the HTTP client differs.

### React Native / TypeScript

Read these sample files for complete, working examples:

| File                                                | Description                                          |
| --------------------------------------------------- | ---------------------------------------------------- |
| `ts/example-vercel-gateway-speech.ts`               | Gateway text-to-speech with base64 audio output      |
| `ts/example-vercel-gateway-transcription.ts`        | Gateway speech-to-text from base64 audio             |
| `ts/example-vercel-gateway-realtime-setup-route.ts` | Setup response for browser AI SDK realtime hook      |
| `ts/example-vercel-gateway-realtime-browser.tsx`    | Gateway realtime through Toolkit with AI SDK codec   |
| `ts/example-vercel-gateway-realtime-node.ts`        | Bun/Node Gateway realtime smoke test through Toolkit |
| `ts/example-elevenlabs-ai-sdk-transcribe.ts`        | AI SDK Scribe transcription through the Rork proxy   |
| `ts/example-elevenlabs-tts.ts`                      | Text-to-speech with audio file output                |
| `ts/example-elevenlabs-speech-to-speech.ts`         | Speech-to-speech voice conversion                    |
| `ts/example-elevenlabs-dialogue.ts`                 | Multi-speaker dialogue generation                    |
| `ts/example-elevenlabs-sound-generation.ts`         | Sound effect generation from text description        |
| `ts/example-elevenlabs-scribe.ts`                   | Raw `fetch` Scribe file upload fallback              |

### Swift (`URLSession`)

Swift cannot use the Vercel AI SDK. Use `URLSession` for Gateway speech and transcription REST calls. Do not generate native Swift realtime WebSocket apps from scratch; realtime Swift should call a server/JS bridge that uses the AI SDK codec unless the user explicitly asks for a maintained native Swift sample with verified Gateway lifecycle and PCM16 audio handling.

Read these Swift sample files for complete, working examples:

| File                                               | Description                                                                |
| -------------------------------------------------- | -------------------------------------------------------------------------- |
| `swift/example-vercel-gateway-speech.swift`        | Gateway text-to-speech with audio file output                              |
| `swift/example-vercel-gateway-transcription.swift` | Gateway speech-to-text from a local audio file                             |
| `swift/example-elevenlabs-tts.swift`               | Text-to-speech with audio file output                                      |
| `swift/example-elevenlabs-speech-to-speech.swift`  | Speech-to-speech voice conversion                                          |
| `swift/example-elevenlabs-dialogue.swift`          | Multi-speaker dialogue generation                                          |
| `swift/example-elevenlabs-sound-generation.swift`  | Sound effect generation from text description                              |
| `swift/example-elevenlabs-list-voices.swift`       | List available voices and their IDs (call before TTS / dialogue endpoints) |
| `swift/example-elevenlabs-scribe.swift`            | Speech-to-text with Scribe file upload or `source_url`                     |

## Speech-to-Text

Use Vercel AI Gateway transcription for new speech-to-text, dictation, voice memo, and caption features when a Gateway transcription model satisfies the product requirements. Use ElevenLabs Scribe when richer diarization/timestamps or ElevenLabs-specific behavior matters.

If the user asks for an AI response to recorded spoken audio, transcribe through Gateway first, then send the transcript to the chosen AI model.

For Swift apps that need native Apple speech recognition, offline or on-device transcription, privacy-preserving local processing, voice activity detection, custom vocabulary, or direct use of Apple Speech APIs, read `.rork/skills/swift/audio-analysis-reference.md`. Prefer `SpeechAnalyzer`, `SpeechTranscriber`, and `SpeechDetector` for those cases when they are available, and fall back to `SFSpeechRecognizer` for older OS support.

For app ideas and product patterns such as VAD-gated transcription into an AI agent, read `.rork/skills/audio/idea.md`.

### Gateway transcription default

Use the Gateway transcription endpoint for the default hosted STT path:

| Method | Path                                   | Description                      |
| ------ | -------------------------------------- | -------------------------------- |
| POST   | `/v2/vercel/v4/ai/transcription-model` | Speech-to-text from base64 audio |

Send JSON with base64 `audio` and `mediaType`, and pass the model in the `ai-model-id` header:

```ts
const response = await fetch(`${toolkitURL}/v2/vercel/v4/ai/transcription-model`, {
  method: "POST",
  headers: {
    Authorization: `Bearer ${secretKey}`,
    "Content-Type": "application/json",
    "ai-model-id": "xai/grok-stt",
  },
  body: JSON.stringify({
    audio: base64Audio,
    mediaType: "audio/mpeg",
  }),
});

const transcript = await response.json();
```

Read `ts/example-vercel-gateway-transcription.ts` or `swift/example-vercel-gateway-transcription.swift` for complete examples.

### ElevenLabs Scribe fallback

Use ElevenLabs Scribe when the app needs diarization, word timestamps, `source_url`, or other ElevenLabs-specific transcription behavior.

| Method | Path                               | Description    |
| ------ | ---------------------------------- | -------------- |
| POST   | `/v2/elevenlabs/v1/speech-to-text` | Speech-to-text |

#### Request

Send `multipart/form-data` directly through the Rork proxy:

| Field         | Type   | Required | Description                                                                                       |
| ------------- | ------ | -------- | ------------------------------------------------------------------------------------------------- |
| model_id      | enum   | yes      | Use `"scribe_v2"`                                                                                 |
| file          | file   | no       | Audio/video file to transcribe                                                                    |
| source_url    | URL    | no       | Hosted audio/video URL                                                                            |
| diarize       | bool   | no       | Speaker labels when appropriate                                                                   |
| language_code | string | no       | Leave unset by default; only pass when the language is known and auto-detection is causing errors |

Exactly one of `file`, `source_url`, or ElevenLabs' legacy `cloud_storage_url` should be provided.

`source_url` was verified against the ElevenLabs API with `scribe_v2`: a hosted WAV returned HTTP 200, `audio_duration_secs`, `fiat-cost-before-overages`, `fiat-currency`, and `character-cost`. Use `source_url` when the audio is already hosted and reachable by ElevenLabs; use `file` when the app only has local bytes.

Do not set `language_code` by default. Scribe auto-detects the language and returns the detected `language_code` in the response. Add `language_code` only for product flows where the language is already known and auto-detection has produced bad transcripts.

#### Response

Scribe returns the transcript, word timestamps, optional speaker/audio event metadata, `transcription_id`, and `audio_duration_secs`. The proxy bills from ElevenLabs' fiat cost header when present and falls back to `audio_duration_secs` at the Scribe API rate if that header is absent.

#### AI SDK example

Use `ts/example-elevenlabs-ai-sdk-transcribe.ts` for the primary TypeScript implementation. The ElevenLabs AI SDK cookbook shows transcription with `experimental_transcribe` and `elevenlabs.transcription("scribe_v2")`, which matches the direct API `model_id=scribe_v2` used by the proxy.

Keep the custom `fetch` wrapper; without it the provider calls `https://api.elevenlabs.io/v1/speech-to-text` directly instead of the Rork proxy.

```ts
import { createElevenLabs } from "@ai-sdk/elevenlabs";
import { experimental_transcribe as transcribe } from "ai";

const elevenlabs = createElevenLabs({
  apiKey: secretKey,
  fetch: proxyFetch,
});

const result = await transcribe({
  model: elevenlabs.transcription("scribe_v2"),
  audio,
  providerOptions: {
    elevenlabs: {
      diarize: true,
      timestampsGranularity: "word",
    },
  },
});
```

### Raw fetch example

Use `ts/example-elevenlabs-scribe.ts` when the AI SDK is not available or when you need to send ElevenLabs' `source_url` field directly. The important request shapes are:

```ts
const body = new FormData();
body.append("model_id", "scribe_v2");
body.append("file", audioFile);
body.append("diarize", "true");

const response = await fetch(`${toolkitURL}/v2/elevenlabs/v1/speech-to-text`, {
  method: "POST",
  headers: {
    Authorization: `Bearer ${secretKey}`,
  },
  body,
});

const transcript = await response.json();
```

For hosted audio, replace `file` with `source_url`:

```ts
const body = new FormData();
body.append("model_id", "scribe_v2");
body.append("source_url", hostedAudioUrl);
body.append("diarize", "true");
```

The AI SDK `audio: new URL(...)` path downloads the URL client-side and sends bytes to ElevenLabs; it does not forward ElevenLabs' `source_url` field.

## Error Handling

See `error-handling.md` (in the `ai` skill) for the full error status codes, user-facing messages, and retry strategy.

## Available tools

### listVoices

Lists available ElevenLabs voices for text-to-speech and dialogue generation.
Call this BEFORE using generateAudio with type "voice" or "dialogue" to get valid voiceId values.
Returns the raw ElevenLabs voice objects without renaming fields, including compatibility fields such as high_quality_base_model_ids and verified_languages when present.
Returns up to 100 voices per call from the v1 voices metadata endpoint.
Choose voices that match the character, use case, and selected model_id.

```json
{"type":"object","properties":{"pageSize":{"description":"Number of voices to fetch, default 100","type":"integer","minimum":1,"maximum":100}}}
```

### getVoiceDetails

Get detailed information about a specific ElevenLabs voice by ID. Returns the raw ElevenLabs voice object without renaming fields.

```json
{"type":"object","properties":{"voiceId":{"type":"string","description":"Voice ID (e.g. 'JBFqnCBsd6RMkjVDRZzb')"}},"required":["voiceId"]}
```

### verifyVoiceId

Check whether a voice ID exists in ElevenLabs using the direct voice metadata endpoint. Returns only exists/not-exists — use this to validate voice IDs before writing code.

```json
{"type":"object","properties":{"voiceId":{"type":"string","description":"Voice ID to verify"}},"required":["voiceId"]}
```
