---
name: app-intents
description: Siri & Shortcuts integration with App Intents framework — AppIntent protocol, @Parameter, SiriTipView, AppShortcutsProvider, EntityQuery, OpenIntent. Makes app actions available to Siri, Shortcuts, and Spotlight. iOS 16+. Read when exposing app functionality to Siri or Shortcuts.
---

# App Intents — Siri & Shortcuts (iOS 16+)

The App Intents framework exposes your app's actions to Siri, Shortcuts, and Spotlight. Define intents as Swift structs conforming to `AppIntent`.

**Note:** Widget-specific intents (`AppIntentTimelineProvider`, interactive widget buttons) are documented in `widgets-reference.md` in the `swift` docs. This skill covers Siri, Shortcuts, and general App Intents.

**Note:** The `swift-add-target` tool can scaffold a new app-intent extension target automatically.

## Triage Workflow

### Step 1: Identify the integration surface

| Surface              | Protocol                     | Since  |
| -------------------- | ---------------------------- | ------ |
| Siri / Shortcuts     | `AppIntent`                  | iOS 16 |
| Configurable widget  | `WidgetConfigurationIntent`  | iOS 17 |
| Control Center       | `ControlConfigurationIntent` | iOS 18 |
| Spotlight search     | `IndexedEntity`              | iOS 18 |
| Apple Intelligence   | `@AppIntent(schema:)`        | iOS 18 |
| Interactive snippets | `SnippetIntent`              | iOS 26 |

### Step 2: Define the data model

- Create `AppEntity` shadow models (do NOT conform core data models directly)
- Create `AppEnum` types for fixed parameter choices
- Choose the right `EntityQuery` variant for resolution
- Mark searchable entities with `IndexedEntity` and `@Property(indexingKey:)`

### Step 3: Implement the intent

- Conform to `AppIntent` (or a specialised sub-protocol)
- Declare `@Parameter` properties for all user-facing inputs
- Implement `perform() async throws -> some IntentResult`
- Add `parameterSummary` for Shortcuts UI
- Register phrases via `AppShortcutsProvider`

## AppIntent Protocol

```swift
import AppIntents

struct OrderSoupIntent: AppIntent {
    static var title: LocalizedStringResource = "Order Soup"
    static var description = IntentDescription("Orders a bowl of soup from the menu.")

    @Parameter(title: "Soup")
    var soup: SoupEntity

    @Parameter(title: "Quantity", default: 1)
    var quantity: Int

    static var parameterSummary: some ParameterSummary {
        Summary("Order \(\.$quantity) of \(\.$soup)")
    }

    func perform() async throws -> some IntentResult & ProvidesDialog {
        let order = try await OrderService.shared.place(soup: soup, quantity: quantity)
        return .result(dialog: "Ordered \(quantity) \(soup.name)!")
    }
}
```

### IntentResult Variants

| Return Type                               | Usage                                                   |
| ----------------------------------------- | ------------------------------------------------------- |
| `.result()`                               | No value returned                                       |
| `.result(value: T)`                       | Returns a typed value (conform to `ReturnsValue`)       |
| `.result(dialog: IntentDialog)`           | Speaks/shows dialog (conform to `ProvidesDialog`)       |
| `.result(value: T, dialog: IntentDialog)` | Value + dialog                                          |
| `.result(view: some View)`                | Shows a SwiftUI snippet (conform to `ShowsSnippetView`) |

### Key Static Properties

```swift
static var title: LocalizedStringResource          // Short verb + noun, title case
static var description: IntentDescription?         // Shown in Shortcuts
static var openAppWhenRun: Bool                    // Default: false
```

## @Parameter Property Wrapper

Declares a parameter that Siri and Shortcuts can resolve:

```swift
// Basic
@Parameter(title: "Name")
var name: String

// With default value
@Parameter(title: "Quantity", default: 1)
var quantity: Int

// With request dialog (Siri asks this if value is missing)
@Parameter(title: "Landmark", requestValueDialog: "Which landmark would you like to open?")
var target: LandmarkEntity

// Optional parameter
@Parameter(title: "Note")
var note: String?

// Numeric slider
@Parameter(title: "Volume", controlStyle: .slider, inclusiveRange: (0, 100))
var volume: Int

// Dynamic options provider
@Parameter(title: "Category", optionsProvider: CategoryOptionsProvider())
var category: Category

// File with content types
@Parameter(title: "Document", supportedContentTypes: [.pdf, .plainText])
var document: IntentFile

// Measurement with unit
@Parameter(title: "Distance", defaultUnit: .miles, supportsNegativeNumbers: false)
var distance: Measurement<UnitLength>
```

**Important:** Non-optional parameters without a `default` prevent the system from showing a preview.

### Supported Parameter Types

- `String`, `Int`, `Double`, `Bool`, `Date`, `URL`
- `AppEnum` conforming types
- `AppEntity` conforming types
- `IntentFile`
- Arrays of the above
- Optional variants

### Parameter Projections

Inside `perform()`, use `$parameterName` for disambiguation:

```swift
func perform() async throws -> some IntentResult {
    guard quantity > 0 else {
        throw $quantity.needsValue("How many would you like?")
    }
    // ...
}
```

## AppEnum — Static Option Lists

**Important:** `AppEnum` only supports `String` raw values. Using `Int` raw values will fail at runtime even though `Int` conforms to `LosslessStringConvertible` — the App Intents framework explicitly requires string-backed enums.

For parameters with a fixed set of choices:

```swift
enum WorkoutStyle: String, AppEnum {
    case running, cycling, swimming

    static var typeDisplayRepresentation: TypeDisplayRepresentation = "Workout Style"

    static var caseDisplayRepresentations: [WorkoutStyle: DisplayRepresentation] = [
        .running:  "Running",
        .cycling:  "Cycling",
        .swimming: "Swimming",
    ]
}

// Used in an intent
@Parameter(title: "Style")
var style: WorkoutStyle
```

## AppEntity — Dynamic Entities

For parameters that reference app-specific data:

```swift
struct SoupEntity: AppEntity {
    static var typeDisplayRepresentation: TypeDisplayRepresentation = "Soup"
    static var defaultQuery = SoupQuery()

    var id: String

    @Property(title: "Name")
    var name: String

    @Property(title: "Price")
    var price: Double

    var displayRepresentation: DisplayRepresentation {
        DisplayRepresentation(title: "\(name)")
    }
}
```

Properties annotated with `@Property(title:)` are exposed to Shortcuts for filtering and sorting. Properties without `@Property` remain internal.

## EntityQuery — Looking Up Entities

Siri and Shortcuts use queries to find entities:

```swift
// Basic query — look up by ID
struct SoupQuery: EntityQuery {
    func entities(for identifiers: [String]) async throws -> [SoupEntity] {
        SoupStore.shared.soups.filter { identifiers.contains($0.id) }
    }

    func suggestedEntities() async throws -> [SoupEntity] {
        SoupStore.shared.popularSoups
    }
}

// String search query — Siri can search by text
struct SoupQuery: EntityStringQuery {
    func entities(for identifiers: [String]) async throws -> [SoupEntity] {
        SoupStore.shared.soups.filter { identifiers.contains($0.id) }
    }

    func entities(matching string: String) async throws -> [SoupEntity] {
        SoupStore.shared.soups.filter { $0.name.localizedCaseInsensitiveContains(string) }
    }

    func suggestedEntities() async throws -> [SoupEntity] {
        SoupStore.shared.popularSoups
    }
}
```

### EnumerableEntityQuery — finite set

```swift
struct AllSoupsQuery: EnumerableEntityQuery {
    func allEntities() async throws -> [SoupEntity] {
        SoupStore.shared.allSoups.map { SoupEntity(from: $0) }
    }

    func entities(for identifiers: [String]) async throws -> [SoupEntity] {
        SoupStore.shared.soups.filter { identifiers.contains($0.id) }.map { SoupEntity(from: $0) }
    }
}
```

### UniqueAppEntityQuery — singleton (iOS 18+)

For single-instance entities like app settings:

```swift
struct AppSettingsQuery: UniqueAppEntityQuery {
    func entity() async throws -> AppSettingsEntity { AppSettingsEntity() }
}
```

## AppShortcutsProvider — Discoverable Shortcuts

Register shortcuts so they appear in Siri, Spotlight, and Shortcuts app without user setup:

```swift
struct MyAppShortcuts: AppShortcutsProvider {
    static var appShortcuts: [AppShortcut] {
        AppShortcut(
            intent: OrderSoupIntent(),
            phrases: [
                "Order \(\.$soup) from \(\.applicationName)",
                "Get me some \(\.$soup) on \(\.applicationName)",
            ],
            shortTitle: "Order Soup",
            systemImageName: "takeoutbag.and.cup.and.straw.fill"
        )
    }

    static var shortcutTileColor: ShortcutTileColor = .orange
}
```

**Register at app launch** (required for Siri to find shortcuts immediately):

```swift
@main
struct MyApp: App {
    init() {
        MyAppShortcuts.updateAppShortcutParameters()
    }

    var body: some Scene {
        WindowGroup { ContentView() }
    }
}
```

### Phrase Interpolation

- `\(\.$parameterName)` — inserts the parameter's display value
- `\(\.applicationName)` — inserts the app name (required in at least one phrase)

Use `negativePhrases` to prevent false Siri activations for phrases that sound similar to your shortcuts.

## Intent Donation

Donate intents so the system learns user patterns and suggests them in Spotlight:

```swift
let intent = OrderSoupIntent()
intent.soup = favoriteSoupEntity
try await intent.donate()
```

## SiriTipView — In-App Siri Suggestions (iOS 16+)

Shows the spoken phrase a user says to invoke an App Shortcut:

```swift
struct ContentView: View {
    @State private var showSiriTip = true

    var body: some View {
        VStack {
            Button("Reorder") { /* ... */ }

            SiriTipView(intent: OrderSoupIntent(), isVisible: $showSiriTip)
                .siriTipViewStyle(.dark)
        }
    }
}
```

**Important:** `SiriTipView` renders as empty if the intent is not registered in an `AppShortcut` via `AppShortcutsProvider`.

### UIKit Equivalent

Use `SiriTipUIView` for UIKit-based views — same semantics.

## OpenIntent — Deep Linking from Siri

For "open this item" actions, the system automatically generates phrases like "Open [entity] in [app]":

```swift
struct OpenLandmarkIntent: OpenIntent {
    static let title: LocalizedStringResource = "Open Landmark"

    @Parameter(title: "Landmark", requestValueDialog: "Which landmark?")
    var target: LandmarkEntity

    func perform() async throws -> some IntentResult {
        LandmarkNavigator.shared.open(target)
        return .result()
    }
}
```

## ParameterSummary

Controls how the intent appears in the Shortcuts editor:

```swift
static var parameterSummary: some ParameterSummary {
    Summary("Order \(\.$quantity) of \(\.$soup)") {
        \.$deliveryAddress
        \.$note
    }
}
```

Parameters listed in `Summary(...)` appear inline. Additional parameters listed in the trailing closure appear in a "Show More" section.

## Entitlement

Apps using SiriKit features need the Siri entitlement:

```
com.apple.developer.siri = true
```

This is configured in `capabilities-entitlements.md`.

## Interactive Widget Intents

Use `AppIntent` with `Button`/`Toggle` in widgets:

```swift
struct ToggleFavouriteIntent: AppIntent {
    static var title: LocalizedStringResource = "Toggle Favourite"
    @Parameter(title: "Item ID") var itemID: String

    func perform() async throws -> some IntentResult {
        FavouriteStore.shared.toggle(itemID)
        return .result()
    }
}

// In widget view:
Button(intent: ToggleFavouriteIntent(itemID: entry.id)) {
    Image(systemName: entry.isFavourite ? "heart.fill" : "heart")
}
```

### WidgetConfigurationIntent

```swift
struct BookWidgetConfig: WidgetConfigurationIntent {
    static var title: LocalizedStringResource = "Favourite Book"
    @Parameter(title: "Book") var bookTitle: String
}

struct MyWidget: Widget {
    var body: some WidgetConfiguration {
        AppIntentConfiguration(kind: "FavouriteBook", intent: BookWidgetConfig.self, provider: MyTimelineProvider()) { entry in
            BookWidgetView(entry: entry)
        }
    }
}
```

Widget-specific intents for `AppIntentTimelineProvider` and interactive widget buttons are also covered in `widgets-reference.md` in the `swift` docs.

## Control Center Widgets (iOS 18+)

```swift
struct LightControlConfig: ControlConfigurationIntent {
    static var title: LocalizedStringResource = "Light Control"
    @Parameter(title: "Light", default: .livingRoom) var light: LightEntity
}

struct LightControl: ControlWidget {
    var body: some ControlWidgetConfiguration {
        AppIntentControlConfiguration(kind: "LightControl", intent: LightControlConfig.self) { config in
            ControlWidgetToggle(config.light.name, isOn: config.light.isOn, action: ToggleLightIntent(light: config.light))
        }
    }
}
```

## Spotlight and IndexedEntity (iOS 18+)

```swift
struct RecipeEntity: IndexedEntity {
    static let defaultQuery = RecipeQuery()
    static var typeDisplayRepresentation: TypeDisplayRepresentation = "Recipe"
    var id: String

    @Property(title: "Name", indexingKey: .title) var name: String
    @ComputedProperty(indexingKey: .description)
    var summary: String { "\(name) — a delicious recipe" }

    var displayRepresentation: DisplayRepresentation {
        DisplayRepresentation(title: "\(name)")
    }
}
```

## iOS 26 Additions

### SnippetIntent

Interactive snippets in system UI:

```swift
struct OrderStatusSnippet: SnippetIntent {
    static var title: LocalizedStringResource = "Order Status"
    func perform() async throws -> some IntentResult & ShowsSnippetView {
        let status = await OrderTracker.currentStatus()
        return .result(view: OrderStatusSnippetView(status: status))
    }
}
```

### IntentValueQuery (Visual Intelligence)

```swift
struct ProductValueQuery: IntentValueQuery {
    typealias Input = String
    typealias Result = ProductEntity
    func values(for input: String) async throws -> [ProductEntity] {
        ProductStore.shared.search(input).map { ProductEntity(from: $0) }
    }
}
```

## Anti-Patterns

| Anti-Pattern                                                      | Fix                                                       |
| ----------------------------------------------------------------- | --------------------------------------------------------- |
| Not calling `updateAppShortcutParameters()` at launch             | Siri cannot discover shortcuts without it                 |
| Using `SiriTipView` without registering in `AppShortcutsProvider` | The tip view renders empty                                |
| Missing `\.applicationName` in all phrases                        | At least one phrase must include the app name             |
| Not implementing `suggestedEntities()` on queries                 | Siri has no suggestions to show users                     |
| Using raw strings instead of `AppEnum` for fixed choices          | Use `AppEnum` for type-safe, localisable options          |
| Creating intents without `parameterSummary`                       | Shortcuts editor shows a poor layout without it           |
| Non-optional `@Parameter` without default                         | System cannot preview. Add `default:` or make optional    |
| `Int` raw value for `AppEnum`                                     | Use `String` — `Int` is not `LosslessStringConvertible`   |
| Throwing for missing entities in `entities(for:)`                 | Omit missing entities from the result instead             |
| Missing `typeDisplayRepresentation`                               | Required on both `AppEntity` and `AppEnum`                |
| Using deprecated `@AssistantEntity(schema:)`                      | Use `@AppEntity(schema:)` and `@AppEnum(schema:)` instead |
| Blocking `perform()`                                              | Use `await` for all I/O — `perform()` is async            |
