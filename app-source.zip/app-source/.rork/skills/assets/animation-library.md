# Meshy Animation Library

All 678 animation presets available for generated humanoid models, grouped by category / subcategory. Line format: `<actionId> <name>`.

Pass the chosen numeric actionIds to `generate3DHumanoid({ animations: [...] })` (pre-seeds the widget's animation picker) or `append3DAnimations({ modelId, animations: [...] })` (adds clips to an existing rig-ready model). Only actionIds listed here exist — never invent ids.

## WalkAndRun / Walking

- 1 Walking_Woman
- 20 Walk_Fight_Back
- 21 Walk_Fight_Forward
- 30 Casual_Walk
- 55 Stage_Walk
- 106 Confident_Walk
- 107 Confident_Strut
- 108 Flirty_Strut
- 111 Injured_Walk
- 112 Monster_Walk
- 114 Proud_Strut
- 115 Quick_Walk
- 116 Run_to_Walk_Transition
- 117 Red_Carpet_Walk
- 118 Skip_Forward
- 119 Slow_Orc_Walk
- 121 Thoughtful_Walk
- 122 Texting_Walk
- 123 Unsteady_Walk
- 124 Walking_with_Phone
- 540 Injured_Walk_Backward
- 541 Walk_Backward_with_Gun_1
- 542 Walk_Backward_with_Grenade
- 543 Step_Back
- 544 Walk_Backward
- 545 Walk_Backward_with_Bow
- 546 Walk_Backward_with_Sword
- 547 Walk_Backward_with_Bow_1
- 548 Walk_Backward_with_Sword_Shield
- 549 Crawl_Backward
- 550 Carry_Heavy_Cannon_Forward
- 551 Carry_Heavy_Object_Walk
- 552 Carry_Water_Bucket_Walk
- 553 Elderly_Shaky_Walk
- 554 Funky_Walk
- 555 Limping_Walk_1
- 556 Limping_Walk_2
- 557 Limping_Walk_3
- 558 Limping_Walk
- 559 Sneaky_Walk
- 560 Spear_Walk
- 561 Step_Hip_Hop_Dance
- 562 Stumble_Walk
- 563 Stylish_Walk
- 564 Tightrope_Walk
- 565 Walk_with_Umbrella
- 566 walking_2
- 567 Walk_with_Walker_Support
- 610 Carry_Heavy_Cannon_Forward_inplace
- 611 Carry_Heavy_Object_Walk_inplace
- 612 Carry_Water_Bucket_Walk_inplace
- 613 Casual_Walk_inplace
- 621 Confident_Strut_inplace
- 622 Crawl_Backward_inplace
- 626 Elderly_Shaky_Walk_inplace
- 629 Flirty_Strut_inplace
- 632 Funky_Walk_inplace
- 637 Injured_Walk_inplace
- 638 Injured_Walk_Backward_inplace
- 645 Limping_Walk_inplace
- 646 Limping_Walk_1_inplace
- 647 Limping_Walk_2_inplace
- 648 Limping_Walk_3_inplace
- 652 Proud_Strut_inplace
- 653 Red_Carpet_Walk_inplace
- 667 Run_to_Walk_Transition_inplace
- 668 Skip_Forward_inplace
- 669 Slow_Orc_Walk_inplace
- 671 Sneaky_Walk_inplace
- 672 Spear_Walk_inplace
- 674 Stumble_Walk_inplace
- 675 Stylish_Walk_inplace
- 676 Texting_Walk_inplace
- 677 Tightrope_Walk_inplace
- 678 Unsteady_Walk_inplace
- 679 Walk_Backward_inplace
- 681 Walk_Backward_with_Bow_inplace
- 682 Walk_Backward_with_Bow_1_inplace
- 684 Walk_Backward_with_Grenade_inplace
- 686 Walk_Backward_with_Gun_1_inplace
- 687 Walk_Backward_with_Sword_inplace
- 688 Walk_Fight_Back_inplace
- 689 Walk_Fight_Forward_inplace
- 692 walking_2_inplace
- 693 Walking_with_Phone_inplace
- 695 Walk_with_Umbrella_inplace
- 696 Walk_with_Walker_Support_inplace

## WalkAndRun / Running

- 5 BackLeft_run
- 6 BackRight_Run
- 13 Jump_Run
- 14 Run_02
- 15 Run_03
- 16 RunFast
- 110 Hello_Run
- 120 Touch_and_Run
- 509 Lean_Forward_Sprint
- 510 Standard_Forward_Charge
- 511 Rifle_Charge
- 512 Male_Head_Down_Charge
- 513 Female_Head_Down_Charge
- 514 Female_Bow_Charge_Left_Hand
- 515 Female_Throwing_Stance_Charge
- 516 slide_light
- 517 slide_right
- 518 sliding_rool
- 519 sliding_stumble
- 530 run_fast_3
- 531 Sprint_and_Sudden_Stop
- 532 run_fast_4
- 533 run_fast_5
- 534 run_fast_6
- 535 run_fast_7
- 536 run_fast_8
- 537 run_fast_9
- 538 run_fast_10
- 539 run_fast_2
- 606 BackLeft_run_inplace
- 607 BackRight_Run_inplace
- 627 Female_Bow_Charge_Left_Hand_inplace
- 628 Female_Throwing_Stance_Charge_inplace
- 636 Hello_Run_inplace
- 643 Jump_Run_inplace
- 644 Lean_Forward_Sprint_inplace
- 654 Rifle_Charge_inplace
- 657 run_fast_10_inplace
- 658 run_fast_2_inplace
- 659 run_fast_3_inplace
- 660 run_fast_4_inplace
- 661 run_fast_5_inplace
- 662 run_fast_6_inplace
- 663 run_fast_7_inplace
- 664 run_fast_8_inplace
- 665 run_fast_9_inplace
- 673 Standard_Forward_Charge_inplace

## WalkAndRun / CrouchWalking

- 520 Crouch_Walk_with_Torch
- 521 Crouch_Walk_Left_with_Torch
- 522 Crouch_Walk_Right_with_Torch
- 523 Cautious_Crouch_Walk_Backward
- 524 Cautious_Crouch_Walk_Forward
- 525 Cautious_Crouch_Walk_Left
- 526 Cautious_Crouch_Walk_Right
- 527 Crouch_Walk_Left_with_Gun
- 528 Walk_Left_with_Gun
- 529 Walk_Backward_with_Gun
- 615 Cautious_Crouch_Walk_Backward_inplace
- 616 Cautious_Crouch_Walk_Forward_inplace
- 617 Cautious_Crouch_Walk_Left_inplace
- 618 Cautious_Crouch_Walk_Right_inplace
- 623 Crouch_Walk_Left_with_Gun_inplace
- 624 Crouch_Walk_Left_with_Torch_inplace
- 625 Crouch_Walk_Right_with_Torch_inplace
- 685 Walk_Backward_with_Gun_inplace
- 694 Walk_Left_with_Gun_inplace

## WalkAndRun / Swimming

- 568 Swim_Idle
- 569 Swim_Forward
- 570 swimming_to_edge

## WalkAndRun / TurningAround

- 571 Run_Turn_Left
- 572 Walk_Turn_Left
- 573 Rifle_Turn_Left
- 574 Walk_Turn_Left_with_Weapon
- 575 Combat_Idle_Turn_Left
- 576 Idle_Turn_Left
- 577 Idle_Step_Turn_Left
- 578 Idle_Torch_Turn_Left
- 579 Depressed_Full_Turn_Left
- 580 Sword_and_Shield_Alert_Turn_Left
- 581 Run_Sharp_Turn_Right
- 582 Run_Turn_Right
- 583 Walk_Turn_Right
- 584 Walk_Turn_Right_Female
- 585 Rifle_Aim_Turn_Right
- 586 Idle_Turn_Right
- 587 Walk_Turn_Right_Idle_Style
- 588 Frustrated_Turn_Right
- 589 Alert_Quick_Turn_Right
- 590 Sword_and_Shield_Alert_Turn_Right

## DailyActions / Idle

- 0 Idle
- 11 Idle_02
- 12 Idle_03
- 32 Chair_Sit_Idle_F
- 33 Chair_Sit_Idle_M
- 36 Confused_Scratch
- 38 Dozing_Elderly
- 48 Mirror_Viewing
- 243 Idle_3
- 244 Idle_4
- 245 Idle_5
- 246 Idle_6
- 247 Idle_7
- 248 Idle_8
- 249 Idle_9
- 250 Idle_10
- 251 Idle_11
- 252 Idle_12
- 253 Idle_13
- 254 Idle_14
- 255 Angry_Ground_Stomp
- 256 Angry_Ground_Stomp_1
- 257 Angry_Ground_Stomp_2
- 258 CrouchLookAroundBow
- 599 Idle_15

## DailyActions / LookingAround

- 2 Alert
- 3 Arise
- 333 Look_Around_Dumbfounded
- 334 Lower_Weapon_Look_Raise
- 335 Axe_Breathe_and_Look_Around
- 336 Long_Breathe_and_Look_Around
- 337 Torch_Look_Around
- 338 Short_Breathe_and_Look_Around
- 339 Walking_Scan_with_Sudden_Look_Back
- 340 Crawl_and_Look_Back
- 341 Walk_Slowly_and_Look_Around

## DailyActions / Interacting

- 25 Agree_Gesture
- 26 Angry_Stomp
- 28 Big_Wave_Hello
- 34 Checkout_Gesture
- 37 Discuss_While_Moving
- 41 Formal_Bow
- 42 Gentlemans_Bow
- 47 Listening_Gesture
- 49 Motivational_Cheer
- 50 Phone_Call_Gesture
- 56 Stand_and_Chat
- 285 open_door
- 286 open_door_1
- 287 open_door_2
- 288 open_door_3
- 289 open_door_4
- 290 Wave_One_Hand
- 291 Wave_for_Help
- 292 Gesture_with_Hand_on_Gun
- 293 Wave_for_Help_1
- 294 Wave_for_Help_2
- 295 Wave_for_Help_3
- 296 Wave_for_Help_4
- 297 Personalized_Gesture
- 298 Cheer_with_Both_Hands_Up
- 299 Stand_Clap_and_Sit_Down
- 300 Sit_Cheer_with_Left_Hand
- 301 Cheer_with_Both_Hands_1
- 302 Stand_Wave_and_Sit_Down
- 303 Cheer_with_Both_Hands
- 304 Seated_Fist_Pump
- 305 Stand_Cheer_and_Sit_Down
- 306 Cheer_with_One_Hand_Up
- 307 Sitting_Answering_Questions
- 308 Talk_Passionately
- 309 Talk_with_Left_Hand_on_Hip
- 310 Talk_with_Left_Hand_Raised
- 311 Stand_Talking_Angry
- 312 Phone_Conversation
- 313 Talk_with_Hands_Open
- 314 Talk_with_Right_Hand_Open
- 315 Hand_on_Hip_Gesture
- 316 Headache_Relief
- 317 Shrug
- 318 Scheming_Hand_Rub

## DailyActions / Transitioning

- 52 Sit_to_Stand_Transition_F
- 53 Sit_to_Stand_Transition_M
- 57 Stand_to_Sit_Transition_M
- 58 Step_to_Sit_Transition
- 60 Walk_to_Sit
- 344 Stand_Up1
- 345 Stand_Up2
- 346 Stand_Up3
- 347 Stand_Up4
- 348 Stand_Up5
- 349 Stand_Up6
- 350 Stand_Up7
- 351 Stand_Up8
- 352 Stand_Up9
- 353 Stand_Up10
- 354 Sitting_Clap
- 355 Sit_Finger_Wag_No
- 356 Sit_Hands_on_Head_Lean_Back
- 357 Sit_Thumbs_Up_Right
- 358 Sit_Shout_Hands_on_Mouth
- 359 Look_Back_and_Sit
- 360 Sit_to_standTransition_Female_2
- 361 Sit_Dodge
- 362 Sit_Cross_Legged
- 363 Sit_Cross_Legged_on_Floor
- 364 Sit_on_Chair_Arms_Crossed
- 365 Kneel_on_One_Knee_and_Stand
- 366 falling_down
- 367 SideLying_Reach_Help
- 368 Angry_To_Tantrum_Sit
- 369 Lie_Back_Leg_Swing
- 370 Stand_To_Side_Lying
- 371 Sit_Lie_Bed
- 372 Prone_Reach_Help

## DailyActions / Pushing

- 259 Step_Forward_and_Push
- 260 Push_Forward_and_Stop
- 261 Push_and_Walk_Forward
- 262 Crouch_and_Push_Forward

## DailyActions / Sleeping

- 263 Sleep_on_Desk
- 264 Cough_While_Sleeping
- 265 Groan_Holding_Stomach_in_Sleep
- 266 Lie_Down_Hands_Spread
- 267 Sleep_Normally
- 268 Sit_and_Doze_Off
- 269 sleep
- 270 Toss_and_Turn
- 271 Wake_Up_and_Look_Up
- 272 Lie_on_Chair_Sunbathe_and_Sleep

## DailyActions / PickingUpItem

- 273 Male_Run_Forward_Pick_Up_Left
- 274 Female_Crouch_Pick_Up_Place_Side
- 275 Female_Run_Forward_Pick_Up_Right
- 276 Male_Bend_Over_Pick_Up
- 277 Female_Crouch_Pick_Fruit_Basket_Stand
- 278 Female_Stand_Pick_Fruit_Basket
- 279 Female_Crouch_Pick_Gun_Point_Forward
- 280 Female_Crouch_Pick_Throw_Forward
- 281 Female_Bend_Over_Pick_Up_Inspect
- 282 Female_Walk_Pick_Put_In_Pocket
- 283 Pull_Radish
- 284 Collect_Object

## DailyActions / WorkingOut

- 319 air_squat
- 320 bicep_curl
- 321 bicycle_crunch
- 322 circle_crunch
- 323 golf_drive
- 324 idle_to_push_up
- 325 jump_push_up
- 326 jumping_jacks
- 327 kettlebell_swing
- 328 push_up_to_idle
- 329 push_up
- 330 situps
- 331 Sumo_High_Pull
- 598 kettlebell_swing_1

## DailyActions / Drinking

- 342 Stand_and_Drink
- 343 Sit_and_Drink

## Fighting / AttackingwithWeapon

- 4 Attack
- 86 Basic_Jump
- 89 Combat_Stance
- 91 Double_Blade_Spin
- 92 Double_Combo_Attack
- 95 Gun_Hold_Left_Turn
- 97 Left_Slash
- 98 Run_and_Shoot
- 102 Sword_Judgment
- 103 Simple_Kick
- 104 Side_Shot
- 105 Triple_Combo_Attack
- 128 Heavy_Hammer_Swing
- 222 Draw_and_Shoot_from_Back
- 223 Draw_and_Shoot_from_Back_1
- 224 Archery_Shot
- 225 Archery_Shot_1
- 226 Archery_Shot_2
- 227 Archery_Shot_3
- 228 Walk_Forward_with_Bow_Aimed
- 229 Draw_and_Shoot_from_Back_2
- 230 Walk_Backward_with_Bow_Aimed
- 231 Archery_Aim_with_Lateral_Scan
- 232 Cowboy_Quick_Draw_Shooting
- 233 Walk_Backward_While_Shooting
- 234 Walk_Forward_While_Shooting
- 235 Forward_Roll_and_Fire
- 236 Draw_and_Shoot_Left
- 237 Charged_Axe_Chop
- 238 Axe_Spin_Attack
- 239 Crouch_Pull_and_Throw
- 240 Thrust_Slash
- 241 Weapon_Combo_2
- 242 Charged_Slash
- 680 Walk_Backward_While_Shooting_inplace
- 683 Walk_Backward_with_Bow_Aimed_inplace
- 690 Walk_Forward_While_Shooting_inplace
- 691 Walk_Forward_with_Bow_Aimed_inplace

## Fighting / GettingHit

- 7 BeHit_FlyUp
- 172 Electrocution_Reaction
- 173 Slap_Reaction
- 174 Face_Punch_Reaction
- 175 Face_Punch_Reaction_1
- 176 Face_Punch_Reaction_2
- 177 Gunshot_Reaction
- 178 Hit_Reaction
- 179 Hit_Reaction_1
- 180 Shot_in_the_Back_and_Fall
- 608 BeHit_FlyUp_inplace

## Fighting / Dying

- 8 Dead
- 181 Electrocuted_Fall
- 182 Shot_and_Blown_Back
- 183 Shot_and_Fall_Backward
- 184 Shot_and_Fall_Forward
- 185 Shot_and_Slow_Fall_Backward
- 186 Strangled_and_Fall_Forward
- 187 Knock_Down
- 188 Fall_Dead_from_Abdominal_Injury
- 189 dying_backwards
- 190 Knock_Down_1

## Fighting / Transitioning

- 9 ForwardLeft_Run_Fight
- 10 ForwardRight_Run_Fight
- 85 Axe_Stance
- 88 Chest_Pound_Taunt
- 99 Reaping_Swing
- 100 Rightward_Spin
- 156 Stand_Dodge
- 157 Stand_Dodge_1
- 158 Roll_Dodge
- 159 Roll_Dodge_1
- 160 Roll_Dodge_2
- 161 Roll_Dodge_3
- 162 Stand_Dodge_2
- 163 Roll_Dodge_4
- 164 Stand_Dodge_3
- 165 Kneeling_Reload
- 166 Running_Reload
- 167 Slow_Walk_Reload
- 168 Prone_Reload
- 169 Forward_Reload_Subtle
- 170 Standing_Reload
- 171 Hit_Reaction_to_Waist
- 630 ForwardLeft_Run_Fight_inplace
- 631 ForwardRight_Run_Fight_inplace
- 666 Running_Reload_inplace
- 670 Slow_Walk_Reload_inplace

## Fighting / Punching

- 87 Boxing_Practice
- 90 Counterstrike
- 93 Dodge_and_Counter
- 94 Flying_Fist_Kick
- 96 Kung_Fu_Punch
- 191 Left_Jab_from_Guard
- 192 Right_Jab_from_Guard
- 193 Left_Hook_from_Guard
- 194 Right_Uppercut_from_Guard
- 195 Right_Upper_Hook_from_Guard
- 196 Left_Uppercut_from_Guard
- 197 Left_Short_Hook_from_Guard
- 198 Punch_Combo
- 199 Weapon_Combo
- 200 Punch_Combo_1
- 201 Punch_Combo_2
- 202 Weapon_Combo_1
- 203 Punch_Combo_3
- 204 Punch_Combo_4
- 205 Punch_Combo_5
- 206 Spartan_Kick
- 207 Roundhouse_Kick
- 208 Lunge_Roundhouse_Kick
- 209 Boxing_Guard_Right_Straight_Kick
- 210 Boxing_Guard_Prep_Straight_Punch
- 211 Boxing_Guard_Step_Knee_Strike
- 212 Elbow_Strike
- 213 Leg_Sweep
- 214 Punch_Forward_with_Both_Fists
- 215 High_Kick
- 216 Lunge_Spin_Kick
- 217 Sweeping_Kick
- 218 Step_in_High_Kick
- 219 Right_Hand_Sword_Slash
- 220 Shield_Push_Left
- 221 Charged_Upward_Slash
- 609 Boxing_Practice_inplace
- 649 Lunge_Roundhouse_Kick_inplace

## Fighting / CastingSpell

- 125 Charged_Spell_Cast
- 126 Charged_Spell_Cast_1
- 127 Charged_Ground_Slam
- 129 mage_soell_cast
- 130 mage_soell_cast_1
- 131 mage_soell_cast_2
- 132 mage_soell_cast_3
- 133 mage_soell_cast_4
- 134 mage_soell_cast_5
- 135 mage_soell_cast_6
- 136 mage_soell_cast_7
- 137 mage_soell_cast_8

## Fighting / Blocking

- 138 Block1
- 139 Block2
- 140 Block3
- 141 Block4
- 142 Block5
- 143 Block6
- 144 Block8
- 145 Block9
- 146 Block10
- 147 Sword_Parry
- 148 Sword_Parry_Backward
- 149 Two_Handed_Parry
- 150 Hit_Reaction_with_Bow
- 151 Sword_Parry_Backward_1
- 152 Sword_Parry_Backward_2
- 153 Sword_Parry_Backward_3
- 154 Sword_Parry_Backward_4
- 155 Sword_Parry_Backward_5

## BodyMovements / Acting

- 17 Skill_01
- 18 Skill_02
- 19 Skill_03
- 27 Big_Heart_Gesture
- 29 Call_Gesture
- 31 Catching_Breath
- 35 Clapping_Run
- 39 Excited_Walk_F
- 40 Excited_Walk_M
- 43 Handbag_Walk
- 44 Happy_jump_f
- 45 Indoor_Play
- 46 Jump_Rope
- 51 Shouting_Angrily
- 59 Victory_Cheer
- 61 happy_jump_m
- 62 penguin_walk
- 101 Sword_Shout
- 109 Groovy_Walk
- 113 Mummy_Stagger
- 375 Handstand_Flip
- 376 Punch_Pose
- 377 Relax_arms_then_strike_battle_pose
- 378 Large_step_then_high_kick
- 379 Side_jumps_in_horse_stance
- 381 Step_Right_for_Exercise
- 382 Jump_and_Slam_Back_Down
- 384 Quick_Step_and_Spin_Dodge
- 385 Boxing_Warmup
- 386 Zombie_Scream
- 387 Half_Squat_with_Thumb_Up
- 388 Show_Both_Arm_Muscles
- 389 Grip_and_Throw_Down
- 390 Stand_on_Pole_and_Balance
- 391 Head_Hold_in_Pain
- 392 Ground_Flip_and_Sweep_Up
- 393 baseball_pitching
- 394 Backflip_and_Hooks
- 395 Breakdance_1990
- 396 Burpee_Exercise
- 397 360_Power_Spin_Jump
- 398 Crouch_Charge_and_Throw
- 399 Step_Step_Turn_Kick
- 401 Sprint_Roll_and_Flip
- 402 Run_and_Leap
- 403 Victory_Fist_Pump
- 404 Crouch_and_Step_Back
- 405 Joyful_Dance_with_Hand_Sway
- 406 Thomas_Flair_to_Jump_Up
- 407 Wall_Push_Jump_and_Flip
- 408 Jazz_Hands
- 409 Finger_Wag_No
- 410 Kick_a_Soccer_Ball
- 411 Neck_Slashing_Gesture
- 412 victory
- 413 Backflip_and_Rise
- 414 Double_kick_forward
- 415 Happy_Sway_Standing
- 416 Hit_in_Back_While_Running
- 417 Hop_with_Arms_Raised
- 419 Jump_to_Catch_and_Fall
- 420 Left_Hand_Bitten_Step_Back
- 421 Over_Shoulder_Throw
- 422 Rising_Flying_Kick
- 635 Handbag_Walk_inplace
- 639 Jazz_Hands_inplace
- 650 Mummy_Stagger_inplace
- 656 Run_and_Leap_inplace

## BodyMovements / VaultingOverObstacle

- 425 Vault_with_Rifle
- 426 Roll_Behind_Cover
- 427 Vault_and_Land
- 428 Unarmed_Vault
- 429 Parkour_Vault
- 430 Parkour_Vault_with_Roll
- 431 Parkour_Vault_1
- 432 Parkour_Vault_2
- 433 Parkour_Vault_3
- 651 Parkour_Vault_with_Roll_inplace

## BodyMovements / Climbing

- 434 Fast_Ladder_Climb
- 435 Ladder_Climb_Finish
- 436 Ladder_Mount_Start
- 437 Slow_Ladder_Climb
- 438 Ladder_Climb_Loop
- 439 Climb_Left_with_Both_Limbs
- 440 Climb_Right_with_Both_Limbs
- 441 Climb_Stairs
- 442 Fast_Stair_Climb
- 444 climbing_up_wall
- 445 diagonal_wall_run
- 446 Hang_and_Climb_Left
- 447 Hang_and_Climb_Rght
- 448 Jump_and_Grab_Wall
- 449 Climb_Up_Rope
- 497 climbing_down_wall
- 619 Climb_Left_with_Both_Limbs_inplace
- 620 Climb_Right_with_Both_Limbs_inplace

## BodyMovements / PerformingStunt

- 450 Wall_Flip
- 451 One_Arm_Handstand
- 452 Backflip
- 453 Backflip_Sweep_Kick
- 455 Sweep_Kick
- 456 Jumping_Head_Scissor_Takedown
- 457 Jumping_Punch
- 458 Unicycle_Jump_Dismount
- 459 Run_Jump_and_Roll
- 601 Backflip_inplace
- 604 Backflip_Sweep_Kick_inplace

## BodyMovements / Jumping

- 460 Jump_with_Arms_Open
- 461 Jump_with_Arms_and_Legs_Open
- 462 Backflip_Jump
- 463 Run_and_Jump
- 464 Leap_and_Punch
- 465 Leap_Right_and_Catch
- 466 Regular_Jump
- 467 Jump_Over_Obstacle_2
- 468 Back_Jump
- 470 Jumping_Down
- 471 Jump_Over_Obstacle
- 472 Jump_Over_Obstacle_1
- 605 Back_Jump_inplace
- 640 Jump_Over_Obstacle_inplace
- 641 Jump_Over_Obstacle_1_inplace
- 642 Jump_Over_Obstacle_2_inplace

## BodyMovements / HangingfromLedge

- 473 Quad_Jump_Left
- 474 Quad_Jump_Up
- 475 Quad_Climb_Right
- 476 Hang_and_Push_with_Foot
- 477 Rope_Hang_Idle
- 478 Bar_Hang_Idle
- 479 Upside_Down_Rope_Hang
- 480 Upside_Down_Rope_Hang_1
- 481 Upside_Down_Rope_Hang_2
- 482 Grab_Wall_Midair_Idle
- 483 Slow_Bar_Hang_Left
- 484 Slow_Bar_Hang_Right
- 485 Jump_and_Hang_on_Bar
- 486 Wall_Support_to_Step_Down
- 490 Fall_Down
- 491 Fall_from_Bar
- 492 Wall_Support_Jump_to_Ground
- 493 Jump_Down_from_Wall
- 494 Swing_on_Rope_to_Ground
- 495 Grab_Bar_and_Swing_Forward
- 496 Rope_Hang_Backflip_to_Crouch

## BodyMovements / FallingFreely

- 487 Climb_Attempt_and_Fall_3
- 488 Climb_Attempt_and_Fall_4
- 489 Climb_Attempt_and_Fall_5
- 498 Climb_Attempt_and_Fall
- 499 Climb_Attempt_and_Fall_1
- 500 Climb_Attempt_and_Fall_2
- 501 Leap_of_Faith
- 502 Fall1
- 503 Fall2
- 504 Fall3
- 505 Fall4
- 506 Dive_Down_and_Land
- 507 Dive_Down_and_Land_1
- 508 Dive_Down_and_Land_2

## Dancing / Dancing

- 22 FunnyDancing_01
- 23 FunnyDancing_02
- 24 FunnyDancing_03
- 54 Squat_Stance
- 63 Arm_Circle_Shuffle
- 64 All_Night_Dance
- 65 Bass_Beats
- 66 Boom_Dance
- 67 Bubble_Dance
- 68 Cherish_Pop_Dance
- 69 Crystal_Beads
- 70 Cardio_Dance
- 71 Denim_Pop_Dance
- 72 Dont_You_Dare
- 73 Fast_Lightning
- 74 Gangnam_Groove
- 75 Indoor_Swing
- 76 Love_You_Pop_Dance
- 77 Magic_Genie
- 78 Not_Your_Mom
- 79 OMG_Groove
- 80 Pop_Dance_LSA2
- 81 Pod_Baby_Groove
- 82 Shake_It_Off_Dance
- 83 Superlove_Pop_Dance
- 84 You_Groove
- 591 Hip_Hop_Dance
- 592 Hip_Hop_Dance_1
- 593 Hip_Hop_Dance_2
- 594 Hip_Hop_Dance_3
- 595 jazz_danc
- 596 ymca_dance
- 597 Hip_Hop_Dance_4
