# Generated 3D models on the web (three.js / React Three Fiber)

Generated 3D models and animations are delivered to web apps as **GLB URLs** — there is no Swift-style bundling step (the one exception: the shipping-time optimization recipe in "GLB weight and load time" below downloads GLBs to compress them). The generation tools (`generate3DAsset` / `generate3DHumanoid`) return the base model's GLB URL; `listExistingAssets` with `types: ["3d-model"]` lists every model's GLB URL, a Rigged GLB URL once the model has animations, and a GLB URL per accepted animation. Reference those URLs directly from the loader; for animated models render the Rigged GLB (see Animations below).

Use `@react-three/fiber` + `@react-three/drei` in the Vite React app (`bun add three @react-three/fiber @react-three/drei` — web projects use bun). Plain `three` with `GLTFLoader` works the same way for non-React render loops. Stay on the stable R3F 9.x / drei 10.x line — R3F v10 is in alpha; do not use v10-only APIs (`state.renderer`, `useUniforms`, `usePostProcessing`).

## Loading

```tsx
import { Suspense } from "react";
import { useGLTF } from "@react-three/drei";

function GeneratedModel({ url }: { url: string }) {
  const gltf = useGLTF(url); // remote R2 URL works directly; loaders fetch with CORS-safe defaults
  return <primitive object={gltf.scene} />;
}

// Always wrap remote models in <Suspense> so the scene renders while GLBs stream in.
<Suspense fallback={null}>
  <GeneratedModel url={MODEL_GLB_URL} />
</Suspense>;
```

Plain three.js: `const gltf = await new GLTFLoader().loadAsync(url)`.

- **Multiple instances of a skinned (rigged) model**: never reuse one `gltf.scene` across instances and never `scene.clone()` a skinned mesh — bones desync. Use `import * as SkeletonUtils from "three/addons/utils/SkeletonUtils.js"` and `SkeletonUtils.clone(gltf.scene)`, or drei's `<Clone object={gltf.scene} />` which does this automatically for skinned meshes.
- Static (non-rigged) props can be instanced/cloned freely; prefer `<Instances>`/`InstancedMesh` for many copies.
- Dispose geometries/materials/textures when a model leaves the scene for good (drei's `useGLTF` caches per URL — call `useGLTF.preload(url)` for known URLs).

## Placement contract (mirror of the Swift normalization contract)

Wrap every generated model in three groups and never position the loaded scene directly:

```text
container (Group)            ← world placement: position/rotate THIS for gameplay
└── generated_model_runtime  ← local motion: bob / lean / recoil / hover animate THIS
    └── visual (Group)       ← scale + orientation correction + centering applied ONCE here
        └── cloned gltf.scene
```

Normalization rules:

1. **Never mutate the cached `gltf.scene`.** drei's `useGLTF` shares one scene per URL across every consumer, and React StrictMode re-runs render/memo logic twice — in-place scaling silently compounds or self-cancels, producing models that are "accidentally correct" in dev and broken elsewhere. Clone first (`SkeletonUtils.clone` for rigged models, `<Clone>` for static props), compute the normalization as a pure function of the fresh clone, and apply it declaratively to the wrapper group (`<group position={...} quaternion={...} scale={n.scale}>`), never to the loaded scene itself.
2. **Measure with the skinned-aware helper below — never `Box3.setFromObject` on a rigged model.** `setFromObject` ignores skinning: it transforms raw geometry bounds by the mesh node's world matrix. Generated rigged GLBs ship an `Armature` root with scale 0.01 (cm→m) while the skinned geometry is authored in meters, so `setFromObject` reports ~1% of the rendered size and the "corrective" scale comes out ~100x — characters the size of buildings. At render time skinned vertices follow only the bones (GLTFLoader binds skinned meshes with an identity bind matrix, so the mesh node's own transform cancels out).
3. Scale so the relevant dimension matches the planned size (height for characters and floor props; length along the front axis for weapons/vehicles; longest axis only for directionless props).
4. Apply the orientation correction quaternion (below).
5. Transform the measured box by the scale+rotation (or re-measure), then offset so the model is centered on X/Z and grounded on Y. Do not only fix `min.y` — uncentered X/Z leaves the model's origin outside its anchor.
6. **Sanity-check the factor.** Generated models already arrive at roughly real-world scale, so a normalization factor far outside `0.2x–5x` almost always means the measurement is wrong (skinning ignored, or an already-normalized object re-measured) — fix the measurement, never ship the factor.

```ts
/**
 * Bounds of the model as actually rendered, in the object's local frame.
 * Box3.setFromObject is wrong for skinned meshes (rule 2): they must be
 * measured through their bones instead.
 */
function measureGeneratedModel(object: THREE.Object3D): THREE.Box3 {
  object.updateMatrixWorld(true);
  const rootInverse = object.matrixWorld.clone().invert();
  const box = new THREE.Box3();
  const childBox = new THREE.Box3();
  const toRoot = new THREE.Matrix4();
  object.traverse((node) => {
    const mesh = node as THREE.Mesh;
    if (!mesh.isMesh || !mesh.geometry) return;
    const skinned = node as THREE.SkinnedMesh;
    if (skinned.isSkinnedMesh) {
      skinned.skeleton.update();
      skinned.computeBoundingBox(); // measures through bone transforms
      childBox.copy(skinned.boundingBox!);
    } else {
      if (!mesh.geometry.boundingBox) mesh.geometry.computeBoundingBox();
      childBox.copy(mesh.geometry.boundingBox!);
    }
    toRoot.multiplyMatrices(rootInverse, mesh.matrixWorld);
    box.union(childBox.applyMatrix4(toRoot));
  });
  return box;
}
```

Move the **container** for world placement; animate **generated_model_runtime** for local motion. Writing to the visual group's transform later overwrites the centering/grounding offsets.

Keep collision footprints, hitboxes, and grid occupancy separate from the container's visual anchor.

## Orientation correction

Each model's persisted orientation verdict (`hasIntrinsicFront`, `localFrontAxis`, `localUpAxis`, …) arrives as the ORIENTATION METADATA line in its generation tool output; `listExistingAssets` with `types: ["3d-model"]` re-lists it for reused models. Rules:

- `hasIntrinsicFront: false` → apply NO rotation.
- Never infer facing from the preview thumbnail and never guess raw Y-rotation constants like `Math.PI / 2`.
- Choose `desiredWorldForward` from the object's gameplay role: player/NPC → movement direction, vehicle → travel direction, obstacle/sign meant to face the player → vector toward the player or camera target, decorative props → none.

```ts
import * as THREE from "three";

const GENERATED_MODEL_AXIS_VECTORS = {
  positiveX: new THREE.Vector3(1, 0, 0),
  negativeX: new THREE.Vector3(-1, 0, 0),
  positiveY: new THREE.Vector3(0, 1, 0),
  negativeY: new THREE.Vector3(0, -1, 0),
  positiveZ: new THREE.Vector3(0, 0, 1),
  negativeZ: new THREE.Vector3(0, 0, -1),
} as const;

type GeneratedModelAxis = keyof typeof GENERATED_MODEL_AXIS_VECTORS;

/** Quaternion mapping +Z onto `front` and +Y onto `up` (orthonormalized). */
function generatedModelBasisQuaternion(front: THREE.Vector3, up: THREE.Vector3): THREE.Quaternion {
  const f = front.clone().normalize();
  const r = new THREE.Vector3().crossVectors(up, f).normalize();
  const u = new THREE.Vector3().crossVectors(f, r).normalize();
  return new THREE.Quaternion().setFromRotationMatrix(new THREE.Matrix4().makeBasis(r, u, f));
}

/**
 * Full body-frame correction: rotates the model so its classified local front
 * axis points along desiredWorldForward while its local up axis stays world-up.
 * Apply once to the normalized visual.
 */
function generatedModelOrientationCorrection(options: {
  localFrontAxis: GeneratedModelAxis;
  localUpAxis: GeneratedModelAxis;
  desiredWorldForward: THREE.Vector3;
  worldUp?: THREE.Vector3;
}): THREE.Quaternion {
  const localBasis = generatedModelBasisQuaternion(
    GENERATED_MODEL_AXIS_VECTORS[options.localFrontAxis],
    GENERATED_MODEL_AXIS_VECTORS[options.localUpAxis],
  );
  const worldBasis = generatedModelBasisQuaternion(
    options.desiredWorldForward,
    options.worldUp ?? new THREE.Vector3(0, 1, 0),
  );
  return worldBasis.multiply(localBasis.invert());
}
```

For a flat horizontal turn-to-face during gameplay (already-corrected model), rotate the **container** with `THREE.Quaternion.setFromUnitVectors(baseForward, flatMovementDirection)` or `Math.atan2` yaw — keep this separate from the one-time visual correction above.

## Animations

Each accepted animation is a **separate GLB sharing one auto-rig skeleton**. Get the URLs via `listExistingAssets` (`types: ["3d-model"]`): each animated model lists a `Rigged GLB: <url>` plus `Animation "<name>" (id: …) GLB: <url>` per accepted animation.

**The character visual MUST be the model's Rigged GLB.** The plain model GLB is the unrigged mesh — it has NO skeleton, so animation clips bound to it silently do nothing (three.js only logs PropertyBinding warnings and the mesh stays frozen). The Rigged GLB is the auto-rig output whose bones match every animation GLB of that model. Keep using the plain GLB for static (non-animated) models and props.

Play animation clips on ONE mixer bound to the rigged model's scene — the skeletons match, so clips transfer directly. **Bind, don't retarget**: never reach for `SkeletonUtils.retargetClip` here — it is for mismatched rigs and is known-buggy; same-rig clips apply as-is. In R3F, the idiomatic path is drei's `useAnimations` with the rigged scene as root:

```tsx
// Rigged GLB from listExistingAssets — NOT the plain model GLB (no skeleton).
const base = useGLTF(RIGGED_MODEL_GLB_URL);
const idleGltf = useGLTF(IDLE_ANIMATION_GLB_URL);
const runGltf = useGLTF(RUN_ANIMATION_GLB_URL);

// Per-instance skeleton clone — bind the mixer to the clone, never to the
// cached base.scene (see Normalization rule 1), even for a single character.
const scene = useMemo(() => SkeletonUtils.clone(base.scene), [base.scene]);

// Rename clips before merging — Meshy animation GLBs may all ship a generically
// named clip, and useAnimations keys actions by clip name.
const clips = useMemo(() => {
  const idle = idleGltf.animations[0].clone();
  idle.name = "idle";
  const run = runGltf.animations[0].clone();
  run.name = "run";
  return [idle, run];
}, [idleGltf, runGltf]);

const { actions, mixer } = useAnimations(clips, scene);
useEffect(() => {
  actions.idle?.reset().play();
}, [actions]);
```

Plain three.js: create one `new THREE.AnimationMixer(base.scene)`, register clips with `mixer.clipAction(clip)`, and call `mixer.update(delta)` every frame (R3F's `useAnimations` does this internally).

- Crossfade state changes: `next.reset().play(); previous.crossFadeTo(next, 0.25, false);` — never hard-cut between locomotion states.
- One-shots (jump/attack/emote): `action.setLoop(THREE.LoopOnce, 1); action.clampWhenFinished = true;` and return to the loop state on the mixer's `"finished"` event (`mixer.addEventListener("finished", ...)`).
- For gameplay states without a generated clip, stop the stale action (`action.stop()`) so the model returns to its base pose instead of sliding with a wrong loop.
- An animation GLB alone does not create a mechanic: wire the input, gameplay state, and timers that trigger it, then map the state to the action.

## Held and equipped items (attach to bones, not to the body)

A weapon/tool/shield "held" by an animated character MUST be parented to the hand bone — never positioned as a sibling of the model at a fixed body offset. A fixed offset means every clip (run, jump, shoot, dance) moves the hand while the item floats in mid-air at the old position.

```ts
// Find the bone on the per-instance CLONE (auto-rig bones use names like
// RightHand, LeftHand, Head, Spine, Hips — inspect gltf.scene if unsure).
const hand = scene.getObjectByName("RightHand");
hand?.add(rifle); // in R3F: createPortal(<Rifle />, hand) renders JSX into the bone
```

- **Compensate the inherited bone scale.** Bones of generated rigs sit under the Armature's 0.01 (cm→m) scale, so a naive bone child renders at ~1% size — a matchstick rifle. Measure `hand.getWorldScale(v)` after `updateMatrixWorld` and set the item's local scale to `desiredWorldSize / boneWorldScale` (≈100x for these rigs). Because the item is a bone child, clips that scale bones (some Meshy clips stretch the skeleton a few percent) keep it proportional to the hand automatically.
- **Derive the grip transform from a real pose, never hand-tuned constants.** Pose the skeleton with the most demanding clip between frames (apply the clip via the mixer at t=0, `updateMatrixWorld(true)`), compute the item's desired world transform from skeletal landmarks (e.g. rifle: center just ahead of the right wrist, barrel aimed at the left hand on the forestock), convert it into the bone's local frame (premultiply by the inverse of the bone's `matrixWorld`), bake it once, then reset the mixer. The result holds across all clips: perfect alignment in the aiming pose, natural carry elsewhere.
- The bone-local transform already encodes scale, rotation, and offset — do NOT also wrap the attached item in the placement-contract normalization group, or scale gets applied twice.

## Physics and character control

- **Decision rule**: raycast-only / grid-based / lane-runner / lerp-motion games need NO physics library — manual math is lighter and more predictable. Anything with stacking, ragdolls, vehicles, projectile physics, or character-vs-terrain collision should use `@react-three/rapier` (Rapier, the de facto R3F physics engine): `bun add @react-three/rapier`. Do not hand-roll a rigid-body solver.
- **Character controllers** are the most common source of janky generated games — for a physics-backed third/first-person character prefer `ecctrl` (pmndrs, rapier-based floating capsule with keyboard/joystick modes) over hand-rolled capsule math: `bun add ecctrl`.
- Keep game state outside React renders (module-level state or zustand); React re-renders are for HUD/menus, `useFrame` drives the simulation.

## Input mapping (screen-left must move world-left)

Inverted controls — pressing left moves the character right, dragging left pans the world right — are a top generated-game bug. The cause is always the same: a hardcoded world-axis sign that only matches one particular camera placement. Rules:

- **Derive movement axes from the camera every frame, never hardcode them.** `x += speed` for "right" is only correct while the camera happens to look down `-Z`; it silently inverts when the camera sits on the other side of the scene, gets rotated 180°, or the game switches to top-down. Camera-relative basis:

```ts
const forward = camera.getWorldDirection(new THREE.Vector3());
forward.y = 0;
forward.normalize(); // flatten for ground movement
const right = new THREE.Vector3().crossVectors(forward, camera.up).normalize(); // screen-right for ANY camera yaw
move.copy(right).multiplyScalar(input.x).addScaledVector(forward, input.y);
```

For fixed-camera games (side-scroller, top-down) compute this basis once from the actual camera placement instead of assuming `+X` is screen-right.

- **Mouse-look yaw subtracts**: `rotation.y -= event.movementX * sensitivity` — minus, because positive Y-rotation turns left in three.js's right-handed system. Same sign for touch-drag orbit.
- **Drag-to-pan moves the camera opposite the pointer delta** so the world follows the finger/cursor (map-like feel). DOM Y grows downward while three.js Y grows upward — flip `deltaY` once at the input layer. Wheel `deltaY > 0` means scroll down / zoom out.
- **Verify the mapping with the real camera before moving on**: press each direction key / drag each way once and confirm the on-screen result matches. If a sign is wrong, fix it at the single input-mapping site — never sprinkle compensating negations through gameplay code.

## Raycasting (shooting / picking)

- **Always set `raycaster.camera = camera`** when you build rays manually (`raycaster.set(origin, direction)` — the usual pattern for pointer-locked FPS shooting from the camera center). Only `setFromCamera()` sets it for you. If it stays `null` and the ray traversal reaches any `Sprite` (name labels, damage numbers, billboards), `Sprite.raycast` throws `Cannot read properties of null (reading 'matrixWorld')` on the first shot.
- Raycast against an **explicit array of hit targets** (terrain, obstacles, enemy hitboxes) instead of `scene.children` with `recursive: true` — recursive traversal hits every descendant including UI sprites and effects, and `intersectObjects` does not skip invisible objects.
- Keep cosmetic sprites out of hit tests entirely: the explicit hit-target array above is the primary defense; also attach them outside the hitbox subtree. If you use layers instead, remember `sprite.layers.set(1)` removes the sprite from layer 0 and the camera renders only layer 0 by default — you must also call `camera.layers.enable(1)` or the sprite disappears from screen (the default-layer raycaster will correctly ignore it).
- Raycasting every frame against detailed level geometry is a perf cliff — use `three-mesh-bvh` (`bun add three-mesh-bvh`, patches `Raycaster` via `acceleratedRaycast`) for raycast-heavy games.

## Renderer and performance

- **Renderer**: use the React Three Fiber `<Canvas>` default (WebGLRenderer) — it is the stable, maintained path for WebGL games. three.js also ships `WebGPURenderer` (`three/webgpu`, WebGPU backend with automatic WebGL 2 fallback) for TSL node materials and compute shaders — reach for it only when the user explicitly asks for WebGPU/TSL features, since it needs async `renderer.init()` and a custom R3F `gl` setup. Do NOT copy experimental compute examples (e.g. the nanite-style rasterizer) into user games — three.js marks them as technical studies, not production APIs.
- **Repeated props** (trees, rocks, coins, obstacles): render all copies with instancing — never N separate scene clones. Note `InstancedMesh` / drei `<Instances>` take ONE geometry + ONE material, and a generated GLB prop usually contains several meshes/materials, so instance each mesh of the model separately (drei `<Merged>` automates per-mesh instancing of a whole model; do not pass `gltf.scene` to `<Instances>`). Skinned (rigged) models cannot be instanced; clone them with `SkeletonUtils.clone` and keep their count low.
- **Many distinct static geometries** sharing one material can be merged into a `BatchedMesh` (one draw call, per-instance matrices, built-in frustum culling/sorting).
- **Budget awareness**: any standard model (`generate3DAsset` prop or `generate3DHumanoid` character) is ~90-95K triangles after Meshy's fixed adaptive remesh, a `lowPoly` model ~4K faces. Keep total rendered triangles — each model's triangles × its instance count, summed — around 200K-500K for scenes that must run on phones (shared links open there); a clearly desktop-targeted experience can go higher. Use `lowPoly: true` for props the scene instances many times, clone templates instead of re-loading, and keep draw calls per frame low (renderer `info.render.calls` is the metric).
- **Cleanup**: call `dispose()` on geometries/materials/textures (and `InstancedMesh.dispose()`) when objects leave the scene permanently.

## GLB weight and load time

GLB download weight is dominated by **textures, not triangles** — uncompressed Meshy textures routinely make a model 10x heavier than its geometry alone, and a scene referencing many raw GLBs can hang the loading screen on an average connection. Served GLBs already arrive texture-optimized (WebP: 2048px base color, 1024px normal/metallic-roughness maps). Budget the scene's total download (roughly 15-20MB is a healthy ceiling for a shareable game) and compress proactively when shipping, not after the user reports slow loading:

1. For the final game, download each shipped GLB into the app (e.g. `public/models/`) and compress its geometry:

   ```bash
   bunx @gltf-transform/cli draco model.glb public/models/model.glb
   ```

   Textures are already WebP-optimized on the server — do NOT re-run texture compression (`optimize`/`--texture-compress` re-encodes the WebP textures lossy-over-lossy, and any `--texture-size` below 2048 downscales the 2048px base color). Draco compresses geometry only, which is the remaining win. Reference the local optimized path instead of the remote URL. Keep the remote-URL flow while prototyping and for quick previews — shipping is the one legitimate reason to download a GLB locally on web.

2. Decoders: drei's `useGLTF` wires the draco and meshopt decoders by default, so optimized files load with no extra setup. Plain `GLTFLoader` needs `loader.setDRACOLoader(...)` for `--compress draco`, or use `--compress meshopt` with `loader.setMeshoptDecoder(MeshoptDecoder)` from `three/addons/libs/meshopt_decoder.module.js`.
3. Load progressively: `useGLTF.preload(url)` the first-screen models, wrap scenes in `Suspense` with a byte-level progress UI where loading time matters, and stagger downloads (a handful at a time) instead of kicking off dozens of simultaneous fetches.

## Other generated assets

Images, audio, and video are also referenced by URL on web (no bundling): use the URLs reported by their generation tools / `listExistingAssets` directly in `<img>`, `Audio`, `<video>`, or texture loaders.
