---
name: Assets Generation
description: Generate media assets for apps via tools including
  `generate3DHumanoid` (animatable human-shaped 3D characters with built-in
  preview approval and animation selection), `generate3DAsset` (all other 3D
  models with built-in preview approval), `append3DAnimations` (add animations
  to an existing humanoid model), `generateAudio` (background music, sound
  effects, voiceovers, narration, dialogue), `generateImageAsset` (backgrounds,
  illustrations, UI graphics), and `generateVideo` (animations, trailers,
  clips). The full Meshy animation catalog (actionIds) lives in
  `animation-library.md` in this skill. Use when the app needs AI-generated 3D
  models, sound effects, music, voice/dialogue, image assets, or video assets.
  Use `generateIcon` from `.rork/skills/app-config/SKILL.md` for app icons, not
  `generateImageAsset`.
---

# Media Asset Generation

You just unlocked tools for generating media assets. Invoke any of them via the root `callTool({ toolName, params })` dispatcher. Asset generation tools that produce final app assets support `runInBackground: true`; the 3D generation tools (`generate3DHumanoid` / `generate3DAsset`) always run in the background — preview, user approval, and generation included. The background pattern is:

1. If you need to check for duplicates or reuse an existing asset, first read `.rork/skills/asset-library/SKILL.md` and call `listExistingAssets` with the matching `types` filter
2. Call `callTool({ toolName: "generate*", params: "{\"runInBackground\":true}" })` with every required field included in that JSON string — returns a `generationId`
3. Continue building the app while assets generate in parallel
4. Call `waitTask({ generationIds: [...] })` ONCE with every pending `generationId` at the very end, right before the final build


## Available tools

### generateImageAsset

Generates an image asset using AI and uploads it to R2 storage.
Returns the image URL and a uniqueKey for referencing in app code.
Each generation takes 10-30 seconds. For multiple images, use runInBackground: true and generate in parallel.
For Swift apps, the image is automatically bundled into Assets.xcassets so the agent code can use UIImage(named:).
IMPORTANT: If you need to avoid duplicates or reuse an existing image asset, first read `.rork/skills/asset-library/SKILL.md` and call `listExistingAssets` with `types: ["image"]`.
IMPORTANT: After scheduling background generations, continue building the app. Call waitTask only at the end.
IMPORTANT: Never use it to generate app icons. Read `.rork/skills/app-config/SKILL.md` for the app icon generation tool.

```json
{"type":"object","properties":{"prompt":{"type":"string","maxLength":5000,"description":"Detailed description of the image. Include style, colors, composition, and context of where it will be used."},"assetName":{"description":"Short snake_case name (e.g. 'hero_banner', 'onboarding_bg').","type":"string","maxLength":60},"size":{"default":"1024x1024","description":"Image dimensions.","type":"string","enum":["1024x1024","1024x1536","1536x1024"]},"background":{"default":"auto","description":"Use 'transparent' whenever the user asks for transparent/no background, cutouts, alpha PNGs, sprites, stickers, or UI assets without a backdrop. Use 'opaque' for photos/scenes or solid backgrounds. Use 'auto' only when background is unspecified.","type":"string","enum":["transparent","opaque","auto"]},"inputImages":{"description":"Array of image URLs to use as edit input. Use for editing/compositing existing images.","type":"array","items":{"type":"string"}},"runInBackground":{"default":true,"description":"If true (default), schedules in background and returns a generationId; pair with waitTask. Set to false only when the caller really needs to block.","type":"boolean"}},"required":["prompt"]}
```

### generateAudio

Generates audio using ElevenLabs AI. Four types:
- music: Background music, soundtracks from text prompt. Min 3s, max 10 min. Use forceInstrumental for no vocals.
- sound_effect: Short SFX (whoosh, click, explosion, ambient) from text. Max 30s. Use loop for seamless loops.
- voice: Text-to-speech with a specific voice. Use listVoices first to get voiceId. Supports emotion markers in text like [cheerfully] or [whispering].
- dialogue: Multi-voice dialogue (cutscenes, NPC conversations). Pass dialogueInputs array with text + voiceId pairs (up to 10 unique voices).
Returns audio URL (MP3) and uniqueKey for use in app code via https://rork.app/pa/{projectId}/{uniqueKey}.
Each generation takes 15-60 seconds. For multiple audio assets, use runInBackground: true and generate in parallel.
Cost scales with generated duration and spoken text length. Reuse existing audio assets when possible, keep clips as short as the product needs, and avoid regenerating the same line or sound effect.
For Swift apps, the file is automatically bundled into the app's Resources/ folder so the agent code can use Bundle.main.url(forResource:withExtension:).
IMPORTANT: If you need to avoid duplicates or reuse an existing audio asset, first read `.rork/skills/asset-library/SKILL.md` and call `listExistingAssets` with `types: ["audio"]`.
IMPORTANT: For voice/dialogue, call listVoices first to get valid voiceId values.
IMPORTANT: After scheduling background generations, continue building the app. Call waitTask only at the end.

```json
{"type":"object","properties":{"type":{"type":"string","enum":["music","sound_effect","voice","dialogue"],"description":"'music' for tracks, 'sound_effect' for SFX, 'voice' for TTS with a chosen voice, 'dialogue' for multi-voice conversations."},"prompt":{"type":"string","maxLength":5000,"description":"For music: describe genre, mood, instruments. For SFX: describe the sound. For voice: the text to speak. For dialogue: ignored (use dialogueInputs)."},"assetName":{"description":"Short snake_case name (e.g. 'battle_theme', 'npc_greeting').","type":"string","maxLength":60},"musicLengthMs":{"description":"Duration in ms for music (3000-600000). Music only.","type":"integer","minimum":3000,"maximum":600000},"forceInstrumental":{"description":"Guarantees no vocals. Music only.","type":"boolean"},"durationSeconds":{"description":"Duration in seconds for SFX (0.5-30). Sound effect only.","type":"number","minimum":0.5,"maximum":30},"promptInfluence":{"description":"Prompt adherence (0-1, default 0.3). Sound effect only.","type":"number","minimum":0,"maximum":1},"loop":{"description":"Seamless loop. Sound effect only.","type":"boolean"},"voiceId":{"description":"ElevenLabs voice ID. Required for voice type. Use listVoices to find IDs.","type":"string"},"dialogueInputs":{"description":"Array of { text, voiceId } for dialogue type. Supports emotion markers like [cheerfully], [whispering], [angry]. Max 10 unique voices.","minItems":1,"maxItems":50,"type":"array","items":{"type":"object","properties":{"text":{"type":"string","maxLength":5000},"voiceId":{"type":"string"}},"required":["text","voiceId"]}},"runInBackground":{"default":true,"description":"If true (default), schedules in background and returns a generationId; pair with waitTask. Set to false only when the caller really needs to block.","type":"boolean"}},"required":["type","prompt"]}
```

### generateVideo

Generates a video using AI. Five modes:
- text-to-video (default): Generate video from a text prompt. Models: Google Veo, KlingAI, Seedance, Wan, Grok.
- image-to-video: Animate a static image into a video. Provide inputImageUrl.
- reference-to-video: Generate a new scene featuring characters from reference images/videos. Provide referenceUrls. Use character1, character2 etc in prompt.
- motion-control: Transfer motion from a reference video onto a character image. Provide inputImageUrl (character) + motionVideoUrl (reference motion).
- video-editing: Edit an existing video with text prompts. Provide editVideoUrl.
Returns video URL and uniqueKey for use in app code.
Each generation takes 1-5 minutes. For multiple videos, use runInBackground: true and generate in parallel.
For Swift apps, the file is automatically bundled into the app's Resources/ folder so the agent code can use Bundle.main.url(forResource:withExtension:) with AVPlayer.
Models vary significantly in cost and speed — see video-generation.md for pricing hints and selection guidance. Refresh the live Vercel model catalog as documented by the AI skill before comparing current pricing.
IMPORTANT: If you need to avoid duplicates or reuse an existing video asset, first read `.rork/skills/asset-library/SKILL.md` and call `listExistingAssets` with `types: ["video"]`.
IMPORTANT: After scheduling background generations, continue building the app. Call waitTask only at the end.

```json
{"type":"object","properties":{"prompt":{"type":"string","maxLength":2500,"description":"Detailed description of the video. For reference-to-video, use character1/character2 to refer to reference images."},"assetName":{"description":"Short snake_case name (e.g. 'hero_intro', 'onboarding_anim').","type":"string","maxLength":60},"videoType":{"default":"text-to-video","description":"Generation mode. 'text-to-video' from text, 'image-to-video' to animate an image, 'reference-to-video' for character references, 'motion-control' to transfer motion, 'video-editing' to edit existing video.","type":"string","enum":["text-to-video","image-to-video","reference-to-video","motion-control","video-editing"]},"inputImageUrl":{"description":"Public image URL. Required for image-to-video and motion-control (character image).","type":"string"},"referenceUrls":{"description":"Reference image/video URLs for reference-to-video. First URL = character1, second = character2, etc. Max 5.","maxItems":5,"type":"array","items":{"type":"string"}},"motionVideoUrl":{"description":"URL of reference motion video for motion-control mode.","type":"string"},"editVideoUrl":{"description":"URL of source video to edit for video-editing mode. Max 8.7s.","type":"string"},"duration":{"default":8,"description":"Video length in seconds. Veo: 4/6/8. KlingAI: 5/10. Seedance: 4-12. Wan: 2-15. Grok: 1-15.","type":"number"},"aspectRatio":{"default":"16:9","description":"Aspect ratio. Currently supported: 16:9 or 9:16. 16:9 is the safest default.","type":"string","enum":["16:9","9:16"]},"runInBackground":{"default":true,"description":"If true (default), schedules in background and returns a generationId; pair with waitTask. Set to false only when the caller really needs to block.","type":"boolean"}},"required":["prompt"]}
```

### generate3DHumanoid

Generates a HUMANOID 3D character (one head, two arms, two legs — humans, knights, zombies,
robots, anthropomorphic mascots) as USDZ + GLB, then rigs it and generates the selected
skeletal animations. For props, vehicles, and non-humanoid creatures use generate3DAsset.

Runs entirely in the background and immediately returns a generationId. The chat widget
first shows a concept preview image (full body, A-pose); the user can approve or reject it
directly on the widget, and if they do not respond the preview auto-approves after 90 seconds.
On approval the final Meshy generation continues automatically. After the mesh completes, the SAME widget shows
an animation picker pre-seeded from the animations parameter (or an automatic
recommendation); rigging + animations then run before the task resolves (accepted clips are
bundled into Swift Resources/ on Swift workspaces; web workspaces reference the Rigged GLB +
animation GLB URLs instead — no bundling).
Announce the preview as "here is the character I'll build" — do not ask for permission in
chat.

waitTask returns either the finished character or the user's rejection feedback. If
rejected, revise the prompt according to the feedback and call this tool again — the new
call adds a fresh preview widget.

The prompt must describe the character's body, clothing, and worn accessories only — no
held weapons/props and no other characters (generate props separately with generate3DAsset).

The finished model is saved to the user's Assets only after the whole flow completes.
Generate different characters in parallel (separate calls), then waitTask every
generationId in one call. Never call this tool twice for the same character unless the
previous call returned rejected/failed.

```json
{"type":"object","properties":{"name":{"type":"string","minLength":1,"maxLength":60,"description":"Short display name, e.g. 'Player Character', 'Wooden Crate'. Shown as the widget title and used as the bundled resource file name."},"prompt":{"type":"string","minLength":1,"maxLength":800,"description":"Description of the model, including any style words (realistic, cartoon, voxel, ...) the user asked for. Describe visible semantic landmarks instead of local coordinate axes: use muzzle/stock, windshield/grille, face/back, tip/handle; never say +X, -Z, positive X axis, or model local axis. For humanoids, describe the body, clothing, and wearable accessories only — no held/carried/nearby props unless the user explicitly asked for a standalone prop model."},"imageUrls":{"description":"Optional user-provided reference image URLs (public https jpg/jpeg/png). One image: image-to-3D with the normal preview approval step. 2-4 images of the SAME object from different angles: direct multi-image-to-3D, skipping the preview. Put the front view first — Meshy treats the first image as the primary view; the order of the rest does not matter. NEVER invent or guess URLs.","minItems":1,"maxItems":4,"type":"array","items":{"type":"string","format":"uri"}},"lowPoly":{"description":"Use Meshy's lowpoly geometry mode (faceted, flat-shaded geometry). This is a real geometry switch — prompt style words cannot reproduce it, and standard mode smooths even faceted-looking previews. Runs on Meshy Smart Topology, which generates a few thousand clean faces directly. Not supported with multi-image references.","type":"boolean"},"animations":{"description":"Meshy animation actionIds to pre-select on the widget's animation picker (pick them from .rork/skills/assets/animation-library.md). Pick clips the app's code will actually drive (idle, walk, run, jump, attack...). Omit to let the system recommend a set from the model's prompt and thumbnail. Max 10.","maxItems":10,"type":"array","items":{"type":"integer","minimum":0,"maximum":677}}},"required":["name","prompt"]}
```

### generate3DAsset

Generates a NON-HUMANOID 3D model (props, vehicles, weapons, buildings, food, furniture,
creatures without a human body plan) as USDZ + GLB. For human-shaped characters that should
be animated, use generate3DHumanoid instead.

Runs entirely in the background and immediately returns a generationId. The chat widget
first shows a concept preview image; the user can approve or reject it directly on the
widget, and if they do not respond the preview auto-approves after 90 seconds. On approval
the final Meshy generation continues automatically. Announce the preview as
"here is the model I'll build" — do not ask for permission in chat.

waitTask returns either the finished model or the user's rejection feedback. If rejected,
revise the prompt according to the feedback and call this tool again — the new call adds a
fresh preview widget.

With 2+ imageUrls (same object, different angles) the preview step is skipped and
multi-image-to-3D starts directly.

The finished model is saved to the user's Assets only after generation fully completes.
Generate different models in parallel (separate calls), then waitTask every generationId
in one call. Never call this tool twice for the same model unless the previous call
returned rejected/failed.

```json
{"type":"object","properties":{"name":{"type":"string","minLength":1,"maxLength":60,"description":"Short display name, e.g. 'Player Character', 'Wooden Crate'. Shown as the widget title and used as the bundled resource file name."},"prompt":{"type":"string","minLength":1,"maxLength":800,"description":"Description of the model, including any style words (realistic, cartoon, voxel, ...) the user asked for. Describe visible semantic landmarks instead of local coordinate axes: use muzzle/stock, windshield/grille, face/back, tip/handle; never say +X, -Z, positive X axis, or model local axis. For humanoids, describe the body, clothing, and wearable accessories only — no held/carried/nearby props unless the user explicitly asked for a standalone prop model."},"imageUrls":{"description":"Optional user-provided reference image URLs (public https jpg/jpeg/png). One image: image-to-3D with the normal preview approval step. 2-4 images of the SAME object from different angles: direct multi-image-to-3D, skipping the preview. Put the front view first — Meshy treats the first image as the primary view; the order of the rest does not matter. NEVER invent or guess URLs.","minItems":1,"maxItems":4,"type":"array","items":{"type":"string","format":"uri"}},"lowPoly":{"description":"Use Meshy's lowpoly geometry mode (faceted, flat-shaded geometry). This is a real geometry switch — prompt style words cannot reproduce it, and standard mode smooths even faceted-looking previews. Runs on Meshy Smart Topology, which generates a few thousand clean faces directly. Not supported with multi-image references.","type":"boolean"}},"required":["name","prompt"]}
```

### append3DAnimations

Generates additional skeletal animations for an EXISTING completed humanoid 3D model and
(on Swift workspaces) bundles the finished USDZ clips into Resources/.

Use this when the user asks to add animations to a model that already exists — models
created by generate3DHumanoid handle their initial animation set on their own widget, so
this tool is for follow-up requests ("also add a dance", "add attack + dodge").

Pick the actionIds from .rork/skills/assets/animation-library.md first; this tool accepts
resolved actionIds only. It verifies the model is humanoid and rig-ready, starts Meshy
auto-rig + animation jobs, then completes in the background — call waitTask with the
returned generationId before telling the user the animations are ready. The waitTask
result lists exact bundled resourceName strings for Swift wiring; for gameplay requests
(attack, jump, dodge, ...) also patch the app code so input/state actually triggers the
new clips.

```json
{"type":"object","properties":{"modelId":{"type":"string","format":"uuid","pattern":"^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$","description":"Row id of the completed humanoid project_3d_models entry to animate."},"animations":{"minItems":1,"maxItems":10,"type":"array","items":{"type":"integer","minimum":0,"maximum":677},"description":"Meshy animation actionIds to generate for this model (pick them from .rork/skills/assets/animation-library.md). Max 10 per call."},"runInBackground":{"default":true,"description":"If true (default), schedules in background and returns a generationId; pair with waitTask. Set to false only when the caller really needs to block.","type":"boolean"}},"required":["modelId","animations"]}
```

### add3DModelToProject

Bundles a previously-generated 3D model into a Swift app's Resources/ folder so the Swift code can load it with Entity(named:) / Model3D(named:) without any download or crash risk.

WHEN TO CALL THIS TOOL:
  - The user explicitly asks to add the model into their app / integrate it into code.
  - You are building a game, AR experience, or any feature whose Swift code needs to reference a static/non-humanoid/generated model by name. In that case call this after generate3DAsset completes — no need to ask.
  - Animated humanoids generated through generate3DHumanoid (and follow-up append3DAnimations runs) bundle the base model and succeeded animation USDZ files automatically — do not call this tool for them.
  - If unsure, ASK the user first ("Want me to integrate it into your iOS app?") and only call after they confirm.

DO NOT call this tool when the user just wanted to browse the asset in their library — leaving the model in Assets is the default for ambient generations.

The tool downloads the USDZ from the user's Assets and writes it to the active Swift app's Resources/ folder. Returns the saved path. Only works for projects that contain at least one Swift app. For non-Swift workspaces, the tool returns an error.

```json
{"type":"object","properties":{"modelId":{"type":"string","format":"uuid","pattern":"^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$","description":"Canonical project_3d_models row id. This is the `modelId` returned by `generate3DAsset` / `generate3DHumanoid` (NOT the chat content id)."},"fileName":{"description":"Optional override for the bundled file name (without extension). Defaults to the canonical bundled resource name derived from the model's `modelName`, `prompt`, or id.","type":"string","minLength":1,"maxLength":120}},"required":["modelId"]}
```
### How to generate image assets (backgrounds, illustrations, UI graphics)

Use the `generateImageAsset` tool for image assets. Do NOT use `generateImage` for project assets. For app icons, read `.rork/skills/app-config/SKILL.md` and use `generateIcon`.

Generate custom image assets using AI (OpenAI gpt-image-2). Returns image URLs hosted on R2.

**Workflow:**

1. Decide what images the app needs (backgrounds, illustrations, banners, etc.)
2. If you need to check for duplicates or reuse an existing asset, read `.rork/skills/asset-library/SKILL.md` and call `listExistingAssets` with the matching `types` filter
3. Call `generateImageAsset` via `callTool` with `runInBackground: true` for each image
4. Continue building the app while generation runs — store each returned `generationId`
5. At the end, call `waitTask({ generationIds: [...] })` once with every pending `generationId`, then use the returned URLs in code


**Sizes:** `"1024x1024"` (square, default), `"1024x1536"` (portrait), `"1536x1024"` (landscape)

**Background:** Use `"transparent"` whenever the user asks for transparent/no background, cutouts, alpha PNGs, sprites, stickers, or UI assets without a backdrop. Use `"opaque"` for photos/scenes or solid backgrounds. Use `"auto"` only when the background is unspecified.

**Edit mode:** Pass `inputImages` array with URLs to edit/composite existing images

**Tips for prompts:**

- Be specific about style, colors, composition, and where it will be used
- For app backgrounds: describe the mood, gradient, pattern
- For illustrations: describe the subject, style (flat, 3D, watercolor), colors
- For transparent assets: set `background: "transparent"` in the tool call, not only in the prompt
- Use `assetName` as a short snake_case identifier: `hero_banner`, `onboarding_bg`, `empty_state_illustration`


**NEVER retry failed image generations.** If an image fails, the user sees the error on the card and can retry manually.

### How to generate audio (music, sound effects, voice, and dialogue)

Use the `generateAudio` tool for audio assets, including voiceovers and narration.

Generate background music, sound effects, voice, and dialogue using ElevenLabs AI. Returns audio URLs (MP3) hosted on R2, accessible via `https://rork.app/pa/{projectId}/{uniqueKey}`.

**Workflow:**

1. Decide what audio the app needs (background music, UI sounds, ambient, etc.)
2. Call `generateAudio` via `callTool` with `runInBackground: true` for each audio asset
3. Continue building the app while generation runs — store each returned `generationId`
4. At the end, call `waitTask({ generationIds: [...] })` once with every pending `generationId`, then use the returned `uniqueKey` URLs


**Types:**

- `"music"` — background tracks, soundtracks (3s to 10min). Use `forceInstrumental: true` for no vocals. Use `musicLengthMs` to control duration.
- `"sound_effect"` — short SFX up to 30s (clicks, explosions, ambience). Use `durationSeconds` to control length, `loop: true` for seamless loops.
- `"voice"` — text-to-speech with a specific voice (NPC lines, narration, instructions). Requires `voiceId` — call `listVoices` first. Supports emotion markers: `[cheerfully]`, `[whispering]`, `[angry]`, `[stuttering]`.
- `"dialogue"` — multi-voice conversations (cutscenes, NPC dialogues). Pass `dialogueInputs` array with `{ text, voiceId }` pairs. Up to 10 unique voices. Supports emotion markers in text.


**Tips for prompts:**

- Music: describe genre, mood, instruments, tempo. "Upbeat chiptune 8-bit adventure theme, 120 BPM, loopable"
- SFX: be specific. "Wooden door creaking open slowly, with rusty hinges" not just "door sound"
- Voice: write the exact text to speak. Add emotion markers: "[excited] Welcome to the arena, brave warrior!"
- Dialogue: use descriptive text per character. "[whispering] The treasure is behind the waterfall."
- Use `assetName` as a short snake_case identifier: `battle_theme`, `door_open`, `npc_greeting`


**Voice selection:** Call `listVoices` to see available voices with IDs, names, and labels (gender, accent, age). Pick voices that match your characters.

**In code:** Reference audio via `https://rork.app/pa/{projectId}/{uniqueKey}`. Download the MP3 to local cache on first use, then play locally for zero latency. See the "Play Audio from URL" recipe in `audio-patterns.md` for the complete pattern.

### How to generate video assets

Use the `generateVideo` tool for video assets.

Generate video clips using AI (Vercel AI Gateway). Returns video URLs (MP4) hosted on R2.

**Flow:**

1. Decide what videos the app needs
2. Call `generateVideo` via `callTool` with `runInBackground: true` for each video
3. Continue building the app while generation runs — store each returned `generationId`
4. At the end, call `waitTask({ generationIds: [...] })` once with every pending `generationId`, then use the returned video URLs/`uniqueKey`s


**Video types (5 modes):**

- `text-to-video` (default): Generate from a text prompt. Models: Google Veo, KlingAI, Seedance, Wan, Grok.
- `image-to-video`: Animate a static image into a video. Provide `inputImageUrl`.
- `reference-to-video`: Generate a new scene featuring characters from reference images. Provide `referenceUrls` (1-5 URLs). Use `character1`, `character2` in prompt to reference each.
- `motion-control`: Transfer motion from a reference video onto a character image. Provide `inputImageUrl` (character) + `motionVideoUrl` (reference motion).
- `video-editing`: Edit an existing video with text prompts. Provide `editVideoUrl`. Describe the changes in `prompt`.


**Parameters:**

- `duration`: Depends on model. Veo: 4/6/8s. KlingAI: 5/10s. Seedance: 4-12s. Wan: 2-15s. Grok: 1-15s. Default 8.
- `aspectRatio`: "16:9" (default) or "9:16".


**Generation takes 1-5 minutes per video.** Always use `runInBackground: true` and generate in parallel.

**NEVER retry failed video generations.** If a video fails, the user sees the error on the card and can retry manually. Do NOT call `generateVideo` again for a video that already failed.

### How to generate 3D models

Two tools cover every 3D generation, one call per model:

- `generate3DHumanoid` — human-shaped characters that should be animatable (humans, knights, zombies, robots, mascots with one head / two arms / two legs). Handles preview approval, Meshy generation, rigging, and animation selection on ONE widget. Pick animation actionIds from `animation-library.md` in this skill and pass them as `animations` to pre-seed the picker.
- `generate3DAsset` — everything else: props, vehicles, weapons, buildings, food, furniture, and non-humanoid creatures.


Both tools run entirely in the background and immediately return a `generationId` — like every other generation tool. The chat widget first shows a concept preview image that the user can approve or reject directly on the widget; without a response it auto-approves after 90 seconds, then the final Meshy generation continues automatically. Announce the preview as "here is the model I'll build", never ask for permission before calling the tool. `waitTask` returns the finished model, `{ action: "rejected", feedback }`, or `{ action: "cancelled" }`. On rejection, revise the prompt per the feedback and call the SAME tool again (a fresh preview widget appears). On cancellation, acknowledge the dismissal and stop — do not treat it as a completed model or revise and retry the prompt.

For humanoid characters, keep the prompt rigging-safe: body, clothing, colors, hair, facial expression, and wearable accessories are fine, but do not add books, tools, weapons, sports balls, instruments, bags, foot-mounted gear, nearby props, or anything held/carried/attached unless the user explicitly asked for that standalone prop as a separate model (generate it with `generate3DAsset`). Hands, arms, legs, and feet must stay clearly visible.

Completed models return USDZ and thumbnail URLs hosted on R2 and are saved to the user's Assets only after the whole generation (including the humanoid animation phase) finishes successfully.

**When to use:** Whenever the app needs characters, creatures, vehicles, props, or any object that would look significantly better as a real 3D model than as procedural geometry.

**When NOT to use — use procedural geometry instead:**

- Floors, walls, platforms, ground planes → `generatePlane` / `generateBox`
- Bullets, projectiles, particles → `generateSphere` / `generateCylinder`
- Simple flat coins or tokens → `generateCylinder` (flat) with a material. Only use `collectible` role for detailed/3D pickups like treasure chests, ornate gems, trophies.
- Simple barriers, fences, pillars → `generateBox` / `generateCylinder`
- Any shape that is essentially a box, sphere, cylinder, or cone


**Scene composition — keep scenes lightweight:**

- Limit to **~8 unique generated models** per scene. More variety = worse performance.
- If you need **multiple copies** of the same object (5 trees, 10 coins, 20 asteroids), generate ONE model and use `entity.clone(recursive: true)` or `MeshInstancesComponent` (see `game-performance-reference.md`). Do NOT generate separate models for each copy.
- For games with many on-screen objects: generate 3–5 hero models + use procedural geometry for everything else.
- Geometry density is fixed server-side (see below): any standard model (prop or humanoid) lands around 90–95K triangles — one standard model is roughly the whole non-Pro iPhone budget — and a `lowPoly` model around 4K faces. Count clones when composing — `entity.clone` and `MeshInstancesComponent` save draw calls, NOT triangles — and use `lowPoly` or procedural geometry for anything placed many times.


**Performance:** A preview image takes ~10-30 seconds. Each Meshy model takes ~2 minutes and costs credits. The generation tools never block — preview, approval, and generation all run in the background. Build the entire app first, then collect results with one `waitTask({ generationIds: [...] })` at the end.

**Failed generations:** if `waitTask` reports a failed 3D generation, you may re-schedule that ONE model with a new tool call and call `waitTask` again with the still-pending ids plus the new generationId. If it fails twice, move on and use procedural geometry as a fallback.

#### Geometry density

There is no per-model polygon or quality parameter. Every standard model — `generate3DAsset` prop or `generate3DHumanoid` character — runs Meshy's high-detail geometry pass and then one fixed remesh (adaptive, detail-preserving triangle decimation), landing around **90–95K triangles** (~3.5–5MB of geometry) with edges, fingers, and thin parts intact. GLB textures ship as WebP with a 2048px base color and 1024px normal and metallic/roughness maps; USDZ textures are capped at 1024px. Humanoids are the expensive ones at runtime — a skinned mesh costs more than static geometry and each animation clip ships as its own file — so keep the number of unique animated characters small and clone them. The one knob you do have:

- `lowPoly: true` — Meshy Smart Topology generates ~4K clean faceted faces directly. Use it for stylized/faceted looks and for anything the scene clones many times (trees, rocks, coins, crowd characters).


One standard model is already the whole ~100K triangle budget of a non-Pro iPhone (see the table in `game-performance-reference.md`): plan **one standard hero** per scene on non-Pro phones and at most two on iPhone Pro / iPad, and fit every remaining `lowPoly` clone and procedural mesh inside the rest of the budget.

**Example** — a game with 5 unique models, targeting iPhone Pro (~200K), goblins, trees and rocks cloned:

```
generate3DHumanoid({ name: "Knight", prompt: "...", animations: [30, 19, 2] })  // hero, the one standard model: ~95K
generate3DHumanoid({ name: "Goblin", prompt: "...", lowPoly: true })            // 3 clones → ~12K
generate3DAsset({ name: "Sword", prompt: "...", lowPoly: true })                // ~4K
generate3DAsset({ name: "Tree", prompt: "...", lowPoly: true })                  // 8 clones → ~32K
generate3DAsset({ name: "Rock", prompt: "...", lowPoly: true })                  // 4 clones → ~16K
// Rendered total ≈ 160K — inside the iPhone Pro budget; for non-Pro iPhones make the hero lowPoly too or cut clones.
// Still generate ONE model per asset kind and use entity.clone(recursive: true) for copies.

```

#### Workflow

Choose Swift/RealityKit generated-3D game orientation before `createApp`. Orientation follows the requested gameplay, camera, and controls, not the fact that the scene is 3D. Use `swiftTemplateProfile: "landscape-3d-game"` when the chosen orientation is landscape: explicit landscape/horizontal requests, generic or ambiguous Swift/RealityKit 3D games, racing/driving/flight, FPS/TPS/shooters, arena combat, action RPG/open-world/adventure, sports/fighting, dual-stick controls, wide tactical maps, or designs that need a wide camera view or two-thumb controls. Keep portrait/default orientation for portrait-first games: endless/lane runners, vertical runners/climbers/fallers, one-tap or swipe hypercasual games, idle/merge/tycoon/collection games, card/board/puzzle/gacha games, vertical shooters, rhythm lane games, regular apps, AR/model viewers, product viewers, and non-game 3D showcases. If a generic 3D game is ambiguous, do not ask; default to landscape and use `swiftTemplateProfile: "landscape-3d-game"`. For an existing Swift app whose chosen design is landscape, set the main iOS target's iPhone/iPad supported orientations to LandscapeLeft/LandscapeRight, set `INFOPLIST_KEY_UIRequiresFullScreen` to `YES`, and mark the app's `rork.json` settings with `previewOrientation: "landscape"` before final RealityKit integration. Keep device orientation separate from generated-model local axes.

1. Read the app's code to understand the design, style, and context
2. Decide which objects need 3D models, mark cloned decorations as `lowPoly` (except models built from multiple reference images — multi-image does not support it), and split them into humanoids (animatable characters) vs assets
3. For humanoids, read `animation-library.md` in this skill first and pick the actionIds the app's code will drive (idle, walk, run, jump, attack, ...)
4. Before the generation calls, write ONE short sentence acknowledging what you're about to generate (e.g. "Here are the models I'll build — preview cards are coming up; reject a card to change it before generation"). Then call `generate3DHumanoid` / `generate3DAsset` once per model. Each call immediately returns a `generationId` while the preview, the user's approval, and the final generation all run in the background. In prompts, describe visible semantic landmarks, never local coordinate axes: say "muzzle clearly visible at one end, stock at the opposite end" or "windshield and grille visible at the front", not "+X", "-Z", "positive X axis", "negative Z direction", or "model local axis".
5. If `waitTask` returns `{ action: "rejected", feedback }` for a model, revise the prompt per the feedback and call the same tool again (a fresh preview widget appears). If it returns `cancelled`, drop that model and ask what the user wants instead.
6. **Split asset-independent code from final generated-model placement code.** Do NOT write final RealityKit transforms, socket constants, camera framing, model scale/orientation constants, or assembly offsets from preview thumbnails or pre-bundle guesses. For Swift/RealityKit generated-3D games, the canonical sequence is `generate3DHumanoid` / `generate3DAsset` (preview approval happens on the widget while the task runs) → asset-independent code only → `waitTask({ generationIds: [...] })` → `add3DModelToProject` for static models (humanoids with accepted animations are bundled automatically) → final scene code → `runChecks`. While Meshy generation runs, write state, input, HUD, audio hooks, scoring, systems, resource-name constants, and procedural fallbacks. Final placement code uses the ORIENTATION METADATA reported by the generation and bundling tool outputs.
7. **Before writing final generated-model RealityKit placement/assembly code**, call `waitTask` once with every 3D generationId. If a generation failed, you may re-schedule that one model and re-wait; if it fails again, keep the procedural fallback. The humanoid result already covers the animation phase (the user confirmed the selection on the widget while generation ran) and reports the bundled model + animation resourceNames. For static models call `add3DModelToProject`.
8. Once a generation completes, follow the tool output:
  - For Swift apps where the model must be referenced by name in code (`Entity(named:)` / `Model3D(named:)`): humanoids with accepted animations are bundled automatically by the tool; bundle static models with `add3DModelToProject`. Each tool output reports the bundled `resourceName` and the model's persisted ORIENTATION METADATA — write the placement code yourself per the recipe in `.rork/skills/swift/game-asset-integration.md` (gameplay container → runtime child → normalized visual; body-frame correction from `localFrontAxis` + `localUpAxis`). For composed objects (vehicle + wheels, weapon body + magazine + bolt, humanoid + hands), create one assembly root with named socket children, measure socket offsets from the corrected visual bounds after bundling, and keep part motion axes (wheel spin, slide recoil) separate from `localFrontAxis`.
  - For ambient asset-first generations (the user just asked for a 3D thing without integration intent): leave the model in the user's Assets and ask in chat before integrating.
  - For web (Vite React) workspaces: reference each model's GLB URL with three.js / React Three Fiber per `web/three-js.md` in this skill — there is no bundling step on web; the orientation metadata arrives in each generation tool's output (and via `listExistingAssets` for reused models). For other non-Swift workspaces: reference the USDZ/GLB URL through the active platform's loader.
  - Use the returned `orientation` metadata for every `Entity(named:)` / `Model3D(named:)` load, including RealityKit scenes, `ARView`, `UIViewRepresentable`, and SwiftUI overlay/composited game pieces. If `hasIntrinsicFront=true`, choose `desiredWorldForward` from the object's gameplay role, not from the camera, preview, or thumbnail: player/NPC uses movement or facing direction, vehicle uses travel direction, obstacle/sign/door meant to face the player uses the vector toward the player or camera target. Do NOT use raw `.pi` / `.pi / 2` constants in a `rotation(for:)` helper for generated models. If adding wobble, lean, or animation, apply it to the runtime child or compose deltas from a saved rest transform instead of overwriting the normalized visual/base socket transform. Use a gameplay container, a runtime child, and a loaded visual child; normalize scale by the semantic size being set (height for characters/floor props, front-axis length for long weapon/vehicle/bolt parts, longest axis only for directionless dominant-extent sizing), center X/Z, and ground/center/top-anchor Y from post-transform `visualBounds(relativeTo: runtimeChild)`. Move the gameplay container to the world/anchor position instead. Do not only fix `bounds.min.y`. If `hasIntrinsicFront=false`, treat the model as directionless for yaw correction, but still define explicit socket names and motion axes when it is a part of an assembly. For forward-scrolling endless runners where the camera follows from `+Z` and the track extends toward `-Z`, runner `desiredWorldForward` is `[0, 0, -1]`; an oncoming tram facing the runner uses `[0, 0, 1]`.
9. **Humanoid animations.** `generate3DHumanoid` handles the animation flow on its own widget: after the mesh completes it shows an animation picker (pre-seeded from the `animations` parameter or an automatic recommendation), waits for the user's confirmation, then rigs the model, generates the selected clips, and bundles them into Swift Resources/. The `waitTask` result reports the exact bundled `resourceName` strings plus an `animationPhase` outcome:
Do not invent animation `actionId`s in code or in chat — every actionId must come from `animation-library.md` or existing animations via `listExistingAssets`.
  - **Animations succeeded** — wire the reported resource names into Swift using the pattern in `.rork/skills/swift/generated-3d-animations.md` (write the small animation-player type from that doc yourself): one player per generated model container, exact resource names preloaded once, loops and one-shots driven from gameplay state. For states without listed resources, stop the stale loop so walk/run playback stops and the base visual is restored. Do not guess resource names. Read `.rork/skills/swift/realitykit-meshy-animation.md` for the bundled-filename contract and Meshy pitfalls.
  - **Web (Vite React) workspaces** — there is no bundling: after `waitTask` resolves, call `listExistingAssets({ types: ["3d-model"] })` for the model's Rigged GLB URL and each accepted animation's GLB URL, then wire playback per `web/three-js.md`: render the Rigged GLB as the visual (the plain model GLB has no skeleton — clips bound to it silently do nothing) and play the clips on one `AnimationMixer` bound to that rigged scene.
  - **Animations skipped or not rig-ready** — the result says why (user skipped, or the mesh failed the rigging readiness check: `not_full_body` → regenerate with "full body, head to feet, no cropping"; `limbs_unclear` → "clear arms and legs visible, no occluding clothing"; `crossed_limbs` → A-pose "standing, arms held slightly out, legs apart"; `occluded_limbs` → no props or capes hiding joints). Treat the model as static, surface the reason briefly, and offer to regenerate with a clearer body plan when rigging failed.
  - **Follow-up animation requests** ("also add a dance") — pick actionIds from `animation-library.md` in this skill, then call `append3DAnimations({ modelId, animations })` and `waitTask`. Patch app code before claiming the action works only when the user asked for gameplay behavior, controls, or playback wiring. A bundled animation USDZ is not gameplay by itself: add or update input, state/timers, hitbox or movement effects when relevant, and the animation-player state mapping before claiming a mechanic such as slide, attack, dodge, jump, or wave works.
  - To drop an animation the user no longer wants later, call `remove3DModelAnimation` (idempotent — succeeds with `alreadyAbsent: true` if it's already gone; throws CONFLICT while the model is currently being animated, in which case wait for the in-progress animation to finish and retry).
  - To enumerate animations a user has already added through the in-app Animate panel, call `listExistingAssets({ types: ["3d-model"] })` — animation row ids and names are surfaced under each model.


### Image-to-3D generation

Both generation tools accept reference images via `imageUrls`; the array length decides the flow:

- **One image** — image-to-3D with the normal preview-approval step: `generate3DAsset({ name: "Toy", prompt: "Create a 3D model from this reference image", imageUrls: ["https://..."] })`. The preview widget shows what will be built; the user approves or rejects with feedback as usual.
- **2-4 images of the SAME object from different angles** — direct Meshy multi-image-to-3D, skipping the preview (the user's own photos are the approval surface). Only use this when the user explicitly provides multiple reference images — never generate images to use as multi-image input. `lowPoly` is not supported with multi-image references.


Rules:

- Image must be a public https URL (user attachments and generated outputs are public)
- Supported formats: jpg, jpeg, png
- NEVER invent or guess URLs
- Multi-image direct pipeline takes ~2 minutes; single-image requests create a preview first


**Editing an existing model** — there are no retexture/remesh tools; edits are fresh generations. When the user attaches a generated asset (or names one) and asks for changes — different texture, colors, lower poly count, geometry tweaks — call the same generation tool again: pass the attached image (or the model's thumbnail URL from `listExistingAssets`) in `imageUrls` and fold the requested changes into the prompt (e.g. "same knight as the reference image, but with golden armor"). Use `lowPoly` for a faceted, lighter mesh. The previous model stays in the user's Assets until they delete it.

Tips for good prompts:

- Describe a **single object** — multi-object prompts produce poor results
- Generate EXACTLY what was requested. A ball is a sphere, a tree is a tree. Do NOT add humanoid features (limbs, faces, arms, legs) to non-humanoid objects.
- Front-load important descriptors: "low-poly cartoon red dragon with wings spread" not "a dragon that is red and low-poly"
- Mention style when it matters, but do not add cartoon/stylized unless the user or project explicitly calls for it; otherwise prefer realistic or clean 3D preview wording.
- Include physical details: colors, materials, proportions
- Never describe a pose in the prompt — the API handles posing automatically.
- For game props: mention scale context ("hand-held sword", "chest-high barrel")
- Bad: "a dragon" — Good: "a low-poly cartoon red dragon with wings spread, facing forward"
- Bad: "a soccer ball with arms and legs" — Good: "a realistic soccer ball with black and white hexagonal panels"


**In code:** See `realitykit-reference.md` for the `downloadModel` + `RealityView` pattern to load generated USDZ files. Always prefer generated models over procedural geometry for characters, creatures, vehicles, and detailed props.
