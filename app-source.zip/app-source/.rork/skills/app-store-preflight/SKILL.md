---
name: app-store-preflight
description: Run pre-submission checks on your iOS/macOS project to catch common
  App Store rejection patterns. Read this before running preflight checks.
---

## App Store Preflight

You just unlocked the `runPreflight` tool for running App Store compliance checks before submission.

### Overview

This tool runs pre-submission source review, streams progress in the existing widget, and reports evidence-backed issues. During rollout, the server can fall back to the legacy deterministic checks without changing the callable or widget contract.

### Before Calling This Tool

**You MUST complete ALL steps below in order. Do NOT skip ahead to calling `runPreflight`.**

1. **Pull App Store metadata when an App Store connection is available**:
  - Read `.rork/skills/app-store-connect/SKILL.md` to unlock ASC tools
  - Call `setupAsc({ requireAppleSession: false })`
  - Run `asc metadata pull --app "<APP_ID>" --version "<VERSION>" --dir ./<appPath>/metadata` via bash
  - If the app has never been published or ASC is unavailable, tell the user that the run is source-only. Do not delay source review just to obtain metadata.
2. **Read the app code** to understand:
  - What frameworks and APIs the app uses
  - Whether it has subscriptions/IAP
  - Whether it collects user data
  - What entitlements it requests
3. **Determine the app type** for the `appType` parameter:
  - `general` — Most apps (default)
  - `subscription` — Apps with subscriptions or IAP
  - `social` — Social/UGC apps
  - `kids` — Apps in the Kids category
  - `health` — Health & fitness apps
  - `games` — Games
  - `ai` — Apps using generative AI
  - `crypto` — Crypto/finance apps
  - `vpn` — VPN/networking apps


### What Gets Checked

The evaluated path fans out to five read-only reviewers:

- Safety — guideline 1.x
- Performance and reviewer-visible completeness — guideline 2.x
- Business, payments, and subscriptions — guideline 3.x
- Design and platform expectations — guideline 4.x
- Legal, privacy, and account deletion — guideline 5.x


Five isolated specialists run directly in the existing sandbox. They receive the app path, app type, read-only file/search tools, and sanitized App Store Connect readiness reports. Standalone preflight uses current app-level evidence. When a publishing tool resolves or completes a build in the same turn, preflight automatically uses exact-submission evidence. Do not search project files, `.rork/history`, logs, or prior messages for submission IDs. They do not receive Apple cookies, App Store Connect sessions, shell access, network access, or the parent conversation.

All model-produced findings are advisory during rollout. Report the tool's `likely_rejection`, `pass`, or `uncertain` assessment as a prediction, not enforcement. Do not describe it as a guaranteed rejection or use it as the final submission gate. The deterministic server-side checks that run during submission remain authoritative.

### Input

- `appPath`: app folder path (e.g. "expo", "ios", "DogMedicineTracker")
- `appType`: one of the app type values listed above


### After Preflight

Review the report in the widget, explain the likely Apple outcome, and recommend fixes for evidence-backed issues. Do not automatically stop submission on this advisory assessment; if the user proceeds, continue to the separate deterministic submission checks. A standalone run uses current app-level App Store Connect evidence when configured. After a publishing tool resolves or completes a build in the same turn, rerunning preflight automatically uses exact-submission evidence.

## Available tools

### runPreflight

Run App Store preflight compliance checks on the project.
The gated reviewer rollout inspects Safety, Performance, Business,
Design, and Legal surfaces with five isolated review specialists. Model findings are
advisory; final deterministic submission checks remain authoritative.

Results stream live to the existing preflight widget.

IMPORTANT: This tool waits for user input. Start any background tasks BEFORE calling this.

```json
{"type":"object","properties":{"appPath":{"type":"string","minLength":1,"maxLength":120,"description":"App folder path (e.g. 'expo', 'ios')"},"buildId":{"description":"Immutable source identifier for the build being reviewed. Metadata only; preserve when provided.","type":"string"},"appType":{"default":"general","description":"App type for category-specific checks.","type":"string","enum":["general","subscription","social","kids","health","games","ai","crypto","vpn"]}},"required":["appPath"]}
```
