# Rule: Account Deletion Requirement

- **Guideline**: 5.1.1(v)
- **Severity**: REJECTION
- **Category**: design

## What to Check

If an app supports account creation, it **must** offer an in-app account deletion option. Apple enforces this strictly — apps that allow users to create accounts but lack an in-app way to delete them will be rejected.

### What Counts as "Account Creation"

Any of the following qualifies:

- Sign in with Apple / Google / Facebook / email
- OAuth flows, `ASWebAuthenticationSession`, `expo-auth-session`
- Custom registration forms that persist a user identity
- Token-based auth (storing access/refresh tokens)

### What Does NOT Satisfy the Requirement

- A line in the Privacy Policy stating "you can request account deletion"
- A "Contact Support" button or email link
- A web-only deletion page with no in-app flow
- Directing users to Settings > Apple ID to revoke Sign in with Apple

### What Apple Expects

1. A clearly visible in-app option (e.g. Settings / Profile screen) to initiate account deletion
2. The deletion must actually delete the account and associated personal data on the backend
3. If some data must be retained (legal/regulatory reasons), explain the retention policy to the user before confirming
4. The flow can include a confirmation step but must not be intentionally cumbersome

## How to Detect

### Code-Level Signals

```bash
# Check for auth / account creation patterns (React Native)
grep -rn "signIn\|sign_in\|login\|useAuth\|AuthProvider\|SecureStore.*token\|expo-auth-session\|GoogleSignIn" --include="*.tsx" --include="*.ts" .

# Check for auth patterns (Swift)
grep -rn "ASAuthorizationAppleIDProvider\|SignInWithApple\|ASWebAuthenticationSession\|Authentication\|LoginView\|SignInView" --include="*.swift" .

# Check for account deletion patterns (React Native)
grep -rn "deleteAccount\|delete.*account\|account.*delet\|removeAccount\|remove.*account\|Delete.*Account\|Account.*Delet" --include="*.tsx" --include="*.ts" .

# Check for account deletion patterns (Swift)
grep -rn "deleteAccount\|delete.*account\|account.*delet\|removeAccount\|remove.*account\|Delete.*Account\|Account.*Delet" --include="*.swift" .
```

### Red Flags

- App has sign-in / authentication flow but no "Delete Account" button or screen
- Auth tokens stored in SecureStore / Keychain but no endpoint called to delete the account
- Profile/Settings screen with "Sign Out" but no "Delete Account"

## Resolution

1. **Add a "Delete Account" option** in the profile or settings screen
2. **Call a backend endpoint** that deletes the user's account and associated data
3. **Show a confirmation dialog** explaining what will be deleted
4. **Clear local auth state** (tokens, cached user data) after deletion
5. **Navigate to the signed-out state** after successful deletion

## Example Rejection

> **Guideline 5.1.1(v) - Data Collection and Storage**
>
> We noticed that your app supports account creation but does not include a mechanism for users to delete their account within the app.
>
> Apps that support account creation must also offer account deletion to give users more control over their data.
>
> Next Steps
>
> If your app already includes account deletion in a location other than the Settings or Profile area, please reply to this message and let us know. Otherwise, please add account deletion to your app.
