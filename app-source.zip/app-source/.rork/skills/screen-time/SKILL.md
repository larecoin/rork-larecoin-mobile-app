---
name: screen-time
description: Build iOS Screen Time, app blocking, focus, parental control, and digital wellbeing features with FamilyControls, DeviceActivity, ManagedSettings, and shield extensions. Use to distinguish OS-level app/site blocking from app-local limits, cooldowns, and demo flows.
aliases:
  - Screen Time
  - Family Controls
  - FamilyControls
  - DeviceActivity
  - ManagedSettings
  - ManagedSettingsUI
  - app blocking
  - app blocker
  - screen blocking
  - hard block
  - shield extension
  - parental controls
  - focus mode
  - digital wellbeing
---

# Screen Time and Family Controls

Use this skill for iOS apps that block apps or websites, schedule focus sessions, show Screen Time reports, customize the blocked-state shield UI, or could be confused with those features.

## Conversation Contract

Handle this conversationally. Do not silently decide that the user needs Family Controls just because they mention limits, cooldowns, blocking, discipline, or a shield icon.

When the user's request involves real iOS app or website blocking, explain the Apple constraint early in normal chat before claiming the feature can be tested:

- Real app and website blocking uses Apple's Screen Time APIs and requires the Family Controls entitlement.
- There is no real-device bypass for OS-level blocking. Mock UI can demonstrate the product flow, but it cannot block other apps.
- Real-device development builds need the entitlement in the signed provisioning profile. TestFlight and App Store distribution additionally need Apple's manual distribution approval. Give the request link: https://developer.apple.com/contact/request/family-controls-distribution
- Offer two useful paths:
  - Build the real Screen Time implementation and remind the user they need the entitlement before real device blocking works.
  - Build a mock/demo mode so onboarding, schedule setup, block lists, timers, and blocked-state UI can be tested while approval is pending.
- Do not sound like the user did something wrong. This is an Apple platform gate; Rork should guide them through it.

If the intent is ambiguous, ask one short clarifying question before adding Screen Time APIs or entitlements:

> Should this block other iPhone apps or websites through Apple Screen Time, or only limit behavior inside this app?

Good response shape:

> I can build this, but real iOS app blocking is gated by Apple's Family Controls entitlement. That means device testing and TestFlight need Apple approval first. I'll add the real Screen Time setup and include a mock mode so you can test the UX while approval is pending.

If the user is already blocked while testing, respond like a product guide:

> You're not stuck because of your code. Apple gates real app blocking behind Family Controls, so this build cannot actually block other apps until the entitlement is present in the provisioning profile. I can still make the flow testable now with mock blocking, and keep the real Screen Time path ready for when Apple enables it.

## Observed User Patterns

Use these patterns from prior agent chats and App Store submissions to choose the right path:

- Explicit Screen Time requests: "iOS Screen Time", "App Blocking access", DeviceActivity, ManagedSettings, FamilyControls, shield extensions. Build the real Screen Time path and explain the entitlement gate immediately.
- Product semantics that imply OS-level blocking: "lock distracting apps", "block selected apps until prayer/reflection/tasks are complete", "selected apps become unavailable", "earn social media time". Treat these as real Screen Time work even if the user does not name Apple's frameworks.
- Ambiguous "lock", "limit", or "cooldown" language: ask whether this controls other iPhone apps/websites or only behavior inside this app before adding entitlements.
- App-local responsible-use features: max bets per day, max loss per day, stake limits, lesson gates, mini-game cooldowns, subscription limits, or disabled in-app actions. Keep these app-local unless the user explicitly wants to block external apps or websites.
- Approval-pending testing: build mock/demo mode first so users can test onboarding, selection, schedules, credits, timers, and blocked-state screens while the real entitlement is pending.
- Existing publish failures: inspect the submitted snapshot for active entitlements/imports before telling the user to request approval. Historical, commented, or removed Screen Time traces are not enough.

## Intent Triage

Use real Screen Time and Family Controls only when the product needs OS-level control outside this app:

- Blocking, shielding, or unlocking other installed apps, app categories, or websites.
- User-selectable distracting apps, social apps, YouTube, browser domains, or app categories.
- Explicit mentions of iOS Screen Time, Family Controls, DeviceActivity, ManagedSettings, shield extensions, or app picker access.
- A blocked-state screen that appears when the user tries to open another app or website.

Use app-local state instead when the feature only limits behavior inside the generated app:

- Daily counters, max actions per day, max loss per day, stake limits, cooldown timers, onboarding gates, or paywall/trial limits.
- "Lock", "block", "shield", or "restricted" language where the object is an in-app form, lesson, bet submission, mini-game, or workflow.
- A coach, wellness, finance, or learning app that warns the user, disables an in-app button, or delays an in-app action.

Prior submission evidence showed both classes:

- Faith/productivity apps that unlock selected distracting apps after prayer, reflection, or tasks are real Screen Time work.
- Apps that give extra social-media time after exercise are real Screen Time work when they spend credits on other apps.
- A betting coach with max bets per day, max loss per day, and a cooldown should use in-app counters and timers. Family Controls is overreach unless the user explicitly wants to block external betting apps or websites.

## Framework Map

- `FamilyControls` — asks for authorization and lets the user pick apps, categories, and websites.
- `ManagedSettings` — applies shields and restrictions to selected apps, categories, and web domains.
- `DeviceActivity` — schedules monitoring and receives activity callbacks.
- `ManagedSettingsUI` — customizes shield configuration and shield actions.

## Implementation Shape

Keep Screen Time behind a narrow boundary so the user can keep building while Apple approval is pending:

- Create an app-local limits service for in-app counters, cooldowns, credits, streaks, and unlock rules.
- Create a Screen Time service only when the app needs OS-level app/site blocking.
- Give the UI one flow that can be backed by either mock/demo data or real Screen Time authorization.
- Do not add Family Controls entitlements to projects that only need app-local limits.
- In chat, say what works now, what is mock-only, and what will require entitlement approval. Users should not discover this only at publish time.

## Platform Fit

- Native Swift apps can use the real FamilyControls, ManagedSettings, DeviceActivity, and ManagedSettingsUI stack.
- React Native or Expo apps can build the product flow and mock/demo UX, but real Screen Time blocking requires native iOS targets/extensions or a Swift implementation path.
- If the current project cannot support the native extension stack, be honest early and offer a mock/demo mode or a Swift/native migration path.

## Implementation Checklist

For a real Screen Time app:

1. Add the Family Controls entitlement to the main app and Screen Time extensions: `com.apple.developer.family-controls`.
2. Add an App Group when extensions need shared state with the main app.
3. Add a Device Activity Monitor extension for scheduled monitoring.
4. Add Shield Configuration and Shield Action extensions when the app needs custom blocked-screen UI or actions.
5. Request Family Controls authorization before showing the picker or applying shields.
6. Store selected tokens safely. Do not try to serialize opaque Apple tokens into ad hoc strings.
7. Apply shields through `ManagedSettingsStore` only after authorization succeeds.
8. Add mock/demo state for previews, simulator, and users waiting on Apple approval.

## Testing Guidance

- Simulator can test most UI and mock mode, but not real OS-level app blocking.
- Real blocking requires a physical device, a signed build, Screen Time authorization, and the approved entitlement in the provisioning profile.
- If authorization or shielding fails on device, check the entitlement in the signed app and provisioning profile before rewriting product code.
- If the user wants to record a marketing/demo video before approval, use mock mode or a manually prepared account that already has Family Controls approved.
- If the chat only says the user is testing the flow, offer mock/demo testing first and explain what cannot be verified until Apple approves the entitlement.

## Mock Mode

Mock mode should be honest and useful:

- Show the same onboarding, permission explanation, app/category picker UI shell, schedule controls, countdowns, block lists, and blocked-state screens.
- Label blocked-state behavior as demo-only if it does not call the Screen Time APIs.
- Keep real Screen Time code isolated behind a service/protocol so switching from mock to real does not require rewriting UI.
- Use mock mode for previews, simulator, and approval-pending accounts.

## App Store and Publishing

If publishing fails with Family Controls entitlement/profile errors, treat it as an Apple manual-approval gate, not normal profile churn.

- Ask the user to request approval at https://developer.apple.com/contact/request/family-controls-distribution
- After approval, retry profile/capability preparation.
- If the user no longer wants real app blocking, remove the entitlement and Screen Time API usage rather than trying to bypass the gate.
- "Family Controls (Development)" is not enough for TestFlight or App Store distribution. Distribution needs Apple approval.
- Before escalating a publish failure as Family Controls, confirm active code or entitlements in the submitted snapshot. Old, commented, generated, or removed Screen Time traces should not force the user through Apple approval.

Do not conflate these failure classes:

- Missing `com.apple.developer.family-controls` in a provisioning profile means entitlement/profile approval is the blocker.
- "Family Controls (Development)" in an App Store export means the app needs the distribution capability approval.
- Invalid shield extension identifiers, DeviceActivity report extension errors, or ExtensionKit packaging errors are extension target or Info.plist problems. Fix those directly; entitlement approval alone will not solve them.
