---
name: Asset Library
description: Browse and reuse existing project media assets (3D models, audio,
  images, videos). Use when you need to inspect what the project already has,
  avoid duplicates, or reuse existing assets in code.
---

# Asset Library

Use this skill when you need to inspect or reuse assets that already belong to the project. Invoke the tool below via the root `callTool({ toolName, params })` dispatcher.

Call `listExistingAssets` to inspect existing assets and reuse their URLs / uniqueKeys in code. This is read-only and never writes files.

The tool accepts an optional `types` filter — pass a single-element array (`["image"]`, `["audio"]`, `["video"]`, `["3d-model"]`) to scope before a specific generation call, or omit `types` to list everything.

For Swift apps, call `saveExistingAssetsToProject` only after you have selected the exact assets that should be local bundle resources. It writes images into Assets.xcassets and audio/video/3D models/3D animations into Resources/. Already-saved files are skipped. For 3D models, the tool output lists each model's persisted orientation metadata — write the placement code yourself per the recipe in `.rork/skills/swift/game-asset-integration.md`; do not invent raw placement from scratch.

For web (Vite React) apps there is no bundling step: reference each model's GLB URL with three.js / React Three Fiber per `.rork/skills/assets/web/three-js.md`, take orientation metadata from the `listExistingAssets` output, and derive the facing correction from `localFrontAxis` / `localUpAxis` — never from thumbnails or raw Y-rotation guesses. Animation GLB URLs are listed under each model; render the model's Rigged GLB as the visual (the plain GLB has no skeleton — clips bound to it silently do nothing) and play the clips with one `AnimationMixer` bound to that rigged scene.

For existing 3D models, use orientation metadata returned by `listExistingAssets` / `saveExistingAssetsToProject` exactly like newly generated models. If `hasIntrinsicFront=true`, choose `desiredWorldForward` from the object's gameplay role and derive the body-frame correction from both `localFrontAxis` and `localUpAxis` (recipe in `.rork/skills/swift/game-asset-integration.md`). Apply this on every `Entity(named:)` / `Model3D(named:)` load, including RealityKit scenes, `ARView`, `UIViewRepresentable`, and SwiftUI overlay/composited game pieces. Player/NPC uses movement or facing direction; vehicle uses travel direction; obstacle/sign/door meant to face the player uses the vector toward the player or camera target; directionless props use nil/no rotation. Do not assign raw `.pi` / `.pi / 2` constants or `simd_quatf(...)` literals to the visual entity, even inside a `rotation(for:)` helper; apply wobble/lean/animation to the runtime child instead of overwriting the normalized visual transform. Use a gameplay container, a runtime child, and a loaded visual child; normalize scale, center X/Z, and ground Y from post-transform `visualBounds(relativeTo: runtimeChild)`. Move the gameplay container to the lane/world position instead. Do not only fix `bounds.min.y`. For forward-scrolling endless runners where the camera follows from `+Z` and the track extends toward `-Z`, runner `desiredWorldForward` is `[0, 0, -1]`; an oncoming tram facing the runner uses `[0, 0, 1]`.

To drop a previously-started 3D animation from a model, call `remove3DModelAnimation` with the animation row id from `listExistingAssets`. The call is idempotent — removing an animation that is already gone returns `{ removed: false, alreadyAbsent: true }`. If the model is currently being animated, the call rejects with a CONFLICT and you should wait before retrying.

Use this skill to browse, reuse, replace, or check assets that are already in the project. Do not treat it as a generation workflow. Do not use `saveExistingAssetsToProject` just to inspect assets.

## Available tools

### listExistingAssets

Lists existing project assets so the agent can reuse them instead of regenerating.
Pass `types` to scope the listing — e.g. `["image"]` before `generateImageAsset` for duplicate checks.
Defaults to all asset types when `types` is omitted.
Read-only: this never downloads files or writes into the app. Use saveExistingAssetsToProject when existing assets need to be bundled locally.

```json
{"type":"object","properties":{"types":{"description":"Asset types to include in the listing. Defaults to all four when omitted. Use a single-element array to scope to one type before a generation call.","type":"array","items":{"type":"string","enum":["image","audio","video","3d-model"]}}}}
```

### saveExistingAssetsToProject

Explicitly saves existing project assets into the local app bundle for code use.
Use this after listExistingAssets when a Swift app needs local resources instead of remote URLs.
Supports images (Assets.xcassets), audio/video (Resources), and 3D models with animations (Resources).
This tool has side effects by design: it downloads files and writes them into the project.

```json
{"type":"object","properties":{"types":{"description":"Asset types to save. Defaults to all existing asset types when omitted.","type":"array","items":{"type":"string","enum":["image","audio","video","3d-model"]}},"ids":{"description":"Optional asset identifiers to save. For 3D models, use model id or model name. For other assets, use id, uniqueKey, or assetName.","type":"array","items":{"type":"string"}},"includeAnimations":{"default":true,"description":"For 3D models, also save successful animation USDZ files. Default true.","type":"boolean"},"animationIds":{"description":"For 3D models, optional list of animation row ids (UUIDs from project_3d_model_animations) to save. Omit (do not pass the field) to save all of the model's successful animations. Pass an empty array to save the model with NO animations. Ignored entirely when includeAnimations is false. REQUIRES `ids` to scope which model the animation ids belong to — passing animationIds without ids is rejected.","type":"array","items":{"type":"string"}}}}
```

### remove3DModelAnimation

Removes a previously-started animation from a 3D model. Thin wrapper around the
backend removeAnimation mutation with idempotent semantics: if the animation row is
already absent (e.g. the user removed it in the UI first), the tool returns
`{ removed: false, alreadyAbsent: true }` instead of failing.

Conflict errors (the model is currently being animated) are propagated so the agent
can wait and retry. Use this when the user explicitly asks to drop a specific
animation from a model — do NOT call it speculatively.

```json
{"type":"object","properties":{"modelId":{"type":"string","format":"uuid","pattern":"^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$","description":"Row id of the project_3d_models entry."},"animationId":{"type":"string","format":"uuid","pattern":"^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$","description":"Row id of the project_3d_model_animations entry to remove."}},"required":["modelId","animationId"]}
```
