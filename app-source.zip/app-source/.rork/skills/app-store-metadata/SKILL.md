---
name: app-store-metadata
description: Generate App Store listing metadata (description, subtitle,
  keywords, promotional text) by analyzing the app's codebase. Read this before
  generating App Store metadata.
---

# App Store Metadata Generation

Generate App Store listing metadata (description, subtitle, keywords, promotional text) by analyzing the app's codebase.

## When to use

Call `generateAppStoreMetadata` when the user wants to prepare their app for the App Store, write App Store listing copy, or generate metadata for App Store Connect.

## Before calling

1. **Read the app code** to understand what the app does, its key features, screens, and value proposition.
2. Build a solid `appContext` from the code — don't guess. Read navigation, main screens, feature files.
3. If the user has preferences (tone, target audience, specific features to highlight), pass them as `userNotes`.
4. If legal or support URLs are needed, pass only public URLs from a generated or confirmed website in `legalUrls`. Do not invent placeholder legal URLs.


## appContext guidelines

- `appName`: The actual app name from the code (check app.json, Info.plist, or similar config)
- `category`: Specific category (e.g. "pixel RPG task manager", not just "productivity")
- `summary`: 1-2 sentences grounded in what the code actually does
- `features`: List 3-8 key features you found in the code. Be specific — "habit tracking with streak counter" not "tracking"
- `legalUrls`: Public support, marketing, privacy, terms, and privacy choices URLs from the generated or confirmed website


## After acceptance

The tool returns the accepted metadata fields. If the user wants to upload them, use canonical metadata JSON files for descriptions, release notes, and any other multiline text, even for one locale.

Pull the existing metadata first, then edit the returned JSON files with WriteFile or MultiEdit. Preserve unrelated locales and fields and encode line breaks as JSON `\n` escapes. Do not construct these values in shell arguments with `$'...'`: the Bash tool runs `sh`, which can pass that quoting through as literal text.

```bash
asc metadata pull --app "APP_ID" --version "VERSION" --platform "PLATFORM" --dir "./metadata"
# Edit the pulled JSON files before validating and pushing.
asc metadata validate --dir "./metadata" --check-urls
asc metadata push --app "APP_ID" --version "VERSION" --platform "PLATFORM" --dir "./metadata" --dry-run
asc metadata push --app "APP_ID" --version "VERSION" --platform "PLATFORM" --dir "./metadata"
```

Inspect the dry-run diff and confirm the intended paragraphs before pushing. Missing locales can produce deletes; restore missing files rather than bypassing the deletion guard with `--allow-deletes`. Reserve `asc apps info edit` for short single-line fields such as keywords and URLs.

`--check-urls` fetches the support and privacy policy URLs and reports redirects, dead links, and bare site roots; fix those before pushing, since a broken support or privacy URL is a routine App Review rejection.

Canonical metadata files cover app-info localizations (`name`, `subtitle`, `privacyPolicyUrl`, `privacyChoicesUrl`, `privacyPolicyText`) and version localizations (`description`, `keywords`, `promotionalText`, `supportUrl`, `marketingUrl`, `whatsNew`).

## Available tools

### generateAppStoreMetadata

Generate App Store listing metadata — description, subtitle, keywords, and promotional text.

Before calling, read the app code to understand features, screens, and value proposition.
Build appContext from actual code, not guesses.

The user reviews and can edit the generated metadata in a widget before accepting.

IMPORTANT: This tool waits for user input. Start any background tasks BEFORE calling this.

```json
{"type":"object","properties":{"appContext":{"type":"object","properties":{"appName":{"type":"string","minLength":1,"maxLength":120,"description":"The app's display name."},"category":{"type":"string","minLength":1,"maxLength":160,"description":"Specific product category (e.g. 'habit tracker', 'recipe organizer')."},"summary":{"type":"string","minLength":1,"maxLength":600,"description":"What the app does, who it's for, grounded in the codebase."},"features":{"minItems":3,"maxItems":8,"type":"array","items":{"type":"string","minLength":1,"maxLength":200},"description":"Key features found in the code. Be specific."}},"required":["appName","category","summary","features"]},"userNotes":{"description":"User preferences: tone, target audience, specific angles to emphasize.","type":"string","maxLength":1000},"locale":{"default":"en-US","description":"Target locale for the metadata.","type":"string"},"legalUrls":{"description":"Public legal/support URLs generated or confirmed before metadata generation.","type":"object","properties":{"homeUrl":{"description":"Public marketing/home page URL.","type":"string","format":"uri"},"supportUrl":{"description":"Public support URL.","type":"string","format":"uri"},"privacyPolicyUrl":{"description":"Public privacy policy URL.","type":"string","format":"uri"},"termsUrl":{"description":"Public Terms of Use or EULA URL.","type":"string","format":"uri"},"privacyChoicesUrl":{"description":"Public privacy choices, data export, or deletion URL.","type":"string","format":"uri"}}},"includeLegalLinksInDescription":{"description":"Set true for apps with subscriptions or in-app purchases that need Terms/Privacy links in the App Store description.","type":"boolean"}},"required":["appContext"]}
```
