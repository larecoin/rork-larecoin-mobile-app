---
name: app-config
description: Generate app icons and web share (Open Graph) images, capture App
  Store screenshots, and add Xcode targets. Read this before generating icons,
  share images, screenshots, or adding Swift targets.
---

## App Configuration

You just unlocked the `generateIcon`, `generateOgImage`, `captureAppScreenshots`, and `swiftAddTarget` tools. Invoke any of them via the root `callTool({ toolName, params })` dispatcher.

### Tool usage notes

- `generateIcon` — main app icon prompts must describe one clear centered focal symbol, explicit colors, explicit style, and an opaque full-bleed background. Do not ask for text, letters, screenshots, device frames, or a rounded-corner icon mask. For Swift apps the icon is saved into `Assets.xcassets/AppIcon.appiconset/icon.png` for all Xcode targets. For React Native it lands in `assets/images/icon.png` and adaptive variants. tvOS/visionOS/iMessage icon types read the existing main icon from disk and transform it — generate the main `icon` first, then call again with `tvos-icon`, `visionos-icon`, or `imessage-icon`.
- `generateOgImage` — web apps only, and only after `generateIcon` has completed (waitTask its generationId first when it ran in background): the icon at `public/icon.png` is required input so the share card matches the app's branding. The user approves the generated card in chat before it is saved to `public/og-image.jpg`; on rejection nothing is saved — ask what to change and call the tool again. Pick the `layout` preset that fits the app, put the app name and tagline in the prompt, then follow the tool output: it says when to ask the user which domain to use (projects with custom domains) and carries the `<head>` tags to merge into index.html — update existing og:/twitter: tags in place (never duplicate) and fill in the app name and description from the app's actual content.
- `captureAppScreenshots` — read `.rork/skills/app-config/screenshots.md` for the full screenshot workflow (exploration strategy, marketing prompt guidelines, upload instructions). Every capture rents a real iOS simulator, which costs credits regardless of framework. If the owner cannot cover it the call returns a clear error and does not start any work.
- `swiftAddTarget` — after the tool succeeds, write the actual Swift code for the new target and call `runChecks` with the exact Swift app folder path to verify the project compiles.


## Available tools

### generateIcon

Generates and saves an app icon into the correct project asset structure.
Always runs in background — returns a generationId immediately. Call
waitTask with that id when you actually need the saved paths.

For Swift apps: saves into Assets.xcassets/AppIcon.appiconset for all Xcode targets.
For React Native apps: saves into assets/images/icon.png and adaptive variants.
For Web apps: saves into public/icon.png and public/favicon.png.

For tvos-icon/visionos-icon/imessage-icon: reads the existing app icon from disk and transforms it.
Generate the main icon first before using these secondary types.

Main app icon prompts must describe one clear centered focal symbol, explicit colors, explicit style, and an opaque full-bleed background. Do not ask for text, letters, screenshots, device frames, or a rounded-corner icon mask.

```json
{"type":"object","properties":{"prompt":{"anyOf":[{"type":"object","properties":{"type":{"type":"string","const":"generate"},"prompt":{"type":"string","description":"Detailed description of the image to generate.\nWhen describing the image, match current design.\nBe specific about design details, colors, and other visual elements.\nExplain where it will be used.\nProvide as much detail as reasonable to make the changes."}},"required":["type","prompt"]},{"type":"object","properties":{"type":{"type":"string","const":"edit"},"prompt":{"type":"string","description":"The model can see the input images directly — you do NOT need to describe their content.\nFocus on what you want to change, transform, or compose. Be as detailed as you want —\nthe more specific you are about positioning, colors, typography, effects, and layout, the better the result."},"inputImages":{"type":"array","items":{"type":"string"},"description":"Array of images to edit. You are allowed to use urls or file paths to the images."}},"required":["type","prompt","inputImages"]}]},"appPath":{"type":"string","description":"App folder path (e.g. 'expo', 'ios')"},"iconType":{"default":"icon","description":"'icon' for main app icon, 'tvos-icon'/'visionos-icon'/'imessage-icon' to populate platform-specific assets from existing icon.","type":"string","enum":["icon","tvos-icon","visionos-icon","imessage-icon"]},"runInBackground":{"default":true,"description":"If true (default), schedules in background and returns a generationId; pair with waitTask. Set to false only when the caller really needs to block.","type":"boolean"}},"required":["prompt","appPath"]}
```

### generateOgImage

Generates a social share (Open Graph) image for a web app and shows it in chat for approval. Only the approved image is saved, to public/og-image.jpg (1200x630); a rejection saves nothing. Web apps only.
Requires the app icon at public/icon.png — call generateIcon first and wait for it to complete (waitTask on its generationId if it ran in background). The icon is passed to the image model so the card matches the app's branding.
Generation can run in background; waitTask returns only after the user's decision (auto-approved after 90 seconds without a response).
Returns the exact <head> meta tags to merge into index.html after the user approves.
The prompt only needs the app name, the tagline, and any extra style direction — the layout preset handles composition and the icon handles brand colors.

```json
{"type":"object","properties":{"prompt":{"type":"string","maxLength":5000,"description":"The app name, the one-line tagline, and any extra style direction for the card."},"appPath":{"type":"string","description":"Web app folder path (e.g. 'web')"},"layout":{"default":"icon-top","description":"Card composition, always center-weighted: 'icon-top' (centered stack: icon, name, tagline — the safe default), 'lockup' (icon and name side by side as one centered group), 'brand-art' (centered text over abstract icon-derived background, no literal icon).","type":"string","enum":["icon-top","lockup","brand-art"]},"runInBackground":{"default":true,"description":"If true (default), schedules in background and returns a generationId; pair with waitTask. Set to false only when the caller really needs to block.","type":"boolean"}},"required":["prompt","appPath"]}
```

### captureAppScreenshots

Capture real app screenshots via an iOS simulator and generate marketing-quality App Store screenshots.

Before calling this tool, read the app code to understand navigation, key screens, and design.
Use askUser to learn the user's style preferences first.

The tool provisions a Limrun simulator, navigates the app, captures real screenshots,
then plans a cohesive deck, generates background art, and asks the model to author the final HTML slides.

The user reviews results in a widget and can accept, edit individual screenshots,
regenerate all, or cancel.

Every capture rents a real iOS simulator, which costs credits regardless of framework. If the owner cannot cover it the call returns a clear error and no work is started.
IMPORTANT: This tool waits for user input. Start any background tasks BEFORE calling this.

```json
{"type":"object","properties":{"appPath":{"type":"string","description":"App folder path"},"appContext":{"type":"object","properties":{"appName":{"type":"string","minLength":1,"maxLength":120,"description":"Human-readable app name."},"category":{"type":"string","minLength":1,"maxLength":160,"description":"Specific product category, not a broad guess (e.g. 'dog training', 'budgeting', 'meditation', 'meal planning')."},"summary":{"type":"string","minLength":1,"maxLength":600,"description":"Short codebase-grounded description of what the app does, who it is for, and what outcome it helps users achieve."},"domainKeywords":{"minItems":1,"maxItems":20,"type":"array","items":{"type":"string","minLength":1,"maxLength":80}},"forbiddenInterpretations":{"minItems":1,"maxItems":20,"type":"array","items":{"type":"string","minLength":1,"maxLength":120}}},"required":["appName","category","summary"],"description":"Required codebase-grounded app context. Read the app code before calling this tool and pass a specific app summary, category, domain keywords, and any forbidden interpretations."},"device":{"default":"iphone","description":"Target App Store creative device. 'ipad' means a wider, roomier, less text-heavy composition with an iPad mockup; do not treat it as a stretched iPhone screenshot.","type":"string","enum":["iphone","ipad"]},"screenshotPrompts":{"minItems":1,"maxItems":10,"type":"array","items":{"type":"object","properties":{"label":{"type":"string","description":"Short label for this screenshot (e.g. 'Home Screen', 'Profile Tab')"},"screenDescription":{"type":"string","maxLength":500,"description":"Description of what the captured screen should visually show. Used to validate the screenshot after capture. Example: 'The New Task sheet is open with title field, note field, and category chips visible' or 'Task list showing 3 tasks with checkboxes, the first task is completed'."},"prompt":{"type":"string","maxLength":5000,"description":"Creative direction for this App Store screenshot slide. Must contain: one headline (3-5 words per line, max 2 lines, one idea, no 'and' joins), background style/theme, and the marketing angle for this screen. Do not ask for extra decorative HTML elements, badges, labels, frames, or floating shapes. The system will separately generate background art and then ask the model to author the final HTML slide."}},"required":["label","screenDescription","prompt"]},"description":"Prompts for each marketing screenshot to generate. Each prompt should describe the headline/subtitle direction and background mood. For iPad, prompts should imply more spacious, editorial creative with less copy and more breathing room."},"appLanguage":{"description":"ISO 639-1 language code of the app's UI as shown on screen (e.g. 'en', 'ru', 'ja'). Defaults to marketingLanguageCode if omitted. Used by the simulator navigator to read screen labels.","type":"string"},"marketingLanguageCode":{"description":"ISO 639-1 language code for generated App Store marketing content like headlines (e.g. 'en', 'ru', 'ja'). Defaults to 'en'.","type":"string"},"userScreenshots":{"description":"User-provided screenshots. If set, skip simulator exploration.","type":"array","items":{"type":"object","properties":{"label":{"type":"string"},"url":{"type":"string"}},"required":["label","url"]}},"reuseExistingCaptures":{"default":false,"type":"boolean"}},"required":["appPath","appContext","screenshotPrompts"]}
```

### swiftAddTarget

Add a new target to the Xcode project. Supports widgets (WidgetKit),
share extensions, notification content extensions, app intent extensions,
watchOS apps, tvOS apps, visionOS apps, and iMessage apps.

The tool creates the target in the Xcode project, sets up build settings,
adds a dependency from the host app (where applicable), embeds the extension,
and creates minimal scaffold source files. After calling this tool, write
the actual Swift code for the target.

IMPORTANT:
- The target name should be PascalCase (e.g. "MyAppWidget", "MyAppShare")
- For widgets: you will need to implement a TimelineProvider and Widget views
- For watch apps: no simulator preview available, but you can build and test on physical devices
- For tv apps: standalone target (not embedded in iOS app), design for the 10-foot UI and Focus navigation
- For vision apps: standalone target (not embedded in iOS app), design for spatial computing with SwiftUI volumes and windows
- For iMessage apps: creates two targets (container + Messages extension), the extension contains MessagesViewController with a SwiftUI view
- After adding a target, call runChecks with the app path to verify the project compiles

```json
{"type":"object","properties":{"name":{"type":"string","description":"Target name in PascalCase (e.g. \"MyAppWidget\", \"MyAppShare\")"},"type":{"type":"string","enum":["widget","share-extension","notification-content","app-intent","watch-app","tv-app","vision-app","imessage-app"],"description":"The type of target to add"},"path":{"description":"App folder containing the Xcode project (e.g. 'ios'). Defaults to the main app.","type":"string"}},"required":["name","type"]}
```
