## App Store Screenshots

### Overview

This tool automates two things:

1. **Capturing real screenshots** by navigating a live app in an iOS simulator (via Limrun)
2. **Generating marketing-quality App Store screenshots** using AI image generation with the real screenshots as reference

### Use the user's own screenshots when they provide them

If the user attached or uploaded their own app screenshots, pass them to the tool as `userScreenshots` (`{ label, url }[]`) instead of navigating the simulator. When `userScreenshots` is set, the tool skips simulator exploration entirely and uses those images as the captured screenshots — faster, cheaper, and exactly what the user asked for.

- Give each `userScreenshots` entry the same `label` as its matching `screenshotPrompts` entry, so the marketing slide gets the intended headline and background direction. A user screenshot whose label has no matching prompt still works, but falls back to a generic background.
- Only drive the simulator (the flow below) when you need to capture fresh screenshots and the user did NOT supply their own.

### How It Works

1. The tool provisions a Limrun iOS simulator and installs the app
2. It uses the accessibility tree (`elementTree()`) to understand the current screen
3. It navigates to core screens by tapping elements, scrolling, and typing
4. It captures real screenshots at each important screen
5. It generates marketing-style App Store screenshots using the captured images as reference
6. The user reviews, edits, or accepts the screenshots in a widget

### Before Calling This Tool

1. **Read the app code** to understand:
   - Navigation structure (tabs, stack navigators, drawer)
   - Key screens and their purposes
   - Color scheme and design language
   - App name and description
   - The literal product domain and nouns the app uses

2. **Check for existing screenshots.** Look for `screenshots/deck.json` in the project. If it exists, read it — it contains the shared visual style, slide labels, headlines per language, and background URLs from a previous run.

   **If `deck.json` exists**, check which devices already have captures by looking for `screenshots/captures/iphone/captures.json` and `screenshots/captures/ipad/captures.json`.

   Ask the user a single simplified question using `askUser`:

   **Question 1 — Reuse existing screenshots** (single-select, id: `reuse`)
   - `reuse` — Reuse existing captures and style (recommended — faster, consistent)
   - `recapture` — Recapture fresh screenshots in the simulator

   Skip style, screen selection, and device questions — those are already decided. If the user picks `reuse`, call the tool with the deck's `screenshotPrompts` labels and `reuseExistingCaptures: true`. Otherwise omit `reuseExistingCaptures` so the simulator captures the latest build. Never reuse after app changes or requests for updated, new, or latest screenshots.

   **Generate for ALL devices that have existing captures.** If both `iphone` and `ipad` captures exist, call the tool twice (once per device) without asking. Do not default to iPhone only.

   **If `deck.json` does NOT exist**, ask the full set of questions:

   **Question 1 — Screenshot style** (single-select, id: `style`)
   Use the same templates as Screenshot Studio (`packages/shared/src/screenshot-style-presets.ts`):
   - `clean-minimal` — Clean & minimal
   - `bold-vibrant` — Bold & vibrant
   - `dark-premium` — Dark premium
   - `playful-fun` — Playful & fun
   - `gradient-dreamy` — Gradient dreamy
   - `dark-moody` — Dark & moody
   - `flat-simple` — Flat & simple
   - `wellness-soft` — Wellness soft
   - `neon-energy` — Neon energy
   - `glass-modern` — Glass modern
   - `warm-organic` — Warm organic
   - `match-app` — Match the app's existing style

   Use the answer to set background mood and typography feel in each screenshot prompt.

   **Question 2 — Screenshot layout** (single-select, id: `layout`)
   Compositions measured across 20,923 real App Store screenshots (`packages/shared/src/screenshot-layout-templates.ts`).
   Style controls color and mood; layout controls where the device and headline sit. They are chosen independently.
   - `full-bleed` — App UI fills the canvas, headline floats on top of it (31%)
   - `hero-clipped` — Headline on top, big phone below, cut off by the bottom edge (13%)
   - `sandwich` — Headline on top, smaller device mid-canvas, open band below (13%)
   - `multi-device` — Two devices staged, one in front and one behind (13%)
   - `floating-centered` — Whole device visible with air above and below (8%)
   - `tall-headline` — Big multi-line copy block, device pushed low and clipped (7%)
   - `edge-to-edge` — Oversized device bleeding off both side edges (5%)
   - `text-first` — Copy owns the top half, device peeks in from below (3%)
   - `offset-device` — Device pushed off-center for an asymmetric frame (3%)
   - `tilted` — Device rotated off-axis for movement (2%)
   - `inverted` — Device runs off the top edge, headline underneath (2%)
   - `auto` — Pick the layout that fits the app's category

   Percentages are how often each composition appears on the store, not a ranking. Dense UI screens need a
   large device (`hero-clipped`, `edge-to-edge`, `full-bleed`); screens built around one number, chart, or
   illustration survive a smaller one (`sandwich`, `floating-centered`, `text-first`).

   **Question 3 — Screens to capture** (multi-select, id: `screens`)
   - `auto` — All main screens (agent picks 4-6 best)
   - Then list each real screen name you found in step 1 (e.g. `home`, `profile`, `search`, `detail`, etc.)

   If the user picks "All main screens", you decide which 4-6 screens look best for marketing. Otherwise, use exactly the screens they selected.

   **Question 4 — Device targets** (single-select, id: `device`)
   - `iphone` — iPhone only
   - `ipad` — iPad only
   - `both` — Both iPhone and iPad

   If `both`, call the screenshot tool twice: once with `device: "iphone"` and once with `device: "ipad"`.

3. **Build `appContext` before calling the tool.** This is required.
   Pass a codebase-grounded object with:
   - `appName`
   - `category` — specific product category, not a broad guess
   - `summary` — what the app does, who it is for, and the main outcome
   - `domainKeywords` — literal nouns/concepts that must be preserved
   - `forbiddenInterpretations` — wrong domains the image model must avoid

Example:

```json
{
  "appName": "FocusFlow",
  "category": "productivity",
  "summary": "A productivity app that helps people organize tasks, plan routines, and track daily progress.",
  "domainKeywords": ["tasks", "routines", "productivity", "planning", "progress"],
  "forbiddenInterpretations": ["fitness coaching", "education platform", "finance app"]
}
```

### Exploration Strategy

Think like a human preparing a product demo. Don't just visit screens — **build a story** through the app by creating content and interacting with it.

**Narrative arc approach:**

1. Start with an empty/fresh state if it looks good (e.g., a welcoming onboarding or clean empty state)
2. Create content: add items, fill forms, type messages, make selections
3. Capture the populated state after content exists
4. Interact with the content: complete tasks, mark favorites, open details
5. Capture the result of those interactions (completed states, detail views, progress screens)

**Example for a todo app:**

- Screenshot 1: Empty state with "No Tasks Yet" and a welcoming CTA
- Screenshot 2: The "Add Task" sheet with a task being entered
- Screenshot 3: The task list populated with 3-4 realistic tasks
- Screenshot 4: A task marked complete with celebration feedback
- Screenshot 5: Stats/progress screen showing streaks and achievements

**Rules:**

- Aim for exactly 5 screenshots (3-5 recommended, up to 10 max)
- Use `setup` steps AND the navigation agent's `type_text` action to fill the app with realistic content
- Each screenshot should show a DIFFERENT state of the app, not just different tabs
- Think about what makes the app look alive and useful, not empty
- Use realistic, domain-appropriate text when filling forms (not "test" or "hello")
- Wait 2-3 seconds for the app to fully load before the first interaction

### Preparing Screens With Input

The navigation agent can **type into text fields**, **press keys**, and **fill forms** during exploration. This means screenshots that require user input (search results, chat messages, filled forms, logged-in states) are now possible.

For screens that need preparation, add a `setup` array to the screenshot prompt. Each step runs in order before navigation begins:

```json
{
  "label": "Search Results",
  "prompt": "Find it fast. Dark minimal.",
  "setup": [
    {
      "action": "tap",
      "tapX": 200,
      "tapY": 60,
      "description": "Tap search bar"
    },
    {
      "action": "type_text",
      "tapX": 200,
      "tapY": 60,
      "text": "chocolate cake",
      "description": "Type search query"
    },
    { "action": "press_key", "key": "return", "description": "Submit search" },
    { "action": "wait", "waitMs": 2000, "description": "Wait for results" }
  ]
}
```

Available setup actions: `tap`, `type_text`, `press_key`, `scroll_down`, `wait`.

The navigation agent can also type and press keys autonomously during its vision-based exploration. If it sees an empty text field that should contain content for a good screenshot, it can fill it without explicit setup steps.

### Marketing Screenshot Prompts

**Screenshots are advertisements, not documentation.** Every screenshot sells one idea. You are not showing UI — you are selling a feeling, an outcome, or killing a pain point.

#### Headline Rules

- **3-5 words per line**, max 2 lines. Must be readable at arm's length in one second.
- **One idea per headline.** Never join two things with "and."
- No feature lists, compound clauses, jargon, or marketing buzzwords.

#### Three Headline Approaches (pick one per screenshot)

| Approach             | What it does                          | Example                     |
| -------------------- | ------------------------------------- | --------------------------- |
| **Paint a moment**   | The user pictures themselves doing it | "Your morning, simplified." |
| **State an outcome** | What life looks like after            | "Every workout, tracked."   |
| **Kill a pain**      | Name a problem and destroy it         | "Never miss a dose."        |

#### Narrative Arc

- **First screenshot = hero.** App's single biggest benefit. This is the only one most people see.
- Each subsequent screenshot sells a different angle — never repeat the same idea.
- Vary composition across screenshots — never use the same layout/background twice in a row.
- Include at least one contrast slide (inverted background) for visual rhythm.

#### What Each Prompt Should Contain

- Background mood in a few words (e.g., "dark minimal", "warm gradient", "deep blue")
- The marketing angle — what feeling or outcome this slide sells
- Do NOT include literal headline text in the creative direction. The deck planner generates headlines automatically based on the `marketingLanguageCode`. If you include English headline suggestions like "Headline: never miss a dose", the planner may copy them verbatim instead of writing in the target language.

#### How Screenshot Rendering Works

Screenshots are generated in two stages:

1. **Deck planning** — a single model call plans the entire deck: theme, palette, font, font size, per-slide headlines, and per-slide image-generation prompts for backgrounds. The plan is saved to `screenshots/deck.json` and reused across devices and locales.
2. **Background generation + HTML slides** — AI generates background images from the deck's image-gen prompts, then an HTML model composes each final slide (background + headline + device mockup with the real screenshot).

This means:

- The phone is always in the exact same position across all slides, as fixed by the chosen layout
- Headlines use the exact same font and size across the entire deck
- Backgrounds are generated once and reused across all locales
- The real app screenshot is displayed pixel-perfect inside the device frame
- Second locale runs skip capture, background generation, and style planning — only headlines are translated

#### What Makes a Good Screenshot Series

- **Consistent phone position** — one layout for the whole deck, so the device sits in the exact same spot on every slide. Variation comes from headlines and backgrounds only.
- **One headline per slide** — no app name labels, no subtitles, no captions. Just one bold statement.
- **Each slide sells a different angle** — never repeat the same idea or screen.
- **Cohesive color family** — backgrounds should feel related across the set while varying per slide.

#### iPad Screenshots

- Treat iPad screenshots as a **different creative format**, not a stretched iPhone screenshot.
- iPad backgrounds should feel **wider and calmer** with more breathing room.
- Use the same copy rules, but be even stricter: one short headline is usually enough.
- Favor screens that benefit from a larger canvas: dashboards, content-heavy views, split layouts, charts, canvases, media.

### Input Options

- `appPath`: The app folder path (e.g., `"expo"`, `"ios"`)
- `appContext`: Required structured app/domain context derived from the codebase and user intent
- `device`: `"iphone"` or `"ipad"` — use `"ipad"` only when you want iPad App Store creative, which should feel roomier and less text-heavy than iPhone
- `screenshotPrompts`: Array of prompt objects describing each screenshot to generate
- `userScreenshots`: Optional `{ label, url }[]`. If the user attached/uploaded their own screenshots, pass them here to skip simulator exploration entirely (see "Use the user's own screenshots when they provide them"). Match each `label` to a `screenshotPrompts` label so each image pairs with its matching marketing slide.

### After Screenshots Are Accepted

When the user accepts the generated screenshots, they are saved to the `screenshots/` directory.

IMPORTANT: Do NOT prompt for Apple Developer authentication or call `connectAppleDeveloper` during screenshot generation. Screenshot upload uses the ASC API key only and does NOT require a fresh Apple Developer web session.

After screenshots are saved, ask the user what they want to do next:

- "Would you like me to upload these screenshots to App Store Connect?"
- Options: "Yes, upload now" / "No, just keep them saved"

To upload:

1. Call `setupAsc({ requireAppleSession: false })`
2. Validate the files before any mutation: `asc screenshots validate --path "./screenshots/" --device-type IPHONE_65`
3. Preview and skip files already present by checksum: `asc screenshots upload --version-localization "LOC_ID" --path "./screenshots/" --device-type IPHONE_65 --skip-existing --dry-run`
4. Upload with `--skip-existing`: `asc screenshots upload --version-localization "LOC_ID" --path "./screenshots/" --device-type IPHONE_65 --skip-existing`
5. If the upload partially fails, resume with the exact artifact printed by the CLI, for example `asc screenshots upload --resume "./.asc/reports/screenshots-upload/failures-123.json"`. Do not combine `--resume` with the target selectors above.
6. Use `--replace --dry-run`, followed by `--replace --confirm`, only when the user explicitly approves deleting the entire target screenshot set. Do not delete records blindly to recover a failed upload.

Note: `IPHONE_65` accepts both 1242x2688 (6.5") and 1284x2778 (6.7") screenshots. Our generated screenshots are 1284x2778 which is valid for this device type. For iPad, use `IPAD_PRO_3GEN_129`.

If `setupAsc` returns `{status: "no_api_key"}`, then call `connectAppleDeveloper`. Otherwise, proceed directly — no auth prompt needed.
