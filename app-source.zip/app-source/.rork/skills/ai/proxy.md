# How the Rork Proxy Works

The Rork Toolkit server (`EXPO_PUBLIC_TOOLKIT_URL`, e.g. `toolkit.rork.com`) acts as a **reverse proxy** that forwards AI requests to upstream providers. It handles authentication, billing, rate limiting, and cost tracking so that the generated app only needs a single API key.

## URL structure

```
${TOOLKIT_URL}/v2/<service>/<upstream-path>
```

The proxy strips the `/v2/<service>` prefix and forwards the **rest of the path as-is** to the upstream.

- `/v2/vercel/` → Vercel AI Gateway (`ai-gateway.vercel.sh`). Example: `/v2/vercel/v1/chat/completions` → `ai-gateway.vercel.sh/v1/chat/completions`. Gateway speech uses `/v2/vercel/v4/ai/speech-model`; Gateway transcription uses `/v2/vercel/v4/ai/transcription-model`.
- `/v2/elevenlabs/` → ElevenLabs. Example: `/v2/elevenlabs/v1/text-to-speech/...` or `/v2/elevenlabs/v1/speech-to-text`.
- `/v2/exa/` → Exa (`api.exa.ai`). Example: `/v2/exa/search` → `api.exa.ai/search`.

**The upstream path must be complete and correct**, including version prefixes like `/v1/`, `/v3/ai/`, or `/v4/ai/`. Omitting them (e.g. `/v2/vercel/chat/completions` instead of `/v2/vercel/v1/chat/completions`) will result in a **404** from the upstream.

## Authentication

Browser builds (standalone web and React Native web preview) receive
short-lived delegated authentication from the Rork build runtime. Do not mint,
store, return, or manually expose `EXPO_PUBLIC_RORK_TOOLKIT_SECRET_KEY` to
browser code. Calls to `EXPO_PUBLIC_TOOLKIT_URL` may omit `Authorization`; the
runtime injects the delegated bearer token. Existing cross-platform React
Native source may still set the legacy header: web builds replace the value
with a non-secret placeholder and the runtime overwrites it before transport.

Native and server-only calls continue to include:

```
Authorization: Bearer <EXPO_PUBLIC_RORK_TOOLKIT_SECRET_KEY>
Content-Type: application/json
```

Rork AI Cloud is enabled by calling the `getOrCreateToolkitSecret` tool with a
short description of why the app needs it. The tool checks Cloud Credits
status without exposing the value. If Cloud Credits are already enabled,
continue without asking. Only ask the user to enable or claim credits when the
tool returns confirmation required.

## Base URL

The base URL is available as the environment variable `EXPO_PUBLIC_TOOLKIT_URL`.
