# Error Handling — Swift

Read `error-handling/api.md` first for the platform-agnostic HTTP status code matrix, retry strategy, idempotency keys, and `Retry-After` rules. This file covers the Swift-specific request/retry wiring.

## HTTP Status Codes — Swift mapping

Define a single error type per Swift layer that talks to the proxy. Map status codes to cases once, at the transport boundary, so UI layers only see the enum.

```swift
enum ProxyError: LocalizedError {
    case authError              // 401
    case insufficientBalance    // 402
    case payloadTooLarge        // 413
    case rateLimited            // 429
    case serverError(Int)       // 5xx
    case clientError(Int)       // other 4xx
    case noData                 // empty body on 200

    var errorDescription: String? {
        switch self {
        case .authError:           "AI features are currently unavailable. Please restart the app."
        case .insufficientBalance: "AI features are temporarily unavailable. Please try again later."
        case .payloadTooLarge:     "Image is too large. Please try a smaller photo."
        case .rateLimited:         "Too many requests. Please wait a moment and try again."
        case .serverError:         "Something went wrong. Please try again."
        case .clientError:         "Something went wrong. Please try again."
        case .noData:              "No response from the AI service. Please try again."
        }
    }
}
```

## Sending with retry, `Retry-After`, and idempotency

Every Swift call against `/v2/...` must go through a single `sendWithRetry` helper. The helper owns three cross-cutting concerns that are easy to get wrong if re-implemented per call site:

1. **Max 2 retries** — 3 attempts total. More burns user time and app-owner credits without helping. Do **not** raise this number when you see a flaky endpoint; fix the endpoint.
2. **`Retry-After` header takes precedence** over exponential backoff for 429 / 503. See `error-handling/api.md` for header formats.
3. **Same `idempotency-key` across retries** of one logical user action. Different logical action → new key. This prevents double billing when the first attempt succeeded upstream but the client never saw the response.

The reference implementation is at `error-handling/example-retry-sender.swift`. Copy it verbatim into the app (do not rewrite) and call it from every POST to `toolkit.rork.com/v2/...`. Example call site:

```swift
var request = URLRequest(url: url)
request.httpMethod = "POST"
request.setValue("application/json", forHTTPHeaderField: "Content-Type")
request.setValue("Bearer \(secret)", forHTTPHeaderField: "Authorization")
request.httpBody = try JSONSerialization.data(withJSONObject: body)
request.timeoutInterval = 120

// sendWithRetry auto-generates idempotency-key if none is set.
// Set one explicitly when the same user action spans multiple calls.
let (data, _) = try await sendWithRetry(request)
```

## Common mistakes (do NOT do these)

- **Inventing a new retry count per file.** If every service has its own `for attempt in 0..<4` loop, a UI that calls 3 services can wait 30+ seconds before surfacing a failure. Centralise in `sendWithRetry`.
- **Re-generating `UUID()` on every attempt inside the retry loop.** That defeats idempotency — each attempt gets a different key and the server treats them as independent requests. Generate the key **once**, before entering the loop.
- **Ignoring `Retry-After` on 429.** The gateway returns this header specifically because it knows how long to wait. Your exponential backoff is a guess.
- **Retrying 401, 402, or 413.** These are deterministic — retrying the same payload will fail the same way. Surface them to the user immediately.
- **Retrying non-idempotent logical actions without an `idempotency-key`.** Every POST that triggers a billable generation (image, chat, TTS, video) is subject to double billing on retry unless you send the key.

## Sample Code

| File                                        | Description                              |
| ------------------------------------------- | ---------------------------------------- |
| `error-handling/example-retry-sender.swift` | Reference `sendWithRetry` implementation |
