// Example: sendWithRetry — canonical Swift retry wrapper for the Rork proxy.
//
// Usage: swift example-retry-sender.swift <TOOLKIT_URL> <SECRET_KEY>
//
// Demonstrates the three concerns every POST to /v2/... must handle:
//   1. Max 2 retries (3 attempts total) on 5xx / 429 / transport errors.
//   2. `Retry-After` header takes precedence over exponential backoff.
//   3. Same `idempotency-key` across every retry of one logical request,
//      so the toolkit proxy can deduplicate and avoid double billing.
//
// Copy sendWithRetry + ProxyError + retryAfterSeconds verbatim into the app.
// Do not rewrite — the whole point is that every caller shares one correct
// implementation instead of reinventing it per service.

import Foundation

// MARK: - Error type

enum ProxyError: LocalizedError {
    case authError
    case insufficientBalance
    case payloadTooLarge
    case rateLimited
    case serverError(Int)
    case clientError(Int)
    case noData

    var errorDescription: String? {
        switch self {
        case .authError:           "AI features are currently unavailable. Please restart the app."
        case .insufficientBalance: "AI features are temporarily unavailable. Please try again later."
        case .payloadTooLarge:     "Image is too large. Please try a smaller photo."
        case .rateLimited:         "Too many requests. Please wait a moment and try again."
        case .serverError:         "Something went wrong. Please try again."
        case .clientError:         "Something went wrong. Please try again."
        case .noData:              "No response from the AI service. Please try again."
        }
    }
}

// MARK: - Retry-After parsing
//
// Two formats per RFC 7231 §7.1.3:
//   - Delta-seconds: `Retry-After: 30`
//   - HTTP-date:     `Retry-After: Wed, 21 Oct 2026 07:28:00 GMT`
// Returns nil for absent or unparseable values so the caller can fall back
// to exponential backoff.
func retryAfterSeconds(from response: HTTPURLResponse) -> Double? {
    guard let value = response.value(forHTTPHeaderField: "Retry-After") else { return nil }

    // Delta-seconds form — cheap integer path first.
    if let seconds = Double(value.trimmingCharacters(in: .whitespaces)) {
        return max(0, seconds)
    }

    // HTTP-date form — parse against the RFC 1123 locale to avoid device-locale
    // surprises (non-English locales would otherwise fail to parse "Wed").
    let formatter = DateFormatter()
    formatter.locale = Locale(identifier: "en_US_POSIX")
    formatter.timeZone = TimeZone(identifier: "GMT")
    formatter.dateFormat = "EEE, dd MMM yyyy HH:mm:ss zzz"
    if let date = formatter.date(from: value) {
        return max(0, date.timeIntervalSinceNow)
    }
    return nil
}

// MARK: - Exponential backoff with jitter
//
// Jitter prevents retry-storms when many clients fail at the same instant
// (e.g. a single upstream blip). 0..0.5s of random offset is enough to
// desynchronise retries without noticeably delaying any single caller.
func exponentialDelay(attempt: Int) -> Double {
    let base = pow(2.0, Double(attempt)) // 1s, 2s, 4s, ...
    let jitter = Double.random(in: 0...0.5)
    return base + jitter
}

// MARK: - sendWithRetry
//
// Retries on 429, 5xx, and transport errors up to `maxAttempts` total
// (default = 3 → initial + 2 retries). Never retries 401/402/413 — those
// are deterministic and retrying wastes time.
//
// If the caller did not set an `idempotency-key`, one UUID is generated
// here and reused across every attempt. Callers that span multiple
// requests for one logical action should set the header explicitly with
// the same value on all of them.
func sendWithRetry(
    _ request: URLRequest,
    maxAttempts: Int = 3,
    session: URLSession = .shared
) async throws -> (Data, HTTPURLResponse) {
    var req = request
    if req.value(forHTTPHeaderField: "idempotency-key") == nil {
        // Generate once, outside the loop — reusing the same key is the whole point.
        req.setValue(UUID().uuidString, forHTTPHeaderField: "idempotency-key")
    }

    var lastTransportError: Error?

    for attempt in 0..<maxAttempts {
        let isLastAttempt = attempt == maxAttempts - 1

        do {
            let (data, response) = try await session.data(for: req)
            guard let http = response as? HTTPURLResponse else {
                throw ProxyError.serverError(0)
            }

            switch http.statusCode {
            case 200...299:
                return (data, http)

            case 401:
                throw ProxyError.authError
            case 402:
                throw ProxyError.insufficientBalance
            case 413:
                throw ProxyError.payloadTooLarge

            case 429:
                if isLastAttempt { throw ProxyError.rateLimited }
                let wait = retryAfterSeconds(from: http) ?? exponentialDelay(attempt: attempt)
                try await Task.sleep(for: .seconds(wait))
                continue

            case 500...599:
                if isLastAttempt { throw ProxyError.serverError(http.statusCode) }
                let wait = retryAfterSeconds(from: http) ?? exponentialDelay(attempt: attempt)
                try await Task.sleep(for: .seconds(wait))
                continue

            default:
                // Other 4xx are client bugs — don't retry, surface to the user.
                throw ProxyError.clientError(http.statusCode)
            }
        } catch let error as ProxyError {
            // Non-retryable errors short-circuit immediately.
            throw error
        } catch {
            // Transport-level failure (DNS, connection reset, timeout) —
            // treat the same as 5xx and retry with backoff.
            lastTransportError = error
            if isLastAttempt { throw error }
            try await Task.sleep(for: .seconds(exponentialDelay(attempt: attempt)))
            continue
        }
    }

    // Unreachable — the loop either returns on 2xx, throws on a non-retryable
    // error, or throws on the last attempt. Guard against future edits.
    throw lastTransportError ?? ProxyError.serverError(0)
}

// MARK: - Demo call

guard CommandLine.arguments.count >= 3 else {
    print("Usage: swift example-retry-sender.swift <TOOLKIT_URL> <SECRET_KEY>")
    exit(1)
}

let toolkitURL = CommandLine.arguments[1]
let secretKey = CommandLine.arguments[2]

let url = URL(string: "\(toolkitURL)/v2/vercel/v1/chat/completions")!
let body: [String: Any] = [
    "model": "anthropic/claude-haiku-4.5",
    "messages": [
        ["role": "user", "content": "Say hello in one word."]
    ]
]

var request = URLRequest(url: url)
request.httpMethod = "POST"
request.setValue("application/json", forHTTPHeaderField: "Content-Type")
request.setValue("Bearer \(secretKey)", forHTTPHeaderField: "Authorization")
request.httpBody = try JSONSerialization.data(withJSONObject: body)
request.timeoutInterval = 60

let (data, http) = try await sendWithRetry(request)
print("Status: \(http.statusCode)")
print("Idempotency-Key sent: \(request.value(forHTTPHeaderField: "idempotency-key") ?? "(none)")")

struct ChatResponse: Codable {
    struct Choice: Codable {
        struct Message: Codable { let content: String? }
        let message: Message
    }
    let choices: [Choice]
}

let decoded = try JSONDecoder().decode(ChatResponse.self, from: data)
print("Reply: \(decoded.choices.first?.message.content ?? "(empty)")")
