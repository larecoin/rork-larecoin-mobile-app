# Error Handling — React Native / TypeScript (AI SDK)

Read `error-handling/api.md` first for the platform-agnostic HTTP status code matrix, retry strategy, idempotency keys, and `Retry-After` rules. This file covers the AI SDK-specific request/error wiring.

<references>
Fetch the AI SDK error handling documentation for the latest patterns:
https://ai-sdk.dev/docs/ai-sdk-core/error-handling
</references>

## Catching Errors

For `useChat`, errors surface through the `error` state and `onError` callback. For `generateText` / `streamText`, wrap in `try`/`catch`.

```ts
function getStatus(error: unknown): number | undefined {
  if (!error || typeof error !== "object") return undefined;
  const record = error as Record<string, unknown>;
  const status = record.statusCode ?? record.status;
  return typeof status === "number" ? status : undefined;
}

function getToolkitErrorMessage(error: unknown): string | null {
  if (!(error instanceof Error)) return "Something went wrong. Please try again.";

  const status = getStatus(error);

  switch (status) {
    case 401:
      return "AI features are currently unavailable. Please restart the app.";
    case 402:
      return "AI features are temporarily unavailable. Please try again later.";
    case 413:
      return "Image is too large. Please try a smaller photo.";
    case 429:
      return "Too many requests. Please wait a moment and try again.";
    default:
      if (status !== undefined && status >= 500) return "Something went wrong. Please try again.";
      return null;
  }
}
```

## Retry Behaviour

- **401** / **402** / **413**: Do NOT retry. These are deterministic — the same payload will fail the same way.
- **429**: The AI SDK handles retries automatically for `generateText` / `streamText` after a short delay. Respect any `Retry-After` header.
- **5xx**: The AI SDK handles retries automatically with exponential backoff (max 2 retries).

For `useChat`, the hook does not retry automatically — let the user retry by sending a new message.

## Inspecting gateway diagnostics

The error shown to the agent (e.g. `AI_APICallError`) is often a summary. Use the `fetchAiGatewayLogs` tool to correlate the failure with customer-safe status, timing, and request identifiers — see `error-handling/api.md` for usage. Provider, model, routing, and raw bodies remain internal-only.
