# Error Handling — HTTP Status Codes & Strategy

All Rork proxy endpoints return standard HTTP status codes. The status → action mapping below is platform-agnostic. The platform implementation lives in `error-handling/swift.md` (typed errors + `sendWithRetry`) or `error-handling/react-native.md` (AI SDK error helpers).

## Status code matrix

| Status | Meaning              | Response Body                                            | Action                                         |
| ------ | -------------------- | -------------------------------------------------------- | ---------------------------------------------- |
| 200    | Success              | Varies by endpoint                                       | Parse response JSON                            |
| 401    | Auth error           | `{ "error": "Missing or invalid Authorization header" }` | Do not retry — check API key                   |
| 402    | Insufficient balance | `{ "error": "...", "code": "INSUFFICIENT_BALANCE" }`     | Show user-friendly message, do not retry       |
| 413    | Payload too large    | `FUNCTION_PAYLOAD_TOO_LARGE`                             | Do not retry as-is — re-encode the image first |
| 429    | Rate limited         | `{ "error": "Rate limit exceeded" }`                     | Retry with exponential backoff                 |
| 5xx    | Server error         | Varies                                                   | Retry with exponential backoff (max 2 retries) |

## User-Facing Error Messages

**Always show user-friendly messages instead of raw errors or stack traces.** The user of the app does not understand technical error messages — show clear, actionable messaging.

| Status | User-Facing Message                                                | Notes                                               |
| ------ | ------------------------------------------------------------------ | --------------------------------------------------- |
| 401    | "AI features are currently unavailable. Please restart the app."   | Auth issue — do not retry automatically             |
| 402    | "AI features are temporarily unavailable. Please try again later." | Insufficient balance — the app owner must add funds |
| 413    | "Image is too large. Please try a smaller photo."                  | Resize locally before retrying                      |
| 429    | "Too many requests. Please wait a moment and try again."           | Rate limited — retry after a short delay            |
| 5xx    | "Something went wrong. Please try again."                          | Server error — retry with exponential backoff       |

### Detecting 402 (Insufficient Balance)

The 402 response includes `"code": "INSUFFICIENT_BALANCE"` in the JSON body. Use this to distinguish from other errors.

## Retry Strategy

- **401**: Do NOT retry. The API key is invalid or missing.
- **402**: Do NOT retry. The app owner needs to add funds.
- **413**: Do NOT retry the same payload. Resize or recompress the image first.
- **429**: Retry after a short delay — prefer the `Retry-After` header, fall back to exponential backoff.
- **5xx**: Retry with exponential backoff, **max 2 retries** (3 attempts total). More than this burns user time and credits without helping.

Transport-level errors (DNS failure, request timeout, connection reset) should be treated the same as 5xx: retry with exponential backoff, capped at 2 retries.

## Respecting `Retry-After`

When the proxy returns `429` or `503`, the response **may** include a `Retry-After` header telling you exactly how long to wait. Always prefer it over a self-chosen backoff: ignoring it makes rate-limit bursts worse and can get your project throttled further.

Two formats are possible:

- **Delta-seconds** (most common): a plain integer like `Retry-After: 30` → wait 30 seconds.
- **HTTP-date**: an RFC 1123 date like `Retry-After: Wed, 21 Oct 2026 07:28:00 GMT` → wait until that absolute time.

Fall back to exponential backoff only when the header is absent or unparseable.

## Idempotency Keys

The toolkit proxy deduplicates retried POSTs when you send an `idempotency-key` header. The server stores the first response under that key and returns it again (instead of re-billing the upstream model) if the same key arrives within a short window. Without this header, a retry can cause **double billing** — the first request may have succeeded upstream and only failed in transit, but the server has no way to know your retry is the same logical request.

**Rule:**

- Generate a fresh `idempotency-key` (e.g. a UUID) **once per logical user action**.
- Use the **same** key across every retry of that action.
- Generate a **new** key for the next logical action, even if the payload is identical.

```http
POST /v2/vercel/v1/chat/completions
Authorization: Bearer rork_sk_...
idempotency-key: 8f4a2b1c-7d3e-4f5a-9b0c-1d2e3f4a5b6c
Content-Type: application/json
```

The header name is lowercase `idempotency-key`. Idempotency applies to **all** POSTs that trigger billable work: chat completions, image generation, image editing, video generation, TTS, STT. Do not add it to GETs (they are already idempotent by HTTP semantics).

## Inspecting gateway diagnostics

The error shown to the agent (e.g. `AI_APICallError`) is often a summary. Use the customer-safe gateway diagnostics to correlate the failed request with its status and request ID.

Use the `fetchAiGatewayLogs` tool to retrieve failed calls for the current project:

```
fetchAiGatewayLogs({})                                       // 20 most recent errors (default)
fetchAiGatewayLogs({ assistantMessageId: "<id>" })           // scoped to one assistant message
fetchAiGatewayLogs({ onlyErrors: false, limit: 10 })         // include successful calls too
```

Each entry includes generic request metadata: `responseStatus`, `durationMs`, `assistantMessageId`, and `requestId`. Provider, model, routing, endpoint, request content, and raw response content are retained only in internal admin observability. The tool is scoped server-side to the current project's logs — you cannot query other projects.
