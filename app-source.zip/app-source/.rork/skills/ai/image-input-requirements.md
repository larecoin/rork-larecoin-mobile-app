# Image Input Requirements

<references>
These pages document provider-specific image input constraints. Fetch for the latest requirements:

| Topic                          | URL                                                                                 |
| ------------------------------ | ----------------------------------------------------------------------------------- |
| Image-to-Video (all providers) | https://vercel.com/docs/ai-gateway/capabilities/video-generation/image-to-video     |
| Text-to-Video                  | https://vercel.com/docs/ai-gateway/capabilities/video-generation/text-to-video      |
| Reference-to-Video             | https://vercel.com/docs/ai-gateway/capabilities/video-generation/reference-to-video |
| Image Generation (AI SDK)      | https://vercel.com/docs/ai-gateway/capabilities/image-generation/ai-sdk             |
| Image Generation (OpenAI)      | https://vercel.com/docs/ai-gateway/capabilities/image-generation/openai             |

</references>

This applies to every path that sends image bytes through the Vercel AI Gateway: vision chat, image editing, image-to-image, image-to-video for base64-capable providers, motion control, and multimodal reasoning.

> `xai/grok-imagine-video` with a source video URL is video-in / video-out, not image input.
>
> URL-only providers such as Wan, Seedance, and xAI bypass the Vercel request-body limit because the request carries only a URL string. You still want to resize before uploading to storage, but the byte-budget loop below is only required for base64 / buffer-in-body requests.

## The binding constraint: Vercel's 4.5 MB request-body limit

For requests that embed image bytes directly in the JSON body, Vercel rejects payloads above 4.5 MB before the model runs. The error is:

- `413 Request Entity Too Large`
- `FUNCTION_PAYLOAD_TOO_LARGE`

That limit is lower than common provider limits such as KlingAI 10 MB or Gemini 20 MB, so the Vercel edge is the real ceiling for these paths.

Base64 adds about 33% overhead, and the JSON envelope adds more. Use these budgets:

- Single-image requests: keep the re-encoded JPEG under about 3 MB raw.
- Multi-image requests: split that budget across all input images.
- Four reference images: target about 700 KB per image, not 3 MB each.

Fixed pixel caps are not enough. A detailed 1280px or 1536px JPEG can still exceed the Vercel limit.

## What to do before upload

1. Re-encode against a byte budget, not just a pixel cap.
2. Strip any `data:image/...;base64,` prefix to raw base64.

Use an iterative ladder instead of one fixed resize:

| Step | Max pixel (long edge) | JPEG quality |
| ---- | --------------------- | ------------ |
| 1    | 1280                  | 0.82         |
| 2    | 1024                  | 0.78         |
| 3    | 832                   | 0.74         |
| 4    | 640                   | 0.70         |
| 5    | 512                   | 0.65         |

Stop at the first version that fits the budget. If every step is still too large, fail locally and surface the same user-facing message you would use for a server-side 413.

## Canonical React Native helper

The canonical Expo helper lives at `ts/resize-for-upload.ts`. Read that file and copy it into `lib/resize-for-upload.ts` in the generated app.

```ts
import { resizeForUpload } from "./lib/resize-for-upload";

const { base64, mimeType } = await resizeForUpload(imageUri, maxBytes?);
```

It:

- strips any `data:` prefix
- walks the resize / compression ladder
- checks `Buffer.byteLength(base64, "base64")`
- throws `IMAGE_TOO_LARGE` when every step is still over budget

Swift examples inline the equivalent helper so each sample remains runnable as a standalone file.

## Reference implementations

| Platform          | Where                                                                                                                                                                                                                                                  | Resize approach                                                               | Prefix handling             |
| ----------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ----------------------------------------------------------------------------- | --------------------------- |
| Swift (iOS)       | `image-generation/example-image-edit-chat.swift`, `image-generation/example-image-edit-v3.swift`, `video-generation/example-image-to-video.swift` (the i2v sample auto-detects URL / `data:` URI / raw base64 / file path)                             | `ImageIO` thumbnail decode + iterative JPEG re-encode against a byte budget   | `stripDataUriPrefix(_:)`    |
| React Native / TS | `chat/react-native.md`, `video-generation/react-native.md`, `ts/resize-for-upload.ts`, plus CLI references in `image-generation/example-image-edit-chat.ts`, `image-generation/example-image-edit-v3.ts`, `video-generation/example-image-to-video.ts` | `expo-image-manipulator` in a loop for RN, `sharp` or equivalent for Node/Bun | `stripDataUriPrefix` helper |

## Minimal strip-prefix snippets

```swift
func stripDataUriPrefix(_ base64: String) -> String {
    guard base64.hasPrefix("data:"), let comma = base64.firstIndex(of: ",") else { return base64 }
    return String(base64[base64.index(after: comma)...])
}
```

```ts
const stripDataUriPrefix = (b64: string): string => {
  if (!b64.startsWith("data:")) return b64;
  const comma = b64.indexOf(",");
  return comma === -1 ? b64 : b64.slice(comma + 1);
};
```

## Provider-specific requirements

| Provider           | Formats        | Max file size | Dimensions | Aspect ratio   | Wire shape                                          |
| ------------------ | -------------- | ------------- | ---------- | -------------- | --------------------------------------------------- |
| KlingAI            | jpg, jpeg, png | 10 MB         | Min 300px  | 1:2.5 to 2.5:1 | `{ "type": "file", "data": <raw base64> }`          |
| Gemini             | jpg, png, webp | 20 MB         | —          | —              | `{ "type": "file", "data": <raw base64 \| data:> }` |
| OpenAI (GPT Image) | png, jpg, webp | 20 MB         | —          | —              | URL string or base64 envelope                       |
| FLUX Kontext       | jpg, png       | —             | —          | —              | `{ "type": "file", "data": <raw base64> }`          |
| Wan                | URL only       | —             | —          | —              | `{ "type": "url", "url": "https://…" }`             |
| Seedance           | URL only       | —             | —          | —              | `{ "type": "url", "url": "https://…" }`             |
| Veo                | URL or base64  | —             | —          | —              | Either shape                                        |
| xAI                | URL only       | —             | —          | —              | `{ "type": "url", "url": "https://…" }`             |

> **The "Wire shape" column is for raw HTTP / Swift `URLSession`.** The TypeScript AI SDK's `experimental_generateVideo` takes `{ image: Buffer | string, text }` and serialises to the right envelope per provider — see `video-generation.rn.md` for the SDK shape. Raw fetch must pick the envelope explicitly.

> **Always fetch the exact model's endpoint metadata before picking a shape.** The authoritative source is `capabilities.input_limits.image.supported_sources` on the endpoint spec — `["url"]`, `["base64"]`, or `["url", "base64"]` (and sometimes `"buffer"`, which uses the same `{ "type": "file" }` envelope as `"base64"`). Do not guess from the model ID — minor versions sometimes flip between URL-only and URL+base64.

## Request shape for raw fetch (Swift / `URLSession`)

```swift
// URL-only providers (Wan, Seedance i2v, xAI)
let body: [String: Any] = [
    "model": "alibaba/wan-v2.6-i2v",
    "prompt": prompt,
    "image": [
        "type": "url",
        "url": "https://your-bucket.example.com/photo.jpg"
    ]
]

// Base64-capable providers (Kling, FLUX, Veo)
let body: [String: Any] = [
    "model": "klingai/kling-v3.0-i2v",
    "prompt": prompt,
    "image": [
        "type": "file",
        "mediaType": "image/jpeg",
        "data": rawBase64  // strip any `data:image/...;base64,` prefix first
    ]
]
```

Sending the `{ "type": "file", "data": ... }` envelope to a URL-only provider returns a 400 from the upstream. Sending `{ "type": "url", ... }` to a base64-only provider does the same. The runnable Swift samples below cover both shapes.

## Common pitfalls

- Sending the original camera-roll photo directly.
- Using a single resize such as `width: 1536, compress: 0.85` and assuming it is safe.
- Forgetting to split the byte budget across multiple input images.
- Passing a `data:` URI to providers that require raw base64.
- Sending the `{ "type": "file" }` envelope to URL-only providers — pass a URL (or upload first and pass the public URL) so the unified `video-generation/example-image-to-video.swift` builds a `{ "type": "url" }` envelope instead.
