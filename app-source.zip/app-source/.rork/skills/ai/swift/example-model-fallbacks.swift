// Usage:
//   swift example-model-fallbacks.swift <TOOLKIT_URL> <SECRET_KEY> text
//   swift example-model-fallbacks.swift <TOOLKIT_URL> <SECRET_KEY> image
//   swift example-model-fallbacks.swift <TOOLKIT_URL> <SECRET_KEY> video

import Foundation

guard CommandLine.arguments.count >= 4 else {
    print("Usage: swift example-model-fallbacks.swift <TOOLKIT_URL> <SECRET_KEY> <text|image|video>")
    exit(1)
}

let toolkitURL = CommandLine.arguments[1]
let secretKey = CommandLine.arguments[2]
let mode = CommandLine.arguments[3]

func postJSON(url: URL, body: [String: Any], headers: [String: String] = [:], timeout: TimeInterval = 120) async throws -> Data {
    var request = URLRequest(url: url)
    request.httpMethod = "POST"
    request.timeoutInterval = timeout
    request.setValue("application/json", forHTTPHeaderField: "Content-Type")
    request.setValue("Bearer \(secretKey)", forHTTPHeaderField: "Authorization")
    for (key, value) in headers {
        request.setValue(value, forHTTPHeaderField: key)
    }
    request.httpBody = try JSONSerialization.data(withJSONObject: body)

    let (data, response) = try await URLSession.shared.data(for: request)
    let httpResponse = response as! HTTPURLResponse
    guard (200..<300).contains(httpResponse.statusCode) else {
        let text = String(data: data, encoding: .utf8) ?? ""
        throw NSError(domain: "GatewayFallbackSample", code: httpResponse.statusCode, userInfo: [NSLocalizedDescriptionKey: text])
    }
    return data
}

func printJSONSummary(_ data: Data) {
    let object = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] ?? [:]
    let json = try? JSONSerialization.data(withJSONObject: object, options: [.prettyPrinted, .sortedKeys])
    print(String(data: json ?? Data(), encoding: .utf8) ?? "{}")
}

func parseLastVideoResult(_ data: Data) throws -> [String: Any] {
    let text = String(data: data, encoding: .utf8) ?? ""
    var result: [String: Any]?
    for line in text.split(separator: "\n") {
        let trimmed = line.trimmingCharacters(in: .whitespaces)
        guard trimmed.hasPrefix("data: ") else { continue }
        let jsonText = String(trimmed.dropFirst(6))
        guard jsonText != "[DONE]", let jsonData = jsonText.data(using: .utf8) else { continue }
        if let object = try JSONSerialization.jsonObject(with: jsonData) as? [String: Any] {
            if object["type"] as? String == "error" {
                throw NSError(domain: "GatewayFallbackSample", code: 1, userInfo: [NSLocalizedDescriptionKey: jsonText])
            }
            if let videos = object["videos"] as? [[String: Any]], !videos.isEmpty {
                result = object
            }
        }
    }
    guard let result else {
        throw NSError(domain: "GatewayFallbackSample", code: 2, userInfo: [NSLocalizedDescriptionKey: "No video result event"])
    }
    return result
}

switch mode {
case "text":
    let data = try await postJSON(
        url: URL(string: "\(toolkitURL)/v2/vercel/v1/chat/completions")!,
        body: [
            "model": "openai/gpt-5.4-mini",
            "messages": [["role": "user", "content": "Reply with exactly: ok"]],
            "max_tokens": 20,
            "providerOptions": [
                "gateway": [
                    "models": ["anthropic/claude-haiku-4.5", "google/gemini-3.1-flash-lite-preview"]
                ]
            ]
        ]
    )
    printJSONSummary(data)

case "image":
    let model = "openai/gpt-image-2"
    let data = try await postJSON(
        url: URL(string: "\(toolkitURL)/v2/vercel/v3/ai/image-model")!,
        body: [
            "model": model,
            "prompt": "A tiny red dot on a white background",
            "n": 1,
            "size": "1024x1024",
            "providerOptions": [
                "gateway": [
                    "models": ["openai/gpt-image-1-mini"]
                ]
            ]
        ],
        headers: [
            "ai-gateway-protocol-version": "0.0.1",
            "ai-image-model-specification-version": "4",
            "ai-model-id": model
        ]
    )
    let object = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] ?? [:]
    let images = object["images"] as? [String] ?? []
    printJSONSummary(try JSONSerialization.data(withJSONObject: [
        "imageCount": images.count,
        "firstImageBase64Length": images.first?.count ?? 0,
        "providerMetadata": object["providerMetadata"] ?? NSNull()
    ]))

case "video":
    let model = "xai/grok-imagine-video"
    let data = try await postJSON(
        url: URL(string: "\(toolkitURL)/v2/vercel/v3/ai/video-model")!,
        body: [
            "model": model,
            "prompt": "A short abstract white screen with a small red dot",
            "n": 1,
            "providerOptions": [
                "gateway": [
                    "models": ["google/veo-3.1-fast-generate-001"]
                ]
            ]
        ],
        headers: [
            "accept": "text/event-stream",
            "ai-gateway-protocol-version": "0.0.1",
            "ai-video-model-specification-version": "4",
            "ai-model-id": model
        ],
        timeout: 180
    )
    let result = try parseLastVideoResult(data)
    let videos = result["videos"] as? [[String: Any]] ?? []
    printJSONSummary(try JSONSerialization.data(withJSONObject: [
        "videoCount": videos.count,
        "firstVideoType": videos.first?["type"] ?? NSNull(),
        "providerMetadata": result["providerMetadata"] ?? NSNull()
    ]))

default:
    print("Mode must be one of: text, image, video")
    exit(1)
}
