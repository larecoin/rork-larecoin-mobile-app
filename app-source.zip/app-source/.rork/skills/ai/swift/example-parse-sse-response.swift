// Example: SSE response parsing
//
// Usage: swift example-parse-sse-response.swift
//
// SSE responses have lines prefixed with "data: ". A naive
// replacingOccurrences(of: "data: ", with: "") breaks when there are
// multiple events or "data: " appears inside the JSON payload.
// Always parse line-by-line instead.

import Foundation

/// Parse all SSE event payloads from a raw response body.
func parseSSEEvents(from responseText: String) -> [String] {
    var events: [String] = []
    for line in responseText.components(separatedBy: "\n") {
        let trimmed = line.trimmingCharacters(in: .whitespaces)
        if trimmed.hasPrefix("data: ") {
            let json = String(trimmed.dropFirst(6))
            if !json.isEmpty, json != "[DONE]" {
                events.append(json)
            }
        }
    }
    return events
}

/// Extract the last SSE event payload (for single-result endpoints like video generation).
func parseLastSSEEvent(from responseText: String) -> String? {
    parseSSEEvents(from: responseText).last
}

// --- Self-test ---
let sample = """
data: {"choices":[{"delta":{"content":"Hello"}}]}
data: {"choices":[{"delta":{"content":" world"}}]}
data: [DONE]
"""
let events = parseSSEEvents(from: sample)
assert(events.count == 2, "Expected 2 events, got \(events.count)")
assert(parseLastSSEEvent(from: sample)!.contains("world"), "Last event should contain 'world'")
print("SSE parser: OK (\(events.count) events parsed)")
