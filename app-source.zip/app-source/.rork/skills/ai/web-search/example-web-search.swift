// Example: Web search via perplexity/sonar-pro through the Rork proxy.
//
// Reference: https://vercel.com/docs/ai-gateway/capabilities/web-search
// (check this page for the latest tools and parameters before relying on this example)
//
// Perplexity's sonar models search the web natively — no tool plumbing required.
// A system prompt instructs the model to write full URLs inline instead of [1][2]
// markers, because the Vercel OpenAI-compatible endpoint strips the separate
// citations array.
//
// Usage: swift example-web-search.swift <TOOLKIT_URL> <SECRET_KEY> "<query>"

import Foundation

guard CommandLine.arguments.count >= 4 else {
    print("Usage: swift example-web-search.swift <TOOLKIT_URL> <SECRET_KEY> <query>")
    exit(1)
}

let toolkitURL = CommandLine.arguments[1]
let secretKey = CommandLine.arguments[2]
let query = CommandLine.arguments[3]
let vercelV1URL = "\(toolkitURL)/v2/vercel/v1"

// --- Error type with user-facing messages ---

enum WebSearchError: LocalizedError {
    case authError
    case insufficientBalance
    case rateLimited
    case serverError(Int)

    var errorDescription: String? {
        switch self {
        case .authError:           "AI features are currently unavailable. Please restart the app."
        case .insufficientBalance: "AI features are temporarily unavailable. Please try again later."
        case .rateLimited:         "Too many requests. Please wait a moment and try again."
        case .serverError:         "Something went wrong. Please try again."
        }
    }
}

// --- Response type ---

struct ChatResponse: Codable {
    struct Choice: Codable {
        struct Message: Codable { let content: String? }
        let message: Message
    }
    let choices: [Choice]
}

// --- Request ---

let url = URL(string: "\(vercelV1URL)/chat/completions")!

let systemPrompt = """
You are a web search assistant. For every claim, include the full source URL inline \
in parentheses. Do NOT use [1][2] citation markers — always write the full https:// URL.
"""

let body: [String: Any] = [
    "model": "perplexity/sonar-pro",
    "messages": [
        ["role": "system", "content": systemPrompt],
        ["role": "user",   "content": query],
    ],
    // Optional — constrain by recency / domain:
    // "search_recency_filter": "week",
    // "search_domain_filter": ["techcrunch.com", "theverge.com"],
]

var request = URLRequest(url: url)
request.httpMethod = "POST"
request.setValue("application/json", forHTTPHeaderField: "Content-Type")
request.setValue("Bearer \(secretKey)", forHTTPHeaderField: "Authorization")
request.httpBody = try JSONSerialization.data(withJSONObject: body)

let (data, response) = try await URLSession.shared.data(for: request)
let httpResponse = response as! HTTPURLResponse

switch httpResponse.statusCode {
case 200:  break
case 401:  throw WebSearchError.authError
case 402:  throw WebSearchError.insufficientBalance
case 429:  throw WebSearchError.rateLimited
default:   throw WebSearchError.serverError(httpResponse.statusCode)
}

let result = try JSONDecoder().decode(ChatResponse.self, from: data)
print(result.choices.first?.message.content ?? "(empty)")
