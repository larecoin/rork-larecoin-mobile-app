// @ts-nocheck
// Example: Web search via AI SDK generateText + anthropic.tools.webSearch_20250305()
//
// Usage: bun example-web-search-anthropic.ts <TOOLKIT_URL> <SECRET_KEY> <QUERY>
//
// Requires: ai@^6, @ai-sdk/anthropic@^3, @ai-sdk/gateway@^3. Older 2.x adapters
// send provider-defined tools in a shape the current Vercel Gateway server
// rejects with HTTP 400 (`tools[0].type expected "function" | "provider"`).
//
// Reference: https://vercel.com/docs/ai-gateway/capabilities/web-search
// (check this page for the latest tools and parameters before relying on this example)
//
// Claude performs the search itself, synthesises an answer with citations, and
// returns both `result.text` (with the citations rendered inline by the model)
// and a structured `result.sources` array (`{ url, title }`) in a single
// `generateText` call. No second synth pass needed.
//
// This is the recommended TS path when the surrounding feature already speaks
// Claude or wants Anthropic prose. For OpenAI models use openai.tools.webSearch
// (see example-web-search-openai.ts); for any model use gateway.tools.perplexitySearch
// (see example-web-search.ts).
//
// Non-streaming on purpose: the final answer is 1–3 sentences; streaming only
// adds SSE parsing complexity.

import { createGateway, generateText } from "ai";
import { anthropic } from "@ai-sdk/anthropic";

const toolkitURL = process.argv[2];
const secretKey = process.argv[3];
const query = process.argv[4];

if (!toolkitURL || !secretKey || !query) {
  console.log("Usage: bun example-web-search-anthropic.ts <TOOLKIT_URL> <SECRET_KEY> <QUERY>");
  process.exit(1);
}

const gw = createGateway({
  baseURL: `${toolkitURL}/v2/vercel/v3/ai`,
  apiKey: secretKey,
});

const result = await generateText({
  model: gw("anthropic/claude-haiku-4.5"),
  prompt: query,
  tools: {
    web_search: anthropic.tools.webSearch_20250305({
      // Optional — restrict / shape search behaviour. Pick at most one of
      // `allowedDomains` or `blockedDomains` (Anthropic rejects sending both):
      //
      // maxUses: 3,
      // allowedDomains: ["techcrunch.com", "wired.com"],
      // userLocation: { type: "approximate", country: "US", city: "San Francisco" },
    }),
  },
});

console.log("Answer:\n" + result.text + "\n");
console.log("Sources:");
for (const s of result.sources) {
  console.log(`- ${s.title ?? "(untitled)"} — ${s.url}`);
}
