// Example: Web search via Anthropic's native `web_search_20250305` tool through
// the Rork proxy + Vercel AI Gateway's Anthropic Messages API surface.
//
// Endpoint:  POST {TOOLKIT_URL}/v2/vercel/v1/messages
// Tool spec: { "type": "web_search_20250305", "name": "web_search" }
// Reference: https://vercel.com/docs/ai-gateway/capabilities/web-search
// (check this page for the latest tools and parameters before relying on this example)
//
// Why a system prompt instructing inline URLs?
// The Vercel Gateway's Anthropic-Messages surface elides `web_search_tool_result`
// content blocks from the response (verified live, May 2026): only `text` and
// `tool_use` blocks come back, and the `text[].citations[]` entries are
// `char_location` shaped — they include `document_title` but not `url`.
// The simplest reliable way to surface URLs to the UI is to instruct the model
// to write them inline (same pattern as the perplexity/sonar-pro example).
//
// Usage: swift example-web-search-anthropic.swift <TOOLKIT_URL> <SECRET_KEY> "<query>"

import Foundation

guard CommandLine.arguments.count >= 4 else {
    print("Usage: swift example-web-search-anthropic.swift <TOOLKIT_URL> <SECRET_KEY> <query>")
    exit(1)
}

let toolkitURL = CommandLine.arguments[1]
let secretKey = CommandLine.arguments[2]
let query = CommandLine.arguments[3]

// --- Error type with user-facing messages ---

enum WebSearchError: LocalizedError {
    case authError
    case insufficientBalance
    case rateLimited
    case serverError(Int)

    var errorDescription: String? {
        switch self {
        case .authError:           "AI features are currently unavailable. Please restart the app."
        case .insufficientBalance: "AI features are temporarily unavailable. Please try again later."
        case .rateLimited:         "Too many requests. Please wait a moment and try again."
        case .serverError:         "Something went wrong. Please try again."
        }
    }
}

// --- Response decoding ---
//
// Anthropic Messages returns a heterogeneous `content[]`. We only care about
// `text` blocks for display — `tool_use` blocks are server-side bookkeeping
// and are not user-facing.

struct AnthropicResponse: Codable {
    let content: [ContentBlock]
}

struct ContentBlock: Codable {
    let type: String
    let text: String?
}

// --- Request ---

let url = URL(string: "\(toolkitURL)/v2/vercel/v1/messages")!

let systemPrompt = """
You are a web search assistant. For every claim, write the full source URL inline \
in parentheses. Do NOT use [1][2] citation markers — always write the full https:// URL.
"""

let body: [String: Any] = [
    "model": "anthropic/claude-haiku-4.5",
    "max_tokens": 1024,
    "system": systemPrompt,
    "tools": [
        ["type": "web_search_20250305", "name": "web_search", "max_uses": 3],
    ],
    "messages": [
        ["role": "user", "content": query],
    ],
    // Optional — restrict / shape search behaviour. Pick at most one of
    // `allowed_domains` or `blocked_domains` (Anthropic rejects sending both):
    //
    // "tools": [[
    //     "type": "web_search_20250305",
    //     "name": "web_search",
    //     "max_uses": 3,
    //     "allowed_domains": ["techcrunch.com", "wired.com"],
    //     // OR (mutually exclusive with allowed_domains):
    //     // "blocked_domains": ["example-spam-site.com"],
    //     "user_location": [
    //         "type": "approximate",
    //         "country": "US",
    //         "region": "California",
    //         "city": "San Francisco",
    //         "timezone": "America/Los_Angeles",
    //     ],
    // ]],
]

var request = URLRequest(url: url)
request.httpMethod = "POST"
request.setValue("application/json", forHTTPHeaderField: "Content-Type")
request.setValue("Bearer \(secretKey)", forHTTPHeaderField: "Authorization")
// Anthropic Messages API requires `anthropic-version`. The gateway currently
// defaults this when missing, but pin it explicitly so the example does not
// silently break if that default ever changes.
request.setValue("2023-06-01", forHTTPHeaderField: "anthropic-version")
request.httpBody = try JSONSerialization.data(withJSONObject: body)

let (data, response) = try await URLSession.shared.data(for: request)
let httpResponse = response as! HTTPURLResponse

switch httpResponse.statusCode {
case 200:  break
case 401:  throw WebSearchError.authError
case 402:  throw WebSearchError.insufficientBalance
case 429:  throw WebSearchError.rateLimited
default:   throw WebSearchError.serverError(httpResponse.statusCode)
}

let result = try JSONDecoder().decode(AnthropicResponse.self, from: data)

// Aggregate prose from every "text" block in order. The system prompt makes
// Claude embed full URLs directly in the text, so this single string contains
// both answer and sources.
let answer = result.content
    .filter { $0.type == "text" }
    .compactMap { $0.text }
    .joined(separator: "\n")

print(answer.isEmpty ? "(empty)" : answer)
