// @ts-nocheck
// Example: Web search via AI SDK generateText + openai.tools.webSearch()
//
// Usage: bun example-web-search-openai.ts <TOOLKIT_URL> <SECRET_KEY> <QUERY>
//
// Reference: https://vercel.com/docs/ai-gateway/capabilities/web-search
// (check this page for the latest tools and parameters before relying on this example)
//
// Requires: ai@^6, @ai-sdk/openai@^3, @ai-sdk/gateway@^3. Older 2.x adapters
// send provider-defined tools in a shape the current Vercel Gateway server
// rejects with HTTP 400 (`tools[0].type expected "function" | "provider"`).
//
// For OpenAI-family language models selected from the live catalog — the model performs the
// search itself, synthesises an answer, and returns both text and structured
// sources in a single `generateText` call. No second synth step needed (unlike
// `gateway.tools.perplexitySearch()`).
//
// Non-streaming on purpose: the final answer is 1–3 sentences; streaming only
// adds SSE parsing complexity.

import { createGateway, generateText } from "ai";
import { openai } from "@ai-sdk/openai";

const toolkitURL = process.argv[2];
const secretKey = process.argv[3];
const query = process.argv[4];

if (!toolkitURL || !secretKey || !query) {
  console.log("Usage: bun example-web-search-openai.ts <TOOLKIT_URL> <SECRET_KEY> <QUERY>");
  process.exit(1);
}

const gw = createGateway({
  baseURL: `${toolkitURL}/v2/vercel/v3/ai`,
  apiKey: secretKey,
});

const result = await generateText({
  model: gw("openai/gpt-5.4-mini"),
  prompt: query,
  tools: { web_search: openai.tools.webSearch({}) },
});

console.log("Answer:\n" + result.text + "\n");
console.log("Sources:");
for (const s of result.sources) {
  console.log(`- ${s.title ?? "(untitled)"} — ${s.url}`);
}
