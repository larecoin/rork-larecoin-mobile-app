# Web Search — React Native / TypeScript (AI SDK)

Read `web-search/api.md` first for the path overview. This file covers Exa direct search and the Vercel AI SDK implementation (paths A, B, and C).

> **Requires `ai@^6` and `@ai-sdk/{anthropic,openai,gateway}@^3`.** Older 2.x adapters (`ai@5` + `@ai-sdk/gateway@2`) send provider-defined tools in a shape the current Vercel Gateway server rejects with HTTP 400 (`tools[0].type expected "function" | "provider"`). The Rork monorepo catalog already pins these — make sure your project follows the catalog when adding `ai` deps.

Use `generateText` (not `streamText`).

<references>
| Topic             | URL                                                           |
| ----------------- | ------------------------------------------------------------- |
| Exa Search        | https://exa.ai/docs/reference/search-api-guide-for-coding-agents |
| Web Search        | https://vercel.com/docs/ai-gateway/capabilities/web-search    |
| `generateText`    | https://ai-sdk.dev/docs/reference/ai-sdk-core/generate-text   |
| Perplexity Search | https://docs.perplexity.ai/guides/search-quickstart           |

Always fetch the Vercel Web Search page before implementing — the available tools evolve.
</references>

## Exa direct search

Use Exa when the app needs structured hits, snippets/highlights, publication dates, full page contents, domain filters, category filters, or sources that are rendered separately from the answer. Call the Rork proxy directly; do not send an Exa key from the app.

If the feature is already built around an OpenAI or Anthropic model and only needs a short answered summary with sources, prefer the provider-native path below. Exa is the better default when search results are app data rather than only model context.

Exa has an official JS/TS SDK (`exa-js`), but generated apps should use direct `fetch` to the Rork proxy instead. The proxy owns the Exa key, balance checks, rate limits, and `costDollars.total` billing.

See `web-search/example-exa-web-search.ts` for a runnable version.

```ts
const TOOLKIT_URL = process.env["EXPO_PUBLIC_TOOLKIT_URL"];
const SECRET_KEY = process.env["EXPO_PUBLIC_RORK_TOOLKIT_SECRET_KEY"];

export type ExaSearchHit = {
  title?: string;
  url: string;
  publishedDate?: string | null;
  author?: string | null;
  highlights?: string[];
};

export async function searchWithExa(query: string): Promise<ExaSearchHit[]> {
  const response = await fetch(`${TOOLKIT_URL}/v2/exa/search`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${SECRET_KEY}`,
    },
    body: JSON.stringify({
      query,
      type: "auto",
      numResults: 5,
      contents: { highlights: true },
    }),
  });

  if (!response.ok) throw new Error(`Exa search failed: ${response.status}`);

  const data = (await response.json()) as { results?: ExaSearchHit[] };
  return data.results ?? [];
}
```

Keep Exa content options under `contents` on `/search`:

```json
{
  "contents": {
    "highlights": true,
    "text": { "maxCharacters": 3000 },
    "summary": { "query": "Main points" }
  }
}
```

Do not pass `stream: true`; the proxy bills Exa from the completed JSON response's `costDollars.total`.

## A. OpenAI native web search (simplest)

Pass `openai.tools.webSearch({})` only when the selected OpenAI language model has a live endpoint whose `tags` include `web-search`; verify this through `model-discovery.md`. The model performs the search itself, synthesises an answer, and returns both text and sources in a single call — no second `generateText` needed.

See `web-search/example-web-search-openai.ts` for a runnable version.

```ts
import { createGateway, generateText } from "ai";
import { openai } from "@ai-sdk/openai";

const gw = createGateway({
  baseURL: `${process.env["EXPO_PUBLIC_TOOLKIT_URL"]}/v2/vercel/v3/ai`,
  apiKey: process.env["EXPO_PUBLIC_RORK_TOOLKIT_SECRET_KEY"],
});

const result = await generateText({
  model: gw("openai/gpt-5.4-mini"),
  prompt: "What is the latest news about Apple Vision Pro? One sentence with URL.",
  tools: { web_search: openai.tools.webSearch({}) },
});

// result.text is a natural-language answer with inline URLs.
// result.sources is a structured array: { url, title } per source.
for (const s of result.sources) console.log("-", s.title, s.url);
```

Render `result.text` for the answer and iterate `result.sources` for a tap-through list.

## B. Perplexity search for any model

Pass `gateway.tools.perplexitySearch()` as a tool to any language model. The gateway executes the search and attaches the result to the assistant message as a `tool-result` content part.

**Read URLs from `result.toolResults[0].output.results` — not from `result.text`.** Provider-executed tools end the turn on the tool call, so the model never sees its own tool output; `result.text` will be either empty (Claude) or pre-tool chatter like _"I'll search for…"_ (Haiku). Whenever hits come back, run a second `generateText` with the hits inlined as context to get a real answer.

See `web-search/example-web-search.ts` for a runnable version.

```ts
import { createGateway, gateway, generateText } from "ai";

const gw = createGateway({
  baseURL: `${process.env["EXPO_PUBLIC_TOOLKIT_URL"]}/v2/vercel/v3/ai`,
  apiKey: process.env["EXPO_PUBLIC_RORK_TOOLKIT_SECRET_KEY"],
});

export type SearchHit = {
  title: string;
  url: string;
  snippet: string;
  date: string;
  last_updated: string;
};

export async function searchWeb(query: string): Promise<{ answer: string; hits: SearchHit[] }> {
  const first = await generateText({
    model: gw("anthropic/claude-haiku-4.5"),
    prompt: query,
    tools: { perplexity_search: gateway.tools.perplexitySearch({ maxResults: 5 }) },
  });

  const hits = first.toolResults.flatMap((tr) =>
    tr.toolName === "perplexity_search" ? (tr.output.results as SearchHit[]) : [],
  );
  if (hits.length === 0) return { answer: first.text, hits };

  const synth = await generateText({
    model: gw("anthropic/claude-haiku-4.5"),
    prompt: `Answer the user's question in 2 sentences using these results. Cite the full URL after each claim.

Question: ${query}

Results:
${hits.map((h) => `- ${h.title} (${h.url}): ${h.snippet}`).join("\n")}`,
  });
  return { answer: synth.text, hits };
}
```

### Perplexity tool output shape

Each entry in `toolResults[i].output.results` has:

| Field          | Type   | Description                 |
| -------------- | ------ | --------------------------- |
| `title`        | string | Page title                  |
| `url`          | string | Full source URL             |
| `snippet`      | string | Extracted excerpt           |
| `date`         | string | Published date (YYYY-MM-DD) |
| `last_updated` | string | Last-modified date          |

### Perplexity options

```ts
gateway.tools.perplexitySearch({
  maxResults: 5, // 1–20, default 10
  searchRecencyFilter: "week", // "day" | "week" | "month" | "year"
  searchDomainFilter: ["reuters.com"], // prefix "-" to exclude
  country: "US", // ISO 3166-1 alpha-2
  searchLanguageFilter: ["en"], // ISO 639-1 codes
});
```

## C. Anthropic native web search (Claude models)

For Claude language models, pass `anthropic.tools.webSearch_20250305()` as a tool. Claude performs the search itself, synthesises an answer with citations rendered inline in the prose, and returns both `result.text` and a structured `result.sources` array (`{ url, title }`) — same one-call shape as path A. Use this when the surrounding feature already speaks Claude or wants Anthropic prose.

See `web-search/example-web-search-anthropic.ts` for a runnable version.

```ts
import { createGateway, generateText } from "ai";
import { anthropic } from "@ai-sdk/anthropic";

const gw = createGateway({
  baseURL: `${process.env["EXPO_PUBLIC_TOOLKIT_URL"]}/v2/vercel/v3/ai`,
  apiKey: process.env["EXPO_PUBLIC_RORK_TOOLKIT_SECRET_KEY"],
});

const result = await generateText({
  model: gw("anthropic/claude-haiku-4.5"),
  prompt: "What is the latest news about Apple Vision Pro? One sentence with URL.",
  tools: { web_search: anthropic.tools.webSearch_20250305() },
});

for (const s of result.sources) console.log("-", s.title, s.url);
```

### Anthropic options

```ts
anthropic.tools.webSearch_20250305({
  maxUses: 3, // cap searches per conversation
  allowedDomains: ["techcrunch.com"], // restrict to allowlist
  // OR (mutually exclusive with allowedDomains):
  // blockedDomains: ["example-spam-site.com"],
  userLocation: { type: "approximate", country: "US", city: "San Francisco" },
});
```

## Why not `streamText`?

Web search is a "fetch results, then write an answer" flow. The search itself is a blocking upstream call — nothing streams until it finishes. After that, the final text is typically 1–3 sentences. Streaming buys you nothing except complexity (full-stream part handling, polyfills, buffering).

Stick with `generateText`.

## Sample Code

| File                                         | Path | Description                                                            |
| -------------------------------------------- | ---- | ---------------------------------------------------------------------- |
| `web-search/example-exa-web-search.ts`       | Exa  | Exa structured search via direct Rork proxy fetch                      |
| `web-search/example-web-search-openai.ts`    | A    | OpenAI native web search via `openai.tools.webSearch({})`              |
| `web-search/example-web-search.ts`           | B    | Perplexity search via `gateway.tools.perplexitySearch()` (any model)   |
| `web-search/example-web-search-anthropic.ts` | C    | Anthropic native web search via `anthropic.tools.webSearch_20250305()` |

## Error Handling

See `error-handling/react-native.md` for AI SDK error patterns and `error-handling/api.md` for the HTTP status code matrix.
