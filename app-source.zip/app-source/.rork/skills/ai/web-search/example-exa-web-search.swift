// Example: Exa search via direct Rork proxy fetch
//
// Usage: swift example-exa-web-search.swift <TOOLKIT_URL> <SECRET_KEY> "<query>"

import Foundation

guard CommandLine.arguments.count >= 4 else {
    print("Usage: swift example-exa-web-search.swift <TOOLKIT_URL> <SECRET_KEY> <query>")
    exit(1)
}

let toolkitURL = CommandLine.arguments[1]
let secretKey = CommandLine.arguments[2]
let query = CommandLine.arguments[3]

enum ExaSearchError: LocalizedError {
    case authError
    case insufficientBalance
    case rateLimited
    case serverError(Int)

    var errorDescription: String? {
        switch self {
        case .authError:           "AI features are currently unavailable. Please restart the app."
        case .insufficientBalance: "AI features are temporarily unavailable. Please try again later."
        case .rateLimited:         "Too many requests. Please wait a moment and try again."
        case .serverError:         "Something went wrong. Please try again."
        }
    }
}

struct ExaSearchResponse: Codable {
    struct Result: Codable {
        let title: String?
        let url: String
        let publishedDate: String?
        let author: String?
        let highlights: [String]?
    }

    let results: [Result]
}

let url = URL(string: "\(toolkitURL)/v2/exa/search")!

let body: [String: Any] = [
    "query": query,
    "type": "auto",
    "numResults": 5,
    "contents": [
        "highlights": true,
    ],
]

var request = URLRequest(url: url)
request.httpMethod = "POST"
request.setValue("application/json", forHTTPHeaderField: "Content-Type")
request.setValue("Bearer \(secretKey)", forHTTPHeaderField: "Authorization")
request.httpBody = try JSONSerialization.data(withJSONObject: body)

let (data, response) = try await URLSession.shared.data(for: request)
let httpResponse = response as! HTTPURLResponse

switch httpResponse.statusCode {
case 200:  break
case 401:  throw ExaSearchError.authError
case 402:  throw ExaSearchError.insufficientBalance
case 429:  throw ExaSearchError.rateLimited
default:   throw ExaSearchError.serverError(httpResponse.statusCode)
}

let result = try JSONDecoder().decode(ExaSearchResponse.self, from: data)
for hit in result.results {
    print("- \(hit.title ?? "(untitled)") — \(hit.url)")
    for highlight in hit.highlights ?? [] {
        print("  \(highlight)")
    }
}
