// @ts-nocheck
// Example: Web search via AI SDK generateText + gateway.tools.perplexitySearch()
//
// Usage: bun example-web-search.ts <TOOLKIT_URL> <SECRET_KEY> <QUERY>
//
// Reference: https://vercel.com/docs/ai-gateway/capabilities/web-search
// (check this page for the latest tools and parameters before relying on this example)
//
// Requires: ai@^6, @ai-sdk/gateway@^3. Older 2.x ai-sdk pins (e.g. ai@5 +
// @ai-sdk/gateway@2) send provider-defined tools in a shape the current
// Vercel Gateway server rejects with HTTP 400, and `gateway.tools` is
// undefined on older `ai` packages.
//
// Works with ANY language model — the gateway executes the search and attaches
// structured results (title, url, snippet, date) to the assistant message as a
// tool-result part. Read URLs from `result.toolResults[i].output.results[].url`,
// NOT from `result.text`:
//   - Provider-executed tools end the turn on the tool call; the model never
//     sees its own tool output, so it cannot synthesise an answer in the same
//     call.
//   - `first.text` is often empty, OR contains pre-tool chatter like "I'll
//     search for …" which is useless as an answer.
// Whenever the tool produced hits, run a second `generateText` with the hits
// inlined as context to get a real answer.
//
// Non-streaming on purpose: web search is a blocking upstream fetch followed by
// a 1–3 sentence answer — streaming buys nothing but SSE parsing overhead.

import { createGateway, gateway, generateText } from "ai";

const toolkitURL = process.argv[2];
const secretKey = process.argv[3];
const query = process.argv[4];

if (!toolkitURL || !secretKey || !query) {
  console.log("Usage: bun example-web-search.ts <TOOLKIT_URL> <SECRET_KEY> <QUERY>");
  process.exit(1);
}

const gw = createGateway({
  baseURL: `${toolkitURL}/v2/vercel/v3/ai`,
  apiKey: secretKey,
});

type SearchHit = {
  title: string;
  url: string;
  snippet: string;
  date: string;
  last_updated: string;
};

const first = await generateText({
  model: gw("anthropic/claude-haiku-4.5"),
  prompt: query,
  tools: {
    perplexity_search: gateway.tools.perplexitySearch({ maxResults: 5 }),
  },
});

const hits: SearchHit[] = first.toolResults.flatMap((tr) =>
  tr.toolName === "perplexity_search" ? (tr.output.results as SearchHit[]) : [],
);

let answer = first.text;

// If the tool produced hits, always run a second call to synthesise. The first
// call either returned empty text (Claude) or pre-tool chatter like "I'll
// search for …" (Haiku) — neither is a useful answer. The second call sees
// the hits as plain context and writes a real answer with URLs.
if (hits.length > 0) {
  const synth = await generateText({
    model: gw("anthropic/claude-haiku-4.5"),
    prompt: `Answer the question in 2 sentences using these results. Cite the full URL after each claim.

Question: ${query}

Results:
${hits.map((h) => `- ${h.title} (${h.url}): ${h.snippet}`).join("\n")}`,
  });
  answer = synth.text;
}

console.log("Answer:\n" + answer + "\n");
console.log("Sources:");
for (const h of hits) {
  console.log(`- ${h.title} — ${h.url}`);
}
