// @ts-nocheck
// Example: Exa search via direct Rork proxy fetch
//
// Usage: bun example-exa-web-search.ts <TOOLKIT_URL> <SECRET_KEY> <QUERY>
//
// Use this when the app needs structured search hits, highlights, dates,
// domain filters, category filters, or contents it can render itself.

const toolkitURL = process.argv[2];
const secretKey = process.argv[3];
const query = process.argv[4];

if (!toolkitURL || !secretKey || !query) {
  console.log("Usage: bun example-exa-web-search.ts <TOOLKIT_URL> <SECRET_KEY> <QUERY>");
  process.exit(1);
}

type ExaSearchHit = {
  title?: string;
  url: string;
  publishedDate?: string | null;
  author?: string | null;
  highlights?: string[];
};

const response = await fetch(`${toolkitURL}/v2/exa/search`, {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
    Authorization: `Bearer ${secretKey}`,
  },
  body: JSON.stringify({
    query,
    type: "auto",
    numResults: 5,
    contents: { highlights: true },
  }),
});

if (!response.ok) {
  const errorText = await response.text();
  throw new Error(`Exa search failed with ${response.status}: ${errorText}`);
}

const data = (await response.json()) as {
  results?: ExaSearchHit[];
};

console.log("Sources:");
for (const hit of data.results ?? []) {
  console.log(`- ${hit.title ?? "(untitled)"} — ${hit.url}`);
  for (const highlight of hit.highlights ?? []) {
    console.log(`  ${highlight}`);
  }
}
