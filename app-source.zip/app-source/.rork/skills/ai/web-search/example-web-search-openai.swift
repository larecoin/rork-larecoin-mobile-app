// Example: Web search via OpenAI's native built-in `web_search` tool through
// the Rork proxy + Vercel AI Gateway's OpenAI Responses API surface.
//
// Endpoint:  POST {TOOLKIT_URL}/v2/vercel/v1/responses
// Tool spec: { "type": "web_search" }
// Reference: https://vercel.com/docs/ai-gateway/capabilities/web-search
// (check this page for the latest tools and parameters before relying on this example)
//
// Two response-shape gotchas with the Vercel Gateway's Responses surface
// (verified live, May 2026):
//
//   1. Top-level `output_text` is null. Read the answer from the assistant
//      message item: `output[].content[].text` where the inner type is
//      `output_text`.
//   2. `annotations[]` on output_text comes back empty — `url_citation`
//      entries that the upstream OpenAI Responses API documents are not
//      surfaced through the gateway. We instruct the model via the top-level
//      `instructions` field to write full URLs inline (same pattern as the
//      perplexity/sonar-pro example), which is reliable.
//
// Usage: swift example-web-search-openai.swift <TOOLKIT_URL> <SECRET_KEY> "<query>"

import Foundation

guard CommandLine.arguments.count >= 4 else {
    print("Usage: swift example-web-search-openai.swift <TOOLKIT_URL> <SECRET_KEY> <query>")
    exit(1)
}

let toolkitURL = CommandLine.arguments[1]
let secretKey = CommandLine.arguments[2]
let query = CommandLine.arguments[3]

// --- Error type with user-facing messages ---

enum WebSearchError: LocalizedError {
    case authError
    case insufficientBalance
    case rateLimited
    case serverError(Int)

    var errorDescription: String? {
        switch self {
        case .authError:           "AI features are currently unavailable. Please restart the app."
        case .insufficientBalance: "AI features are temporarily unavailable. Please try again later."
        case .rateLimited:         "Too many requests. Please wait a moment and try again."
        case .serverError:         "Something went wrong. Please try again."
        }
    }
}

// --- Response decoding ---
//
// The Responses API output is a heterogeneous array. We decode opportunistically
// and filter by `type` at the call site — only `message` items carry user-facing
// text; `web_search_call` items are server-side bookkeeping.

struct ResponsesResponse: Codable {
    let output: [OutputItem]
}

struct OutputItem: Codable {
    let type: String
    let content: [MessageContent]?
}

struct MessageContent: Codable {
    let type: String
    let text: String?
}

// --- Request ---

let url = URL(string: "\(toolkitURL)/v2/vercel/v1/responses")!

let instructions = """
You are a web search assistant. For every claim, write the full source URL inline \
in parentheses. Do NOT use [1][2] citation markers — always write the full https:// URL.
"""

let body: [String: Any] = [
    "model": "openai/gpt-5.4-mini",
    "instructions": instructions,
    "input": query,
    "tools": [
        ["type": "web_search"],
    ],
    // Optional — bias search context size or constrain user location:
    //
    // "tools": [[
    //     "type": "web_search",
    //     "search_context_size": "medium",     // "low" | "medium" | "high"
    //     "user_location": [
    //         "type": "approximate",
    //         "country": "US",
    //         "city": "San Francisco",
    //     ],
    // ]],
]

var request = URLRequest(url: url)
request.httpMethod = "POST"
request.setValue("application/json", forHTTPHeaderField: "Content-Type")
request.setValue("Bearer \(secretKey)", forHTTPHeaderField: "Authorization")
request.httpBody = try JSONSerialization.data(withJSONObject: body)

let (data, response) = try await URLSession.shared.data(for: request)
let httpResponse = response as! HTTPURLResponse

switch httpResponse.statusCode {
case 200:  break
case 401:  throw WebSearchError.authError
case 402:  throw WebSearchError.insufficientBalance
case 429:  throw WebSearchError.rateLimited
default:   throw WebSearchError.serverError(httpResponse.statusCode)
}

let result = try JSONDecoder().decode(ResponsesResponse.self, from: data)

// Walk every assistant message item, every content part, and join the
// `output_text` parts. The instructions make GPT embed full URLs directly in
// the text, so this single string contains both answer and sources.
let answer = result.output
    .filter { $0.type == "message" }
    .flatMap { $0.content ?? [] }
    .filter { $0.type == "output_text" }
    .compactMap { $0.text }
    .joined(separator: "\n")

print(answer.isEmpty ? "(empty)" : answer)
