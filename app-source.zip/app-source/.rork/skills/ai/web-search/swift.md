# Web Search — Swift

Read `web-search/api.md` first for the path overview. Swift cannot use the Vercel AI SDK, so every Swift path here is a raw `URLSession` POST against the Rork proxy. Exa direct search uses `/v2/exa/*`; the answer-generation options route through Vercel AI Gateway. Pick by whether the app needs structured search data or a model-family-specific answer.

I did not find an official Swift SDK in Exa's current SDK or integrations docs. Use `URLSession` against the Rork proxy for Swift apps so the server-side Exa key and toolkit billing path are used.

Use a non-streaming `POST` (no SSE). Web search is a single-turn fetch-and-answer flow; streaming only adds parsing complexity.

<references>
| Topic                  | URL                                                                              |
| ---------------------- | -------------------------------------------------------------------------------- |
| Exa Search             | https://exa.ai/docs/reference/search-api-guide-for-coding-agents                 |
| Web Search overview    | https://vercel.com/docs/ai-gateway/capabilities/web-search                       |
| Anthropic Messages API | https://vercel.com/docs/ai-gateway/sdks-and-apis/anthropic-messages-api/advanced |
| OpenAI Responses API   | https://vercel.com/docs/ai-gateway/sdks-and-apis/responses                       |
| Perplexity Search      | https://docs.perplexity.ai/guides/search-quickstart                              |

</references>

## Path picker

| Path                              | Endpoint               | Model                            | When to use                                                                      |
| --------------------------------- | ---------------------- | -------------------------------- | -------------------------------------------------------------------------------- |
| Exa direct search                 | `/v2/exa/search`       | Exa                              | Structured results, highlights, page text, dates, filters, app-rendered sources. |
| C1. Perplexity model directly     | `/v1/chat/completions` | `perplexity/sonar-pro`           | Default answer path. Cheapest, single-call answer + inline URLs.                 |
| C2. Anthropic native `web_search` | `/v1/messages`         | `anthropic/claude-haiku-4.5` etc | When the surrounding feature already uses Claude or wants Claude prose.          |
| C3. OpenAI native `web_search`    | `/v1/responses`        | `openai/gpt-5.4-mini` etc        | When the surrounding feature already uses GPT or you want OpenAI grounding.      |

All three converge on the same UX shape: a single answer string with full URLs embedded inline. **The Vercel Gateway elides each provider's structured citation/source fields** — `web_search_tool_result` blocks (Anthropic), `url_citation` annotations (OpenAI), and the top-level `citations` array (Perplexity OpenAI-compat) all come back empty or absent. The reliable cross-provider pattern is to instruct the model via system prompt / `instructions` to write full URLs inline. Every example in this folder follows that pattern.

Don't mix tool shapes across endpoints — the gateway forwards bodies verbatim, so each native tool spec only works on its provider's compatible endpoint.

## Sample Code

| File                                            | Path | Description                                               |
| ----------------------------------------------- | ---- | --------------------------------------------------------- |
| `web-search/example-exa-web-search.swift`       | Exa  | Exa structured search with `URLSession`                   |
| `web-search/example-web-search.swift`           | C1   | Perplexity sonar-pro via `/v1/chat/completions`           |
| `web-search/example-web-search-anthropic.swift` | C2   | Anthropic native `web_search_20250305` via `/v1/messages` |
| `web-search/example-web-search-openai.swift`    | C3   | OpenAI native `web_search` via `/v1/responses`            |

## Exa direct search

```
POST {TOOLKIT_URL}/v2/exa/search
Authorization: Bearer <EXPO_PUBLIC_RORK_TOOLKIT_SECRET_KEY>
Content-Type: application/json
```

Request body:

```json
{
  "query": "<user query>",
  "type": "auto",
  "numResults": 5,
  "contents": { "highlights": true }
}
```

Use `contents.highlights` for token-efficient source snippets, `contents.text`
for full markdown page text, and `includeDomains`, `excludeDomains`,
`startPublishedDate`, or `category` when the app needs constrained search.
Do not pass `stream: true`; Exa proxy billing uses JSON `costDollars.total`.

## C1. Perplexity sonar-pro (default)

`perplexity/sonar-pro` and `perplexity/sonar` search the web natively and return a single text response.

```
POST {TOOLKIT_URL}/v2/vercel/v1/chat/completions
Authorization: Bearer <EXPO_PUBLIC_RORK_TOOLKIT_SECRET_KEY>
Content-Type: application/json
```

Request body:

```json
{
  "model": "perplexity/sonar-pro",
  "messages": [
    {
      "role": "system",
      "content": "You are a web search assistant. For every claim, include the full source URL inline in parentheses. Do NOT use [1][2] citation markers — always write the full https:// URL."
    },
    { "role": "user", "content": "<user query>" }
  ]
}
```

The assistant reply appears at `choices[0].message.content`.

### Citations and URLs

The Vercel OpenAI-compatible endpoint does **not** return a separate `citations` array — only the assistant's text comes back. By default Perplexity writes `[1]` `[2]` markers into the text with no URL mapping.

To get clickable URLs in the final answer, **instruct the model via a system message** to write full URLs inline instead of `[n]` markers (see the body above). This is reliable: Perplexity will embed `https://...` links directly in the response text.

### Optional: domain / recency filters

Pass Perplexity-specific fields alongside `model` and `messages`:

```json
{
  "model": "perplexity/sonar-pro",
  "messages": [
    /* ... */
  ],
  "search_recency_filter": "week",
  "search_domain_filter": ["techcrunch.com", "theverge.com"]
}
```

| Field                   | Values                                               |
| ----------------------- | ---------------------------------------------------- |
| `search_recency_filter` | `"day"` \| `"week"` \| `"month"` \| `"year"`         |
| `search_domain_filter`  | up to 20 domains (prefix `-` to exclude)             |
| `web_search_options`    | `{ "search_context_size": "low"\|"medium"\|"high" }` |

### Model choice

| Model                  | Notes                                            |
| ---------------------- | ------------------------------------------------ |
| `perplexity/sonar-pro` | Higher quality, slower, more expensive.          |
| `perplexity/sonar`     | Faster and cheaper. Same request/response shape. |

## C2. Anthropic native `web_search_20250305`

Anthropic's first-party web search runs through the Anthropic Messages API surface. The gateway proxies `/v1/messages` verbatim, so the tool spec is the same as the Anthropic docs.

```
POST {TOOLKIT_URL}/v2/vercel/v1/messages
Authorization: Bearer <EXPO_PUBLIC_RORK_TOOLKIT_SECRET_KEY>
Content-Type: application/json
anthropic-version: 2023-06-01
```

Request body — the `system` field carries the inline-URL instruction:

```json
{
  "model": "anthropic/claude-haiku-4.5",
  "max_tokens": 1024,
  "system": "You are a web search assistant. For every claim, write the full source URL inline in parentheses. Do NOT use [1][2] citation markers — always write the full https:// URL.",
  "tools": [{ "type": "web_search_20250305", "name": "web_search", "max_uses": 3 }],
  "messages": [{ "role": "user", "content": "<user query>" }]
}
```

The response `content[]` array is heterogeneous. **Through the Vercel Gateway, only `text` and `tool_use` blocks are emitted** — verified live (May 2026):

| Block `type` | What it carries                                                                        |
| ------------ | -------------------------------------------------------------------------------------- |
| `text`       | Assistant prose. The system prompt makes Claude embed full URLs directly in this text. |
| `tool_use`   | Server-side bookkeeping for the search invocation (`input.query`). Safe to ignore.     |

> **Don't rely on `text[].citations[].url`.** Through the gateway, citations are
> `char_location` shaped: they include `document_title` but no `url`. The
> documented `web_search_tool_result` blocks are not surfaced. Treat the joined
> `text[].text` as the canonical user-facing string and let the system-prompt
> URLs do the citation work.

See `example-web-search-anthropic.swift` for the full decode.

### Optional: tool configuration

Pass these next to `type` and `name` in the tool spec:

| Field             | Description                                                              |
| ----------------- | ------------------------------------------------------------------------ |
| `max_uses`        | Cap how many search calls the model may make in this conversation.       |
| `allowed_domains` | Restrict search to this allowlist (`["techcrunch.com", "wired.com"]`).   |
| `blocked_domains` | Skip these domains (`["example-spam-site.com"]`). Cannot mix with allow. |
| `user_location`   | `{ type: "approximate", country, region, city, timezone }` for locality. |

## C3. OpenAI native `web_search`

OpenAI's first-party web search runs through the Responses API surface (`/v1/responses`), which is the modern OpenAI alternative to chat completions. The gateway proxies it verbatim.

```
POST {TOOLKIT_URL}/v2/vercel/v1/responses
Authorization: Bearer <EXPO_PUBLIC_RORK_TOOLKIT_SECRET_KEY>
Content-Type: application/json
```

Request body — the `instructions` field carries the inline-URL prompt:

```json
{
  "model": "openai/gpt-5.4-mini",
  "instructions": "You are a web search assistant. For every claim, write the full source URL inline in parentheses. Do NOT use [1][2] citation markers — always write the full https:// URL.",
  "input": "<user query>",
  "tools": [{ "type": "web_search" }]
}
```

Two response-shape gotchas through the Vercel Gateway (verified live, May 2026):

> **Top-level `output_text` is null.** Walk `output[]` for items where
> `type == "message"`, then read `content[].text` where the inner type is
> `output_text`.

> **`annotations[]` comes back empty.** The `url_citation` entries OpenAI's
> Responses API documents are not surfaced through the gateway. The
> `instructions` prompt above is what makes URLs appear inline.

| `output[].type`   | Notes                                                                       |
| ----------------- | --------------------------------------------------------------------------- |
| `web_search_call` | Marker that the model performed a search. Safe to ignore for display.       |
| `message`         | Assistant reply. Walk `content[]` for `output_text` parts and join `.text`. |

See `example-web-search-openai.swift` for the full decode.

### Optional: search options

Pass alongside `type` in the tool spec:

| Field                 | Values                                        |
| --------------------- | --------------------------------------------- |
| `search_context_size` | `"low"` \| `"medium"` \| `"high"`             |
| `user_location`       | `{ type: "approximate", country, city, ... }` |

## Error Handling

See `error-handling/swift.md` for the `sendWithRetry` wrapper and Swift-specific error mapping. The HTTP status code matrix lives in `error-handling/api.md`.
