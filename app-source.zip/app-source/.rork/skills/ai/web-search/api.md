# Web Search

Real-time web results via the Rork proxy. Seven concrete paths are available — pick by platform, model family, and whether the app needs structured search data or a natural-language answer. Every path bills via the existing toolkit middleware.

| Path | Platform       | Endpoint               | Tool / model                                          | Notes                                                                                           |
| ---- | -------------- | ---------------------- | ----------------------------------------------------- | ----------------------------------------------------------------------------------------------- |
| Exa  | TS / RN, Swift | `/v2/exa/search`       | Exa direct search                                     | Best for raw results, highlights, page text, dates, domain filters, and app-rendered citations. |
| A    | TS / RN        | AI SDK gateway         | OpenAI-family model + `openai.tools.webSearch({})`    | One call returns both `result.text` (synthesised) and `result.sources`.                         |
| B    | TS / RN        | AI SDK gateway         | Any model + `gateway.tools.perplexitySearch()`        | Model-agnostic (Claude, Gemini, Llama, …). Needs a second `generateText` to synthesise.         |
| C    | TS / RN        | AI SDK gateway         | Claude model + `anthropic.tools.webSearch_20250305()` | One call returns `result.text` and structured `result.sources`. Same UX as path A.              |
| C1   | Swift          | `/v1/chat/completions` | `perplexity/sonar-pro` (no tool plumbing)             | **Default Swift path.** Cheapest, single call, inline URLs via system prompt.                   |
| C2   | Swift          | `/v1/messages`         | Anthropic `web_search_20250305` tool                  | Use when the surrounding feature already speaks Claude / wants Anthropic prose.                 |
| C3   | Swift          | `/v1/responses`        | OpenAI native `web_search` tool                       | Use when the surrounding feature already speaks GPT / wants OpenAI grounding.                   |

> **TS / RN paths require `ai@^6` and `@ai-sdk/{anthropic,openai,gateway}@^3`.** Older 2.x adapters (`ai@5` + `@ai-sdk/gateway@2`) send provider-defined tools in a shape the current Vercel Gateway rejects with HTTP 400 (`tools[0].type expected "function" | "provider"`). The Rork monorepo catalog already pins these — keep new packages on the catalog versions.

**Don't mix tool shapes across endpoints.** The gateway forwards each provider's native tool spec verbatim, so the spec only works on the matching compatible endpoint. `anthropic.tools.webSearch_*` only on `/v1/messages`; OpenAI's `{type:"web_search"}` only on `/v1/responses`; Perplexity / Parallel `gateway.tools.*` only via the AI SDK gateway baseURL. `vertex.tools.googleSearch` and `gateway.tools.parallelSearch` are untested through this proxy — avoid until verified.

**Swift paths: citations / sources are unreliable through the gateway** (verified live, May 2026): the Anthropic Messages surface drops `web_search_tool_result` blocks and returns citations as `char_location` (no `url`); the OpenAI Responses surface returns `annotations[]` empty and leaves top-level `output_text` null; the Perplexity OpenAI-compat surface drops the standalone `citations[]` array. Every Swift path uses the same workaround — instruct the model to write full URLs inline, then read the joined assistant text. The TS / RN AI SDK paths (A / B / C) do **not** have this issue — `result.sources` is populated normally.

Use Exa when the app needs to render sources, snippets, dates, company/people/news filters, or clean page text directly. If the app only needs a short answered summary and already uses OpenAI or Anthropic, prefer the provider-native web search path for that model.

Do not set `stream: true` for Exa proxy calls; the Rork proxy bills Exa from the JSON `costDollars.total` field. The Exa proxy also exposes `POST /v2/exa/contents` for fetching contents from known URLs or Exa result IDs, and `POST /v2/exa/answer` for Exa-generated answers with citations. Use `/search` first when discovering URLs, `/contents` when the app already has URLs, and `/answer` when Exa should synthesize the answer instead of the selected language model.

Exa publishes an official JS/TS SDK (`exa-js`) for server-side or direct Exa integrations. Generated apps should still call the Rork proxy with `fetch` or `URLSession` so the server-side Exa key, balance checks, rate limits, and `costDollars.total` billing path are used. I did not find an official Swift SDK in Exa's current SDK or integrations docs, so Swift apps should use `URLSession`.

For the platform implementation see `web-search/swift.md` (Exa / C1 / C2 / C3) or `web-search/react-native.md` (Exa / A / B / C).

Use **`generateText`** (not `streamText`) for paths A / B / C. Web search is a single-turn fetch + synthesise flow; there is nothing incremental worth streaming token-by-token. Swift paths post non-streaming JSON for the same reason.

<references>
| Topic                  | URL                                                                              |
| ---------------------- | -------------------------------------------------------------------------------- |
| Exa Search             | https://exa.ai/docs/reference/search-api-guide-for-coding-agents                 |
| Exa Contents           | https://exa.ai/docs/reference/contents-api-guide-for-coding-agents               |
| Exa JS/TS SDK          | https://exa.ai/docs/sdks/typescript-sdk-specification                            |
| Exa Integrations       | https://exa.ai/integrations                                                      |
| Web Search overview    | https://vercel.com/docs/ai-gateway/capabilities/web-search                       |
| Anthropic Messages API | https://vercel.com/docs/ai-gateway/sdks-and-apis/anthropic-messages-api/advanced |
| OpenAI Responses API   | https://vercel.com/docs/ai-gateway/sdks-and-apis/responses                       |
| Perplexity Search      | https://docs.perplexity.ai/guides/search-quickstart                              |
| `generateText`         | https://ai-sdk.dev/docs/reference/ai-sdk-core/generate-text                      |

Always fetch the Vercel Web Search page before implementing — the available tools and parameters evolve.
</references>

## Error handling

See `error-handling/api.md` for the platform-agnostic HTTP status codes, retry strategy, idempotency keys, and `Retry-After` rules. Platform-specific request/retry wiring is in `error-handling/swift.md` or `error-handling/react-native.md`.
