// @ts-nocheck
// Usage:
//   bun example-model-fallbacks.ts <TOOLKIT_URL> <SECRET_KEY> text
//   bun example-model-fallbacks.ts <TOOLKIT_URL> <SECRET_KEY> image
//   bun example-model-fallbacks.ts <TOOLKIT_URL> <SECRET_KEY> video

import {
  createGateway,
  experimental_generateImage as generateImage,
  experimental_generateVideo as generateVideo,
} from "ai";
import { streamText } from "ai";

const toolkitURL = process.argv[2];
const secretKey = process.argv[3];
const mode = process.argv[4] ?? "text";

if (!toolkitURL || !secretKey || !["text", "image", "video"].includes(mode)) {
  console.log(
    "Usage: bun example-model-fallbacks.ts <TOOLKIT_URL> <SECRET_KEY> <text|image|video>",
  );
  process.exit(1);
}

const gateway = createGateway({
  baseURL: `${toolkitURL}/v2/vercel/v3/ai`,
  apiKey: secretKey,
});

if (mode === "text") {
  const result = streamText({
    model: gateway("openai/gpt-5.4-mini"),
    prompt: "Reply with exactly: ok",
    providerOptions: {
      gateway: {
        models: ["anthropic/claude-haiku-4.5", "google/gemini-3.1-flash-lite-preview"],
      },
    },
  });

  for await (const chunk of result.textStream) {
    process.stdout.write(chunk);
  }
  process.stdout.write("\n");
}

if (mode === "image") {
  const result = await generateImage({
    model: gateway.imageModel("openai/gpt-image-2"),
    prompt: "A tiny red dot on a white background",
    size: "1024x1024",
    providerOptions: {
      gateway: {
        models: ["openai/gpt-image-1-mini"],
      },
    },
  });

  console.log({
    imageCount: result.images.length,
    firstImageMediaType: result.images[0]?.mediaType,
    firstImageBase64Length: result.images[0]?.base64.length,
    gateway: result.providerMetadata?.gateway,
  });
}

if (mode === "video") {
  const result = await generateVideo({
    model: gateway.videoModel("xai/grok-imagine-video"),
    prompt: "A short abstract white screen with a small red dot",
    providerOptions: {
      gateway: {
        models: ["google/veo-3.1-fast-generate-001"],
      },
    },
  });

  console.log({
    videoCount: result.videos.length,
    firstVideoMediaType: result.videos[0]?.mediaType,
    firstVideoBytes: result.videos[0]?.uint8Array.byteLength,
    gateway: result.providerMetadata?.gateway,
  });
}
