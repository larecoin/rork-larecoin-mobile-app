# Live model discovery

Treat remembered model IDs as stale. Before writing any model ID, including fallbacks, refresh the Vercel catalog:

```sh
catalog_dir="$(mktemp -d /tmp/rork-models.XXXXXX)"
curl -fsS https://ai-gateway.vercel.sh/v1/models -o "$catalog_dir/vercel-models.json.tmp"
jq -e '.data | type == "array"' "$catalog_dir/vercel-models.json.tmp" >/dev/null
mv "$catalog_dir/vercel-models.json.tmp" "$catalog_dir/vercel-models.json"
```

Keep using this run's `$catalog_dir`. Filter with `jq` or `rg`; never print the whole catalog.

## Selection flow

1. Filter `.data` by `owned_by`, `type`, `tags`, or `modalities`, then sort for the task.
2. When cost or capability tradeoffs are material, present the candidate and alternatives before implementation. Do not pause for an explicit or obvious choice.
3. Fetch the chosen model's endpoint metadata:

   ```sh
   model_id='provider/model'
   curl -fsS "https://ai-gateway.vercel.sh/v1/models/$model_id/endpoints" \
     -o "$catalog_dir/vercel-model-endpoints.json.tmp"
   jq -e '.data.endpoints | type == "array"' "$catalog_dir/vercel-model-endpoints.json.tmp" >/dev/null
   mv "$catalog_dir/vercel-model-endpoints.json.tmp" "$catalog_dir/vercel-model-endpoints.json"
   jq '.data' "$catalog_dir/vercel-model-endpoints.json"
   ```

4. Treat the endpoint response as authoritative for modalities, limits, parameters, pricing, provider options, and request shape. If it is missing, choose again instead of guessing.
5. Report the selected model ID and reason in the final summary.

For image generation, match the `image-generation` tag or an `image` output modality, then route by `type`: language models use chat completions; image models use `/v3/ai/image-model`. Video models use `/v3/ai/video-model`, embeddings use `/v1/embeddings`, and other language models use `/v1/chat/completions`.
