// Example: Reference-to-video generation via Rork proxy
//
// Usage: swift example-reference-to-video.swift <TOOLKIT_URL> <SECRET_KEY> <REF_URL_1> [REF_URL_2...] [--prompt "..."]
//
// Generates a NEW scene featuring characters from reference images/videos.
// Distinct from image-to-video: the reference images tell the model what
// characters look like; the prompt describes a completely new scene.
// Provider: Alibaba Wan r2v (URL-only inputs, no buffer/base64). Upload local
// files to R2 / Vercel Blob first and pass the public URLs.
// The response is SSE.

import Foundation

guard CommandLine.arguments.count >= 4 else {
    print("Usage: swift example-reference-to-video.swift <TOOLKIT_URL> <SECRET_KEY> <REF_URL_1> [REF_URL_2...] [--prompt \"...\"]")
    exit(1)
}

let toolkitURL = CommandLine.arguments[1]
let secretKey = CommandLine.arguments[2]

// Parse remaining args — treat everything after `--prompt` as the prompt text,
// everything before it as reference URLs (up to 5 total per Wan docs).
let rest = Array(CommandLine.arguments.dropFirst(3))
let promptFlagIndex = rest.firstIndex(of: "--prompt")
let referenceUrls = Array(rest.prefix(promptFlagIndex ?? rest.count))
let prompt: String
if let idx = promptFlagIndex, idx + 1 < rest.count {
    prompt = rest[idx + 1]
} else {
    prompt = "character1 and character2 have a friendly conversation in a cozy cafe"
}

guard !referenceUrls.isEmpty, referenceUrls.count <= 5 else {
    print("Need 1–5 reference URLs (images and/or videos) before --prompt.")
    exit(1)
}

let vercelV3URL = "\(toolkitURL)/v2/vercel/v3/ai"

// --- Error type ---

enum R2VError: LocalizedError {
    case authError
    case insufficientBalance
    case rateLimited
    case serverError(Int)
    case parsingFailed
    case generationFailed(String)
    case noVideoReturned

    var errorDescription: String? {
        switch self {
        case .authError:                 "AI features are currently unavailable. Please restart the app."
        case .insufficientBalance:       "AI features are temporarily unavailable. Please try again later."
        case .rateLimited:               "Too many requests. Please wait a moment and try again."
        case .serverError:               "Something went wrong. Please try again."
        case .parsingFailed:             "Couldn't process the video response. Please try again."
        case .generationFailed(let msg): "Video generation failed: \(msg)"
        case .noVideoReturned:           "No video was returned. Please try again."
        }
    }
}

// --- Response type ---
//
// Vercel AI Gateway returns the generated video as either a hosted URL
// (most providers) or an inline base64 payload (e.g. Google Veo). Decode
// both shapes — clients that only read `.url` silently fail on Veo with
// `noVideoReturned`, even though the upstream generation succeeded.
struct VideoSSEResponse: Codable {
    let type: String?
    let videos: [VideoItem]?
    let message: String?
    struct VideoItem: Codable {
        let type: String?
        let url: String?
        // The gateway sometimes emits inline base64 under `data` and sometimes
        // under `base64` depending on the upstream provider — accept both.
        let data: String?
        let base64: String?
        let mediaType: String?
    }
}

func decodedBase64Data(from value: String) -> Data? {
    let trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines)
    let raw: String
    if let comma = trimmed.firstIndex(of: ",") {
        raw = String(trimmed[trimmed.index(after: comma)...])
    } else {
        raw = trimmed
    }
    return Data(base64Encoded: raw)
}

// --- Request ---
//
// Wan r2v takes references via `providerOptions.alibaba.referenceUrls`. The
// model substitutes `character1`, `character2`, ... in the prompt with the
// corresponding reference in order (up to 5 total, max 5 images + 3 videos).

let model = "alibaba/wan-v2.6-r2v"

let body: [String: Any] = [
    "model": model,
    "prompt": prompt,
    "resolution": "1280x720",
    "duration": 4,
    "providerOptions": [
        "alibaba": [
            "referenceUrls": referenceUrls,
            "shotType": "single",
            // Generation often takes 5–10 min for Wan. Nudge the gateway's poll
            // window up to match; Swift's URLSession timeout below is the
            // outer bound.
            "pollTimeoutMs": 1_200_000,
        ]
    ]
]

var request = URLRequest(url: URL(string: "\(vercelV3URL)/video-model")!)
request.httpMethod = "POST"
request.setValue("application/json", forHTTPHeaderField: "Content-Type")
request.setValue("Bearer \(secretKey)", forHTTPHeaderField: "Authorization")
request.setValue("0.0.1", forHTTPHeaderField: "ai-gateway-protocol-version")
request.setValue("4", forHTTPHeaderField: "ai-video-model-specification-version")
request.setValue(model, forHTTPHeaderField: "ai-model-id")
request.setValue("text/event-stream", forHTTPHeaderField: "accept")
request.httpBody = try JSONSerialization.data(withJSONObject: body)
// Video generation can take ≥10 min. The gateway holds the connection open
// until the video is ready, so the URLSession timeout needs to exceed the
// upstream poll timeout or the request will be killed mid-flight.
request.timeoutInterval = 1_500

print("Generating reference-to-video with \(model) (\(referenceUrls.count) references)...")

let (data, response) = try await URLSession.shared.data(for: request)
let httpResponse = response as! HTTPURLResponse

switch httpResponse.statusCode {
case 200:  break
case 401:  throw R2VError.authError
case 402:  throw R2VError.insufficientBalance
case 429:  throw R2VError.rateLimited
default:   throw R2VError.serverError(httpResponse.statusCode)
}

// Parse SSE — extract the last valid JSON event.
let text = String(data: data, encoding: .utf8) ?? ""
var lastJSON: String?
for line in text.components(separatedBy: "\n") {
    let trimmed = line.trimmingCharacters(in: .whitespaces)
    if trimmed.hasPrefix("data: ") {
        let json = String(trimmed.dropFirst(6))
        if !json.isEmpty, json != "[DONE]" {
            lastJSON = json
        }
    }
}

guard let jsonString = lastJSON, let jsonData = jsonString.data(using: .utf8) else {
    throw R2VError.parsingFailed
}

let result = try JSONDecoder().decode(VideoSSEResponse.self, from: jsonData)

if result.type == "error" {
    throw R2VError.generationFailed(result.message ?? "Unknown error")
}

guard let video = result.videos?.first else {
    throw R2VError.noVideoReturned
}

if let videoURL = video.url {
    print("Video URL: \(videoURL)")
} else if let encoded = video.data ?? video.base64, let bytes = decodedBase64Data(from: encoded) {
    // Providers such as Google Veo return the video inline as base64
    // instead of a hosted URL. Write the bytes to a temp file so the
    // caller has a path to play, upload, or copy into the app sandbox.
    let ext = video.mediaType?.split(separator: "/").last.map(String.init) ?? "mp4"
    let outputURL = URL(fileURLWithPath: NSTemporaryDirectory())
        .appendingPathComponent("video-\(UUID().uuidString).\(ext)")
    try bytes.write(to: outputURL)
    print("Video file: \(outputURL.path) (\(bytes.count) bytes)")
} else {
    throw R2VError.noVideoReturned
}
