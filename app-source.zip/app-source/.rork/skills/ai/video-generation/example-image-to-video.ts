// @ts-nocheck
// Example: Image-to-video via AI SDK experimental_generateVideo
//
// Usage: bun example-image-to-video.ts <TOOLKIT_URL> <SECRET_KEY> <IMAGE_PATH> [PROMPT]
//
// All i2v models (Veo, Kling, Wan, Grok, Seedance) use the object-form prompt:
//   `prompt: { image: string | Buffer, text }`
// where `image` is a URL string (Wan / Seedance / xAI only support URLs) or
// a `Buffer` (Kling / Veo accept base64 buffers).
// Saves the result as output.mp4 in the current directory.

import { createGateway } from "ai";
import { experimental_generateVideo as generateVideo } from "ai";

const toolkitURL = process.argv[2];
const secretKey = process.argv[3];
const imagePath = process.argv[4];
const prompt = process.argv[5] ?? "The scene comes to life with gentle wind";

if (!toolkitURL || !secretKey || !imagePath) {
  console.log("Usage: bun example-image-to-video.ts <TOOLKIT_URL> <SECRET_KEY> <IMAGE_PATH> [PROMPT]");
  process.exit(1);
}

const gateway = createGateway({
  baseURL: `${toolkitURL}/v2/vercel/v3/ai`,
  apiKey: secretKey,
});

// KlingAI docs explicitly require raw base64 (no `data:` prefix). Normalise
// unconditionally — safe for all providers.
const stripDataUriPrefix = (b64: string): string => {
  if (!b64.startsWith("data:")) return b64;
  const comma = b64.indexOf(",");
  return comma === -1 ? b64 : b64.slice(comma + 1);
};

// Read + resize in production. For base64 / buffer requests, budget for the
// Vercel 4.5 MB request-body limit, not only the provider limit. See
// `image-input-requirements.md`.
const imageBytes = await Bun.file(imagePath).arrayBuffer();
const imageBuffer = Buffer.from(stripDataUriPrefix(Buffer.from(imageBytes).toString("base64")), "base64");

// Video generation can take 30 s – 5 min. The AI SDK providers poll internally
// and honour `pollTimeoutMs` in providerOptions.
const result = await generateVideo({
  model: gateway.videoModel("klingai/kling-v3.0-i2v"),
  prompt: {
    text: prompt,
    image: imageBuffer, // Kling / Veo accept Buffer. For Wan/Seedance/xAI pass a URL string instead.
  },
  // KlingAI i2v output dimensions follow the input image — aspectRatio is
  // not accepted. For text-to-video (no input image), aspectRatio is honoured.
  duration: 5,
  providerOptions: {
    klingai: { mode: "std", pollTimeoutMs: 600_000 },
  },
});

const first = result.videos[0];
if (!first) {
  console.error("No video returned");
  process.exit(1);
}
await Bun.write("output.mp4", first.uint8Array);
console.log(`Video saved to: output.mp4 (${first.uint8Array.byteLength} bytes)`);
