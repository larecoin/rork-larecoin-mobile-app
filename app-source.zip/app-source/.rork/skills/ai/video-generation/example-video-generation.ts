// @ts-nocheck
// Example: Text-to-video via AI SDK experimental_generateVideo
//
// Usage: bun example-video-generation.ts <TOOLKIT_URL> <SECRET_KEY> [PROMPT]
//
// Pure text-to-video with no input image. For image-to-video / motion control
// / reference-to-video / video editing see the dedicated samples.
//
// Video generation takes 30 s – 5 min. AI SDK polls the gateway internally;
// adjust `providerOptions.<provider>.pollTimeoutMs` if your model is slower.

import { createGateway } from "ai";
import { experimental_generateVideo as generateVideo } from "ai";

const toolkitURL = process.argv[2];
const secretKey = process.argv[3];
const prompt = process.argv[4] ?? "A cat walking on a treadmill in slow motion";

if (!toolkitURL || !secretKey) {
  console.log("Usage: bun example-video-generation.ts <TOOLKIT_URL> <SECRET_KEY> [PROMPT]");
  process.exit(1);
}

const gateway = createGateway({
  baseURL: `${toolkitURL}/v2/vercel/v3/ai`,
  apiKey: secretKey,
});

const result = await generateVideo({
  model: gateway.videoModel("bytedance/seedance-2.0-fast"),
  prompt,
  aspectRatio: "16:9",
  duration: 5,
  providerOptions: {
    bytedance: {
      pollTimeoutMs: 600_000,
    },
  },
});

const first = result.videos[0];
if (!first) {
  console.error("No video returned");
  process.exit(1);
}
await Bun.write("output.mp4", first.uint8Array);
console.log(`Video saved to: output.mp4 (${first.uint8Array.byteLength} bytes)`);
