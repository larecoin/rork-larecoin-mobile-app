// @ts-nocheck
// Example: Reference-to-video via AI SDK experimental_generateVideo (Alibaba Wan r2v)
//
// Usage: bun example-reference-to-video.ts <TOOLKIT_URL> <SECRET_KEY> <REF_URL_1> [REF_URL_2...] [--prompt "..."]
//
// Generates a NEW scene featuring characters from reference images/videos.
// Distinct from image-to-video: references only tell the model what the
// characters look like; the prompt describes a brand-new scene using
// `character1`, `character2`, ... to refer to each reference in order.
//
// Inputs are URLs only (no buffers). Upload local files to Vercel Blob / R2
// first and pass the public URLs. Up to 5 references total (max 5 images + 3 videos).

import { createGateway } from "ai";
import { experimental_generateVideo as generateVideo } from "ai";

const toolkitURL = process.argv[2];
const secretKey = process.argv[3];

if (!toolkitURL || !secretKey) {
  console.log("Usage: bun example-reference-to-video.ts <TOOLKIT_URL> <SECRET_KEY> <REF_URL_1> [REF_URL_2...] [--prompt \"...\"]");
  process.exit(1);
}

// Parse remaining args: URLs up to `--prompt`, then prompt text.
const rest = process.argv.slice(4);
const promptFlagIdx = rest.indexOf("--prompt");
const referenceUrls = promptFlagIdx === -1 ? rest : rest.slice(0, promptFlagIdx);
const prompt =
  promptFlagIdx !== -1 && rest[promptFlagIdx + 1]
    ? rest[promptFlagIdx + 1]
    : "character1 and character2 have a friendly conversation in a cozy cafe";

if (referenceUrls.length === 0 || referenceUrls.length > 5) {
  console.log("Need 1–5 reference URLs (images and/or videos) before --prompt.");
  process.exit(1);
}

const gateway = createGateway({
  baseURL: `${toolkitURL}/v2/vercel/v3/ai`,
  apiKey: secretKey,
});

// Reference-to-video is slow — default pollTimeoutMs is 10 min. Push it to
// 20 min for headroom; AI SDK polls internally, so the caller doesn't need
// to manage any HTTP-level timeout beyond what fetch provides.
const result = await generateVideo({
  model: gateway.videoModel("alibaba/wan-v2.6-r2v"),
  prompt,
  resolution: "1280x720",
  duration: 4,
  providerOptions: {
    alibaba: {
      referenceUrls,
      shotType: "single",
      pollTimeoutMs: 1_200_000,
    },
  },
});

const first = result.videos[0];
if (!first) {
  console.error("No video returned");
  process.exit(1);
}
await Bun.write("output.mp4", first.uint8Array);
console.log(`Video saved to: output.mp4 (${first.uint8Array.byteLength} bytes)`);
