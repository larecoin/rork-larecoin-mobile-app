// Example: Image-to-video generation via Rork proxy
//
// Usage: swift example-image-to-video.swift <TOOLKIT_URL> <SECRET_KEY> <MODEL> <IMAGE> [PROMPT]
//
// Animates an input image using i2v (image-to-video) models. The IMAGE arg is
// auto-detected and wrapped in the matching gateway envelope so the same
// script works across providers regardless of their `supported_sources`:
//
//   • https://… or http://…              → { "type": "url",  "url":  "…" }
//   • data:image/jpeg;base64,…           → { "type": "file", "data": <raw base64>, "mediaType": "…" }
//   • a base64 string (≥ 256 chars)      → { "type": "file", "data": <raw base64>, "mediaType": "image/jpeg" }
//   • a local file path                  → resize against a byte budget, then file envelope
//
// Always confirm the chosen shape against the model's
// `capabilities.input_limits.image.supported_sources` in the endpoint metadata.
// Sending the wrong envelope returns 400 — there is no provider hardcoding in
// this script on purpose; the model arg drives the request.
//
// The response is SSE — uses line-by-line parsing with a defensive scan for
// the last `videos`-bearing event (some providers emit a trailing finish
// event that would break a "take the last data: line" parser).

import Foundation
import ImageIO
import UniformTypeIdentifiers

guard CommandLine.arguments.count >= 5 else {
    print("Usage: swift example-image-to-video.swift <TOOLKIT_URL> <SECRET_KEY> <MODEL> <IMAGE> [PROMPT]")
    print("  IMAGE: https URL, data: URI, raw base64, or a local file path")
    exit(1)
}

let toolkitURL = CommandLine.arguments[1]
let secretKey = CommandLine.arguments[2]
let model = CommandLine.arguments[3]
let imageArg = CommandLine.arguments[4]
let prompt = CommandLine.arguments.count >= 6 ? CommandLine.arguments[5] : "The scene comes to life with gentle wind"
let vercelV3URL = "\(toolkitURL)/v2/vercel/v3/ai"

// --- Error type ---

enum I2VError: LocalizedError {
    case fileNotFound
    case imageProcessingFailed
    case authError
    case insufficientBalance
    case payloadTooLarge
    case rateLimited
    case serverError(Int)
    case parsingFailed
    case generationFailed(String)
    case noVideoReturned

    var errorDescription: String? {
        switch self {
        case .fileNotFound:              "Image file not found."
        case .imageProcessingFailed:     "Couldn't prepare the image. Please try a different photo."
        case .authError:                 "AI features are currently unavailable. Please restart the app."
        case .insufficientBalance:       "AI features are temporarily unavailable. Please try again later."
        case .payloadTooLarge:           "Image is too large. Please try a smaller photo."
        case .rateLimited:               "Too many requests. Please wait a moment and try again."
        case .serverError:               "Something went wrong. Please try again."
        case .parsingFailed:             "Couldn't process the video response. Please try again."
        case .generationFailed(let msg): "Video generation failed: \(msg)"
        case .noVideoReturned:           "No video was returned. Please try again."
        }
    }
}

// --- Response type ---
//
// Vercel AI Gateway returns the generated video as either a hosted URL
// (most providers) or an inline base64 payload (e.g. Google Veo). Decode
// both shapes — clients that only read `.url` silently fail on Veo with
// `noVideoReturned`, even though the upstream generation succeeded.
struct VideoSSEResponse: Codable {
    let type: String?
    let videos: [VideoItem]?
    let message: String?
    struct VideoItem: Codable {
        let type: String?
        let url: String?
        // The gateway sometimes emits inline base64 under `data` and sometimes
        // under `base64` depending on the upstream provider — accept both.
        let data: String?
        let base64: String?
        let mediaType: String?
    }
}

// Decode an inline video payload, tolerating a leading `data:video/...;base64,`
// header — the gateway occasionally forwards Veo / Bytedance bodies with the
// header still attached.
func decodedBase64Data(from value: String) -> Data? {
    let trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines)
    let raw: String
    if let comma = trimmed.firstIndex(of: ",") {
        raw = String(trimmed[trimmed.index(after: comma)...])
    } else {
        raw = trimmed
    }
    return Data(base64Encoded: raw)
}

// --- Base64 prefix helper ---
//
// Strip a `data:image/...;base64,` prefix and surface the embedded media type
// when present. Why: providers like KlingAI and FLUX Kontext require raw
// base64 and reject data URIs; others (Gemini, OpenAI) accept either. Always
// normalising to raw base64 + an explicit `mediaType` field is safe.
func stripDataUriPrefix(_ input: String) -> (raw: String, mediaType: String?) {
    guard input.hasPrefix("data:"), let comma = input.firstIndex(of: ",") else {
        return (input, nil)
    }
    let header = input[input.index(input.startIndex, offsetBy: 5)..<comma]
    let semicolon = header.firstIndex(of: ";") ?? header.endIndex
    let mediaType = String(header[..<semicolon])
    return (String(input[input.index(after: comma)...]), mediaType.isEmpty ? nil : mediaType)
}

// --- Resize helper (only used for local file paths) ---
//
// Re-encode against a byte budget instead of a fixed pixel cap. For image-input
// requests, the Vercel 4.5 MB request-body limit is often stricter than the
// provider limit.
func resizeImageForUpload(at path: String, maxBytes: Int = 3_000_000) throws -> (data: Data, mimeType: String) {
    let url = URL(fileURLWithPath: path)
    guard let source = CGImageSourceCreateWithURL(url as CFURL, nil) else {
        throw I2VError.fileNotFound
    }

    let ladder: [(maxPixelSize: Int, quality: Double)] = [
        (1280, 0.82),
        (1024, 0.78),
        (832, 0.74),
        (640, 0.70),
        (512, 0.65),
    ]

    func encode(maxPixelSize: Int, quality: Double) throws -> Data {
        let options: [CFString: Any] = [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceCreateThumbnailWithTransform: true,
            kCGImageSourceThumbnailMaxPixelSize: maxPixelSize,
        ]
        guard let cgImage = CGImageSourceCreateThumbnailAtIndex(source, 0, options as CFDictionary) else {
            throw I2VError.imageProcessingFailed
        }
        let outputData = NSMutableData()
        guard let destination = CGImageDestinationCreateWithData(
            outputData,
            UTType.jpeg.identifier as CFString,
            1,
            nil
        ) else {
            throw I2VError.imageProcessingFailed
        }
        CGImageDestinationAddImage(
            destination,
            cgImage,
            [kCGImageDestinationLossyCompressionQuality: quality] as CFDictionary
        )
        guard CGImageDestinationFinalize(destination) else {
            throw I2VError.imageProcessingFailed
        }
        return outputData as Data
    }

    for step in ladder {
        let data = try encode(maxPixelSize: step.maxPixelSize, quality: step.quality)
        if data.count <= maxBytes {
            return (data, "image/jpeg")
        }
    }

    throw I2VError.payloadTooLarge
}

// --- Build the `image` field from whatever the caller passed ---
//
// One unified entry point so the script does not assume a specific provider.
// The wire shape is selected from the input format, not from the model ID.
func buildImageField(from arg: String) throws -> [String: Any] {
    if arg.hasPrefix("https://") || arg.hasPrefix("http://") {
        return ["type": "url", "url": arg]
    }
    if arg.hasPrefix("data:") {
        let (raw, mediaType) = stripDataUriPrefix(arg)
        return [
            "type": "file",
            "mediaType": mediaType ?? "image/jpeg",
            "data": raw,
        ]
    }
    // Heuristic: if it doesn't look like a path on disk and is long enough to
    // plausibly be base64-encoded image bytes, treat it as raw base64.
    let looksLikeBase64 = arg.count >= 256 && arg.allSatisfy { c in
        c.isLetter || c.isNumber || c == "+" || c == "/" || c == "="
    }
    if looksLikeBase64, !FileManager.default.fileExists(atPath: arg) {
        return [
            "type": "file",
            "mediaType": "image/jpeg",
            "data": arg,
        ]
    }
    guard FileManager.default.fileExists(atPath: arg) else {
        throw I2VError.fileNotFound
    }
    let (data, mimeType) = try resizeImageForUpload(at: arg)
    return [
        "type": "file",
        "mediaType": mimeType,
        "data": data.base64EncodedString(),
    ]
}

let imageField = try buildImageField(from: imageArg)

// --- Per-model timing budget ---

func pollTimeoutMs(for modelId: String) -> Int {
    if modelId.contains("kling-v3.0") || modelId.contains("seedance-2.0") || modelId.contains("wan-v2.6") {
        return 1_200_000
    }
    return 900_000
}

// --- Provider options dispatch ---
//
// `providerOptions` is keyed by the upstream provider, which equals
// `endpoints[].provider_name` from the endpoint metadata. The only common
// non-obvious case is Google, which routes through Vertex.
func providerOptions(for modelId: String, pollTimeoutMs: Int, withAudio: Bool) -> [String: Any] {
    let baseTiming: [String: Any] = [
        "pollIntervalMs": 5_000,
        "pollTimeoutMs": pollTimeoutMs,
    ]
    if modelId.hasPrefix("google/") {
        var vertex = baseTiming
        vertex["generateAudio"] = withAudio
        vertex["enhancePrompt"] = true
        return ["vertex": vertex]
    }
    if modelId.hasPrefix("klingai/") {
        var klingai = baseTiming
        klingai["mode"] = (modelId.contains("v3.0") || modelId.contains("v2.6")) ? "pro" : "std"
        klingai["sound"] = withAudio ? "on" : "off"
        return ["klingai": klingai]
    }
    if modelId.hasPrefix("bytedance/") {
        var bytedance = baseTiming
        bytedance["generateAudio"] = withAudio
        return ["bytedance": bytedance]
    }
    if modelId.hasPrefix("alibaba/") {
        var alibaba = baseTiming
        alibaba["audio"] = withAudio
        alibaba["watermark"] = false
        return ["alibaba": alibaba]
    }
    if modelId.hasPrefix("xai/") {
        return ["xai": baseTiming]
    }
    return [:]
}

// --- Request ---

let modelPollTimeoutMs = pollTimeoutMs(for: model)

let body: [String: Any] = [
    "model": model,
    "prompt": prompt,
    "image": imageField,
    "duration": 5,
    "providerOptions": providerOptions(for: model, pollTimeoutMs: modelPollTimeoutMs, withAudio: false),
]

var request = URLRequest(url: URL(string: "\(vercelV3URL)/video-model")!)
request.httpMethod = "POST"
request.setValue("application/json", forHTTPHeaderField: "Content-Type")
request.setValue("Bearer \(secretKey)", forHTTPHeaderField: "Authorization")
request.setValue("0.0.1", forHTTPHeaderField: "ai-gateway-protocol-version")
request.setValue("4", forHTTPHeaderField: "ai-video-model-specification-version")
request.setValue(model, forHTTPHeaderField: "ai-model-id")
request.setValue("text/event-stream", forHTTPHeaderField: "accept")
request.httpBody = try JSONSerialization.data(withJSONObject: body)
request.timeoutInterval = TimeInterval((modelPollTimeoutMs / 1000) + 90)

print("Generating video from image with \(model) (\(imageField["type"] ?? "?") envelope)...")

let (data, response) = try await URLSession.shared.data(for: request)
let httpResponse = response as! HTTPURLResponse

switch httpResponse.statusCode {
case 200:  break
case 401:  throw I2VError.authError
case 402:  throw I2VError.insufficientBalance
case 413:  throw I2VError.payloadTooLarge
case 429:  throw I2VError.rateLimited
default:   throw I2VError.serverError(httpResponse.statusCode)
}

// Parse SSE — scan all events and pick the last one carrying `videos`,
// surfacing any `type: "error"` along the way.
//
// Why scan, not "take the last data: line": some providers (e.g. Bytedance
// Seedance) emit a final `finish` / usage event AFTER the result event.
// Reading only the last `data: ...` then throws `noVideoReturned` even
// though the generation succeeded and was billed.
let text = String(data: data, encoding: .utf8) ?? ""
var lastResultJSON: String?
var firstErrorJSON: String?
for line in text.components(separatedBy: "\n") {
    let trimmed = line.trimmingCharacters(in: .whitespaces)
    guard trimmed.hasPrefix("data: ") else { continue }
    let json = String(trimmed.dropFirst(6))
    if json.isEmpty || json == "[DONE]" { continue }
    guard
        let jsonData = json.data(using: .utf8),
        let decoded = try? JSONDecoder().decode(VideoSSEResponse.self, from: jsonData)
    else { continue }
    if decoded.type == "error", firstErrorJSON == nil {
        firstErrorJSON = json
    }
    if decoded.videos?.isEmpty == false {
        lastResultJSON = json
    }
}

if
    let errorJSON = firstErrorJSON,
    let errorData = errorJSON.data(using: .utf8),
    let errorResult = try? JSONDecoder().decode(VideoSSEResponse.self, from: errorData)
{
    throw I2VError.generationFailed(errorResult.message ?? "Unknown error")
}

guard
    let jsonString = lastResultJSON,
    let jsonData = jsonString.data(using: .utf8)
else {
    throw I2VError.parsingFailed
}

let result = try JSONDecoder().decode(VideoSSEResponse.self, from: jsonData)

guard let video = result.videos?.first else {
    throw I2VError.noVideoReturned
}

if let videoURL = video.url {
    print("Video URL: \(videoURL)")
} else if let encoded = video.data ?? video.base64, let bytes = decodedBase64Data(from: encoded) {
    let ext = video.mediaType?.split(separator: "/").last.map(String.init) ?? "mp4"
    let outputURL = URL(fileURLWithPath: NSTemporaryDirectory())
        .appendingPathComponent("video-\(UUID().uuidString).\(ext)")
    try bytes.write(to: outputURL)
    print("Video file: \(outputURL.path) (\(bytes.count) bytes)")
} else {
    throw I2VError.noVideoReturned
}
