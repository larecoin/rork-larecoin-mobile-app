# Video Generation — React Native / TypeScript (AI SDK)

Read `video-generation/api.md` first for the endpoint contract, request body, response shape, and i2v rules. This file covers the Vercel AI SDK implementation (`experimental_generateVideo`).

The Rork proxy is a standard AI Gateway passthrough — the SDK handles the v3 protocol headers automatically, branches on `videos[0].type` for URL vs base64 responses, and exposes the result as `result.videos[0].uint8Array` regardless.

For production failover, read `model-fallbacks.md` and add compatible video-model fallbacks via `providerOptions.gateway.models`. Keep fallbacks on the same operation and request shape: text-to-video with text-to-video, image-to-video with image-to-video, etc.

<references>
| Topic                        | URL                                                                                 |
| ---------------------------- | ----------------------------------------------------------------------------------- |
| `experimental_generateVideo` | https://ai-sdk.dev/docs/reference/ai-sdk-core/generate-video                        |
| Text-to-Video                | https://vercel.com/docs/ai-gateway/capabilities/video-generation/text-to-video      |
| Image-to-Video               | https://vercel.com/docs/ai-gateway/capabilities/video-generation/image-to-video     |
| Reference-to-Video           | https://vercel.com/docs/ai-gateway/capabilities/video-generation/reference-to-video |

</references>

## Setup

```ts
import { createGateway } from "ai";

const TOOLKIT_URL = process.env["EXPO_PUBLIC_TOOLKIT_URL"];
const SECRET_KEY = process.env["EXPO_PUBLIC_RORK_TOOLKIT_SECRET_KEY"];

const gateway = createGateway({
  baseURL: `${TOOLKIT_URL}/v2/vercel/v3/ai`,
  apiKey: SECRET_KEY,
});
```

Use `gateway.videoModel(id)` — **NOT** `gateway(id)`. `gateway(id)` returns a LanguageModel and crashes inside `@ai-sdk/gateway` when handed to `experimental_generateVideo`.

## Text-to-Video

```ts
import { experimental_generateVideo as generateVideo } from "ai";

const result = await generateVideo({
  model: gateway.videoModel("google/veo-3.1-fast-generate-001"),
  prompt: "A cat walking on a treadmill in slow motion",
  aspectRatio: "16:9",
  // Veo only accepts 4, 6, or 8 seconds. Sending any other value (e.g. 5) makes
  // Vertex reject the request with VERTEX_VIDEO_GENERATION_FAILED.
  duration: 8,
});

// result.videos[0].uint8Array — write to disk, upload to R2, etc.
```

## Image-to-Video

Read `image-input-requirements.md` for provider-specific image format, size, and encoding requirements before passing images to i2v models.

For base64 image inputs, resize against a byte budget before uploading and strip any `data:` prefix. Camera-roll photos can exceed the Vercel request-body limit even after a simple fixed resize.

All i2v models use `experimental_generateVideo` with the **object-form prompt** `{ image, text }`. The `image` field accepts either a URL `string` (required for Wan, Seedance, xAI) or a `Buffer` (supported by KlingAI, Veo). Response: `result.videos[0].uint8Array`.

### i2v with base64 (KlingAI, Veo)

```ts
import { experimental_generateVideo as generateVideo } from "ai";
import { Buffer } from "buffer";
import { resizeForUpload } from "./lib/resize-for-upload";

const { base64 } = await resizeForUpload(imageUri);

const result = await generateVideo({
  model: gateway.videoModel("klingai/kling-v3.0-i2v"),
  prompt: {
    text: "The character in the image starts dancing",
    image: Buffer.from(base64, "base64"),
  },
  // KlingAI i2v output dimensions follow the input image — aspectRatio is not
  // accepted for i2v (only for text-to-video).
  duration: 5,
  providerOptions: {
    klingai: { mode: "std", pollTimeoutMs: 600_000 },
  },
});
```

### i2v with URL (Wan, Seedance, xAI)

These providers accept URLs only — upload to R2 / Vercel Blob first, after resizing on-device:

> The Vercel 4.5 MB body limit does not apply here because the request carries only a URL string, not raw image bytes.

```ts
import { experimental_generateVideo as generateVideo } from "ai";
import * as ImageManipulator from "expo-image-manipulator";

const context = ImageManipulator.manipulate(imageUri);
context.resize({ width: 1536 });
const rendered = await context.renderAsync();
const saved = await rendered.saveAsync({
  format: ImageManipulator.SaveFormat.JPEG,
  compress: 0.85,
});
const publicUrl = await uploadToStorage(saved.uri); // R2 / Vercel Blob

const result = await generateVideo({
  model: gateway.videoModel("alibaba/wan-v2.6-i2v"),
  prompt: {
    text: "The scene comes to life with gentle wind",
    image: publicUrl,
  },
  duration: 5,
  providerOptions: {
    alibaba: { audio: true, pollTimeoutMs: 600_000 },
  },
});
```

## Sample Code

| File                                             | Capability         | Description                                |
| ------------------------------------------------ | ------------------ | ------------------------------------------ |
| `video-generation/example-video-generation.ts`   | text-to-video      | Basic text-to-video with AI SDK            |
| `video-generation/example-image-to-video.ts`     | image-to-video     | i2v with AI SDK + resize/strip for KlingAI |
| `video-generation/example-reference-to-video.ts` | reference-to-video | Wan r2v using `referenceUrls`              |

> **Motion control** (`klingai/kling-v2.6-motion-control`) and **video editing** (`xai/grok-imagine-video`) use the same `experimental_generateVideo` pattern — character image buffer plus a `providerOptions.klingai.videoUrl` for motion control, or source `providerOptions.xai.videoUrl` for editing. Set `pollTimeoutMs ≥ 1_500_000` (25 min) for editing in particular.

## Notes

- Video generation can take 30 seconds to several minutes. Set a long timeout (300s+).
- Cost is billed automatically via `providerMetadata.gateway.marketCost`.
- Show a loading state while the video generates and handle timeout errors gracefully. Default `providerOptions.<provider>.pollTimeoutMs` is 10 min (600_000); bump to 20 min (1_200_000) for reference-to-video / motion control, and 25 min (1_500_000) for video editing.

## Error Handling

See `error-handling/react-native.md` for AI SDK error patterns and `error-handling/api.md` for the HTTP status code matrix.
