// Example: Video generation via Rork proxy
//
// Usage: swift example-video-generation.swift <TOOLKIT_URL> <SECRET_KEY> [MODEL] [PROMPT]
//
// The response is always SSE. Parse line-by-line to extract the last event.
// Video generation can take 30s–25min depending on the provider.
//
// Provider routing: the request body's `providerOptions` is keyed by the
// upstream provider, NOT by the model-ID prefix. The mapping below mirrors
// `endpoints[].provider_name` from endpoint metadata — Google models route
// through `vertex`, the rest match their prefix. Verify against the live
// endpoint spec when adopting a new model ID.

import Foundation

guard CommandLine.arguments.count >= 3 else {
    print("Usage: swift example-video-generation.swift <TOOLKIT_URL> <SECRET_KEY> [MODEL] [PROMPT]")
    exit(1)
}

let toolkitURL = CommandLine.arguments[1]
let secretKey = CommandLine.arguments[2]
let model = CommandLine.arguments.count >= 4 ? CommandLine.arguments[3] : "bytedance/seedance-2.0-fast"
let prompt = CommandLine.arguments.count >= 5 ? CommandLine.arguments[4] : "A cat walking on a treadmill in slow motion"
let vercelV3URL = "\(toolkitURL)/v2/vercel/v3/ai"

// --- Error type with user-facing messages ---

enum VideoError: LocalizedError {
    case authError
    case insufficientBalance
    case rateLimited
    case serverError(Int)
    case parsingFailed
    case generationFailed(String)
    case noVideoReturned

    var errorDescription: String? {
        switch self {
        case .authError:                "AI features are currently unavailable. Please restart the app."
        case .insufficientBalance:      "AI features are temporarily unavailable. Please try again later."
        case .rateLimited:              "Too many requests. Please wait a moment and try again."
        case .serverError:              "Something went wrong. Please try again."
        case .parsingFailed:            "Couldn't process the video response. Please try again."
        case .generationFailed(let msg): "Video generation failed: \(msg)"
        case .noVideoReturned:          "No video was returned. Please try again."
        }
    }
}

// --- Response type ---
//
// Vercel AI Gateway returns the generated video as either a hosted URL
// (most providers) or an inline base64 payload (e.g. Google Veo). Decode
// both shapes — clients that only read `.url` silently fail on Veo with
// `noVideoReturned`, even though the upstream generation succeeded.
struct VideoSSEResponse: Codable {
    let type: String?
    let videos: [VideoItem]?
    let message: String?
    struct VideoItem: Codable {
        let type: String?
        let url: String?
        // The gateway sometimes emits inline base64 under `data` and sometimes
        // under `base64` depending on the upstream provider — accept both.
        let data: String?
        let base64: String?
        let mediaType: String?
    }
}

// Decode an inline video payload, tolerating a leading `data:video/...;base64,`
// header — the gateway occasionally forwards Veo / Bytedance bodies with the
// header still attached.
func decodedBase64Data(from value: String) -> Data? {
    let trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines)
    let raw: String
    if let comma = trimmed.firstIndex(of: ",") {
        raw = String(trimmed[trimmed.index(after: comma)...])
    } else {
        raw = trimmed
    }
    return Data(base64Encoded: raw)
}

// --- Per-model timing budget ---
//
// Some providers / model families take dramatically longer than others. The
// URLSession timeout below has to exceed `pollTimeoutMs`, otherwise the
// socket dies before the gateway finishes polling and the SSE never lands.
func pollTimeoutMs(for modelId: String) -> Int {
    if modelId.contains("kling-v3.0") || modelId.contains("seedance-2.0") || modelId.contains("wan-v2.6") {
        return 1_200_000
    }
    return 900_000
}

// --- Provider options dispatch ---
//
// `providerOptions` is keyed by the upstream provider, which equals
// `endpoints[].provider_name` from endpoint metadata. The only common
// non-obvious case is Google, which routes through Vertex.
//
// `withAudio` and `mode` are illustrative — pass through whatever the
// upstream actually accepts (see the Vercel docs link in <references>).
func providerOptions(for modelId: String, pollTimeoutMs: Int, withAudio: Bool) -> [String: Any] {
    let baseTiming: [String: Any] = [
        "pollIntervalMs": 5_000,
        "pollTimeoutMs": pollTimeoutMs,
    ]
    if modelId.hasPrefix("google/") {
        var vertex = baseTiming
        vertex["generateAudio"] = withAudio
        vertex["enhancePrompt"] = true
        return ["vertex": vertex]
    }
    if modelId.hasPrefix("klingai/") {
        var klingai = baseTiming
        klingai["mode"] = (modelId.contains("v3.0") || modelId.contains("v2.6")) ? "pro" : "std"
        klingai["sound"] = withAudio ? "on" : "off"
        return ["klingai": klingai]
    }
    if modelId.hasPrefix("bytedance/") {
        var bytedance = baseTiming
        bytedance["generateAudio"] = withAudio
        return ["bytedance": bytedance]
    }
    if modelId.hasPrefix("alibaba/") {
        var alibaba = baseTiming
        alibaba["audio"] = withAudio
        alibaba["watermark"] = false
        return ["alibaba": alibaba]
    }
    if modelId.hasPrefix("xai/") {
        return ["xai": baseTiming]
    }
    return [:]
}

// --- Request ---

let modelPollTimeoutMs = pollTimeoutMs(for: model)

let body: [String: Any] = [
    "model": model,
    "prompt": prompt,
    "aspectRatio": "16:9",
    "duration": 5,
    "providerOptions": providerOptions(for: model, pollTimeoutMs: modelPollTimeoutMs, withAudio: true),
]

var request = URLRequest(url: URL(string: "\(vercelV3URL)/video-model")!)
request.httpMethod = "POST"
request.setValue("application/json", forHTTPHeaderField: "Content-Type")
request.setValue("Bearer \(secretKey)", forHTTPHeaderField: "Authorization")
request.setValue("0.0.1", forHTTPHeaderField: "ai-gateway-protocol-version")
request.setValue("4", forHTTPHeaderField: "ai-video-model-specification-version")
request.setValue(model, forHTTPHeaderField: "ai-model-id")
request.setValue("text/event-stream", forHTTPHeaderField: "accept")
request.httpBody = try JSONSerialization.data(withJSONObject: body)
request.timeoutInterval = TimeInterval((modelPollTimeoutMs / 1000) + 90)

print("Generating video with \(model)...")

let (data, response) = try await URLSession.shared.data(for: request)
let httpResponse = response as! HTTPURLResponse

switch httpResponse.statusCode {
case 200:  break
case 401:  throw VideoError.authError
case 402:  throw VideoError.insufficientBalance
case 429:  throw VideoError.rateLimited
default:   throw VideoError.serverError(httpResponse.statusCode)
}

// Parse SSE — scan all events and pick the last one carrying `videos`.
//
// Why scan, not "take the last data: line": some providers (notably
// Bytedance Seedance) emit a final `finish` / usage event AFTER the result
// event. Reading only the last `data: ...` then throws `noVideoReturned`
// even though the generation succeeded and was billed. Surface any
// `type: "error"` event up front so the caller sees the upstream message.
let text = String(data: data, encoding: .utf8) ?? ""
let decoder = JSONDecoder()
var decodedEvents: [VideoSSEResponse] = []
for line in text.components(separatedBy: "\n") {
    let trimmed = line.trimmingCharacters(in: .whitespaces)
    guard trimmed.hasPrefix("data: ") else { continue }
    let json = String(trimmed.dropFirst(6))
    if json.isEmpty || json == "[DONE]" { continue }
    guard
        let jsonData = json.data(using: .utf8),
        let event = try? decoder.decode(VideoSSEResponse.self, from: jsonData)
    else { continue }
    decodedEvents.append(event)
}

guard !decodedEvents.isEmpty else {
    throw VideoError.parsingFailed
}

if let errorEvent = decodedEvents.first(where: { $0.type == "error" }) {
    throw VideoError.generationFailed(errorEvent.message ?? "Unknown error")
}

guard
    let videoEvent = decodedEvents.last(where: { $0.videos?.isEmpty == false }),
    let video = videoEvent.videos?.first
else {
    throw VideoError.noVideoReturned
}

if let videoURL = video.url {
    print("Video URL: \(videoURL)")
} else if let encoded = video.data ?? video.base64, let bytes = decodedBase64Data(from: encoded) {
    // Providers such as Google Veo return the video inline as base64
    // instead of a hosted URL. Write the bytes to a temp file so the
    // caller has a path to play, upload, or copy into the app sandbox.
    let ext = video.mediaType?.split(separator: "/").last.map(String.init) ?? "mp4"
    let outputURL = URL(fileURLWithPath: NSTemporaryDirectory())
        .appendingPathComponent("video-\(UUID().uuidString).\(ext)")
    try bytes.write(to: outputURL)
    print("Video file: \(outputURL.path) (\(bytes.count) bytes)")
} else {
    throw VideoError.noVideoReturned
}
