# POST /v2/vercel/v3/ai/video-model

Video generation endpoint via Vercel AI Gateway v3. Supports text-to-video, image-to-video, reference-to-video, motion control, and video editing depending on the chosen model. Auth + URL structure are documented in `proxy.md`.

For the platform implementation see `video-generation/swift.md` (raw `URLSession`) or `video-generation/react-native.md` (Vercel AI SDK `experimental_generateVideo`).

For production failover, read `model-fallbacks.md`. Keep fallbacks on the same operation and request shape: text-to-video with text-to-video, image-to-video with image-to-video, etc.

<references>
| Topic              | URL                                                                                 |
| ------------------ | ----------------------------------------------------------------------------------- |
| Text-to-Video      | https://vercel.com/docs/ai-gateway/capabilities/video-generation/text-to-video      |
| Image-to-Video     | https://vercel.com/docs/ai-gateway/capabilities/video-generation/image-to-video     |
| Reference-to-Video | https://vercel.com/docs/ai-gateway/capabilities/video-generation/reference-to-video |
| Motion Control     | https://vercel.com/docs/ai-gateway/capabilities/video-generation/motion-control     |
| Video Editing      | https://vercel.com/docs/ai-gateway/capabilities/video-generation/video-editing      |
| Video quickstart   | https://vercel.com/docs/ai-gateway/getting-started/video                            |
| AI Gateway         | https://vercel.com/docs/ai-gateway                                                  |
| Available models   | https://vercel.com/ai-gateway/models                                                |
| Model Fallbacks    | https://vercel.com/docs/ai-gateway/models-and-providers/model-fallbacks             |

</references>

## Required headers

The v3 gateway requires these headers in addition to `Authorization` and `Content-Type`:

| Header                                 | Value               | Description                 |
| -------------------------------------- | ------------------- | --------------------------- |
| `ai-gateway-protocol-version`          | `0.0.1`             | Gateway protocol version    |
| `ai-video-model-specification-version` | `4`                 | Video model spec version    |
| `ai-model-id`                          | model ID            | Same as `model` in the body |
| `accept`                               | `text/event-stream` | Required for SSE response   |

> All video models are `type: "video"` in the live model list. Query the catalog from `model-discovery.md`, filter by provider, and sort by release date. Unlike image generation, there is no language/image type split — all video models use this endpoint.

## Request body

| Field           | Type   | Required | Description                                      |
| --------------- | ------ | -------- | ------------------------------------------------ |
| model           | string | yes      | Video model ID (e.g. `"xai/grok-imagine-video"`) |
| prompt          | string | yes      | Text description of the video to generate        |
| n               | number | no       | Number of videos to generate                     |
| aspectRatio     | string | no       | Aspect ratio (e.g. `"16:9"`, `"9:16"`, `"1:1"`)  |
| resolution      | string | no       | Resolution (e.g. `"1080p"`, `"720p"`)            |
| duration        | number | no       | Duration in seconds                              |
| fps             | number | no       | Frames per second                                |
| seed            | number | no       | Seed for reproducibility                         |
| image           | object | no       | Input image for image-to-video models            |
| providerOptions | object | no       | Provider-specific options                        |

## Response

The response is an SSE stream (`text/event-stream`). Each event is a JSON object prefixed with `data: `.

### Success event

The gateway returns each video as one of two shapes depending on the provider:

```json
// type: "url" — most providers (Kling, Bytedance, Wan, xAI, ...)
{
  "type": "result",
  "videos": [{ "type": "url", "url": "https://example.com/video.mp4", "mediaType": "video/mp4" }],
  "warnings": [],
  "providerMetadata": {
    "gateway": { "marketCost": "0.25", "generationId": "gen_..." }
  }
}

// type: "base64" — Google Veo (3.0, 3.1, 3.1 fast)
{
  "type": "result",
  "videos": [{ "type": "base64", "data": "<base64 mp4>", "mediaType": "video/mp4" }],
  "warnings": [],
  "providerMetadata": { "gateway": { "marketCost": "0.4", "generationId": "gen_..." } }
}
```

**Always handle both shapes.** Reading `videos[0].url` only succeeds for URL responses and silently fails on Veo with "no video returned" — the upstream generation actually succeeded and you were billed, but the parser dropped the inline payload. AI SDK's `experimental_generateVideo` abstracts this via `videos[0].uint8Array`; raw fetch must branch on `videos[0].type`.

### Error event

```json
{
  "type": "error",
  "message": "Model not found",
  "errorType": "not_found_error",
  "statusCode": 404
}
```

### Streaming behaviour

Unlike `/v2/vercel/v1/chat/completions`, this endpoint does **not** support `stream: true/false`. The response is always a **single SSE event** (`data: {...}\n\n`). There is no incremental streaming — the gateway polls the video provider internally and returns the final result in one shot.

Parse the response by reading the full body as text, splitting by lines, and extracting the last `data: ` event. Do **not** use a naive `text.replace(/^data: /, "")` — this breaks when there are multiple SSE events or when `data: ` appears inside the JSON payload.

> **Pitfall — trailing finish events.** Some providers (notably Bytedance Seedance) emit a final `finish` / usage event AFTER the result event. "Take the last `data: ...` line" then returns the finish event and the parser throws `noVideoReturned`, even though the generation succeeded and was billed. Scan all events instead and pick the last one whose payload has a non-empty `videos` array, surfacing any `type: "error"` along the way. The runnable Swift sample `video-generation/example-image-to-video.swift` shows this defensive scan; the AI SDK's `experimental_generateVideo` already does it for you.

For Swift / `URLSession` use the same line-by-line shape — copy from `swift/example-parse-sse-response.swift`.

## Video models

> Only the latest generation per provider is listed below. Older generations (Veo 3.0, Kling v2.6, Wan v2.5, Seedance v1.x) still resolve through the gateway, but **prefer the entries in this table** unless a caller has a hard reason to pin an older ID.

| Model ID                           | Provider  | Type                                        | Cost hint                        | Speed hint                    |
| ---------------------------------- | --------- | ------------------------------------------- | -------------------------------- | ----------------------------- |
| `xai/grok-imagine-video`           | xAI       | text-to-video                               | ~$0.06/video (flat)              | ~45s latency                  |
| `google/veo-3.1-generate-001`      | Google    | text-to-video                               | expensive                        | 60–90s latency                |
| `google/veo-3.1-fast-generate-001` | Google    | text-to-video                               | moderate–expensive               | faster than 3.1               |
| `klingai/kling-v3.0-t2v`           | KlingAI   | text-to-video                               | ~$0.075/s                        | 60–120s latency               |
| `klingai/kling-v3.0-i2v`           | KlingAI   | image-to-video                              | ~$0.075/s                        | 60–120s latency               |
| `alibaba/wan-v2.6-t2v`             | Alibaba   | text-to-video                               | ~$0.07/s (cheap)                 | moderate                      |
| `alibaba/wan-v2.6-i2v`             | Alibaba   | image-to-video                              | ~$0.07/s (cheap)                 | moderate                      |
| `bytedance/seedance-2.0`           | Bytedance | t2v / i2v / ref-to-video / first-last-frame | ~$0.07/s (480p) – $0.16/s (720p) | best Bytedance quality, audio |
| `bytedance/seedance-2.0-fast`      | Bytedance | t2v / i2v / ref-to-video / first-last-frame | ~$0.05/s (480p) – $0.12/s (720p) | fast, native audio, up to 15s |

> **Cost and speed hints are approximate and may be outdated.** When choosing a model or when hints seem stale, search the web for the model name and compare the live catalog's pricing fields.

### Model selection guidance

- **Cheap + flat-rate**: `xai/grok-imagine-video` (~$0.06 flat per video) — predictable pricing, ~45s latency.
- **Cheap + feature-rich**: `bytedance/seedance-2.0-fast` (~$0.05/s 480p) — newest Bytedance generation with native audio, ref-to-video, first-last-frame, up to 15 s.
- **Best overall quality**: `klingai/kling-v3.0-t2v` — #1 ELO benchmark score, native 4K HDR. Expensive (~$0.075/s) and slow (5–15 min).
- **Best quality + audio**: `google/veo-3.1-generate-001` produces excellent native audio with lifelike motion, but is the most expensive.
- **Fast + moderate cost**: `google/veo-3.1-fast-generate-001`.
- **Image-to-video**: `klingai/kling-v3.0-i2v` (best, 4K) or `alibaba/wan-v2.6-i2v` (cheaper).
- **Default recommendation**: Start with `google/veo-3.1-fast-generate-001`. Use `bytedance/seedance-2.0-fast` for Bytedance's latest at lower cost, `klingai/kling-v3.0-t2v` for highest quality, or `veo-3.1-generate-001` if audio quality is critical.

**i2v image-input shape is read from the model, not hardcoded.** The accepted envelope (URL-only vs base64-capable) is provider-version-specific and changes between minor releases. Always fetch the exact model's endpoint metadata and consult `capabilities.input_limits.image.supported_sources` before sending an image. Do not memorise per-model envelopes from this list.

**Pick model IDs via the verification protocol in `model-discovery.md`** (filter `.data` by `type == "video"`) — never write a model ID without running it through that flow.

### Model specs

`duration` is provider-specific. Unsupported values make the upstream reject the request (e.g. `VERTEX_VIDEO_GENERATION_FAILED`).

**Always fetch the exact model's endpoint metadata before choosing request parameters.** The Vercel response includes exact `capabilities.supported_durations_seconds`, `capabilities.supported_resolutions`, `capabilities.supported_aspect_ratios`, `capabilities.supported_operations`, `capabilities.input_limits`, `capabilities.generate_audio`, and pricing. Use those specs for the exact model ID you will call.

## Image-to-video (i2v) input shapes

Models with `-i2v` suffix accept an input image to animate. Read `image-input-requirements.md` for provider-specific image format, size, and encoding requirements before passing images to i2v models.

Each i2v model declares which input shapes the upstream accepts via `capabilities.input_limits.image.supported_sources` on its endpoint spec. **Fetch the model endpoint metadata described in `model-discovery.md` and read that array before picking a shape — do not guess from the model ID.** Picking a shape outside the declared set returns 400 from the upstream.

| `supported_sources` entry | Raw-fetch wire format                                          | Notes                                                                                                                |
| ------------------------- | -------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------- |
| `"url"`                   | `{ "type": "url", "url": "..." }`                              | Always honoured.                                                                                                     |
| `"base64"`                | `{ "type": "file", "mediaType": "image/jpeg", "data": "..." }` | Raw base64 only — strip any `data:image/...;base64,` prefix first. See `image-input-requirements.md`.                |
| `"buffer"`                | Same `{ "type": "file" }` body                                 | The AI SDK exposes this as a `Buffer` argument; under the hood it gets serialised to the `{ "type": "file" }` shape. |

If you are calling through the AI SDK (`experimental_generateVideo`), the SDK adds its own per-provider input rules on top of `supported_sources` — those are documented in `video-generation/react-native.md` and are intentionally more conservative than the gateway-level matrix. Trust the SDK's restrictions for AI SDK calls; trust `supported_sources` for raw fetch.

## Notes

- Video generation can take 30 seconds to several minutes depending on the model and duration. The HTTP connection stays open until the video is ready.
- Cost is billed automatically via `providerMetadata.gateway.marketCost`.
- The gateway resolves the correct provider automatically from the model ID.

## Error handling

See `error-handling/api.md` for the platform-agnostic HTTP status codes, retry strategy, idempotency keys, and `Retry-After` rules. Platform-specific request/retry wiring is in `error-handling/swift.md` or `error-handling/react-native.md`.
