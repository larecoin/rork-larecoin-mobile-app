# Video Generation — Swift

Read `video-generation/api.md` first for the endpoint contract, request body, response shape (URL vs base64 branching), and i2v rules. This file covers the Swift `URLSession` implementation.

For production failover, read `model-fallbacks.md` and add compatible video-model fallbacks via `providerOptions.gateway.models`. Swift sends the same JSON body through `URLSession`; the AI SDK is not required.

<references>
| Topic              | URL                                                                                 |
| ------------------ | ----------------------------------------------------------------------------------- |
| Text-to-Video      | https://vercel.com/docs/ai-gateway/capabilities/video-generation/text-to-video      |
| Image-to-Video     | https://vercel.com/docs/ai-gateway/capabilities/video-generation/image-to-video     |
| Reference-to-Video | https://vercel.com/docs/ai-gateway/capabilities/video-generation/reference-to-video |
| Motion Control     | https://vercel.com/docs/ai-gateway/capabilities/video-generation/motion-control     |
| Video Editing      | https://vercel.com/docs/ai-gateway/capabilities/video-generation/video-editing      |
| Vercel AI Gateway  | https://vercel.com/docs/ai-gateway                                                  |
| Available models   | https://vercel.com/ai-gateway/models                                                |
| Model Fallbacks    | https://vercel.com/docs/ai-gateway/models-and-providers/model-fallbacks             |

**Pick model IDs via the verification protocol in `model-discovery.md`** (filter `.data` by `type == "video"`) — never write a model ID without running it through that flow.
</references>

## Image-to-Video Input Requirements

Read `image-input-requirements.md` for provider-specific image format, size, and encoding requirements.

**Always resize against a byte budget before base64-encoding.** For image-to-video requests that send raw image bytes, the Vercel 4.5 MB request-body limit is often stricter than the provider limit. `video-generation/example-image-to-video.swift` includes a `resizeImageForUpload` helper built on `ImageIO` that walks a size / quality ladder until the JPEG fits the budget, without decoding the full-resolution bitmap into memory.

When using raw fetch (not AI SDK), pass `prompt` as a **string** and the image as a separate `image` field. Do NOT pass prompt as an object — the gateway expects a string and will return 400.

### Picking the request shape

Each i2v model declares which input shapes the upstream accepts via `capabilities.input_limits.image.supported_sources` on its endpoint spec. **Fetch the model endpoint metadata described in `model-discovery.md` and read that array before picking a shape — do not guess from the model ID.** Sending the wrong envelope returns a 400 from the upstream.

| `supported_sources` entry | Swift wire format                                                | Notes                                                                                                                 |
| ------------------------- | ---------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------- |
| `"url"`                   | `["type": "url", "url": "https://…"]`                            | Upload local images to R2 / Vercel Blob first, then pass the public URL. Skips the Vercel 4.5 MB body limit entirely. |
| `"base64"`                | `["type": "file", "mediaType": "image/jpeg", "data": rawBase64]` | Raw base64 only — strip any `data:image/...;base64,` prefix first. Subject to the Vercel 4.5 MB body limit.           |

`video-generation/example-image-to-video.swift` accepts a URL, a `data:` URI, a raw base64 string, or a local file path as the image argument and builds the matching envelope automatically — the same script works regardless of the model's `supported_sources`. Always still confirm the chosen shape against the live model spec; if the model only accepts `["url"]`, supply a URL (or upload first and pass the public URL).

## Sample Code

| File                                                | Capability         | Description                                                                       |
| --------------------------------------------------- | ------------------ | --------------------------------------------------------------------------------- |
| `video-generation/example-video-generation.swift`   | text-to-video      | Basic SSE-parsing text-to-video                                                   |
| `video-generation/example-image-to-video.swift`     | image-to-video     | Auto-detects URL / `data:` URI / raw base64 / file path; defensive SSE event scan |
| `video-generation/example-reference-to-video.swift` | reference-to-video | Wan r2v — new scene with `character1`/`character2` referencing URLs               |
| `swift/example-parse-sse-response.swift`            | helper             | SSE response parsing — reusable pattern                                           |
| `swift/example-model-fallbacks.swift`               | mixed              | Raw proxy model fallbacks for text, image, and video                              |

Motion control (`klingai/kling-v2.6-motion-control`) and video editing (`xai/grok-imagine-video`) follow the same raw-fetch pattern as the above samples, but need per-request public asset URLs (motion reference video, source video) — add them once you have verified test assets in hand.

### SSE result-event selection

Some providers (notably Bytedance Seedance) emit a final `finish` / usage event AFTER the result event. A naive "take the last `data: ...` line" parser then throws `noVideoReturned` even though the generation succeeded and was billed. Scan all events instead and pick the last one with a non-empty `videos` array, surfacing any `type: "error"` you encounter along the way. `video-generation/example-image-to-video.swift` shows the defensive scan.

## Provider options key

`providerOptions` is keyed by the upstream provider, which equals `endpoints[].provider_name` in the model endpoint response. The only routine gotcha is that `google/*` model IDs route through `provider_name: "vertex"` — sending `providerOptions.google` silently drops your settings.

The runnable Swift samples (`video-generation/example-video-generation.swift`, `video-generation/example-image-to-video.swift`) include a `providerOptions(for:pollTimeoutMs:withAudio:)` helper that dispatches on the model-ID prefix and matches the keys / fields actually accepted by each provider. Copy that helper rather than maintaining a parallel table here — it is exercised by the runnable scripts and stays in sync with the live gateway. Verify against `endpoints[].provider_name` whenever you adopt a new provider.

## Long-Running iOS Apps

For production iOS apps, do not hold a foreground `URLSession.shared.data(for:)` request open for 5–25 minute video jobs if the user may lock the phone, switch apps, or let the app suspend.

1. Wrap video generation behind a service boundary such as `VideoGenerationService.startGeneration(...)`, `observeGeneration(id)`, and `cancelGeneration(id)` so the implementation can later change without touching UI code.
2. Use a singleton `URLSession(configuration: .background(withIdentifier: ...), delegate: ..., delegateQueue: ...)`.
3. Create the video-generation `POST` as a `downloadTask(with: URLRequest)`. The SSE response will be delivered as a file; parse that file with the same line-by-line SSE logic after `urlSession(_:downloadTask:didFinishDownloadingTo:)`.
4. If the SSE result contains a remote MP4 URL, start a second background `downloadTask` for the MP4. If it contains base64 video data, write it to app storage when the delegate callback runs.
5. Persist a small pending-generation record (`localGenerationId`, `taskIdentifier`, prompt/model metadata, asset name, createdAt, phase) before starting the task. `CheckedContinuation` is not enough because continuations disappear if the app is killed and relaunched.

Pair long-running generation with a Live Activity when the app target supports it. Show phase-based progress (`starting`, `generating`, `finalizing`, `downloading`, `ready`) rather than fake percentages, because the gateway returns one final SSE result and does not expose reliable incremental progress. Keep the normal in-app pending state as the source of truth; Live Activity is a visibility layer, not the job state store.

Do not use `BGTaskScheduler` for a single in-flight video request; it is not scheduled on demand for user-visible jobs. Do not use `UIApplication.beginBackgroundTask` for video generation; it only gives a short grace period and is not enough for Veo / Kling / Wan latency.

Keep uploaded inputs small. For image / video inputs, upload the media first and pass public URLs to the video-generation request instead of sending large request bodies through the background session.

<important>
Generation timing varies per capability. Match `timeoutInterval` to `providerOptions.<provider>.pollTimeoutMs`:

- **text-to-video / i2v**: 5–10 min — `timeoutInterval ≥ 600` + `pollTimeoutMs: 600_000`
- **reference-to-video**: 10–20 min — `timeoutInterval ≥ 1500` + `pollTimeoutMs: 1_200_000`
- **motion control / video editing**: 15–25+ min — `timeoutInterval ≥ 1800` + `pollTimeoutMs: 1_500_000`

The `URLSession` `timeoutInterval` MUST exceed the provider's poll timeout — otherwise the socket is killed before the gateway finishes polling. The response is always SSE. Do NOT use `replacingOccurrences(of: "data: ", with: "")` — see `swift/example-parse-sse-response.swift` for the correct line-by-line parsing approach.
</important>

## Error Handling

See `error-handling/swift.md` for the `sendWithRetry` wrapper and Swift-specific error mapping. The HTTP status code matrix lives in `error-handling/api.md`.
