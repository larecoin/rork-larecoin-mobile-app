---
name: ai
description: Implements in-app AI through the Rork proxy. Use for chat, vision,
  image or video generation, embeddings, and gateway integration errors.
aliases:
  - Nano Banana
  - Gemini image editing
  - FUNCTION_PAYLOAD_TOO_LARGE
  - Image pixel is invalid
  - KlingAI
  - Grok Imagine Video
  - Google Veo
  - Seedance
  - Wan
---

# AI through the Rork proxy

## Core workflow

1. Read `proxy.md`, `model-discovery.md`, and the requested capability's API and platform files.
2. Call `getOrCreateToolkitSecret` before using an endpoint. Do not ask about credits when Rork AI Cloud is enabled.
3. Read the fallback, image-input, or error-handling files only when relevant.


Use the audio skill for speech, transcription, realtime voice, and sound effects.

## Available tools

### getOrCreateToolkitSecret

Ensure Rork AI Cloud is enabled before using any /v2/ proxy API. Include a short, non-technical description of why this app feature needs Cloud Credits. If Rork AI Cloud is already enabled, continue implementation and mention the selected Rork Toolkit model in your summary instead of asking the user to claim credits. When Cloud Credits are not enabled yet, this tool shows a confirmation widget and waits for the user to claim or enable them before continuing.

```json
{"type":"object","properties":{"description":{"type":"string","minLength":1}},"required":["description"]}
```

### fetchAiGatewayLogs

Fetch customer-safe AI gateway diagnostics for the current project. Use status,
timing, and request identifiers to correlate a failed AI model call. Provider,
model, routing, request content, and raw response content remain available only
in internal admin observability.

Scope is enforced server-side: the logs are always filtered to the caller's own
projectId from the agent token. It is not possible to query another project's logs.

Defaults to only failed requests (responseStatus >= 400). Set `onlyErrors: false`
to include successful calls too. Pass `assistantMessageId` to narrow to a
specific message's model calls.

```json
{"type":"object","properties":{"limit":{"default":20,"description":"Number of logs to fetch (default 20, max 50)","type":"integer","minimum":1,"maximum":50},"skip":{"default":0,"description":"Number of logs to skip for pagination","type":"integer","minimum":0,"maximum":9007199254740991},"onlyErrors":{"description":"Filter to failed requests (responseStatus >= 400). Defaults to true.","type":"boolean"},"assistantMessageId":{"description":"Scope results to a specific assistantMessageId (alphanumeric with dashes/underscores).","type":"string","minLength":1}}}
```

### rotateToolkitSecret

Rotate the toolkit secret key (EXPO_PUBLIC_RORK_TOOLKIT_SECRET_KEY) for this project.
This revokes the old key and creates a new one. The .env file is updated automatically.

IMPORTANT: Always confirm with the user before calling this tool, as it will
invalidate any running app instances that use the old key. After rotation you
must trigger a dev-publish to rebuild the app with the new key.

```json
{"type":"object","properties":{"confirmed":{"type":"boolean","description":"Must be true. Set to true only after the user has explicitly confirmed they want to rotate."}},"required":["confirmed"]}
```
