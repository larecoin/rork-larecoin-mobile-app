# POST /v2/vercel/v1/embeddings

Endpoint contract for vector embeddings via the Rork proxy. Auth + URL structure are documented in `proxy.md`.

For the platform implementation see `embeddings/swift.md` (raw `URLSession`) or `embeddings/react-native.md` (Vercel AI SDK).

## Request body

| Field | Type            | Required | Description                                           |
| ----- | --------------- | -------- | ----------------------------------------------------- |
| model | string          | no       | Model ID (default: `"openai/text-embedding-3-small"`) |
| input | string or array | yes      | Text to embed (single string or array of strings)     |

## Response

```json
{ "data": [{ "embedding": [0.012, -0.034, ...] }] }
```

## Embedding Models

- `openai/text-embedding-3-small` — default, good balance of cost and quality
- `cohere/embed-v4.0` — Cohere
- `google/gemini-embedding-001` — Gemini

**Pick model IDs via the verification protocol in `model-discovery.md`** — never write a model ID without running it through that flow.

## Fallbacks

For production failover, read `model-fallbacks.md` and add embedding-model fallbacks via `providerOptions.gateway.models`. Fallbacks must be embedding models with compatible vector dimensions.

## Error handling

See `error-handling/api.md` for the platform-agnostic HTTP status codes, retry strategy, idempotency keys, and `Retry-After` rules. Platform-specific request/retry wiring is in `error-handling/swift.md` or `error-handling/react-native.md`.
