// Example: Text embeddings via Rork proxy
//
// Usage: swift example-embeddings.swift <TOOLKIT_URL> <SECRET_KEY> [TEXT]
//
// Generates a vector embedding for the given text.

import Foundation

guard CommandLine.arguments.count >= 3 else {
    print("Usage: swift example-embeddings.swift <TOOLKIT_URL> <SECRET_KEY> [TEXT]")
    exit(1)
}

let toolkitURL = CommandLine.arguments[1]
let secretKey = CommandLine.arguments[2]
let text = CommandLine.arguments.count >= 4 ? CommandLine.arguments[3] : "Hello world"
let vercelV1URL = "\(toolkitURL)/v2/vercel/v1"

// --- Error type with user-facing messages ---

enum EmbeddingError: LocalizedError {
    case authError
    case insufficientBalance
    case rateLimited
    case serverError(Int)
    case noEmbeddingReturned

    var errorDescription: String? {
        switch self {
        case .authError:           "AI features are currently unavailable. Please restart the app."
        case .insufficientBalance: "AI features are temporarily unavailable. Please try again later."
        case .rateLimited:         "Too many requests. Please wait a moment and try again."
        case .serverError:         "Something went wrong. Please try again."
        case .noEmbeddingReturned: "No embedding was returned. Please try again."
        }
    }
}

// --- Response type ---

struct EmbeddingResponse: Codable {
    struct DataItem: Codable {
        let embedding: [Double]
    }
    let data: [DataItem]
}

// --- Request ---

let url = URL(string: "\(vercelV1URL)/embeddings")!

let body: [String: Any] = [
    "model": "openai/text-embedding-3-small",
    "input": text
]

var request = URLRequest(url: url)
request.httpMethod = "POST"
request.setValue("application/json", forHTTPHeaderField: "Content-Type")
request.setValue("Bearer \(secretKey)", forHTTPHeaderField: "Authorization")
request.httpBody = try JSONSerialization.data(withJSONObject: body)

let (data, response) = try await URLSession.shared.data(for: request)
let httpResponse = response as! HTTPURLResponse

switch httpResponse.statusCode {
case 200:  break
case 401:  throw EmbeddingError.authError
case 402:  throw EmbeddingError.insufficientBalance
case 429:  throw EmbeddingError.rateLimited
default:   throw EmbeddingError.serverError(httpResponse.statusCode)
}

let result = try JSONDecoder().decode(EmbeddingResponse.self, from: data)

guard let embedding = result.data.first?.embedding else {
    throw EmbeddingError.noEmbeddingReturned
}

print("Dimensions: \(embedding.count)")
print("First 5: \(embedding.prefix(5).map { String(format: "%.6f", $0) }.joined(separator: ", "))")
