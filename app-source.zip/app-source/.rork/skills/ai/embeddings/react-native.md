# Embeddings — React Native / TypeScript

Read `embeddings/api.md` first for the endpoint contract, request body, and response shape. This file covers the Vercel AI SDK implementation.

Use `embed` and `embedMany` from the AI SDK. The Rork proxy is a standard AI Gateway passthrough — point `createGateway` at the proxy URL and call the SDK normally.

<references>
| Function    | URL                                                      |
| ----------- | -------------------------------------------------------- |
| `embed`     | https://ai-sdk.dev/docs/reference/ai-sdk-core/embed      |
| `embedMany` | https://ai-sdk.dev/docs/reference/ai-sdk-core/embed-many |

</references>

## Gateway Setup

```ts
import { createGateway } from "ai";

const TOOLKIT_URL = process.env["EXPO_PUBLIC_TOOLKIT_URL"];
const SECRET_KEY = process.env["EXPO_PUBLIC_RORK_TOOLKIT_SECRET_KEY"];

const gateway = createGateway({
  baseURL: `${TOOLKIT_URL}/v2/vercel/v3/ai`,
  apiKey: SECRET_KEY,
});
```

## Single Embedding

```ts
import { embed } from "ai";

const { embedding } = await embed({
  model: gateway.textEmbeddingModel("openai/text-embedding-3-small"),
  value: "sunny day at the beach",
});
```

## Multiple Embeddings

```ts
import { embedMany } from "ai";

const { embeddings } = await embedMany({
  model: gateway.textEmbeddingModel("openai/text-embedding-3-small"),
  values: ["sunny day at the beach", "rainy afternoon in the city"],
});
```

## Sample Code

| File                               | Description                                       |
| ---------------------------------- | ------------------------------------------------- |
| `embeddings/example-embeddings.ts` | `embed` / `embedMany` via the gateway, end-to-end |

## Error Handling

See `error-handling/react-native.md` for the AI SDK-specific error patterns. The HTTP status code matrix lives in `error-handling/api.md`.
