# Embeddings — Swift

Read `embeddings/api.md` first for the endpoint contract, request body, and response shape. This file covers the Swift `URLSession` implementation.

Swift cannot use the Vercel AI SDK — call the Rork proxy directly with `URLSession` and parse the JSON response.

<references>
| Topic             | URL                                                       |
| ----------------- | --------------------------------------------------------- |
| Vercel AI Gateway | https://vercel.com/docs/ai-gateway                        |
| OpenAI Embeddings | https://platform.openai.com/docs/api-reference/embeddings |

</references>

## Sample Code

| File                                  | Description                              |
| ------------------------------------- | ---------------------------------------- |
| `embeddings/example-embeddings.swift` | Generate vector embeddings via the proxy |

Run it: `swift example-embeddings.swift <TOOLKIT_URL> <SECRET_KEY> "some text"`

## Error Handling

See `error-handling/swift.md` for the `sendWithRetry` wrapper and Swift-specific error mapping. The HTTP status code matrix lives in `error-handling/api.md`.
