// @ts-nocheck
// Example: Text embeddings via AI SDK
//
// Usage: bun example-embeddings.ts <TOOLKIT_URL> <SECRET_KEY> [TEXT]
//
// Generates a vector embedding for the given text. For batch embedding of
// many strings, use `embedMany` instead.

import { createGateway, embed } from "ai";

const toolkitURL = process.argv[2];
const secretKey = process.argv[3];
const text = process.argv[4] ?? "Hello world";

if (!toolkitURL || !secretKey) {
  console.log("Usage: bun example-embeddings.ts <TOOLKIT_URL> <SECRET_KEY> [TEXT]");
  process.exit(1);
}

const gateway = createGateway({
  baseURL: `${toolkitURL}/v2/vercel/v3/ai`,
  apiKey: secretKey,
});

const { embedding, usage } = await embed({
  model: gateway.textEmbeddingModel("openai/text-embedding-3-small"),
  value: text,
});

console.log(`Dimensions: ${embedding.length}`);
console.log(`First 5: ${embedding.slice(0, 5).map((n) => n.toFixed(6)).join(", ")}`);
console.log(`Tokens: ${usage.tokens}`);
