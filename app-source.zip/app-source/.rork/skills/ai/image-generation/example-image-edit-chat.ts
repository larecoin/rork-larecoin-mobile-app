// @ts-nocheck
// Example: Image editing via AI SDK generateText (Gemini image models / chat completions path)
//
// Usage: bun example-image-edit-chat.ts <TOOLKIT_URL> <SECRET_KEY> <IMAGE_PATH> [PROMPT]
//
// For multimodal LLMs (Gemini image models) that generate images via chat
// completions with `modalities: ["text", "image"]` — hosted on the gateway's
// v1 chat completions endpoint. Images land in `result.files` as file parts.
//
// Saves the result as output.png in the current directory.

import { createGateway, generateText } from "ai";

const toolkitURL = process.argv[2];
const secretKey = process.argv[3];
const imagePath = process.argv[4];
const prompt = process.argv[5] ?? "Make this image look like a watercolor painting";

if (!toolkitURL || !secretKey || !imagePath) {
  console.log("Usage: bun example-image-edit-chat.ts <TOOLKIT_URL> <SECRET_KEY> <IMAGE_PATH> [PROMPT]");
  process.exit(1);
}

// The AI SDK gateway points at the v3 AI root; the SDK dispatches to the
// correct upstream endpoint automatically based on the chosen model.
const gateway = createGateway({
  baseURL: `${toolkitURL}/v2/vercel/v3/ai`,
  apiKey: secretKey,
});

// Normalise any incoming `data:image/...,` prefix to raw base64. Gemini
// accepts either form, but stripping up front keeps downstream handling
// uniform with KlingAI / FLUX Kontext which reject data URIs outright.
const stripDataUriPrefix = (b64: string): string => {
  if (!b64.startsWith("data:")) return b64;
  const comma = b64.indexOf(",");
  return comma === -1 ? b64 : b64.slice(comma + 1);
};

// Read + resize in production. For base64 / buffer requests, keep the encoded
// payload under Vercel's 4.5 MB request-body limit by resizing against a byte
// budget — see `image-input-requirements.md`.
const imageBytes = await Bun.file(imagePath).arrayBuffer();
const imageBuffer = Buffer.from(stripDataUriPrefix(Buffer.from(imageBytes).toString("base64")), "base64");
const mimeType = imagePath.endsWith(".png") ? "image/png" : "image/jpeg";

const result = await generateText({
  model: gateway("google/gemini-3.1-flash-image"),
  messages: [
    {
      role: "user",
      content: [
        { type: "image", image: imageBuffer, mimeType },
        { type: "text", text: prompt },
      ],
    },
  ],
});

// Gemini image models return images in `result.files` — each file has a
// `uint8Array` and `mediaType`. There may also be accompanying text.
const imageFile = result.files.find((f) => f.mediaType?.startsWith("image/"));
if (!imageFile) {
  console.error("No image returned");
  process.exit(1);
}

await Bun.write("output.png", imageFile.uint8Array);
console.log(`Edited image saved to: output.png (${imageFile.uint8Array.byteLength} bytes, ${imageFile.mediaType})`);
