// @ts-nocheck
// Example: Text-to-image via AI SDK experimental_generateImage (type=image models)
//
// Usage: bun example-image-generation-v3.ts <TOOLKIT_URL> <SECRET_KEY> [PROMPT]
//
// For type=image models: OpenAI gpt-image-*, FLUX, Google Imagen, Recraft,
// xAI Grok Imagine. Images come back as `result.images[]` with `base64` and
// `mediaType`.
//
// For image EDITING (input image → edited output), use the object-form prompt
// `{ text, images: Buffer[] }` — see `example-image-edit-v3.ts`.

import { createGateway } from "ai";
import { experimental_generateImage as generateImage } from "ai";

const toolkitURL = process.argv[2];
const secretKey = process.argv[3];
const prompt = process.argv[4] ?? "A serene mountain landscape at sunset, oil painting style";

if (!toolkitURL || !secretKey) {
  console.log("Usage: bun example-image-generation-v3.ts <TOOLKIT_URL> <SECRET_KEY> [PROMPT]");
  process.exit(1);
}

const gateway = createGateway({
  baseURL: `${toolkitURL}/v2/vercel/v3/ai`,
  apiKey: secretKey,
});

const result = await generateImage({
  // `gateway(id)` returns a LanguageModel; image/video need the dedicated
  // factory methods (`gateway.imageModel` / `gateway.videoModel`), mirroring
  // `gateway.textEmbeddingModel` for embeddings.
  model: gateway.imageModel("openai/gpt-image-2"),
  prompt,
  size: "1536x1024",
});

if (result.images.length === 0) {
  console.error("No image returned");
  process.exit(1);
}

for (const [index, image] of result.images.entries()) {
  const ext = image.mediaType?.split("/")[1] ?? "png";
  const name = result.images.length === 1 ? `output.${ext}` : `output-${index}.${ext}`;
  await Bun.write(name, Buffer.from(image.base64, "base64"));
  console.log(`Saved ${name} (${image.base64.length} base64 chars, ${image.mediaType})`);
}
