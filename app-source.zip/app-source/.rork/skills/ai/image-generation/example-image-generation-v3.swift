// Example: Image generation via v3 image-model endpoint
//
// Usage: swift example-image-generation-v3.swift <TOOLKIT_URL> <SECRET_KEY> [PROMPT]
//
// For type=image models (OpenAI, FLUX, Imagen, Recraft, xAI).
// Uses the v3 gateway protocol with custom headers.
// Saves the result as output.png in the current directory.

import Foundation

guard CommandLine.arguments.count >= 3 else {
    print("Usage: swift example-image-generation-v3.swift <TOOLKIT_URL> <SECRET_KEY> [PROMPT]")
    exit(1)
}

let toolkitURL = CommandLine.arguments[1]
let secretKey = CommandLine.arguments[2]
let prompt = CommandLine.arguments.count >= 4 ? CommandLine.arguments[3] : "A red circle on a white background"
let vercelV3URL = "\(toolkitURL)/v2/vercel/v3/ai"

// --- Error type with user-facing messages ---

enum ImageGenError: LocalizedError {
    case authError
    case insufficientBalance
    case rateLimited
    case serverError(Int)
    case noImageReturned
    case decodingFailed

    var errorDescription: String? {
        switch self {
        case .authError:           "AI features are currently unavailable. Please restart the app."
        case .insufficientBalance: "AI features are temporarily unavailable. Please try again later."
        case .rateLimited:         "Too many requests. Please wait a moment and try again."
        case .serverError:         "Something went wrong. Please try again."
        case .noImageReturned:     "No image was returned. Please try again."
        case .decodingFailed:      "Couldn't decode the image data. Please try again."
        }
    }
}

// --- Response type ---

struct ImageResponse: Codable {
    let images: [String]?
}

// --- Request ---

let model = "openai/gpt-image-2"
let url = URL(string: "\(vercelV3URL)/image-model")!

let body: [String: Any] = [
    "model": model,
    "prompt": prompt,
    "n": 1,
    "size": "1024x1024",
    "providerOptions": [String: Any]()
]

var request = URLRequest(url: url)
request.httpMethod = "POST"
request.setValue("application/json", forHTTPHeaderField: "Content-Type")
request.setValue("Bearer \(secretKey)", forHTTPHeaderField: "Authorization")
request.setValue("0.0.1", forHTTPHeaderField: "ai-gateway-protocol-version")
request.setValue("4", forHTTPHeaderField: "ai-image-model-specification-version")
request.setValue(model, forHTTPHeaderField: "ai-model-id")
request.httpBody = try JSONSerialization.data(withJSONObject: body)
request.timeoutInterval = 120

print("Generating image with \(model)...")

let (data, response) = try await URLSession.shared.data(for: request)
let httpResponse = response as! HTTPURLResponse

switch httpResponse.statusCode {
case 200:  break
case 401:  throw ImageGenError.authError
case 402:  throw ImageGenError.insufficientBalance
case 429:  throw ImageGenError.rateLimited
default:   throw ImageGenError.serverError(httpResponse.statusCode)
}

let result = try JSONDecoder().decode(ImageResponse.self, from: data)

guard let base64String = result.images?.first else {
    throw ImageGenError.noImageReturned
}

guard let imageData = Data(base64Encoded: base64String) else {
    throw ImageGenError.decodingFailed
}

let outputURL = URL(fileURLWithPath: "output.png")
try imageData.write(to: outputURL)
print("Image saved to: \(outputURL.path) (\(imageData.count) bytes)")
