// Example: Image editing via chat completions (Gemini image models)
//
// Usage: swift example-image-edit-chat.swift <TOOLKIT_URL> <SECRET_KEY> <IMAGE_PATH> [PROMPT]
//
// Sends an image + text prompt to a Gemini image model via /v1/chat/completions.
// Use this for image-to-image transformations (editing, style transfer, etc.).
// Saves the result as output.png in the current directory.

import Foundation
import ImageIO
import UniformTypeIdentifiers

guard CommandLine.arguments.count >= 4 else {
    print("Usage: swift example-image-edit-chat.swift <TOOLKIT_URL> <SECRET_KEY> <IMAGE_PATH> [PROMPT]")
    exit(1)
}

let toolkitURL = CommandLine.arguments[1]
let secretKey = CommandLine.arguments[2]
let imagePath = CommandLine.arguments[3]
let prompt = CommandLine.arguments.count >= 5 ? CommandLine.arguments[4] : "Make this image look like a watercolor painting"
let vercelV1URL = "\(toolkitURL)/v2/vercel/v1"

// --- Error type ---

enum ImageEditError: LocalizedError {
    case fileNotFound
    case imageProcessingFailed
    case authError
    case insufficientBalance
    case payloadTooLarge
    case rateLimited
    case serverError(Int)
    case noImageReturned
    case decodingFailed

    var errorDescription: String? {
        switch self {
        case .fileNotFound:          "Image file not found."
        case .imageProcessingFailed: "Couldn't prepare the image. Please try a different photo."
        case .authError:             "AI features are currently unavailable. Please restart the app."
        case .insufficientBalance:   "AI features are temporarily unavailable. Please try again later."
        case .payloadTooLarge:       "Image is too large. Please try a smaller photo."
        case .rateLimited:           "Too many requests. Please wait a moment and try again."
        case .serverError:           "Something went wrong. Please try again."
        case .noImageReturned:       "No image was returned. Please try again."
        case .decodingFailed:        "Couldn't decode the image data. Please try again."
        }
    }
}

// --- Base64 prefix helper ---
//
// Strip a `data:image/...;base64,` prefix from a base64 string if present.
//
// Why: providers like KlingAI and FLUX Kontext require raw base64 and reject
// data URIs with errors like "Image pixel is invalid". Others (Gemini, OpenAI)
// accept either form. Normalising to raw base64 is always safe — when sending
// raw base64 you set the media type via a separate field anyway.
//
// The OpenAI-compatible chat-completions schema used below reassembles the
// data URI itself (`"url": "data:\(mimeType);base64,\(base64)"`), so we strip
// to raw first to avoid the dreaded double-prefixed `data:image/jpeg;base64,data:...`
// payload when the input is already a data URI from a web cache or JS bridge.
func stripDataUriPrefix(_ base64: String) -> String {
    guard base64.hasPrefix("data:"), let commaIndex = base64.firstIndex(of: ",") else {
        return base64
    }
    return String(base64[base64.index(after: commaIndex)...])
}

// --- Resize helper ---
//
// Re-encode against a byte budget instead of a fixed pixel cap. For image-input
// requests, the Vercel 4.5 MB request-body limit is often stricter than the
// provider limit.
func resizeImageForUpload(
    at path: String,
    maxBytes: Int = 3_000_000
) throws -> (data: Data, mimeType: String) {
    let url = URL(fileURLWithPath: path)
    guard let source = CGImageSourceCreateWithURL(url as CFURL, nil) else {
        throw ImageEditError.fileNotFound
    }

    let ladder: [(maxPixelSize: Int, quality: Double)] = [
        (1280, 0.82),
        (1024, 0.78),
        (832, 0.74),
        (640, 0.70),
        (512, 0.65),
    ]

    func encode(maxPixelSize: Int, quality: Double) throws -> Data {
        let options: [CFString: Any] = [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceCreateThumbnailWithTransform: true,
            kCGImageSourceThumbnailMaxPixelSize: maxPixelSize,
        ]
        guard let cgImage = CGImageSourceCreateThumbnailAtIndex(source, 0, options as CFDictionary) else {
            throw ImageEditError.imageProcessingFailed
        }
        let outputData = NSMutableData()
        guard let destination = CGImageDestinationCreateWithData(
            outputData,
            UTType.jpeg.identifier as CFString,
            1,
            nil
        ) else {
            throw ImageEditError.imageProcessingFailed
        }
        CGImageDestinationAddImage(
            destination,
            cgImage,
            [kCGImageDestinationLossyCompressionQuality: quality] as CFDictionary
        )
        guard CGImageDestinationFinalize(destination) else {
            throw ImageEditError.imageProcessingFailed
        }
        return outputData as Data
    }

    for step in ladder {
        let data = try encode(maxPixelSize: step.maxPixelSize, quality: step.quality)
        if data.count <= maxBytes {
            return (data, "image/jpeg")
        }
    }

    throw ImageEditError.payloadTooLarge
}

// --- Load + resize input image ---

guard FileManager.default.fileExists(atPath: imagePath) else {
    throw ImageEditError.fileNotFound
}
// Always downsample before base64 — camera-roll photos exceed provider limits.
let (imageData, mimeType) = try resizeImageForUpload(at: imagePath)
// Always normalise to raw base64 — some providers reject the `data:...,` prefix.
let base64Image = stripDataUriPrefix(imageData.base64EncodedString())

// --- Request ---

let model = "google/gemini-3.1-flash-image"
let url = URL(string: "\(vercelV1URL)/chat/completions")!

let body: [String: Any] = [
    "model": model,
    "modalities": ["text", "image"],
    "messages": [
        [
            "role": "user",
            "content": [
                ["type": "image_url", "image_url": ["url": "data:\(mimeType);base64,\(base64Image)"]],
                ["type": "text", "text": prompt]
            ]
        ]
    ]
]

var request = URLRequest(url: url)
request.httpMethod = "POST"
request.setValue("application/json", forHTTPHeaderField: "Content-Type")
request.setValue("Bearer \(secretKey)", forHTTPHeaderField: "Authorization")
request.httpBody = try JSONSerialization.data(withJSONObject: body)
request.timeoutInterval = 120

print("Editing image with \(model)...")

let (data, response) = try await URLSession.shared.data(for: request)
let httpResponse = response as! HTTPURLResponse

switch httpResponse.statusCode {
case 200:  break
case 401:  throw ImageEditError.authError
case 402:  throw ImageEditError.insufficientBalance
case 413:  throw ImageEditError.payloadTooLarge
case 429:  throw ImageEditError.rateLimited
default:   throw ImageEditError.serverError(httpResponse.statusCode)
}

// Parse response — images in choices[0].message.images[] as data URIs
struct ChatImageResponse: Codable {
    struct Choice: Codable {
        struct Message: Codable {
            let images: [String]?
        }
        let message: Message
    }
    let choices: [Choice]
}

let result = try JSONDecoder().decode(ChatImageResponse.self, from: data)

guard let dataURI = result.choices.first?.message.images?.first else {
    throw ImageEditError.noImageReturned
}

let parts = dataURI.components(separatedBy: ",")
guard parts.count == 2, let outputData = Data(base64Encoded: parts[1]) else {
    throw ImageEditError.decodingFailed
}

let outputURL = URL(fileURLWithPath: "output.png")
try outputData.write(to: outputURL)
print("Edited image saved to: \(outputURL.path) (\(outputData.count) bytes)")
