# Image Generation — Swift

Read `image-generation/api.md` first for the endpoint contract, request body, response shape, and the multimodal-LLM vs image-only routing rules. This file covers the Swift `URLSession` implementation.

<references>
| Topic                     | URL                                                                     |
| ------------------------- | ----------------------------------------------------------------------- |
| Vercel AI Gateway         | https://vercel.com/docs/ai-gateway                                      |
| Image Generation (OpenAI) | https://vercel.com/docs/ai-gateway/capabilities/image-generation/openai |
| Available models          | https://vercel.com/ai-gateway/models                                    |
| Model Fallbacks           | https://vercel.com/docs/ai-gateway/models-and-providers/model-fallbacks |
</references>

## Language-model image output

Images are in `choices[0].message.images[]`.

See `image-generation/example-image-generation-chat.swift` for text-to-image and `image-generation/example-image-edit-chat.swift` for image editing (image input + prompt).

## Image models

These use the **v3 `/v3/ai/image-model`** endpoint. Images are returned as base64 in the `images` array. Editing via this endpoint passes the input image through a `files[]` array on the request body.

See `image-generation/example-image-generation-v3.swift` for text-to-image, `image-generation/example-image-edit-v3.swift` for editing (input image in `files[]`).

## Image input requirements

Read `image-input-requirements.md` for provider-specific image format, size, and encoding requirements when passing input images.

**Always resize against a byte budget before base64-encoding, and strip any `data:` prefix.** For image-input requests, the Vercel 4.5 MB request-body limit is often stricter than the provider limit, so a fixed `1536px / 0.85` resize is not enough. Both `image-generation/example-image-edit-chat.swift` and `image-generation/example-image-edit-v3.swift` ship with:

- `resizeImageForUpload` — `ImageIO` / `CGImageSourceCreateThumbnailAtIndex` helper that walks a size / quality ladder until the JPEG fits the byte budget
- `stripDataUriPrefix` — normalises base64 strings to raw form

## Sample Code

| File                                                   | Endpoint               | Description                                                                  |
| ------------------------------------------------------ | ---------------------- | ---------------------------------------------------------------------------- |
| `image-generation/example-image-generation-v3.swift`   | `/v3/ai/image-model`   | Text-to-image — type=image models (OpenAI, FLUX, Imagen, Recraft)            |
| `image-generation/example-image-edit-v3.swift`         | `/v3/ai/image-model`   | Image editing — input image in `files[]` (OpenAI gpt-image-\*, FLUX Kontext) |
| `image-generation/example-image-generation-chat.swift` | `/v1/chat/completions` | Text-to-image — Gemini image models with text+image output                   |
| `image-generation/example-image-edit-chat.swift`       | `/v1/chat/completions` | Image editing — send image + prompt to Gemini for transformation             |
| `swift/example-model-fallbacks.swift`                  | mixed                  | Raw proxy model fallbacks for text, image, and video                         |

## Error Handling

See `error-handling/swift.md` for the `sendWithRetry` wrapper and Swift-specific error mapping. The HTTP status code matrix lives in `error-handling/api.md`.
