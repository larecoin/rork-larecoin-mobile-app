// Example: Image editing via /v3/ai/image-model (OpenAI gpt-image-2, FLUX Kontext, Recraft)
//
// Usage: swift example-image-edit-v3.swift <TOOLKIT_URL> <SECRET_KEY> <IMAGE_PATH> [PROMPT]
//
// For type=image models that accept an input image via `files[]` for editing /
// image-to-image. Distinct from `example-image-edit-chat.swift`, which targets
// multimodal LLMs (Gemini) via the chat-completions endpoint.
// Saves the result as output.png.

import Foundation
import ImageIO
import UniformTypeIdentifiers

guard CommandLine.arguments.count >= 4 else {
    print("Usage: swift example-image-edit-v3.swift <TOOLKIT_URL> <SECRET_KEY> <IMAGE_PATH> [PROMPT]")
    exit(1)
}

let toolkitURL = CommandLine.arguments[1]
let secretKey = CommandLine.arguments[2]
let imagePath = CommandLine.arguments[3]
let prompt = CommandLine.arguments.count >= 5 ? CommandLine.arguments[4] : "Replace the background with a tropical beach at sunset"
let vercelV3URL = "\(toolkitURL)/v2/vercel/v3/ai"

// --- Error type ---

enum ImageEditV3Error: LocalizedError {
    case fileNotFound
    case imageProcessingFailed
    case authError
    case insufficientBalance
    case payloadTooLarge
    case rateLimited
    case serverError(Int)
    case noImageReturned
    case decodingFailed

    var errorDescription: String? {
        switch self {
        case .fileNotFound:          "Image file not found."
        case .imageProcessingFailed: "Couldn't prepare the image. Please try a different photo."
        case .authError:             "AI features are currently unavailable. Please restart the app."
        case .insufficientBalance:   "AI features are temporarily unavailable. Please try again later."
        case .payloadTooLarge:       "Image is too large. Please try a smaller photo."
        case .rateLimited:           "Too many requests. Please wait a moment and try again."
        case .serverError:           "Something went wrong. Please try again."
        case .noImageReturned:       "No image was returned. Please try again."
        case .decodingFailed:        "Couldn't decode the image data. Please try again."
        }
    }
}

// --- Response type ---

struct ImageResponse: Codable {
    let images: [String]?
}

// --- Base64 prefix helper ---
//
// Strip a `data:image/...;base64,` prefix from a base64 string if present.
//
// Why: providers like FLUX Kontext require raw base64 and reject data URIs
// with errors like "Image pixel is invalid". Others (GPT image, Recraft)
// accept either form. Normalising to raw base64 is always safe — the media
// type is already supplied via the separate `mediaType` field in `files[]`.
func stripDataUriPrefix(_ base64: String) -> String {
    guard base64.hasPrefix("data:"), let commaIndex = base64.firstIndex(of: ",") else {
        return base64
    }
    return String(base64[base64.index(after: commaIndex)...])
}

// --- Resize helper ---
//
// Re-encode against a byte budget instead of a fixed pixel cap. For image-input
// requests, the Vercel 4.5 MB request-body limit is often stricter than the
// provider limit.
func resizeImageForUpload(
    at path: String,
    maxBytes: Int = 3_000_000
) throws -> (data: Data, mimeType: String) {
    let url = URL(fileURLWithPath: path)
    guard let source = CGImageSourceCreateWithURL(url as CFURL, nil) else {
        throw ImageEditV3Error.fileNotFound
    }

    let ladder: [(maxPixelSize: Int, quality: Double)] = [
        (1280, 0.82),
        (1024, 0.78),
        (832, 0.74),
        (640, 0.70),
        (512, 0.65),
    ]

    func encode(maxPixelSize: Int, quality: Double) throws -> Data {
        let options: [CFString: Any] = [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceCreateThumbnailWithTransform: true,
            kCGImageSourceThumbnailMaxPixelSize: maxPixelSize,
        ]
        guard let cgImage = CGImageSourceCreateThumbnailAtIndex(source, 0, options as CFDictionary) else {
            throw ImageEditV3Error.imageProcessingFailed
        }
        let outputData = NSMutableData()
        guard let destination = CGImageDestinationCreateWithData(
            outputData,
            UTType.jpeg.identifier as CFString,
            1,
            nil
        ) else {
            throw ImageEditV3Error.imageProcessingFailed
        }
        CGImageDestinationAddImage(
            destination,
            cgImage,
            [kCGImageDestinationLossyCompressionQuality: quality] as CFDictionary
        )
        guard CGImageDestinationFinalize(destination) else {
            throw ImageEditV3Error.imageProcessingFailed
        }
        return outputData as Data
    }

    for step in ladder {
        let data = try encode(maxPixelSize: step.maxPixelSize, quality: step.quality)
        if data.count <= maxBytes {
            return (data, "image/jpeg")
        }
    }

    throw ImageEditV3Error.payloadTooLarge
}

// --- Load + resize input image ---

guard FileManager.default.fileExists(atPath: imagePath) else {
    throw ImageEditV3Error.fileNotFound
}
// Always downsample before base64 — camera-roll photos exceed provider limits.
let (imageData, mimeType) = try resizeImageForUpload(at: imagePath)
// Always normalise to raw base64 — FLUX Kontext rejects data URIs outright.
let base64Image = stripDataUriPrefix(imageData.base64EncodedString())

// --- Request ---

let model = "openai/gpt-image-2"
let url = URL(string: "\(vercelV3URL)/image-model")!

let body: [String: Any] = [
    "model": model,
    "prompt": prompt,
    "n": 1,
    "size": "1024x1024",
    "providerOptions": [String: Any](),
    "files": [
        [
            "type": "file",
            "mediaType": mimeType,
            "data": base64Image
        ]
    ]
]

var request = URLRequest(url: url)
request.httpMethod = "POST"
request.setValue("application/json", forHTTPHeaderField: "Content-Type")
request.setValue("Bearer \(secretKey)", forHTTPHeaderField: "Authorization")
request.setValue("0.0.1", forHTTPHeaderField: "ai-gateway-protocol-version")
request.setValue("4", forHTTPHeaderField: "ai-image-model-specification-version")
request.setValue(model, forHTTPHeaderField: "ai-model-id")
request.httpBody = try JSONSerialization.data(withJSONObject: body)
request.timeoutInterval = 180

print("Editing image with \(model)...")

let (data, response) = try await URLSession.shared.data(for: request)
let httpResponse = response as! HTTPURLResponse

switch httpResponse.statusCode {
case 200:  break
case 401:  throw ImageEditV3Error.authError
case 402:  throw ImageEditV3Error.insufficientBalance
case 413:  throw ImageEditV3Error.payloadTooLarge
case 429:  throw ImageEditV3Error.rateLimited
default:   throw ImageEditV3Error.serverError(httpResponse.statusCode)
}

let result = try JSONDecoder().decode(ImageResponse.self, from: data)

guard let base64Output = result.images?.first else {
    throw ImageEditV3Error.noImageReturned
}

guard let outputData = Data(base64Encoded: base64Output) else {
    throw ImageEditV3Error.decodingFailed
}

let outputURL = URL(fileURLWithPath: "output.png")
try outputData.write(to: outputURL)
print("Edited image saved to: \(outputURL.path) (\(outputData.count) bytes)")
