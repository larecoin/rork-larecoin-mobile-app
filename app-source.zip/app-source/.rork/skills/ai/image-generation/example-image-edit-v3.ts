// @ts-nocheck
// Example: Image editing via AI SDK experimental_generateImage (OpenAI gpt-image-2, FLUX Kontext, Recraft)
//
// Usage: bun example-image-edit-v3.ts <TOOLKIT_URL> <SECRET_KEY> <IMAGE_PATH> [PROMPT]
//
// For type=image models that accept input images for editing / image-to-image.
// The AI SDK accepts input images via the object-form prompt:
//   `prompt: { text, images: Buffer[] }` — the gateway routes them through
//   `/v3/ai/image-model` with the correct provider-specific wire format.
// Saves the result as output.png in the current directory.

import { createGateway } from "ai";
import { experimental_generateImage as generateImage } from "ai";

const toolkitURL = process.argv[2];
const secretKey = process.argv[3];
const imagePath = process.argv[4];
const prompt = process.argv[5] ?? "Replace the background with a tropical beach at sunset";

if (!toolkitURL || !secretKey || !imagePath) {
  console.log("Usage: bun example-image-edit-v3.ts <TOOLKIT_URL> <SECRET_KEY> <IMAGE_PATH> [PROMPT]");
  process.exit(1);
}

const gateway = createGateway({
  baseURL: `${toolkitURL}/v2/vercel/v3/ai`,
  apiKey: secretKey,
});

// FLUX Kontext rejects `data:image/...,` prefixes with "Image pixel is
// invalid". Others accept either form, so normalising to raw base64 is
// always safe.
const stripDataUriPrefix = (b64: string): string => {
  if (!b64.startsWith("data:")) return b64;
  const comma = b64.indexOf(",");
  return comma === -1 ? b64 : b64.slice(comma + 1);
};

// Read the input image. In production, resize against a byte budget before
// encoding — for base64 / buffer requests the Vercel 4.5 MB request-body limit
// is often stricter than the provider limit. See `image-input-requirements.md`.
const imageBytes = await Bun.file(imagePath).arrayBuffer();
const imageBuffer = Buffer.from(stripDataUriPrefix(Buffer.from(imageBytes).toString("base64")), "base64");

const result = await generateImage({
  model: gateway.imageModel("openai/gpt-image-2"),
  // Object-form prompt: `{ text, images: Buffer[] }` triggers the edit path.
  // For text-to-image (no input), pass `prompt: "text"` as a plain string.
  prompt: {
    text: prompt,
    images: [imageBuffer],
  },
  // OpenAI GPT Image models use pixel dimensions via `size`, not `aspectRatio`.
  // xAI Grok-Imagine is the opposite — aspectRatio only. Check per-provider.
  size: "1024x1024",
});

const first = result.images[0];
if (!first) {
  console.error("No image returned");
  process.exit(1);
}
await Bun.write("output.png", Buffer.from(first.base64, "base64"));
console.log(`Edited image saved to: output.png (${first.base64.length} base64 chars, ${first.mediaType})`);
