# Image Generation — React Native / TypeScript (AI SDK)

Read `image-generation/api.md` first for the endpoint contract, request body, response shape, and the multimodal-LLM vs image-only routing rules. This file covers the Vercel AI SDK implementation.

<references>
| Topic                     | URL                                                                     |
| ------------------------- | ----------------------------------------------------------------------- |
| Image Generation (AI SDK) | https://vercel.com/docs/ai-gateway/capabilities/image-generation/ai-sdk |

</references>

## Setup

```ts
import { createGateway } from "ai";

const TOOLKIT_URL = process.env["EXPO_PUBLIC_TOOLKIT_URL"];
const SECRET_KEY = process.env["EXPO_PUBLIC_RORK_TOOLKIT_SECRET_KEY"];

const gateway = createGateway({
  baseURL: `${TOOLKIT_URL}/v2/vercel/v3/ai`,
  apiKey: SECRET_KEY,
});
```

Use `gateway.imageModel(id)` — **NOT** `gateway(id)` — for image-only models. `gateway(id)` returns a LanguageModel and crashes inside `@ai-sdk/gateway` when handed to `experimental_generateImage`.

## Language-model image output

Use `generateText` or `streamText`; Gemini images are returned in `result.files`. See the chat image samples for generation and editing. On React Native, wrap the base64 returned by `resizeForUpload(imageUri)` with `Buffer.from(base64, "base64")`.

### OpenAI GPT-5 image generation

GPT-5 variants support image generation via a provider tool. Images are in **`result.staticToolResults`**.

```ts
import { generateText } from "ai";
import { openai } from "@ai-sdk/openai";

const result = await generateText({
  model: gateway("openai/gpt-5.4-mini"),
  prompt: "Generate an image of a sunset over mountains",
  tools: {
    image_generation: openai.tools.imageGeneration({
      outputFormat: "webp",
      quality: "high",
    }),
  },
});

for (const toolResult of result.staticToolResults) {
  if (toolResult.toolName === "image_generation") {
    const base64Image = toolResult.output.result;
  }
}
```

## Image models

These models use `experimental_generateImage`. Images are in **`result.images`** (each has `base64` and `mediaType`).

The text-to-image happy path follows `image-generation/example-image-generation-v3.ts` verbatim — call `gateway.imageModel(id)`, pass `prompt` plus `aspectRatio` or `size`, and read `result.images[0].base64`.

### Image editing with input images

For editing with `type: "image"` models (OpenAI gpt-image-\*, FLUX Kontext, Recraft) pass input images via the **object-form prompt** `{ text, images: Buffer[] }`. Same AI SDK function, different prompt shape — no raw fetch needed.

The runnable pattern is `image-generation/example-image-edit-v3.ts` (resize → strip `data:` prefix → `Buffer.from(base64, "base64")` → `images: [imageBuffer]`); on RN the only difference is sourcing `base64` from `resizeForUpload(imageUri)` instead of `Bun.file(...).arrayBuffer()`. OpenAI GPT Image models use pixel dimensions via `size` (e.g. `"1024x1024"`); xAI Grok-Imagine is the opposite — `aspectRatio` only.

> **Prompt shape:** `generateImage` accepts `prompt: string` for text-to-image and `prompt: { text, images: Buffer[] }` for image editing / image-to-image. Multiple images are allowed for models that support multi-reference editing.

## Image input requirements

Read `image-input-requirements.md` for provider-specific image format, size, and encoding requirements when passing input images.

For React Native, use the shared `resizeForUpload` helper from `ts/resize-for-upload.ts` instead of inlining a fixed `1536px / 0.85` resize.

## Sample Code

| File                                                | Description                                                     |
| --------------------------------------------------- | --------------------------------------------------------------- |
| `image-generation/example-image-generation-v3.ts`   | AI SDK `experimental_generateImage` text-to-image (recommended) |
| `image-generation/example-image-edit-v3.ts`         | AI SDK image editing with `Buffer[]` input                      |
| `image-generation/example-image-generation-chat.ts` | Multimodal chat-completions image generation (Gemini, GPT-5)    |
| `image-generation/example-image-edit-chat.ts`       | Multimodal chat-completions image editing                       |

## Error Handling

See `error-handling/react-native.md` for AI SDK error patterns and `error-handling/api.md` for the HTTP status code matrix.
