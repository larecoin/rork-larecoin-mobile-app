// @ts-nocheck
// Example: Text-to-image via AI SDK generateText (Gemini image models)
//
// Usage: bun example-image-generation-chat.ts <TOOLKIT_URL> <SECRET_KEY> [PROMPT]
//
// Gemini image models are MULTIMODAL LLMs — they generate images alongside text via
// `generateText` / `streamText`, NOT via `experimental_generateImage`.
// Images land in `result.files` as file parts.
//
// For pure text-to-image with type=image models (FLUX, Imagen, Recraft, etc.),
// use `experimental_generateImage` — see `example-image-generation-v3.ts`.

import { createGateway, generateText } from "ai";

const toolkitURL = process.argv[2];
const secretKey = process.argv[3];
const prompt = process.argv[4] ?? "A turquoise-throated hummingbird on a dewy branch at sunrise";

if (!toolkitURL || !secretKey) {
  console.log("Usage: bun example-image-generation-chat.ts <TOOLKIT_URL> <SECRET_KEY> [PROMPT]");
  process.exit(1);
}

const gateway = createGateway({
  baseURL: `${toolkitURL}/v2/vercel/v3/ai`,
  apiKey: secretKey,
});

const result = await generateText({
  model: gateway("google/gemini-3.1-flash-image"),
  prompt,
});

if (result.text) console.log(`Text: ${result.text}`);

// Images come back as file parts — each has `uint8Array` and `mediaType`.
const imageFiles = result.files.filter((f) => f.mediaType?.startsWith("image/"));
if (imageFiles.length === 0) {
  console.error("No image returned");
  process.exit(1);
}

for (const [index, file] of imageFiles.entries()) {
  const ext = file.mediaType?.split("/")[1] ?? "png";
  const name = imageFiles.length === 1 ? `output.${ext}` : `output-${index}.${ext}`;
  await Bun.write(name, file.uint8Array);
  console.log(`Saved ${name} (${file.uint8Array.byteLength} bytes, ${file.mediaType})`);
}
