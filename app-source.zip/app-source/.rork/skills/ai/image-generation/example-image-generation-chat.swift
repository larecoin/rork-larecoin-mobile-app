// Example: Image generation via chat completions (Gemini image models)
//
// Usage: swift example-image-generation-chat.swift <TOOLKIT_URL> <SECRET_KEY> [PROMPT]
//
// For type=language models with image-generation tag (google/gemini-*-image).
// Uses /v1/chat/completions with modalities: ["text", "image"].
// Also supports image input (e.g. transforming a user photo).
// Saves the result as output.png in the current directory.

import Foundation

guard CommandLine.arguments.count >= 3 else {
    print("Usage: swift example-image-generation-chat.swift <TOOLKIT_URL> <SECRET_KEY> [PROMPT]")
    exit(1)
}

let toolkitURL = CommandLine.arguments[1]
let secretKey = CommandLine.arguments[2]
let prompt = CommandLine.arguments.count >= 4 ? CommandLine.arguments[3] : "Generate a picture of a red balloon"
let vercelV1URL = "\(toolkitURL)/v2/vercel/v1"

// --- Error type with user-facing messages ---

enum ImageChatError: LocalizedError {
    case authError
    case insufficientBalance
    case rateLimited
    case serverError(Int)
    case noImageReturned
    case decodingFailed

    var errorDescription: String? {
        switch self {
        case .authError:           "AI features are currently unavailable. Please restart the app."
        case .insufficientBalance: "AI features are temporarily unavailable. Please try again later."
        case .rateLimited:         "Too many requests. Please wait a moment and try again."
        case .serverError:         "Something went wrong. Please try again."
        case .noImageReturned:     "No image was returned. Please try again."
        case .decodingFailed:      "Couldn't decode the image data. Please try again."
        }
    }
}

// --- Response types ---
// Images are returned in choices[0].message.images[] as data URI strings
// or objects with { type: "image_url", image_url: { url: "data:..." } }.
// Handle both formats.

struct ChatImageResponse: Codable {
    struct Choice: Codable {
        struct Message: Codable {
            let content: String?
            let images: [ImageEntry]?
        }
        let message: Message
    }
    let choices: [Choice]

    enum ImageEntry: Codable {
        case string(String)
        case object(ImageObject)

        struct ImageObject: Codable {
            let image_url: ImageURL?
            struct ImageURL: Codable {
                let url: String?
            }
        }

        init(from decoder: Decoder) throws {
            let container = try decoder.singleValueContainer()
            if let str = try? container.decode(String.self) {
                self = .string(str)
            } else {
                self = .object(try container.decode(ImageObject.self))
            }
        }

        func encode(to encoder: Encoder) throws {
            var container = encoder.singleValueContainer()
            switch self {
            case .string(let str): try container.encode(str)
            case .object(let obj): try container.encode(obj)
            }
        }

        /// Extract the data URI from either format.
        var dataURI: String? {
            switch self {
            case .string(let str): return str
            case .object(let obj): return obj.image_url?.url
            }
        }
    }
}

// --- Request ---

let model = "google/gemini-3.1-flash-image"
let url = URL(string: "\(vercelV1URL)/chat/completions")!

let body: [String: Any] = [
    "model": model,
    "modalities": ["text", "image"],
    "messages": [
        ["role": "user", "content": prompt]
    ]
]

var request = URLRequest(url: url)
request.httpMethod = "POST"
request.setValue("application/json", forHTTPHeaderField: "Content-Type")
request.setValue("Bearer \(secretKey)", forHTTPHeaderField: "Authorization")
request.httpBody = try JSONSerialization.data(withJSONObject: body)
request.timeoutInterval = 120

print("Generating image with \(model)...")

let (data, response) = try await URLSession.shared.data(for: request)
let httpResponse = response as! HTTPURLResponse

switch httpResponse.statusCode {
case 200:  break
case 401:  throw ImageChatError.authError
case 402:  throw ImageChatError.insufficientBalance
case 429:  throw ImageChatError.rateLimited
default:   throw ImageChatError.serverError(httpResponse.statusCode)
}

let result = try JSONDecoder().decode(ChatImageResponse.self, from: data)

guard let imageEntry = result.choices.first?.message.images?.first,
      let dataURI = imageEntry.dataURI else {
    throw ImageChatError.noImageReturned
}

// Parse data URI: "data:image/png;base64,<base64data>"
let parts = dataURI.components(separatedBy: ",")
guard parts.count == 2, let imageData = Data(base64Encoded: parts[1]) else {
    throw ImageChatError.decodingFailed
}

let outputURL = URL(fileURLWithPath: "output.png")
try imageData.write(to: outputURL)
print("Image saved to: \(outputURL.path) (\(imageData.count) bytes)")

if let text = result.choices.first?.message.content, !text.isEmpty {
    print("Text: \(text)")
}
