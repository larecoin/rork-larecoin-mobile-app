# POST /v2/vercel/v3/ai/image-model

This endpoint accepts **`type: "image"`** models. Image-capable **`type: "language"`** models use `/v1/chat/completions` with `modalities: ["text", "image"]`; see `chat/api.md`.

For the platform implementation see `image-generation/swift.md` (raw `URLSession`) or `image-generation/react-native.md` (Vercel AI SDK `experimental_generateImage`).

Use `model-discovery.md` to find image-capable models and verify endpoint metadata. For prompt-only generation, start with `openai/gpt-image-2`. Transparent PNG output uses the same model with `providerOptions: { openai: { background: "transparent" } }`.

For production failover, read `model-fallbacks.md`. Image-model fallbacks must be image models with matching `size`, `aspectRatio`, editing `files`, and mask requirements.

<references>
| Topic                                | URL                                                                     |
| ------------------------------------ | ----------------------------------------------------------------------- |
| Image Generation (AI SDK)            | https://vercel.com/docs/ai-gateway/capabilities/image-generation/ai-sdk |
| Image Generation (OpenAI-compatible) | https://vercel.com/docs/ai-gateway/capabilities/image-generation/openai |
| AI Gateway Capabilities              | https://vercel.com/docs/ai-gateway                                      |
| Available models                     | https://vercel.com/ai-gateway/models                                    |
| Model Fallbacks                      | https://vercel.com/docs/ai-gateway/models-and-providers/model-fallbacks |

</references>

## Required headers

The v3 gateway requires these headers in addition to `Authorization` and `Content-Type`:

| Header                                 | Value    | Description                 |
| -------------------------------------- | -------- | --------------------------- |
| `ai-gateway-protocol-version`          | `0.0.1`  | Gateway protocol version    |
| `ai-image-model-specification-version` | `4`      | Image model spec version    |
| `ai-model-id`                          | model ID | Same as `model` in the body |

## Request body

| Field           | Type   | Required | Description                                           |
| --------------- | ------ | -------- | ----------------------------------------------------- |
| model           | string | yes      | Model ID (e.g. `"openai/gpt-image-2"`)                |
| prompt          | string | yes      | Image description                                     |
| n               | number | yes      | Number of images to generate (usually `1`)            |
| providerOptions | object | yes      | Provider-specific options (pass `{}` if none needed)  |
| size            | string | no       | e.g. `"1024x1024"`                                    |
| aspectRatio     | string | no       | e.g. `"16:9"`                                         |
| seed            | number | no       | Reproducibility seed                                  |
| files           | array  | no       | Input images for editing (`[{type:"url",url:"..."}]`) |
| mask            | object | no       | Mask for inpainting (`{type:"url",url:"..."}`)        |

## Response

```json
{
  "images": ["<base64-encoded image data>"],
  "warnings": [],
  "providerMetadata": {
    "gateway": { "marketCost": "0.042305", "generationId": "gen_..." }
  },
  "usage": { "inputTokens": 13, "outputTokens": 1056, "totalTokens": 1069 }
}
```

`images` is an array of raw base64 strings (no data URI prefix).

For transparent backgrounds, use `openai/gpt-image-2` with `providerOptions: { openai: { background: "transparent" } }`. Pair it with `png` (the default) or `webp`; `jpeg` cannot carry an alpha channel.

## Image input requirements (for editing / image-to-image)

Read `image-input-requirements.md` for provider-specific image format, size, and encoding requirements when passing input images for editing.

## Error handling

See `error-handling/api.md` for the platform-agnostic HTTP status codes, retry strategy, idempotency keys, and `Retry-After` rules. Platform-specific request/retry wiring is in `error-handling/swift.md` or `error-handling/react-native.md`.
