# Model Fallbacks

Use Vercel AI Gateway model fallbacks when a production AI feature should keep working if the primary model or provider is unavailable.

<references>
Fetch the Vercel docs before implementing fallbacks:

- Model Fallbacks — https://vercel.com/docs/ai-gateway/models-and-providers/model-fallbacks
- Provider Options — https://vercel.com/docs/ai-gateway/models-and-providers/provider-options

</references>

## How it Works

Add fallback model IDs to `providerOptions.gateway.models`. The gateway tries the primary `model` first, then each fallback model in order. The response comes from the first model/provider combination that succeeds.

```ts
providerOptions: {
  gateway: {
    models: ["<fallback-model-id>", "<second-fallback-model-id>"],
  },
}
```

You can combine `models` with provider routing options such as `order`, `only`, provider timeouts, ZDR filters, and request tags.

This is a Gateway proxy feature, not an AI SDK-only feature. The AI SDK is a wrapper over the same `/v3/ai/*` gateway endpoints, so Swift / URLSession and other raw HTTP clients can use the same request-body field.

## Compatibility

- Text / chat / vision — AI SDK: `generateText` / `streamText` / `useChat`. Raw: `/v2/vercel/v1/chat/completions`. Fallbacks: language models that support the same prompt, tools, structured output, and modalities.
- Multimodal LLM image generation — AI SDK: `generateText` / `streamText`. Raw: `/v2/vercel/v1/chat/completions`. Fallbacks: language models with the same image result shape.
- Image-only generation / editing — AI SDK: `experimental_generateImage`. Raw: `/v2/vercel/v3/ai/image-model`. Fallbacks: image models with matching size, ratio, files, and mask needs.
- Video generation — AI SDK: `experimental_generateVideo`. Raw: `/v2/vercel/v3/ai/video-model`. Fallbacks: video models for the same operation and request shape.
- Embeddings — AI SDK: `embed` / `embedMany`. Raw: `/v2/vercel/v1/embeddings`. Fallbacks: embedding models with compatible vector dimensions.

Do not mix endpoint families. A Gemini image language model fallback cannot replace an Imagen / FLUX / Recraft image-model request, and an image-model fallback cannot replace a Gemini `generateText` image request.

## Video Generation Rules

Video fallbacks must support the same operation and inputs:

- Text-to-video fallback -> text-to-video model.
- Image-to-video fallback -> image-to-video model that accepts the same `prompt.image` source type.
- Reference-to-video / motion control / video editing fallback -> only use models with the same supported operation.

Fetch each candidate's endpoint metadata as described in `model-discovery.md` and check `capabilities.supported_operations`, `capabilities.supported_durations_seconds`, `capabilities.supported_resolutions`, `capabilities.supported_aspect_ratios`, and `capabilities.input_limits` before choosing a fallback. Unsupported duration, resolution, image source, or provider option can make the fallback fail after the primary has already failed.

## Sample Code

Runnable samples live at the root sample folders. Open them directly rather than copying large blocks from this markdown file.

- `ts/example-model-fallbacks.ts` (bun) — AI SDK gateway examples for text, image, and video.
- `swift/example-model-fallbacks.swift` (swift) — raw URLSession examples for text, image, and video proxy calls.

## Verification

After a successful call, inspect `providerMetadata.gateway.routing` to see which model/provider actually served the request. For generated apps, log this metadata during development when adding fallbacks so stale or incompatible fallback IDs are caught quickly.
