// @ts-nocheck
// Example: Non-streaming chat completion via AI SDK
//
// Usage: bun example-chat-completion.ts <TOOLKIT_URL> <SECRET_KEY> [PROMPT]
//
// One-shot text generation using `generateText`. Use this for summarising,
// captioning, parsing, or any single-turn task that doesn't need streaming.

import { createGateway, generateText } from "ai";

const toolkitURL = process.argv[2];
const secretKey = process.argv[3];
const prompt = process.argv[4] ?? "Say hello in one word.";

if (!toolkitURL || !secretKey) {
  console.log("Usage: bun example-chat-completion.ts <TOOLKIT_URL> <SECRET_KEY> [PROMPT]");
  process.exit(1);
}

const gateway = createGateway({
  baseURL: `${toolkitURL}/v2/vercel/v3/ai`,
  apiKey: secretKey,
});

const { text, usage } = await generateText({
  model: gateway("anthropic/claude-haiku-4.5"),
  prompt,
});

console.log(`Response: ${text}`);
console.log(`Tokens: ${usage.inputTokens} in / ${usage.outputTokens} out`);
