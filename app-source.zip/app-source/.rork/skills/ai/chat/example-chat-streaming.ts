// @ts-nocheck
// Example: Streaming chat completion via AI SDK
//
// Usage: bun example-chat-streaming.ts <TOOLKIT_URL> <SECRET_KEY> [PROMPT]
//
// Streaming token-by-token output using `streamText`. The AI SDK handles SSE
// parsing internally — no need to manually walk `data: ` lines like the Swift
// raw-fetch sample does.
//
// In React Native, pair this with `expo/fetch` as the transport (the built-in
// fetch does not support streaming on native):
//   import { fetch as expoFetch } from "expo/fetch";
//   const gateway = createGateway({ ..., fetch: expoFetch });

import { createGateway, streamText } from "ai";

const toolkitURL = process.argv[2];
const secretKey = process.argv[3];
const prompt = process.argv[4] ?? "Write a short poem about a cat.";

if (!toolkitURL || !secretKey) {
  console.log("Usage: bun example-chat-streaming.ts <TOOLKIT_URL> <SECRET_KEY> [PROMPT]");
  process.exit(1);
}

const gateway = createGateway({
  baseURL: `${toolkitURL}/v2/vercel/v3/ai`,
  apiKey: secretKey,
});

const result = streamText({
  model: gateway("google/gemini-3.1-flash-lite-preview"),
  prompt,
});

// `textStream` yields token deltas as they arrive.
for await (const chunk of result.textStream) {
  process.stdout.write(chunk);
}
process.stdout.write("\n");

// After the stream finishes, usage is resolved on the result promise.
const usage = await result.usage;
console.log(`\nTokens: ${usage.inputTokens} in / ${usage.outputTokens} out`);
