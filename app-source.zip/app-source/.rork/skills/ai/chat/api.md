# POST /v2/vercel/v1/chat/completions

OpenAI-compatible chat completions. Supports text generation, streaming, vision, tool use, and **multimodal LLM image generation** (Gemini Nano Banana, GPT-5 image). Auth + URL structure are documented in `proxy.md`.

For the platform implementation see `chat/swift.md` (raw `URLSession`) or `chat/react-native.md` (Vercel AI SDK).

For production failover, read `model-fallbacks.md` and add **language-model** fallbacks via `providerOptions.gateway.models`. Do not use image-only or video models as fallbacks for this endpoint.

## Request body

| Field      | Type    | Required | Description                                                |
| ---------- | ------- | -------- | ---------------------------------------------------------- |
| model      | string  | yes      | Model ID (e.g. `"anthropic/claude-sonnet-5"`)              |
| messages   | array   | yes      | OpenAI-compatible message array                            |
| stream     | boolean | no       | Enable SSE streaming                                       |
| tools      | array   | no       | Function calling tool definitions                          |
| modalities | array   | no       | `["text", "image"]` for image output (Gemini image models) |

Any additional OpenAI-compatible fields (`temperature`, `max_tokens`, etc.) are passed through.

## File / Image / Audio Inputs

Use the raw endpoint metadata described in `model-discovery.md` to decide what the model accepts:

- `details.model.architecture.input_modalities` lists coarse inputs such as `"text"`, `"image"`, `"file"`, and, when available, `"audio"`.
- `details.model.capabilities` and `details.model.endpoints[]` carry provider-specific limits, supported parameters, and pricing.
- Do not infer supported MIME types from model family names. If the metadata is not specific enough, check the linked model page from `modelPageUrl`.

For generic file input, see `chat/example-chat-file-input.ts` for AI SDK usage and `chat/example-chat-file-input.swift` for raw Swift `URLSession` usage. For speech-to-text, prefer the `audio` skill unless the chosen chat model explicitly declares `"audio"` input and you need direct audio reasoning.

## Response

Standard OpenAI chat completion format:

```json
{ "choices": [{ "message": { "role": "assistant", "content": "..." } }] }
```

When `stream: true`, returns an SSE stream.

## Image Input + Image Output

When using a Gemini image model with `modalities: ["text", "image"]`, the response returns images in `choices[0].message.images[]` — **not** in `content`.

Each entry in `images[]` may be either a plain data URI string (`"data:image/png;base64,..."`) or an object (`{ type: "image_url", image_url: { url: "data:..." } }`), depending on the upstream provider. Handle both formats — extract the data URI from whichever form is returned.

For image input, read `image-input-requirements.md`. For model selection and endpoint routing, read `model-discovery.md` and `image-generation/api.md`.

## Error handling

See `error-handling/api.md` for the platform-agnostic HTTP status codes, retry strategy, idempotency keys, and `Retry-After` rules. Platform-specific request/retry wiring is in `error-handling/swift.md` or `error-handling/react-native.md`.
