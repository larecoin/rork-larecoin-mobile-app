// Example: Streaming chat completion via Rork proxy
//
// Usage: swift example-chat-streaming.swift <TOOLKIT_URL> <SECRET_KEY>
//
// Tokens arrive one-by-one as SSE events. Use URLSession.shared.bytes()
// to read them line-by-line as they arrive.

import Foundation

guard CommandLine.arguments.count >= 3 else {
    print("Usage: swift example-chat-streaming.swift <TOOLKIT_URL> <SECRET_KEY>")
    exit(1)
}

let toolkitURL = CommandLine.arguments[1]
let secretKey = CommandLine.arguments[2]
let vercelV1URL = "\(toolkitURL)/v2/vercel/v1"

// --- Error type with user-facing messages ---

enum StreamError: LocalizedError {
    case authError
    case insufficientBalance
    case rateLimited
    case serverError(Int)

    var errorDescription: String? {
        switch self {
        case .authError:           "AI features are currently unavailable. Please restart the app."
        case .insufficientBalance: "AI features are temporarily unavailable. Please try again later."
        case .rateLimited:         "Too many requests. Please wait a moment and try again."
        case .serverError:         "Something went wrong. Please try again."
        }
    }
}

// --- Response type ---

struct StreamDelta: Codable {
    struct Choice: Codable {
        struct Delta: Codable { let content: String? }
        let delta: Delta
    }
    let choices: [Choice]
}

// --- Request ---

let url = URL(string: "\(vercelV1URL)/chat/completions")!

let body: [String: Any] = [
    "model": "anthropic/claude-haiku-4.5",
    "messages": [["role": "user", "content": "Count from 1 to 5."]],
    "stream": true
]

var request = URLRequest(url: url)
request.httpMethod = "POST"
request.setValue("application/json", forHTTPHeaderField: "Content-Type")
request.setValue("Bearer \(secretKey)", forHTTPHeaderField: "Authorization")
request.httpBody = try JSONSerialization.data(withJSONObject: body)

let (bytes, response) = try await URLSession.shared.bytes(for: request)
let httpResponse = response as! HTTPURLResponse

switch httpResponse.statusCode {
case 200:  break
case 401:  throw StreamError.authError
case 402:  throw StreamError.insufficientBalance
case 429:  throw StreamError.rateLimited
default:   throw StreamError.serverError(httpResponse.statusCode)
}

// Parse SSE line-by-line as tokens arrive
var fullText = ""
for try await line in bytes.lines {
    let trimmed = line.trimmingCharacters(in: .whitespaces)

    guard trimmed.hasPrefix("data: ") else { continue }
    let json = String(trimmed.dropFirst(6))
    guard !json.isEmpty, json != "[DONE]" else { continue }

    guard let jsonData = json.data(using: .utf8) else { continue }
    if let chunk = try? JSONDecoder().decode(StreamDelta.self, from: jsonData),
       let content = chunk.choices.first?.delta.content {
        fullText += content
        print(content, terminator: "")
        fflush(stdout)
    }
}
print("\n---\nFull: \(fullText)")
