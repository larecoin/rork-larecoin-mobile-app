# Chat & Text Generation — React Native / TypeScript (AI SDK)

Read `chat/api.md` first for the endpoint contract, request body, and response shape. This file covers the Vercel AI SDK implementation — `generateText`, `streamText`, `useChat`, plus multimodal LLM image generation via the same SDK.

<references>
| Topic                         | URL                                                           |
| ----------------------------- | ------------------------------------------------------------- |
| Expo / React Native setup     | https://ai-sdk.dev/docs/getting-started/expo                  |
| `generateText`                | https://ai-sdk.dev/docs/reference/ai-sdk-core/generate-text   |
| `streamText`                  | https://ai-sdk.dev/docs/reference/ai-sdk-core/stream-text     |
| `generateObject`              | https://ai-sdk.dev/docs/reference/ai-sdk-core/generate-object |
| `useChat` hook                | https://ai-sdk.dev/docs/reference/ai-sdk-react/use-chat       |
| Tool use / function calling   | https://ai-sdk.dev/docs/ai-sdk-core/tools-and-tool-calling    |
| Web Search                    | https://vercel.com/docs/ai-gateway/capabilities/web-search    |
| Vercel AI Gateway model pages | https://vercel.com/ai-gateway/models                          |
</references>

## Setup

**Required installs:**

```bash
pnpm add ai zod
# Buffer polyfill is needed for base64 ↔ Uint8Array on native:
pnpm add buffer
```

`zod` is a hard peer of `ai`. Without it the SDK throws `Cannot find module 'zod/v4'` at import time on both Node and React Native runtimes — this is a runtime crash, not just a typecheck warning.

For streaming on native platforms (iOS / Android), polyfills are required. Fetch https://ai-sdk.dev/docs/getting-started/expo for the full setup.

1. **Use `expo/fetch`** instead of the built-in `fetch` for streaming responses.
2. **Install polyfills:** `pnpm add @ungap/structured-clone @stardazed/streams-text-encoding`.
3. **Import polyfills** at the top of the root `_layout.tsx` (before any AI SDK imports):

```ts
// polyfills.ts
import { Platform } from "react-native";
import structuredClone from "@ungap/structured-clone";

if (Platform.OS !== "web") {
  const setupPolyfills = async () => {
    const { polyfillGlobal } = await import("react-native/Libraries/Utilities/PolyfillFunctions");
    const { TextEncoderStream, TextDecoderStream } = await import("@stardazed/streams-text-encoding");

    if (!("structuredClone" in global)) {
      polyfillGlobal("structuredClone", () => structuredClone);
    }
    polyfillGlobal("TextEncoderStream", () => TextEncoderStream);
    polyfillGlobal("TextDecoderStream", () => TextDecoderStream);
  };
  setupPolyfills();
}

export {};
```

## Gateway

```ts
import { createGateway } from "ai";

const TOOLKIT_URL = process.env["EXPO_PUBLIC_TOOLKIT_URL"];
const SECRET_KEY = process.env["EXPO_PUBLIC_RORK_TOOLKIT_SECRET_KEY"];

const gateway = createGateway({
  baseURL: `${TOOLKIT_URL}/v2/vercel/v3/ai`,
  apiKey: SECRET_KEY,
});
```

### Choosing the right model factory

| AI SDK function                                | Factory method                               |
| ---------------------------------------------- | -------------------------------------------- |
| `generateText`, `streamText`, `generateObject` | `gateway(id)` or `gateway.languageModel(id)` |
| `embed`, `embedMany`                           | `gateway.textEmbeddingModel(id)`             |
| `experimental_generateImage`                   | `gateway.imageModel(id)`                     |
| `experimental_generateVideo`                   | `gateway.videoModel(id)`                     |

Passing `gateway(id)` (a LanguageModel) to `generateImage` / `generateVideo` blows up in `@ai-sdk/gateway` at runtime because the SDK tries to walk it as a chat-message prompt.

## Sample Code

End-to-end runnable scripts live next to this doc.

| File                              | Pattern                                   |
| --------------------------------- | ----------------------------------------- |
| `chat/example-chat-completion.ts` | `generateText` — one-shot text generation |
| `chat/example-chat-streaming.ts`  | `streamText` — token-level streaming      |
| `chat/example-chat-file-input.ts` | `generateText` with a file part           |

Image generation samples live in `image-generation/example-*.ts`. The bun-runnable scripts cover the canonical happy paths; the inline blocks below add the React Native scaffolding the bun samples skip (`Buffer` polyfill, `expo/fetch` transport, `useChat` wiring, `resizeForUpload`).

For file, image, PDF, and audio inputs, inspect `architecture.input_modalities` in the raw endpoint response before choosing the model and content parts. Prefer the `audio` skill for speech-to-text unless that metadata explicitly includes `"audio"` and the app needs the model to reason over audio directly.

## One-Shot Text Generation

For simple, single-turn generation (parsing, summarising, captioning) — no chat history needed. `generateText` and `streamText` follow the canonical bun samples; the RN-specific addition is `generateObject` for structured output via a zod schema:

```ts
import { generateObject } from "ai";
import { z } from "zod";

const { object } = await generateObject({
  model: gateway("anthropic/claude-sonnet-4"),
  schema: z.object({
    title: z.string(),
    tags: z.array(z.string()),
  }),
  prompt: "Generate metadata for a cooking app.",
});
```

## Chat UI with `useChat` Hook

For interactive chat UIs with streaming. Requires an Expo API route as the backend.

Fetch https://ai-sdk.dev/docs/getting-started/expo for the full setup pattern including `DefaultChatTransport`, `convertToModelMessages`, and `toUIMessageStreamResponse`.

Key points:

- Always use `expo/fetch` for the transport on native platforms (built-in `fetch` does not support streaming).
- The API route calls `streamText` with the gateway and returns `result.toUIMessageStreamResponse()`.
- Render messages by iterating `message.parts` (type `"text"`, `"tool-invocation"`, etc.).

```ts
// app/api/chat+api.ts
import { createGateway, streamText, UIMessage, convertToModelMessages } from "ai";

const TOOLKIT_URL = process.env["EXPO_PUBLIC_TOOLKIT_URL"];
const SECRET_KEY = process.env["EXPO_PUBLIC_RORK_TOOLKIT_SECRET_KEY"];

const gateway = createGateway({
  baseURL: `${TOOLKIT_URL}/v2/vercel/v3/ai`,
  apiKey: SECRET_KEY,
});

export async function POST(req: Request) {
  const { messages }: { messages: UIMessage[] } = await req.json();

  const result = streamText({
    model: gateway("anthropic/claude-sonnet-4"),
    messages: await convertToModelMessages(messages),
  });

  return result.toUIMessageStreamResponse({
    headers: {
      "Content-Type": "application/octet-stream",
      "Content-Encoding": "none",
    },
  });
}
```

```tsx
// Client component
import { useChat } from "@ai-sdk/react";
import { DefaultChatTransport } from "ai";
import { fetch as expoFetch } from "expo/fetch";

const { messages, error, sendMessage } = useChat({
  transport: new DefaultChatTransport({
    fetch: expoFetch as unknown as typeof globalThis.fetch,
    api: generateAPIUrl("/api/chat"),
  }),
  onError: (error) => console.error(error, "ERROR"),
});
```

For language-model image generation, see `image-generation/react-native.md`.

## Error Handling

See `error-handling/react-native.md` for AI SDK error patterns and `error-handling/api.md` for the HTTP status code matrix.
