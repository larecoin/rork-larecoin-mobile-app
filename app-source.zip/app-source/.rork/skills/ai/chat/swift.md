# Chat & Text Generation — Swift

Read `chat/api.md` first for the endpoint contract, request body, and response shape. This file covers the Swift `URLSession` implementation.

Swift cannot use the Vercel AI SDK — talk to the Rork proxy directly with `URLSession`. The proxy is OpenAI-compatible.

<references>
| Topic             | URL                                                                     |
| ----------------- | ----------------------------------------------------------------------- |
| Chat Completions  | https://platform.openai.com/docs/api-reference/chat/create              |
| Vercel AI Gateway | https://vercel.com/docs/ai-gateway                                      |
| Web Search        | https://vercel.com/docs/ai-gateway/capabilities/web-search              |
| Model Fallbacks   | https://vercel.com/docs/ai-gateway/models-and-providers/model-fallbacks |
</references>

## Sample Code

| File                                     | Description                                                        |
| ---------------------------------------- | ------------------------------------------------------------------ |
| `chat/example-chat-completion.swift`     | Non-streaming chat — one-shot generation (summarising, captioning) |
| `chat/example-chat-streaming.swift`      | Streaming chat — tokens arrive one-by-one via SSE                  |
| `chat/example-chat-file-input.swift`     | Non-streaming chat — local file input via OpenAI-compatible parts  |
| `swift/example-model-fallbacks.swift`    | Raw proxy model fallbacks for text, image, and video               |
| `swift/example-parse-sse-response.swift` | SSE response parsing — reusable pattern for all SSE endpoints      |

For web search, see `web-search/swift.md` + `web-search/example-web-search.swift`.

For file, image, PDF, and audio inputs, inspect `architecture.input_modalities` in the raw endpoint response before choosing the model and content parts. Prefer the `audio` skill for speech-to-text unless that metadata explicitly includes `"audio"` and the app needs the model to reason over audio directly.

<important>
For streaming, always parse SSE responses line-by-line. Do NOT use `replacingOccurrences(of: "data: ", with: "")` — see `swift/example-parse-sse-response.swift` for the correct approach.
</important>

For language-model image generation, see `image-generation/swift.md`.

## Error Handling

See `error-handling/swift.md` for the `sendWithRetry` wrapper and Swift-specific error mapping. The HTTP status code matrix lives in `error-handling/api.md`.
