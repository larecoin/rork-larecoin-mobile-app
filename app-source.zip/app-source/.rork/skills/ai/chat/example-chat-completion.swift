// Example: Non-streaming chat completion via Rork proxy
//
// Usage: swift example-chat-completion.swift <TOOLKIT_URL> <SECRET_KEY>

import Foundation

guard CommandLine.arguments.count >= 3 else {
    print("Usage: swift example-chat-completion.swift <TOOLKIT_URL> <SECRET_KEY>")
    exit(1)
}

let toolkitURL = CommandLine.arguments[1]
let secretKey = CommandLine.arguments[2]
let vercelV1URL = "\(toolkitURL)/v2/vercel/v1"

// --- Error type with user-facing messages ---

enum ChatError: LocalizedError {
    case authError
    case insufficientBalance
    case rateLimited
    case serverError(Int)

    var errorDescription: String? {
        switch self {
        case .authError:           "AI features are currently unavailable. Please restart the app."
        case .insufficientBalance: "AI features are temporarily unavailable. Please try again later."
        case .rateLimited:         "Too many requests. Please wait a moment and try again."
        case .serverError:         "Something went wrong. Please try again."
        }
    }
}

// --- Response type ---

struct ChatResponse: Codable {
    struct Choice: Codable {
        struct Message: Codable { let content: String? }
        let message: Message
    }
    let choices: [Choice]
}

// --- Request ---

let url = URL(string: "\(vercelV1URL)/chat/completions")!

let body: [String: Any] = [
    "model": "anthropic/claude-haiku-4.5",
    "messages": [
        ["role": "user", "content": "Say hello in one word."]
    ]
]

var request = URLRequest(url: url)
request.httpMethod = "POST"
request.setValue("application/json", forHTTPHeaderField: "Content-Type")
request.setValue("Bearer \(secretKey)", forHTTPHeaderField: "Authorization")
request.httpBody = try JSONSerialization.data(withJSONObject: body)

let (data, response) = try await URLSession.shared.data(for: request)
let httpResponse = response as! HTTPURLResponse

switch httpResponse.statusCode {
case 200:  break
case 401:  throw ChatError.authError
case 402:  throw ChatError.insufficientBalance
case 429:  throw ChatError.rateLimited
default:   throw ChatError.serverError(httpResponse.statusCode)
}

let result = try JSONDecoder().decode(ChatResponse.self, from: data)
print("Response: \(result.choices.first?.message.content ?? "(empty)")")
