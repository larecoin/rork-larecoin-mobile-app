---
name: play-store-assets
description: Prepare Google Play store listing graphics and screenshots. Read this for Android screenshots, feature graphics, app icons, preview videos, or listing-asset readiness.
---

# Play Store Assets

Use this skill to prepare, validate, and apply Android listing images through the typed, project-bound tools in `.rork/skills/play-store-connect/SKILL.md`. Never install a third-party CLI, request credentials, or claim prepared files were uploaded before the backend confirms the operation.

## Asset Boundary

- Listing assets are shared across tracks, including testing tracks.
- Preserve existing screenshots, icons, feature graphics, and videos unless the user explicitly asks to replace them.
- Prefer real screenshots from the current build over generated mockups.
- Do not invent tablet, Chromebook, TV, Wear OS, Automotive, or XR assets for an app that does not support those devices.

## Capture Flow

1. Inspect the app routes and choose flows that show the real product.
2. Try to read `.rork/skills/screenshots-v2/screenshots.md` when capturing from a running app. If it is available, follow it and call `captureAppScreenshots` with `device: "android"`. If it is unavailable, Android capture is not enabled for this session; ask the user to supply prepared screenshots instead of calling the iOS-only fallback with an Android device.
3. Record device type, orientation, locale, source screen, and any marketing treatment for each image.
4. Check for overlapping text, broken assets, fake UI, stale names, private data, and inconsistent status bars.
5. Produce an explicit proposed slot order without deleting or replacing remote assets.

## Core Requirements

App icon:

- 32-bit PNG with alpha.
- 512 x 512 px.
- At most 1024 KB.
- No badges or text implying rank, price, category, or endorsement.

Feature graphic:

- JPEG or 24-bit PNG without alpha.
- 1024 x 500 px.
- Communicate the app experience rather than duplicating the icon.
- Produced by `captureAppScreenshots` with `device: "android"` as `screenshots/android/<lang>/feature-graphic.png`, registered as a project asset. Never compose it by hand or with the image generator; if the deck has no feature graphic, call `captureAppScreenshots` again for `android` so the deck regenerates with one.

General listing screenshots:

- At least 2 screenshots across supported device types.
- Up to 8 per supported device type.
- JPEG or 24-bit PNG without alpha. The backend converts registered Android PNGs to 24-bit RGB at upload; do not flatten or re-encode screenshots yourself.
- Each dimension between 320 px and 3840 px.
- The longest side must not exceed twice the shortest side.

Device-specific gates:

- Large screens: at least 4 screenshots, 1080 to 7680 px, in 16:9 landscape or 9:16 portrait.
- Wear OS: at least 1 accurate 1:1 screenshot, minimum 384 x 384 px, with no transparency or masking.
- Android TV: at least 1 TV screenshot and a 1280 x 720 JPEG or 24-bit PNG TV banner.
- Automotive: when applicable, at least 2 portrait screenshots at 800 x 1280 and 2 landscape screenshots at 1024 x 768.
- Android XR: 4 to 8 PNG or JPEG screenshots, 8:5, recommended 3840 x 2400 and minimum 1920 x 1200.

## Publisher Image Slots

Track these Android Publisher image types explicitly:

- `phoneScreenshots`
- `sevenInchScreenshots`
- `tenInchScreenshots`
- `featureGraphic`
- `icon`
- `tvBanner`
- `tvScreenshots`
- `wearScreenshots`

The preview video is listing text metadata rather than an image slot. If a requested device class has no matching Android Publisher image type, prepare the asset and report that Play Console handling remains manual.

## Output

For each image, return the proposed locale, image type, project asset UUID, dimensions, format, order, and replacement intent. Report a preview video separately as localized listing metadata with its YouTube URL and replacement intent; do not assign it image dimensions, format, order, or an image type.

To apply images, read `.rork/skills/play-store-connect/SKILL.md`, call `listExistingAssets({ types: ["image"] })`, inspect the current slot with `listPlayListingImages`, then validate and commit the complete ordered replacement with `replacePlayListingImages`. Use the separate `clearPlayListingImages` tool only for an explicitly confirmed whole-slot deletion.
