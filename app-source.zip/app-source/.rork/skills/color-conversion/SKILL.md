---
name: Color Conversion
description: Convert colors between CSS formats, wide-gamut color spaces, and
  platform code values. Use this instead of guessing when translating Tailwind
  v4, shadcn, Lovable, screenshots, or design tokens.
---

# Color Conversion

Use this skill whenever you need to translate a color from one representation to another. Do not guess or use lookup tables when a token, CSS value, screenshot sample, or design note gives you a real color value.

The converter is backed by `colorjs.io`, including CSS Color 4 parsing and gamut mapping for display targets. Batch all related tokens in one call, then use the returned values literally in the app.

## When to use

- translating Lovable / Tailwind v4 / shadcn `@theme` tokens
- converting CSS variables such as `--background`, `--foreground`, `--primary`, or `--accent`
- converting hex, named CSS colors, `rgb()`, `hsl()`, `hwb()`, `lab()`, `lch()`, `oklab()`, `oklch()`, or `color(display-p3 ...)`
- producing SwiftUI `Color(...)`, UIKit `UIColor(...)`, hex, sRGB, OKLCH, Display P3, Lab/LCH, or other supported target values
- replacing hand-built conversion tables, approximate visual matching, or guessed colors


Use `convertColor` for all color conversions. It records explicit source -> target rows so agents can explain what changed without guessing.

## Available tools

### convertColor

Convert colors between common CSS color formats/spaces and platform code values.
Use this instead of guessing or hand-converting colors whenever you copy
design tokens, CSS variables, screenshots, Tailwind v4/shadcn tokens,
Lovable source colors, or wide-gamut CSS values into an app.

Supported inputs are any CSS colors Color.js can parse, including hex
(#RGB, #RGBA, #RRGGBB, #RRGGBBAA), named colors, transparent, rgb()/rgba(),
hsl()/hsla(), hwb(), lab(), lch(), oklab(), oklch(), and color(...)
functions such as color(display-p3 1 0 0).

Supported targets: hex, rgb, hsl, hwb, lab, lch, oklab, oklch, display-p3, a98-rgb, prophoto-rgb, rec2020, xyz-d50, xyz-d65, swiftui, uicolor.
Batch related tokens in one call. Output includes parsed source space,
per-target conversion rows, sRGB channels, hex, SwiftUI Color(...),
UIKit UIColor(...), optional static Color extension lines, and whether
a target needed gamut mapping.

```json
{"type":"object","properties":{"colors":{"minItems":1,"maxItems":100,"type":"array","items":{"type":"object","properties":{"name":{"description":"Optional semantic token name, e.g. primary, background, mutedForeground.","type":"string","minLength":1,"maxLength":80},"value":{"type":"string","minLength":1,"maxLength":240,"description":"Any CSS color Color.js can parse: hex, named colors, rgb(), hsl(), hwb(), lab(), lch(), oklab(), oklch(), or color(display-p3 ...)."},"targets":{"description":"Target formats/spaces. Defaults to hex, rgb, oklch, SwiftUI Color, and UIKit UIColor.","minItems":1,"maxItems":16,"type":"array","items":{"type":"string","enum":["hex","rgb","hsl","hwb","lab","lch","oklab","oklch","display-p3","a98-rgb","prophoto-rgb","rec2020","xyz-d50","xyz-d65","swiftui","uicolor"]}}},"required":["value"]},"description":"Colors to convert in one batch."},"precision":{"default":4,"description":"Decimal precision for CSS outputs.","type":"integer","minimum":0,"maximum":8}},"required":["colors"]}
```
