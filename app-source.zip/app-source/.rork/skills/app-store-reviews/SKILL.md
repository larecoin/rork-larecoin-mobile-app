---
name: app-store-reviews
description: Draft and post App Store customer review replies with the ASC CLI. Read this when the user asks to answer, reply to, or bulk respond to App Store reviews.
aliases:
  - app reviews
  - customer reviews
  - review replies
  - respond to reviews
---

# App Store Review Replies

Use this workflow to answer App Store customer reviews through the `asc` CLI.

## Setup

1. Read `.rork/skills/app-store-connect/SKILL.md` to unlock ASC tools.
2. Call `setupAsc({ requireAppleSession: false })`.
3. Use `app.ascAppId` from the setup result when present.
4. If setup returns no app, run `asc apps --output table` and ask the user which app to manage. Never guess the app ID.

## Find Reviews

For recent unresponded reviews:

```bash
asc reviews list --app "APP_ID" --response-state unresponded --include-response --sort -createdDate --limit 20 --output json
```

For low-rated unresponded reviews:

```bash
asc reviews list --app "APP_ID" --stars 1 --response-state unresponded --include-response --sort -createdDate --limit 20 --output json
```

For responded reviews:

```bash
asc reviews list --app "APP_ID" --response-state responded --include-response --sort -createdDate --limit 20 --output json
```

For all recent reviews:

```bash
asc reviews list --app "APP_ID" --response-state any --include-response --sort -createdDate --limit 20 --output json
```

To check one review before replying:

```bash
asc reviews view --id "REVIEW_ID" --output json
asc reviews response for-review --review-id "REVIEW_ID" --output json
```

## Draft Replies

- Show the user the review ID, rating, title, body, reviewer nickname, territory, and created date for every review you plan to answer.
- Treat reviews with an existing published response as already handled unless the user explicitly asks to replace or delete a response.
- Draft short, professional responses that address the specific feedback.
- Do not ask users to change their rating.
- Do not include promotional copy, secrets, internal ticket links, private user data, or blame.
- Only mention a bug fix, version, refund, or timeline when the user or repo evidence confirms it.

## Approval Gate

Developer responses are public App Store content. Before posting, show the exact response text and target review ID(s), then wait for explicit user approval.

If the user asked for drafts only, stop after presenting drafts.

## Post One Reply

Check for an existing response first:

```bash
asc reviews response for-review --review-id "REVIEW_ID" --output json
```

If no response exists and the user approved the exact text:

```bash
asc reviews respond --review-id "REVIEW_ID" --response "Thanks for your feedback!" --output json
```

After posting, report the response ID and state.

## Multiple Replies

Use a grouped batch only after the user approves the exact response text. First write a local plan file and show it to the user:

```json
{
  "replies": [
    {
      "response": "Thanks for reporting this. We fixed the issue in the latest update.",
      "reviewIds": ["REVIEW_ID_1", "REVIEW_ID_2"]
    }
  ]
}
```

Dry-run the plan before any write:

```bash
asc reviews respond-batch --app "APP_ID" --file /tmp/review-replies.json --response-state unresponded --dry-run --output json
```

After the dry run matches the user-approved text, post with skip protection:

```bash
asc reviews respond-batch --app "APP_ID" --file /tmp/review-replies.json --response-state unresponded --skip-existing --output json --confirm
```

If the user approves only one reply from the batch, post it with the single-reply flow:

```bash
asc reviews response for-review --review-id "REVIEW_ID_1" --output json
asc reviews respond --review-id "REVIEW_ID_1" --response "Thanks for reporting this. We fixed the issue in the latest update." --output json
```

If any review fails or is skipped, summarize each review ID with its status and reason.
