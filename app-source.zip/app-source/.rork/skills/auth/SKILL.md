---
name: auth
description: Add user authentication with Google or Apple sign-in using Rork
  Auth. Use when the user wants login, sign-in, sign-up, sessions, protected
  routes, profiles, or user accounts.
aliases:
  - login
  - sign up
  - signup
  - authentication
  - session
  - user account
  - profile screen
  - protected route
---

# Rork Auth

Rork Auth provides OAuth authentication with Google and Apple sign-in for your app. The app talks directly to Rork's auth API — no backend needed.

## Choosing an Auth System

A project uses exactly ONE identity model — pick before writing any auth code:

- **Google or Apple sign-in** → Rork Auth (this skill). Zero configuration.
- **Email/password, magic links, phone OTP, or other providers** → Rork Auth does NOT support these. Use **native Supabase Auth** instead — read the backend skill's `supabase/native-auth.md` and skip this skill entirely.


**Never mix the two models.** Do not bolt `supabase.auth.signUp` / `signInWithPassword` onto an app that uses Rork Auth, and never create a second Supabase client to bypass the `accessToken` restriction — the error `supabase.auth.signUp is not possible` means the project is in Rork Auth mode, not that you should work around the client. Mixing produces two incompatible user-ID systems in the same tables and silently breaks RLS.

If the user asks for email/password on a project that already uses Rork Auth, tell them the trade-off (existing sign-ins won't carry over) and, if they confirm, switch the whole app: call the backend skill's `disableRorkAuth`, rewrite RLS from `user_id()` to `auth.uid()`, and replace the auth flow with `native-auth.md`'s.

## Auth Flow (all platforms)

1. User taps "Sign in with Google/Apple"
2. App opens an in-app browser (or `ASWebAuthenticationSession` on Swift) for OAuth
3. After login, the browser redirects back to the app with an authorization code
4. App exchanges the code for tokens directly with Rork
5. App stores tokens securely and the user is logged in


Access tokens are short-lived JWTs (1 hour). Refresh tokens are used to get new access tokens.

## Setup Checklist (all platforms)

1. [ ] Call the `getOrCreateAuthConfig` tool to provision auth keys and set environment variables
2. [ ] Install the platform's auth/secure-storage dependencies
3. [ ] Register the deep-link callback (URL scheme / entitlement)
4. [ ] Create the auth state holder (`AuthProvider` + `useAuth` on RN; `AuthManager` on Swift)
5. [ ] Wire the auth holder into the app's root
6. [ ] Add the sign-in UI


## Provisioning

Call the `getOrCreateAuthConfig` tool. It provisions the app's public key and auth URL, and sets these environment variables. If the project has a Supabase backend, it also registers Rork Auth on it (so `user_id()` works in RLS) — watch the tool output: if it reports the backend already uses native Supabase Auth, stop and resolve the model conflict with the user instead of wiring Rork JWTs into Supabase.

| Variable                    | Purpose                                         |
| --------------------------- | ----------------------------------------------- |
| `EXPO_PUBLIC_RORK_APP_KEY`  | Public client app key — safe to embed in client |
| `EXPO_PUBLIC_RORK_AUTH_URL` | Base URL for Rork's auth API                    |
| `EXPO_PUBLIC_PROJECT_ID`    | Project ID — used to derive the callback scheme |

The same tool also provisions the server-side envs `RORK_AUTH_SECRET_KEY` and
`RORK_AUTH_URL` onto the project — backend/functions code reads them from its
environment. Only Rork can mint these values: never request them from the user
(`requestEnvs` rejects them), and never write them into client code.

On projects with a Supabase backend, run the backend skill's
`syncEdgeFunctionSecrets` tool after provisioning: already-deployed Edge
Functions only receive project envs through that sync (new deploys warn when a
referenced env is missing, but nothing reconciles functions already deployed).

The callback URL scheme on every platform is `rork-<EXPO_PUBLIC_PROJECT_ID>://auth/callback`.

## Endpoints

| Method | Path              | Purpose                                                 |
| ------ | ----------------- | ------------------------------------------------------- |
| POST   | `/oauth/initiate` | Get the OAuth authorization URL for the chosen provider |
| POST   | `/oauth/token`    | Exchange the returned authorization code for tokens     |
| POST   | `/oauth/refresh`  | Refresh an expired access token                         |

All three accept JSON. `/oauth/initiate` takes `{ app_key, provider, code_challenge, target, env, app_path? }` and returns `{ auth_url, state }`. `/oauth/token` takes `{ app_key, code, code_verifier }` and returns `{ access_token, refresh_token, user }`. `/oauth/refresh` takes `{ app_key, refresh_token }` and returns `{ access_token, expires_in }`.

`provider` is either `"google"` or `"apple"`. `target` is `"rn"` for React Native, `"swift"` for Swift, or `"web"` for Vite + React web apps. `env` is `"native"` on device, `"preview"` for both the React Native web preview and the Vite web preview (inside the Rork iframe), `"simulator"` on the iOS Simulator, or `"production"` for a deployed Vite web app. `app_path` is optional and only used when `env === "preview"` — it selects the preview subdomain (e.g. `"web"` for Vite, `"expo"` for RN, which is the default fallback).

## Authenticated API Requests

Send the stored access token as a bearer token to your app's backend:

```
Authorization: Bearer <access_token>

```

## Platform Implementation Guides

The implementation differs per platform — read the file matching the app you're working in:

| File              | When to use                                                                      |
| ----------------- | -------------------------------------------------------------------------------- |
| `react-native.md` | React Native / Expo apps (uses `expo-web-browser` + `expo-secure-store`)         |
| `swift.md`        | Swift / iOS apps (uses `ASWebAuthenticationSession` + Keychain)                  |
| `web.md`          | Vite + React web apps (uses `window.open` / top-level redirect + `localStorage`) |

## Important Notes

- The app talks directly to Rork's auth API — no backend auth routes needed.
- Always use HTTPS in production.
- Keychain / SecureStore data persists across app reinstalls; call `signOut()` if needed during development.


## Available tools

### getOrCreateAuthConfig

Create or retrieve the auth configuration (public app key and auth URL) for this app. Use this when setting up Rork Auth for the first time. The returned values are automatically stored as environment variables.

```json
{"type":"object","properties":{}}
```
