# Rork Auth — Vite + React Web

Use this guide for Vite + React web apps. The contract (endpoints, env vars, token flow) is documented in `SKILL.md`.

`target: "web"` is sent to `/oauth/initiate`. The request also includes:

- `env: "preview"` and `app_path: "web"` when the app is running inside the Rork preview iframe (detect via `window.parent !== window`). The backend redirects the OAuth popup to the app's `--web` preview subdomain, which Rork's `/oauth/callback` intercepts and uses `postMessage` to relay the `code` back to the iframe.
- `env: "production"` when the app is running standalone at `https://{slug}.rork.app`. The backend redirects to the app's own `/auth/callback` route.

There is no native deep-link / URL scheme for the web. Tokens live in `localStorage`.

## 1. Configure Vite for `EXPO_PUBLIC_*` env vars

The auth tool writes `EXPO_PUBLIC_RORK_APP_KEY` and `EXPO_PUBLIC_RORK_AUTH_URL` to `.env`. Vite only exposes vars matching its `envPrefix`. Add `"EXPO_PUBLIC_"` to the prefix list in `vite.config.ts` so the app can read them:

```ts
export default defineConfig(({ mode }) => ({
  // ...existing config...
  envPrefix: ["VITE_", "EXPO_PUBLIC_"],
}));
```

If `vite.config.ts` already has an `envPrefix`, append `"EXPO_PUBLIC_"` to it. Otherwise add the line as shown.

Read keys with `import.meta.env.EXPO_PUBLIC_RORK_APP_KEY` and `import.meta.env.EXPO_PUBLIC_RORK_AUTH_URL`.

## 2. No dependencies to install

PKCE uses the built-in `crypto.subtle` API. Popup/redirect uses `window.open` / `window.location`. Tokens go in `localStorage`. No new packages.

## 3. Create the `useAuth` hook

Create `src/hooks/useAuth.tsx`:

```tsx
import { createContext, useCallback, useContext, useEffect, useRef, useState, type ReactNode } from "react";

const AUTH_URL = import.meta.env.EXPO_PUBLIC_RORK_AUTH_URL as string;
const APP_KEY = import.meta.env.EXPO_PUBLIC_RORK_APP_KEY as string;

const ACCESS_TOKEN_KEY = "rork:access_token";
const REFRESH_TOKEN_KEY = "rork:refresh_token";
const CODE_VERIFIER_KEY = "rork:pkce_verifier";

function generateCodeVerifier(): string {
  const bytes = new Uint8Array(32);
  crypto.getRandomValues(bytes);
  return btoa(String.fromCharCode(...bytes))
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/, "");
}

async function generateCodeChallenge(verifier: string): Promise<string> {
  const data = new TextEncoder().encode(verifier);
  const hash = await crypto.subtle.digest("SHA-256", data);
  return btoa(String.fromCharCode(...new Uint8Array(hash)))
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/, "");
}

interface User {
  id: string;
  email: string;
  name?: string;
  picture?: string;
}

/** Decode the JWT payload to extract user info and check expiration. */
function userFromToken(token: string): User | null {
  try {
    const parts = token.split(".");
    if (parts.length !== 3) return null;

    const base64 = parts[1].replace(/-/g, "+").replace(/_/g, "/");
    const payload = JSON.parse(atob(base64));

    if (payload.exp && payload.exp * 1000 < Date.now()) {
      return null;
    }

    return {
      id: payload.sub,
      email: payload.email ?? "",
      name: payload.name,
      picture: payload.picture,
    };
  } catch {
    return null;
  }
}

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  isSigningIn: boolean;
  error: string | null;
  signIn: (provider: "google" | "apple") => Promise<void>;
  signOut: () => void;
  clearError: () => void;
  /**
   * Exchanges a `code` for tokens. The `/auth/callback` route calls this when
   * a top-level redirect returns from Rork OAuth in production.
   */
  exchangeCode: (code: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSigningIn, setIsSigningIn] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const messageListenerRef = useRef<((event: MessageEvent) => void) | null>(null);

  const clearError = useCallback(() => setError(null), []);

  useEffect(() => {
    void checkAuth();
  }, []);

  useEffect(() => {
    // Detach any popup listener when the provider unmounts.
    return () => {
      if (messageListenerRef.current) {
        window.removeEventListener("message", messageListenerRef.current);
        messageListenerRef.current = null;
      }
    };
  }, []);

  async function checkAuth() {
    try {
      const accessToken = localStorage.getItem(ACCESS_TOKEN_KEY);
      if (accessToken) {
        const decoded = userFromToken(accessToken);
        if (decoded) {
          setUser(decoded);
          return;
        }
      }
      // No usable access token — try refresh.
      if (localStorage.getItem(REFRESH_TOKEN_KEY)) {
        await refreshToken();
      }
    } finally {
      setIsLoading(false);
    }
  }

  async function exchangeCode(code: string) {
    const verifier = localStorage.getItem(CODE_VERIFIER_KEY);
    if (!verifier) {
      setError("Missing PKCE verifier — sign in again.");
      return;
    }
    localStorage.removeItem(CODE_VERIFIER_KEY);

    const response = await fetch(`${AUTH_URL}/oauth/token`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ app_key: APP_KEY, code, code_verifier: verifier }),
    });

    if (!response.ok) {
      const body = await response.json().catch(() => ({}));
      setError(body.error || `Sign in failed (${response.status})`);
      return;
    }

    const { access_token, refresh_token, user: userData } = await response.json();
    localStorage.setItem(ACCESS_TOKEN_KEY, access_token);
    localStorage.setItem(REFRESH_TOKEN_KEY, refresh_token);
    setUser(userData);
  }

  async function signIn(provider: "google" | "apple") {
    setIsSigningIn(true);
    setError(null);
    try {
      const verifier = generateCodeVerifier();
      const challenge = await generateCodeChallenge(verifier);
      // Persist across the OAuth roundtrip: in preview the popup loses its
      // reference to in-memory state when it closes; in production the
      // top-level redirect navigates away and back.
      localStorage.setItem(CODE_VERIFIER_KEY, verifier);

      const isPreview = window.parent !== window;
      const body: Record<string, unknown> = {
        app_key: APP_KEY,
        provider,
        code_challenge: challenge,
        target: "web",
        env: isPreview ? "preview" : "production",
      };
      if (isPreview) body.app_path = "web";

      const response = await fetch(`${AUTH_URL}/oauth/initiate`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });

      if (!response.ok) {
        localStorage.removeItem(CODE_VERIFIER_KEY);
        const errorBody = await response.json().catch(() => ({}));
        setError(errorBody.error || `Sign in failed (${response.status})`);
        return;
      }

      const { auth_url } = await response.json();

      if (isPreview) {
        // Preview iframe: open a popup; Rork's /oauth/callback posts the code
        // back to this window when OAuth completes.
        const popup = window.open(auth_url, "_blank", "width=500,height=650");
        if (!popup) {
          setError("Popup blocked — please allow popups for this site.");
          localStorage.removeItem(CODE_VERIFIER_KEY);
          return;
        }

        await new Promise<void>((resolve) => {
          const onMessage = async (event: MessageEvent) => {
            if (event.data?.type !== "rork_auth_callback") return;
            window.removeEventListener("message", onMessage);
            messageListenerRef.current = null;
            clearInterval(pollTimer);
            const code = event.data.code;
            if (code) {
              await exchangeCode(code);
            }
            resolve();
          };
          messageListenerRef.current = onMessage;
          window.addEventListener("message", onMessage);

          // Detect manual popup close so the sign-in spinner clears.
          const pollTimer = setInterval(() => {
            if (popup.closed) {
              clearInterval(pollTimer);
              window.removeEventListener("message", onMessage);
              messageListenerRef.current = null;
              localStorage.removeItem(CODE_VERIFIER_KEY);
              resolve();
            }
          }, 500);
        });
      } else {
        // Production: top-level redirect. The /auth/callback route picks up
        // the returned `?code=` and calls exchangeCode().
        window.location.href = auth_url;
      }
    } catch (err) {
      console.error("Sign in failed:", err);
      setError(err instanceof Error ? err.message : "Sign in failed");
      localStorage.removeItem(CODE_VERIFIER_KEY);
    } finally {
      setIsSigningIn(false);
    }
  }

  async function refreshToken() {
    const stored = localStorage.getItem(REFRESH_TOKEN_KEY);
    if (!stored) {
      signOut();
      return;
    }

    const response = await fetch(`${AUTH_URL}/oauth/refresh`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ app_key: APP_KEY, refresh_token: stored }),
    });

    if (!response.ok) {
      signOut();
      return;
    }

    const { access_token } = await response.json();
    localStorage.setItem(ACCESS_TOKEN_KEY, access_token);
    setUser(userFromToken(access_token));
  }

  function signOut() {
    localStorage.removeItem(ACCESS_TOKEN_KEY);
    localStorage.removeItem(REFRESH_TOKEN_KEY);
    localStorage.removeItem(CODE_VERIFIER_KEY);
    setUser(null);
  }

  return (
    <AuthContext.Provider value={{ user, isLoading, isSigningIn, error, signIn, signOut, clearError, exchangeCode }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within AuthProvider");
  }
  return context;
}
```

## 4. Wrap the app with `AuthProvider`

In `src/main.tsx` (or whichever file mounts your root component):

```tsx
import { AuthProvider } from "@/hooks/useAuth";

createRoot(document.getElementById("root")!).render(
  <AuthProvider>
    <App />
  </AuthProvider>,
);
```

## 5. Add a `/auth/callback` route (production only)

Production sign-in does a top-level redirect to Rork OAuth, which redirects back to your app's `/auth/callback` with `?code=...`. The preview popup flow does **not** hit this route — Rork's backend intercepts the popup callback and uses `postMessage`. Wire it up anyway so production works:

```tsx
// src/pages/AuthCallback.tsx
import { useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";

export default function AuthCallback() {
  const { exchangeCode } = useAuth();
  const navigate = useNavigate();
  const ran = useRef(false);

  useEffect(() => {
    if (ran.current) return;
    ran.current = true;
    const code = new URLSearchParams(window.location.search).get("code");
    if (!code) {
      navigate("/", { replace: true });
      return;
    }
    void exchangeCode(code).finally(() => navigate("/", { replace: true }));
  }, [exchangeCode, navigate]);

  return <div>Signing in…</div>;
}
```

Register the route at `/auth/callback` in your router (the exact wiring depends on your router; React Router example above).

## 6. Sign-in UI

```tsx
import { useAuth } from "@/hooks/useAuth";

export function SignInScreen() {
  const { user, isLoading, isSigningIn, error, signIn, signOut, clearError } = useAuth();

  if (isLoading) return <div>Loading…</div>;

  if (!user) {
    return (
      <div className="flex flex-col items-center gap-3">
        <h1 className="text-2xl font-semibold">Welcome</h1>
        {error && (
          <div className="rounded bg-red-100 text-red-700 px-3 py-2 flex items-center gap-2">
            <span>{error}</span>
            <button onClick={clearError} className="underline">
              Dismiss
            </button>
          </div>
        )}
        <button
          onClick={() => signIn("google")}
          disabled={isSigningIn}
          className="bg-blue-600 text-white px-4 py-2 rounded disabled:opacity-60"
        >
          Sign in with Google
        </button>
        <button
          onClick={() => signIn("apple")}
          disabled={isSigningIn}
          className="bg-black text-white px-4 py-2 rounded disabled:opacity-60"
        >
          Sign in with Apple
        </button>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center gap-3">
      <p>Welcome, {user.name || user.email}</p>
      <button onClick={signOut} className="bg-gray-700 text-white px-4 py-2 rounded">
        Sign out
      </button>
    </div>
  );
}
```

## Authenticated API Requests

```ts
export async function fetchWithAuth(url: string, options: RequestInit = {}) {
  const accessToken = localStorage.getItem("rork:access_token");
  return fetch(url, {
    ...options,
    headers: {
      ...options.headers,
      ...(accessToken ? { Authorization: `Bearer ${accessToken}` } : {}),
    },
  });
}
```

## Notes

- **Preview vs production detection** uses `window.parent !== window`. The Rork preview always runs the app inside an iframe; deployed apps run at the top level.
- **Tokens in `localStorage`** are convenient but vulnerable to XSS. Treat any XSS hole as an auth bypass. For higher-security needs, swap to short-lived in-memory access tokens plus a refresh-token cookie issued by a small backend.
- **Popup blockers**: most browsers allow `window.open` from a click handler even with an `await` before it, but Safari/Firefox can be strict. If users report blocked popups in preview, the click handler can open a blank popup synchronously and then `popup.location = auth_url` after `/oauth/initiate` returns.
- **Production redirect URI** is `https://{slug}.rork.app/auth/callback`. Custom domains are not yet supported.
