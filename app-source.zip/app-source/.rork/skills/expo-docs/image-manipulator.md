# ImageManipulator

_A library that provides an API for image manipulation on the local file system._

Available on platforms android, ios, tvos, web

`expo-image-manipulator` provides an API to modify images stored on the local file system.

## Installation

```bash
$ bunx expo install expo-image-manipulator
```

If you are installing this in an existing React Native app, make sure to install `expo` in your project.

## Usage

This will first rotate the image 90 degrees clockwise, then flip the rotated image vertically and save it as a PNG.

```jsx
import { useState } from "react";
import { Button, Image, StyleSheet, View } from "react-native";
import { Asset } from "expo-asset";
import { FlipType, SaveFormat, useImageManipulator } from "expo-image-manipulator";

const IMAGE = Asset.fromModule(require("./assets/snack-icon.png"));

export default function App() {
  const [image, setImage] = useState(IMAGE);
  const context = useImageManipulator(IMAGE.uri);

  const rotate90andFlip = async () => {
    context.rotate(90).flip(FlipType.Vertical);
    const image = await context.renderAsync();
    const result = await image.saveAsync({
      format: SaveFormat.PNG,
    });

    setImage(result);
  };

  return (
    <View style={styles.container}>
      <View style={styles.imageContainer}>
        <Image source={{ uri: image.localUri || image.uri }} style={styles.image} />
      </View>
      <Button title="Rotate and Flip" onPress={rotate90andFlip} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
  },
  imageContainer: {
    marginVertical: 20,
    alignItems: "center",
    justifyContent: "center",
  },
  image: {
    width: 300,
    height: 300,
    resizeMode: "contain",
  },
});
```

## API

```js
import * as ImageManipulator from "expo-image-manipulator";
```

## API: expo-image-manipulator

### ImageManipulator (_Class_)

#### Methods

- `addListener(eventName: EventName, listener: indexedAccess): EventSubscription`
  Adds a listener for the given event name.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `eventName` | EventName | - |
  | `listener` | indexedAccess | - |

- `emit(eventName: EventName, args: Parameters<indexedAccess>)`
  Synchronously calls all the listeners attached to that specific event.
  The event can include any number of arguments that will be passed to the listeners.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `eventName` | EventName | - |
  | `args` | Parameters<indexedAccess> | - |

- `listenerCount(eventName: EventName): number`
  Returns a number of listeners added to the given event.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `eventName` | EventName | - |

- `manipulate(source: string | SharedRef<'image'>): ImageManipulatorContext`
  Loads an image from the given URI and creates a new image manipulation context.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `source` | string \| SharedRef<'image'> | - |

- `removeAllListeners(eventName: never)`
  Removes all listeners for the given event name.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `eventName` | never | - |

- `removeListener(eventName: EventName, listener: indexedAccess)`
  Removes a listener for the given event name.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `eventName` | EventName | - |
  | `listener` | indexedAccess | - |

- `startObserving(eventName: EventName)`
  Function that is automatically invoked when the first listener for an event with the given name is added.
  Override it in a subclass to perform some additional setup once the event started being observed.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `eventName` | EventName | - |

- `stopObserving(eventName: EventName)`
  Function that is automatically invoked when the last listener for an event with the given name is removed.
  Override it in a subclass to perform some additional cleanup once the event is no longer observed.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `eventName` | EventName | - |

### ImageManipulatorContext (_Class_)

A context for an image manipulation. It provides synchronous, chainable functions that schedule transformations on the original image to the background thread.
Use an asynchronous [`renderAsync`](#renderasync) to await for all transformations to finish and access the final image.

#### Methods

- `addListener(eventName: EventName, listener: indexedAccess): EventSubscription`
  Adds a listener for the given event name.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `eventName` | EventName | - |
  | `listener` | indexedAccess | - |

- `crop(rect: { height: number; originX: number; originY: number; width: number }): ImageManipulatorContext`
  Crops the image to the given rectangle's origin and size.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `rect` | { height: number; originX: number; originY: number; width: number } | Fields specify top-left corner and dimensions of a crop rectangle. |

- `emit(eventName: EventName, args: Parameters<indexedAccess>)`
  Synchronously calls all the listeners attached to that specific event.
  The event can include any number of arguments that will be passed to the listeners.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `eventName` | EventName | - |
  | `args` | Parameters<indexedAccess> | - |

- `extent(options: { backgroundColor: null | string; height: number; originX: number; originY: number; width: number }): ImageManipulatorContext`
  Set the image size and offset. If the image is enlarged, unfilled areas are set to the `backgroundColor`.
  To position the image, use `originX` and `originY`.
  Available on platform: web
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `options` | { backgroundColor: null \| string; height: number; originX: number; originY: number; width: number } | - |

- `flip(flipType: 'vertical' | 'horizontal'): ImageManipulatorContext`
  Flips the image vertically or horizontally.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `flipType` | 'vertical' \| 'horizontal' | An axis on which image will be flipped. Only one flip per transformation is available. If you<br>want to flip according to both axes then provide two separate transformations. |

- `listenerCount(eventName: EventName): number`
  Returns a number of listeners added to the given event.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `eventName` | EventName | - |

- `release()`
  A function that detaches the JS and native objects to let the native object deallocate
  before the JS object gets deallocated by the JS garbage collector. Any subsequent calls to native
  functions of the object will throw an error as it is no longer associated with its native counterpart.

  In most cases, you should never need to use this function, except some specific performance-critical cases when
  manual memory management makes sense and the native object is known to exclusively retain some native memory
  (such as binary data or image bitmap). Before calling this function, you should ensure that nothing else will use
  this object later on. Shared objects created by React hooks are usually automatically released in the effect's cleanup phase,
  for example: `useVideoPlayer()` from `expo-video` and `useImage()` from `expo-image`.

- `removeAllListeners(eventName: never)`
  Removes all listeners for the given event name.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `eventName` | never | - |

- `removeListener(eventName: EventName, listener: indexedAccess)`
  Removes a listener for the given event name.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `eventName` | EventName | - |
  | `listener` | indexedAccess | - |

- `renderAsync(): Promise<ImageRef>`
  Awaits for all manipulation tasks to finish and resolves with a reference to the resulted native image.

- `reset(): ImageManipulatorContext`
  Resets the manipulator context to the originally loaded image.

- `resize(size: { height: null | number; width: null | number }): ImageManipulatorContext`
  Resizes the image to the given size.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `size` | { height: null \| number; width: null \| number } | Values correspond to the result image dimensions. If you specify only one value, the other will<br>be calculated automatically to preserve image ratio. |

- `rotate(degrees: number): ImageManipulatorContext`
  Rotates the image by the given number of degrees.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `degrees` | number | Degrees to rotate the image. Rotation is clockwise when the value is positive and<br>counter-clockwise when negative. |

- `startObserving(eventName: EventName)`
  Function that is automatically invoked when the first listener for an event with the given name is added.
  Override it in a subclass to perform some additional setup once the event started being observed.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `eventName` | EventName | - |

- `stopObserving(eventName: EventName)`
  Function that is automatically invoked when the last listener for an event with the given name is removed.
  Override it in a subclass to perform some additional cleanup once the event is no longer observed.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `eventName` | EventName | - |

### ImageRef (_Class_)

A reference to a native instance of the image.

#### Properties

- `height` (number)
  Height of the image.
- `nativeRefType` (string)
  The type of the native reference.
- `width` (number)
  Width of the image.

#### Methods

- `addListener(eventName: EventName, listener: indexedAccess): EventSubscription`
  Adds a listener for the given event name.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `eventName` | EventName | - |
  | `listener` | indexedAccess | - |

- `emit(eventName: EventName, args: Parameters<indexedAccess>)`
  Synchronously calls all the listeners attached to that specific event.
  The event can include any number of arguments that will be passed to the listeners.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `eventName` | EventName | - |
  | `args` | Parameters<indexedAccess> | - |

- `listenerCount(eventName: EventName): number`
  Returns a number of listeners added to the given event.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `eventName` | EventName | - |

- `release()`
  A function that detaches the JS and native objects to let the native object deallocate
  before the JS object gets deallocated by the JS garbage collector. Any subsequent calls to native
  functions of the object will throw an error as it is no longer associated with its native counterpart.

  In most cases, you should never need to use this function, except some specific performance-critical cases when
  manual memory management makes sense and the native object is known to exclusively retain some native memory
  (such as binary data or image bitmap). Before calling this function, you should ensure that nothing else will use
  this object later on. Shared objects created by React hooks are usually automatically released in the effect's cleanup phase,
  for example: `useVideoPlayer()` from `expo-video` and `useImage()` from `expo-image`.

- `removeAllListeners(eventName: never)`
  Removes all listeners for the given event name.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `eventName` | never | - |

- `removeListener(eventName: EventName, listener: indexedAccess)`
  Removes a listener for the given event name.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `eventName` | EventName | - |
  | `listener` | indexedAccess | - |

- `saveAsync(options?: SaveOptions): Promise<ImageResult>`
  Saves the image to the file system in the cache directory.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `options` _(optional)_ | SaveOptions | A map defining how modified image should be saved. |

- `startObserving(eventName: EventName)`
  Function that is automatically invoked when the first listener for an event with the given name is added.
  Override it in a subclass to perform some additional setup once the event started being observed.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `eventName` | EventName | - |

- `stopObserving(eventName: EventName)`
  Function that is automatically invoked when the last listener for an event with the given name is removed.
  Override it in a subclass to perform some additional cleanup once the event is no longer observed.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `eventName` | EventName | - |

### Hooks

#### useImageManipulator (_Function_)

- `useImageManipulator(source: string | SharedRef<'image'>): ImageManipulatorContext`
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `source` | string \| SharedRef<'image'> | - |

### ImageManipulator Methods

#### manipulateAsync (_Function_)

- `manipulateAsync(uri: string, actions: Action[], saveOptions: SaveOptions): Promise<ImageResult>`
  Manipulate the image provided via `uri`. Available modifications are rotating, flipping (mirroring),
  resizing and cropping. Each invocation results in a new file. With one invocation you can provide
  a set of actions to perform over the image. Overwriting the source file would not have an effect
  in displaying the result as images are cached.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `uri` | string | URI of the file to manipulate. Should be on the local file system or a base64 data URI. |
  | `actions` | Action[] | An array of objects representing manipulation options. Each object should have<br>**only one** of the keys that corresponds to specific transformation. |
  | `saveOptions` | SaveOptions | A map defining how modified image should be saved. |
  Returns: Promise which fulfils with [`ImageResult`](#imageresult) object.

### Types

#### Action (_Type_)

Type: ActionResize | ActionRotate | ActionFlip | ActionCrop | ActionExtent

#### ActionCrop (_Type_)

| Property | Type                                                                | Description                                                        |
| -------- | ------------------------------------------------------------------- | ------------------------------------------------------------------ |
| `crop`   | { height: number; originX: number; originY: number; width: number } | Fields specify top-left corner and dimensions of a crop rectangle. |

#### ActionExtent (_Type_)

| Property | Type                                                                                                 | Description                                                                                                                                                                                 |
| -------- | ---------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `extent` | { backgroundColor: string \| null; height: number; originX: number; originY: number; width: number } | Set the image size and offset. If the image is enlarged, unfilled areas are set to the `backgroundColor`.<br>To position the image, use `originX` and `originY`. Available on platform: web |

#### ActionFlip (_Type_)

| Property | Type     | Description                                                                                                                                                                     |
| -------- | -------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `flip`   | FlipType | An axis on which image will be flipped. Only one flip per transformation is available. If you<br>want to flip according to both axes then provide two separate transformations. |

#### ActionResize (_Type_)

| Property | Type                              | Description                                                                                                                                             |
| -------- | --------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `resize` | { height: number; width: number } | Values correspond to the result image dimensions. If you specify only one value, the other will<br>be calculated automatically to preserve image ratio. |

#### ActionRotate (_Type_)

| Property | Type   | Description                                                                                                           |
| -------- | ------ | --------------------------------------------------------------------------------------------------------------------- |
| `rotate` | number | Degrees to rotate the image. Rotation is clockwise when the value is positive and<br>counter-clockwise when negative. |

#### ImageResult (_Type_)

| Property              | Type   | Description                                                                                                                                                                                                                                                                                                                       |
| --------------------- | ------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `base64` _(optional)_ | string | It is included if the `base64` save option was truthy, and is a string containing the<br>JPEG/PNG (depending on `format`) data of the image in Base64. Prepend that with `'data:image/xxx;base64,'`<br>to get a data URI, which you can use as the source for an `Image` element for example<br>(where `xxx` is `jpeg` or `png`). |
| `height`              | number | Height of the image or video.                                                                                                                                                                                                                                                                                                     |
| `uri`                 | string | An URI to the modified image (usable as the source for an `Image` or `Video` element).                                                                                                                                                                                                                                            |
| `width`               | number | Width of the image or video.                                                                                                                                                                                                                                                                                                      |

#### SaveOptions (_Type_)

A map defining how modified image should be saved.
| Property | Type | Description |
| --- | --- | --- |
| `base64` _(optional)_ | boolean | Whether to also include the image data in Base64 format. |
| `compress` _(optional)_ | number | A value in range `0.0` - `1.0` specifying compression level of the result image. `1` means<br>no compression (highest quality) and `0` the highest compression (lowest quality). |
| `format` _(optional)_ | SaveFormat | Specifies what type of compression should be used and what is the result file extension.<br>`SaveFormat.PNG` compression is lossless but slower, `SaveFormat.JPEG` is faster but the image<br>has visible artifacts. Defaults to `SaveFormat.JPEG` |

### Constants

#### ImageManipulator (_Constant_)

- `ImageManipulator` (ImageManipulator)

### Enums

#### FlipType (_Enum_)

#### Members

- `Horizontal`
- `Vertical`

#### SaveFormat (_Enum_)

#### Members

- `JPEG`
- `PNG`
- `WEBP`
