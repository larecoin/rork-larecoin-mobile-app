# Brightness

_A library that provides access to an API for getting and setting the screen brightness._

Available on platforms android, ios

An API to get and set screen brightness.

On Android, there is a global system-wide brightness setting, and each app has its own brightness setting that can optionally override the global setting. It is possible to set either of these values with this API. On iOS, the system brightness setting cannot be changed programmatically; instead, any changes to the screen brightness will persist until the device is locked or powered off.

## Installation

```bash
$ bunx expo install expo-brightness
```

If you are installing this in an existing React Native app, make sure to install `expo` in your project.

## Configuration

<ConfigReactNative>

If you're not using Continuous Native Generation ([CNG](https://docs.expo.dev/workflow/continuous-native-generation/)) or you're using a native **android** project manually, then you need to add the `android.permission.WRITE_SETTINGS` permission to the **AndroidManifest.xml** file:

```xml android/app/src/main/AndroidManifest.xml
<uses-permission android:name="android.permission.WRITE_SETTINGS" />
```

</ConfigReactNative>

## Usage

```jsx
import { useEffect } from "react";
import { StyleSheet, View, Text } from "react-native";
import * as Brightness from "expo-brightness";

export default function App() {
  useEffect(() => {
    (async () => {
      const { status } = await Brightness.requestPermissionsAsync();
      if (status === "granted") {
        Brightness.setSystemBrightnessAsync(1);
      }
    })();
  }, []);

  return (
    <View style={styles.container}>
      <Text>Brightness Module Example</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
});
```

## API

```js
import * as Brightness from "expo-brightness";
```

## API: expo-brightness

### Hooks

#### usePermissions (_Function_)

Check or request permissions to modify the system brightness.
This uses both `requestPermissionAsync` and `getPermissionsAsync` to interact with the permissions.

- `usePermissions(options?: PermissionHookOptions<object>): [null | PermissionResponse, RequestPermissionMethod<PermissionResponse>, GetPermissionMethod<PermissionResponse>]`
  Check or request permissions to modify the system brightness.
  This uses both `requestPermissionAsync` and `getPermissionsAsync` to interact with the permissions.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `options` _(optional)_ | PermissionHookOptions<object> | - |
  Example:
  ```ts
  const [permissionResponse, requestPermission] = Brightness.usePermissions();
  ```

#### useSystemBrightnessAsync (_Function_)

- `useSystemBrightnessAsync(): Promise<void>`
  Available on platform: android

### Brightness Methods

#### getBrightnessAsync (_Function_)

- `getBrightnessAsync(): Promise<number>`
  Gets the current brightness level of the device's main screen.
  Returns: A `Promise` that fulfils with a number between `0` and `1`, inclusive, representing the
  current screen brightness.

#### getPermissionsAsync (_Function_)

- `getPermissionsAsync(): Promise<PermissionResponse>`
  Checks user's permissions for accessing system brightness.
  Returns: A promise that fulfils with an object of type [PermissionResponse](#permissionresponse).

#### getSystemBrightnessAsync (_Function_)

- `getSystemBrightnessAsync(): Promise<number>`
  Gets the global system screen brightness.
  Available on platform: android
  Returns: A `Promise` that is resolved with a number between `0` and `1`, inclusive, representing
  the current system screen brightness.

#### getSystemBrightnessModeAsync (_Function_)

- `getSystemBrightnessModeAsync(): Promise<BrightnessMode>`
  Gets the system brightness mode (e.g. whether or not the OS will automatically
  adjust the screen brightness depending on ambient light).
  Available on platform: android
  Returns: A `Promise` that fulfils with a [`BrightnessMode`](#brightnessmode). Requires
  `SYSTEM_BRIGHTNESS` permissions.

#### isAvailableAsync (_Function_)

- `isAvailableAsync(): Promise<boolean>`
  Returns whether the Brightness API is enabled on the current device. This does not check the app
  permissions.
  Returns: Async `boolean`, indicating whether the Brightness API is available on the current device.
  Currently this resolves `true` on iOS and Android only.

#### isUsingSystemBrightnessAsync (_Function_)

- `isUsingSystemBrightnessAsync(): Promise<boolean>`
  Returns a boolean specifying whether or not the current activity is using the
  system-wide brightness value.
  Available on platform: android
  Returns: A `Promise` that fulfils with `true` when the current activity is using the system-wide
  brightness value, and `false` otherwise.

#### requestPermissionsAsync (_Function_)

- `requestPermissionsAsync(): Promise<PermissionResponse>`
  Asks the user to grant permissions for accessing system brightness.
  Returns: A promise that fulfils with an object of type [PermissionResponse](#permissionresponse).

#### restoreSystemBrightnessAsync (_Function_)

- `restoreSystemBrightnessAsync(): Promise<void>`
  Resets the brightness setting of the current activity to use the system-wide
  brightness value rather than overriding it.
  Available on platform: android
  Returns: A `Promise` that fulfils when the setting has been successfully changed.

#### setBrightnessAsync (_Function_)

- `setBrightnessAsync(brightnessValue: number): Promise<void>`
  Sets the current screen brightness. On iOS, this setting will persist until the device is locked,
  after which the screen brightness will revert to the user's default setting. On Android, this
  setting only applies to the current activity; it will override the system brightness value
  whenever your app is in the foreground.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `brightnessValue` | number | A number between `0` and `1`, inclusive, representing the desired screen<br>brightness. |
  Returns: A `Promise` that fulfils when the brightness has been successfully set.

#### setSystemBrightnessAsync (_Function_)

- `setSystemBrightnessAsync(brightnessValue: number): Promise<void>`
  Sets the global system screen brightness and changes the brightness mode to
  `MANUAL`. Requires `SYSTEM_BRIGHTNESS` permissions.
  Available on platform: android
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `brightnessValue` | number | A number between `0` and `1`, inclusive, representing the desired screen<br>brightness. |
  Returns: A `Promise` that fulfils when the brightness has been successfully set.

#### setSystemBrightnessModeAsync (_Function_)

- `setSystemBrightnessModeAsync(brightnessMode: BrightnessMode): Promise<void>`
  Sets the system brightness mode.
  Available on platform: android
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `brightnessMode` | BrightnessMode | One of `BrightnessMode.MANUAL` or `BrightnessMode.AUTOMATIC`. The system<br>brightness mode cannot be set to `BrightnessMode.UNKNOWN`. |

### Event Subscriptions

#### addBrightnessListener (_Function_)

- `addBrightnessListener(listener: (event: BrightnessEvent) => void): EventSubscription`
  Subscribe to brightness (iOS) updates. The event fires whenever
  the power mode is toggled.

  On web and android the event never fires.
  Available on platform: ios
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `listener` | (event: BrightnessEvent) => void | A callback that is invoked when brightness (iOS) changes.<br>The callback is provided a single argument that is an object with a `brightness` key. |
  Returns: A `Subscription` object on which you can call `remove()` to unsubscribe from the listener.

### Types

#### BrightnessEvent (_Type_)

| Property     | Type   | Description                                                                          |
| ------------ | ------ | ------------------------------------------------------------------------------------ |
| `brightness` | number | A number between `0` and `1`, inclusive, representing the current screen brightness. |

#### PermissionExpiration (_Type_)

Permission expiration time. Currently, all permissions are granted permanently.
Type: 'never' | number

#### PermissionHookOptions (_Type_)

Type: PermissionHookBehavior & Options

#### PermissionResponse (_Type_)

An object obtained by permissions get and request functions.
| Property | Type | Description |
| --- | --- | --- |
| `canAskAgain` | boolean | Indicates if user can be asked again for specific permission.<br>If not, one should be directed to the Settings app<br>in order to enable/disable the permission. |
| `expires` | PermissionExpiration | Determines time when the permission expires. |
| `granted` | boolean | A convenience boolean that indicates if the permission is granted. |
| `status` | PermissionStatus | Determines the status of the permission. |

### Enums

#### BrightnessMode (_Enum_)

#### Members

- `AUTOMATIC` — Mode in which the device OS will automatically adjust the screen brightness depending on the
  ambient light.
- `MANUAL` — Mode in which the screen brightness will remain constant and will not be adjusted by the OS.
- `UNKNOWN` — Means that the current brightness mode cannot be determined.

#### PermissionStatus (_Enum_)

#### Members

- `DENIED` — User has denied the permission.
- `GRANTED` — User has granted the permission.
- `UNDETERMINED` — User hasn't granted or denied the permission yet.

## Error codes

### `ERR_BRIGHTNESS`

An error occurred when getting or setting the app brightness.

### `ERR_BRIGHTNESS_MODE`

An error occurred when getting or setting the system brightness mode. See the `nativeError` property of the thrown error for more information.

### `ERR_BRIGHTNESS_PERMISSIONS_DENIED`

An attempt to set the system brightness was made without the proper permissions from the user. The user did not grant `SYSTEM_BRIGHTNESS` permissions.

### `ERR_BRIGHTNESS_SYSTEM`

An error occurred when getting or setting the system brightness.

### `ERR_INVALID_ARGUMENT`

An invalid argument was passed. Only `BrightnessMode.MANUAL` or `BrightnessMode.AUTOMATIC` are allowed.

## Permissions

### Android

You must add the following permissions to your **app.json** inside the [`expo.android.permissions`](../config/app/#permissions) array.

<AndroidPermissions permissions={['WRITE_SETTINGS']} />

### iOS

_No permissions required_.
