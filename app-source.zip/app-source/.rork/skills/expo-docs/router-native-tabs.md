# Router native tabs

_An Expo Router submodule that provides native tabs layout._

Available on platforms android, ios, tvos, web

> **important** Native tabs is an experimental feature available in SDK 54 and later, and its API is subject to change.

`expo-router/unstable-native-tabs` is a submodule of `expo-router` and exports components to build tab layouts using platform-native system tabs.

> See the [Expo Router](./router) reference for more information about the file-based routing library for native and web app.

## Installation

To use `expo-router/unstable-native-tabs` in your project, you need to install `expo-router` in your project. Follow the instructions from Expo Router's installation guide:

[Install Expo Router](https://docs.expo.dev/router/installation/)

## Configuration in app config

If you are using the [default](https://docs.expo.dev/more/create-expo/#--template) template to create a new project, `expo-router`'s [config plugin](https://docs.expo.dev/config-plugins/introduction/) is already configured in your app config.

```json app.json
{
  "expo": {
    "plugins": ["expo-router"]
  }
}
```

## Usage

To learn how to use native tabs, with Expo Router, read the native tabs guide:

[Native tabs](https://docs.expo.dev/router/advanced/native-tabs/)

## API

```js
import { NativeTabs, Icon, Label, Badge, VectorIcon } from "expo-router/unstable-native-tabs";
```

## API: expo-router-native-tabs

### Native tabs Methods

#### Badge (_Function_)

- `Badge(props: BadgeProps): null`
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `props` | BadgeProps | - |

#### Icon (_Function_)

- `Icon(props: IconProps): null`
  Renders an icon for the tab.
  Available on platforms: ios, android
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `props` | IconProps | - |

#### Label (_Function_)

- `Label(props: LabelProps): null`
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `props` | LabelProps | - |

#### NativeTabs (_Function_)

The component used to create native tabs layout.

- `NativeTabs(props: NativeTabsProps): React.JSX.Element`
  The component used to create native tabs layout.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `props` | NativeTabsProps | - |
  Example:

  ```tsx
  // In _layout file
  import { NativeTabs } from "expo-router/unstable-native-tabs";

  export default function Layout() {
    return (
      <NativeTabs>
        <NativeTabs.Trigger name="home" />
        <NativeTabs.Trigger name="settings" />
      </NativeTabs>
    );
  }
  ```

#### NativeTabsTriggerTabBar (_Function_)

- `NativeTabsTriggerTabBar(props: NativeTabsTriggerTabBarProps): React.ReactNode`
  The component used to customize the style of the tab bar, when given trigger is selected.

  Prefer this to global changes of tab bar styles, directly in the page.

  > **Note:** You can use the alias `NativeTabs.Trigger.TabBar` for this component.
  > | Parameter | Type | Description |
  > | --- | --- | --- |
  > | `props` | NativeTabsTriggerTabBarProps | - |
  > Example:

  ```tsx
  <NativeTabs backgroundColor="black">
    <NativeTabs.Trigger name="page">
      <NativeTabs.Trigger.TabBar backgroundColor="white" />
      <Label>Page</Label>
    </NativeTabs.Trigger>
  </NativeTabs>
  ```

#### NativeTabTrigger (_Function_)

- `NativeTabTrigger(props: NativeTabTriggerProps): null`
  The component used to customize the native tab options both in the \_layout file and from the tab screen.

  When used in the \_layout file, you need to provide a `name` prop.
  When used in the tab screen, the `name` prop takes no effect.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `props` | NativeTabTriggerProps | - |
  Example:

  ```tsx
  // In _layout file
  import { NativeTabs } from "expo-router/unstable-native-tabs";

  export default function Layout() {
    return (
      <NativeTabs>
        <NativeTabs.Trigger name="home" />
        <NativeTabs.Trigger name="settings" />
      </NativeTabs>
    );
  }
  ```

#### VectorIcon (_Function_)

- `VectorIcon(props: VectorIconProps<NameT>): null`
  Helper component which can be used to load vector icons for `NativeTabs`.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `props` | VectorIconProps<NameT> | - |
  Example:

  ```tsx
  import { NativeTabs, VectorIcon } from 'expo-router';
  import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';

  export default Layout(){
    return (
      <NativeTabs>
        <NativeTabs.Trigger name="index">
          <Icon src={<VectorIcon family={MaterialCommunityIcons} name="home" />} />
        </NativeTabs.Trigger>
      </NativeTabs>
    );
  }
  ```

### Props

#### BadgeProps (_Interface_)

##### Properties

- `children?` (string)
  The text to display as the badge for the tab.
  If not provided, the badge will not be displayed.
- `hidden?` (boolean)
  If true, the badge will be hidden.
- `selectedBackgroundColor?` (ColorValue)

#### LabelProps (_Interface_)

##### Properties

- `children?` (string)
  The text to display as the label for the tab.
- `hidden?` (boolean)
  If true, the label will be hidden.
- `selectedStyle?` (NativeTabsLabelStyle)

#### NativeTabsProps (_Interface_)

##### Properties

- `backBehavior?` ('history' | 'none' | 'initialRoute')
  The behavior when navigating back with the back button.
  Available on platform: android
- `backgroundColor?` (null | ColorValue)
  The background color of the tab bar.
- `badgeBackgroundColor?` (ColorValue)
  The background color of every badge in the tab bar.
- `badgeTextColor?` (ColorValue)
  The color of the badge text.
  Available on platforms: android, web
- `blurEffect?` ('none' | 'systemDefault' | 'extraLight' | 'light' | 'dark' | 'regular' | 'prominent' | 'systemUltraThinMaterial' | 'systemThinMaterial' | 'systemMaterial' | 'systemThickMaterial' | 'systemChromeMaterial' | 'systemUltraThinMaterialLight' | 'systemThinMaterialLight' | 'systemMaterialLight' | 'systemThickMaterialLight' | 'systemChromeMaterialLight' | 'systemUltraThinMaterialDark' | 'systemThinMaterialDark' | 'systemMaterialDark' | 'systemThickMaterialDark' | 'systemChromeMaterialDark')
  The blur effect applied to the tab bar.
  Available on platform: iOS
- `disableIndicator?` (boolean)
  Disables the active indicator for the tab bar.
  Available on platform: android
- `disableTransparentOnScrollEdge?` (boolean)
  When set to `true`, the tab bar will not become transparent when scrolled to the edge.
  Available on platform: iOS
- `iconColor?` (ColorValue | { default: ColorValue | undefined; selected: ColorValue | undefined })
  The color of every tab icon in the tab bar.
- `indicatorColor?` (ColorValue)
  The color of the tab indicator.
  Available on platforms: android, web
- `labelStyle?` (NativeTabsLabelStyle | { default: NativeTabsLabelStyle; selected: NativeTabsLabelStyle })
  The style of the every tab label in the tab bar.
- `labelVisibilityMode?` ('auto' | 'selected' | 'labeled' | 'unlabeled')
  The visibility mode of the tab item label.
  Available on platform: android
- `minimizeBehavior?` ('automatic' | 'never' | 'onScrollDown' | 'onScrollUp')
  Specifies the minimize behavior for the tab bar.

  Available starting from iOS 26.

  The following values are currently supported:
  - `automatic` - resolves to the system default minimize behavior
  - `never` - the tab bar does not minimize
  - `onScrollDown` - the tab bar minimizes when scrolling down and
    expands when scrolling back up
  - `onScrollUp` - the tab bar minimizes when scrolling up and expands
    when scrolling back down
    Available on platform: iOS 26+

- `rippleColor?` (ColorValue)
  The color of the ripple effect when the tab is pressed.
  Available on platform: android
- `shadowColor?` (ColorValue)
  The color of the shadow.
  Available on platform: iOS
- `tintColor?` (ColorValue)
  The tint color of the tab icon.

  Can be overridden by icon color and label color for each tab individually.

- `titlePositionAdjustment?` ({ horizontal: number; vertical: number })
  Available on platform: iOS

#### NativeTabsTriggerTabBarProps (_Interface_)

##### Properties

- `backgroundColor?` (ColorValue)
  The background color of the tab bar, when the tab is selected
- `badgeBackgroundColor?` (ColorValue)
  The background color of every badge in the tab bar.
  Available on platforms: iOS, web
- `badgeTextColor?` (ColorValue)
  The color of the badge text.
  Available on platform: web
- `blurEffect?` ('none' | 'systemDefault' | 'extraLight' | 'light' | 'dark' | 'regular' | 'prominent' | 'systemUltraThinMaterial' | 'systemThinMaterial' | 'systemMaterial' | 'systemThickMaterial' | 'systemChromeMaterial' | 'systemUltraThinMaterialLight' | 'systemThinMaterialLight' | 'systemMaterialLight' | 'systemThickMaterialLight' | 'systemChromeMaterialLight' | 'systemUltraThinMaterialDark' | 'systemThinMaterialDark' | 'systemMaterialDark' | 'systemThickMaterialDark' | 'systemChromeMaterialDark')
  The blur effect applied to the tab bar, when the tab is selected
  Available on platform: iOS
- `disableTransparentOnScrollEdge?` (boolean)
  When set to `true`, the tab bar will not become transparent when scrolled to the edge.
  Available on platform: iOS
- `iconColor?` (ColorValue)
  The color of every tab icon, when the tab is selected
  Available on platform: iOS
- `indicatorColor?` (ColorValue)
  The color of the tab indicator.
  Available on platform: web
- `labelStyle?` (NativeTabsLabelStyle)
  The style of the every tab label in the tab bar.
  Available on platforms: iOS, web
- `shadowColor?` (ColorValue)
  The color of the shadow when the tab is selected.
  Available on platform: iOS

#### NativeTabTriggerProps (_Interface_)

##### Properties

- `children?` (React.ReactNode)
  The children of the trigger.

  Use `Icon`, `Label`, and `Badge` components to customize the tab.

- `disablePopToTop?` (boolean)
  If true, the tab will not pop stack to the root when selected again.
  Available on platform: iOS
- `disableScrollToTop?` (boolean)
  If true, the tab will not scroll to the top when selected again.
  Available on platform: iOS
- `hidden?` (boolean)
  If true, the tab will be hidden from the tab bar.

  > **Note**: Marking a tab as `hidden` means it cannot be navigated to in any way.

- `name?` (string)
  The name of the route.

  This is required when used inside a Layout component.

  When used in a route it has no effect.

- `options?` (NativeTabOptions)
  The options for the trigger.

  Use `Icon`, `Label`, and `Badge` components as children to customize the tab, rather then raw options.

- `role?` ('search' | 'history' | 'bookmarks' | 'contacts' | 'downloads' | 'favorites' | 'featured' | 'more' | 'mostRecent' | 'mostViewed' | 'recents' | 'topRated')
  System-provided tab bar item with predefined icon and title

  Uses Apple's built-in tab bar items (e.g., bookmarks, contacts, downloads) with
  standard iOS styling and localized titles. Custom `icon` or `selectedIcon`
  properties will override the system icon, but the system-defined title cannot
  be customized.
  Available on platform: ios

#### VectorIconProps (_Interface_)

##### Properties

- `family` ({ getImageSource: (name: VectorIconProps.NameT, size: number, color: ColorValue) => Promise<null | ImageSourcePropType> })
  The family of the vector icon.
- `name` (VectorIconProps.NameT)
  The name of the vector icon.

#### IconProps (_Type_)

| Property                     | Type       | Description |
| ---------------------------- | ---------- | ----------- |
| `selectedColor` _(optional)_ | ColorValue | -           |

### Interfaces

#### CrossPlatformIconCombination (_Interface_)

##### Properties

- `androidSrc?` (React.ReactElement | ImageSourcePropType | { default: ReactElement<unknown, string | JSXElementConstructor<any>> | ImageSourcePropType | undefined; selected: ReactElement<unknown, string | JSXElementConstructor<any>> | ImageSourcePropType })
  The image source to use as an icon on Android.

  The value can be provided in two ways:
  - As an image source
  - As an object specifying the default and selected states
    Available on platform: Android

- `drawable?` (undefined)
- `sf?` (SFSymbols6_0 | { default: SFSymbols6_0 | undefined; selected: SFSymbols6_0 })
  The name of the SF Symbol to use as an icon on iOS.

  The value can be provided in two ways:
  - As a string with the SF Symbol name
  - As an object specifying the default and selected states
    Available on platform: iOS

- `src?` (undefined)

#### NamedIconCombination (_Interface_)

##### Properties

- `androidSrc?` (undefined)
- `drawable?` (string)
  The name of the drawable resource to use as an icon.
  Available on platform: android
- `sf?` (SFSymbols6_0 | { default: SFSymbols6_0 | undefined; selected: SFSymbols6_0 })
  The name of the SF Symbol to use as an icon.

  The value can be provided in two ways:
  - As a string with the SF Symbol name
  - As an object specifying the default and selected states
    Available on platform: iOS

- `src?` (undefined)

#### NativeTabOptions (_Interface_)

##### Properties

- `backgroundColor?` (ColorValue)
  The color of the background when the tab is selected.
- `badgeBackgroundColor?` (ColorValue)
  The color of all the badges when the tab is selected.
- `badgeTextColor?` (ColorValue)
  The color of the badge text.
  Available on platforms: android, web
- `badgeValue?` (string)
  Specifies content of tab bar item badge.

  On Android, the value is interpreted in the following order:
  - If the string can be parsed to integer, displays the value as a number
  - Otherwise if the string is empty, displays "small dot" badge
  - Otherwise, displays the value as a text

  On iOS, badge is displayed as regular string.
  Available on platforms: android, ios

- `blurEffect?` ('none' | 'systemDefault' | 'extraLight' | 'light' | 'dark' | 'regular' | 'prominent' | 'systemUltraThinMaterial' | 'systemThinMaterial' | 'systemMaterial' | 'systemThickMaterial' | 'systemChromeMaterial' | 'systemUltraThinMaterialLight' | 'systemThinMaterialLight' | 'systemMaterialLight' | 'systemThickMaterialLight' | 'systemChromeMaterialLight' | 'systemUltraThinMaterialDark' | 'systemThinMaterialDark' | 'systemMaterialDark' | 'systemThickMaterialDark' | 'systemChromeMaterialDark')
  The blur effect to apply when the tab is selected.
  Available on platform: iOS
- `disableTransparentOnScrollEdge?` (boolean)
  When set to `true`, the tab bar will not become transparent when scrolled to the edge.
  Available on platform: iOS
- `icon?` (SymbolOrImageSource)
  The icon to display in the tab bar.
  Available on platforms: android, iOS
- `iconColor?` (ColorValue)
  The color of the icon when the tab is selected.

  On iOS 26+ you can change the icon color in the scroll edge state.

- `indicatorColor?` (ColorValue)
  The color of the tab indicator.
  Available on platforms: android, web
- `labelStyle?` (NativeTabsLabelStyle)
  The style of all the tab labels, when the tab is selected
- `role?` ('search' | 'history' | 'bookmarks' | 'contacts' | 'downloads' | 'favorites' | 'featured' | 'more' | 'mostRecent' | 'mostViewed' | 'recents' | 'topRated')
  System-provided tab bar item with predefined icon and title

  Uses Apple's built-in tab bar items (e.g., bookmarks, contacts, downloads) with
  standard iOS styling and localized titles. If you override the `title`,
  `icon`, or `selectedIcon`, note that this is not officially supported
  by Apple and may lead to unexpected results.
  Available on platform: ios

- `selectedBadgeBackgroundColor?` (ColorValue)
  The color of the badge when the tab is selected.
- `selectedIcon?` (SymbolOrImageSource)
  The icon to display when the tab is selected.
  Available on platform: iOS
- `selectedIconColor?` (ColorValue)
  The color of the icon when the tab is selected.
- `selectedLabelStyle?` (NativeTabsLabelStyle)
  The style of the tab label when the tab is selected.
- `selectedTitlePositionAdjustment?` ({ horizontal: number; vertical: number })
  The position adjustment for the label when the tab is selected.
  Available on platform: iOS
- `shadowColor?` (ColorValue)
  The color of the shadow when the tab is selected.
  Available on platform: iOS
- `title?` (string)
  Title of the tab screen, displayed in the tab bar item.
  Available on platforms: android, iOS
- `titlePositionAdjustment?` ({ horizontal: number; vertical: number })
  The position adjustment for all the labels when the tab is selected.
  Available on platform: iOS

#### NativeTabsActiveStyleType (_Interface_)

Available on platforms: android, web

##### Properties

- `color?` (ColorValue)
  Available on platforms: android, web
- `fontSize?` (number)
  Available on platforms: android, web
- `iconColor?` (ColorValue)
  Available on platform: android
- `indicatorColor?` (ColorValue)
  Available on platforms: android, web

#### NativeTabsLabelStyle (_Interface_)

##### Properties

- `color?` (ColorValue)
  The color of the tab label.
- `fontFamily?` (string)
  The font family of the tab label.
- `fontSize?` (number)
  The font size of the tab label.
- `fontStyle?` ('italic' | 'normal')
  The font style of the tab label.
- `fontWeight?` (NumericFontWeight | '100' | '200' | '300' | '400' | '500' | '600' | '700' | '800' | '900')
  The font weight of the tab label.

#### SourceIconCombination (_Interface_)

##### Properties

- `androidSrc?` (undefined)
- `drawable?` (undefined)
- `sf?` (undefined)
- `src?` (React.ReactElement | ImageSourcePropType | { default: ReactElement<unknown, string | JSXElementConstructor<any>> | ImageSourcePropType | undefined; selected: ReactElement<unknown, string | JSXElementConstructor<any>> | ImageSourcePropType })
  The image source to use as an icon.

  The value can be provided in two ways:
  - As an image source
  - As an object specifying the default and selected states
    Available on platforms: Android, iOS

### Types

#### NativeTabsBlurEffect (_Type_)

Type: indexedAccess

#### NativeTabsTabBarItemLabelVisibilityMode (_Type_)

Available on platform: android
Type: indexedAccess

#### NativeTabsTabBarItemRole (_Type_)

Type: indexedAccess

#### NativeTabsTabBarMinimizeBehavior (_Type_)

Available on platform: iOS 26
Type: indexedAccess

#### SymbolOrImageSource (_Type_)

| Property                | Type                                                        | Description                                                                         |
| ----------------------- | ----------------------------------------------------------- | ----------------------------------------------------------------------------------- |
| `drawable` _(optional)_ | string                                                      | The name of the drawable resource to use as an icon. Available on platform: android |
| `sf` _(optional)_       | SFSymbol                                                    | The name of the SF Symbol to use as an icon. Available on platform: iOS             |
| `src` _(optional)_      | ImageSourcePropType \| Promise<ImageSourcePropType \| null> | The image source to use as an icon.                                                 |
