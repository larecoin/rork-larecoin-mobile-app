# MediaLibrary

_A library that provides access to the device's media library._

Available on platforms android, ios, tvos

`expo-media-library` provides access to the user's media library, allowing them to access their existing images and videos from your app, as well as save new ones. You can also subscribe to any updates made to the user's media library.

> **warning** Android allows full access to the media library (which is the purpose of this package) only for applications needing broad access to photos. See [Details on Google Play's Photo and Video Permissions policy](https://support.google.com/googleplay/android-developer/answer/14115180).

## Installation

```bash
$ bunx expo install expo-media-library
```

If you are installing this in an existing React Native app, make sure to install `expo` in your project.

## Configuration in app config

You can configure `expo-media-library` using its built-in [config plugin](https://docs.expo.dev/config-plugins/introduction/) if you use config plugins in your project ([Continuous Native Generation (CNG)](https://docs.expo.dev/workflow/continuous-native-generation/)). The plugin allows you to configure various properties that cannot be set at runtime and require building a new app binary to take effect. If your app does **not** use CNG, then you'll need to manually configure the library.

```json
{
  "expo": {
    "plugins": [
      [
        "expo-media-library",
        {
          "photosPermission": "Allow $(PRODUCT_NAME) to access your photos.",
          "savePhotosPermission": "Allow $(PRODUCT_NAME) to save photos.",
          "isAccessMediaLocationEnabled": true,
          "granularPermissions": ["audio", "photo"]
        }
      ]
    ]
  }
}
```

### Configurable properties

| Name                                 | Default                                          | Description                                                                                                                                                                                                                                                                    |
| ------------------------------------ | ------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `photosPermission`                   | `"Allow $(PRODUCT_NAME) to access your photos."` | Only for: ios. Sets the iOS `NSPhotoLibraryUsageDescription` permission message in **Info.plist**.                                                                                                                                                                             |
| `savePhotosPermission`               | `"Allow $(PRODUCT_NAME) to save photos."`        | Only for: ios. Sets the iOS `NSPhotoLibraryAddUsageDescription` permission message in **Info.plist**.                                                                                                                                                                          |
| `preventAutomaticLimitedAccessAlert` | `false`                                          | Only for: ios. Prevents the automatic limited access alert from being shown when the user has limited access to the photo library. Useful for apps that want to access only the limited photo library without having iOS forcibly show the alert.                              |
| `isAccessMediaLocationEnabled`       | `false`                                          | Only for: android. Sets whether or not to request the `ACCESS_MEDIA_LOCATION` permission on Android.                                                                                                                                                                           |
| `granularPermissions`                | `["photo", "video", "audio"]`                    | Only for: android. Sets which [`GranularPermission`](#granularpermission) values to include, determining which media permissions (`READ_MEDIA_IMAGES`, `READ_MEDIA_VIDEO`, `READ_MEDIA_AUDIO`) will be added to the Android manifest. Matches the behavior of the runtime API. |

<ConfigReactNative>

If you're not using Continuous Native Generation ([CNG](https://docs.expo.dev/workflow/continuous-native-generation/)) or you're using native **android** **ios** projects manually, then you need to add following permissions and configuration to your native projects:

**Android**

- To access asset location (latitude and longitude EXIF tags), add `ACCESS_MEDIA_LOCATION` permission to your project's **android/app/src/main/AndroidManifest.xml**:

  ```xml
  <uses-permission android:name="android.permission.ACCESS_MEDIA_LOCATION" />
  ```

- [Scoped storage](https://developer.android.com/training/data-storage#scoped-storage) is available from Android 10. To make `expo-media-library` work with scoped storage, you need to add the following configuration to your **android/app/src/main/AndroidManifest.xml**:

  ```xml
  <manifest ... >
    <application android:requestLegacyExternalStorage="true" ...>
  </manifest>
  ```

**iOS**

- Add `NSPhotoLibraryUsageDescription`, and `NSPhotoLibraryAddUsageDescription` keys to your project's **ios/[app]/Info.plist**:

  ```xml
  <key>NSPhotoLibraryUsageDescription</key>
  <string>Give $(PRODUCT_NAME) permission to access your photos</string>
  <key>NSPhotoLibraryAddUsageDescription</key>
  <string>Give $(PRODUCT_NAME) permission to save photos</string>
  ```

</ConfigReactNative>

## Usage

```jsx
import { useState, useEffect } from "react";
import { Button, Text, ScrollView, StyleSheet, Image, View, Platform } from "react-native";
import * as MediaLibrary from "expo-media-library";

export default function App() {
  const [albums, setAlbums] = useState(null);
  const [permissionResponse, requestPermission] = MediaLibrary.usePermissions();

  async function getAlbums() {
    if (permissionResponse.status !== "granted") {
      await requestPermission();
    }
    const fetchedAlbums = await MediaLibrary.getAlbumsAsync({
      includeSmartAlbums: true,
    });
    setAlbums(fetchedAlbums);
  }

  return (
    <View style={styles.container}>
      <Button onPress={getAlbums} title="Get albums" />
      <ScrollView>{albums && albums.map((album) => <AlbumEntry album={album} />)}</ScrollView>
    </View>
  );
}

function AlbumEntry({ album }) {
  const [assets, setAssets] = useState([]);

  useEffect(() => {
    async function getAlbumAssets() {
      const albumAssets = await MediaLibrary.getAssetsAsync({ album });
      setAssets(albumAssets.assets);
    }
    getAlbumAssets();
  }, [album]);

  return (
    <View key={album.id} style={styles.albumContainer}>
      <Text>
        {album.title} - {album.assetCount ?? "no"} assets
      </Text>
      <View style={styles.albumAssetsContainer}>
        {assets && assets.map((asset) => <Image source={{ uri: asset.uri }} width={50} height={50} />)}
      </View>
    </View>
  );
}

/* @hide const styles = StyleSheet.create({ ... }); */
const styles = StyleSheet.create({
  container: {
    flex: 1,
    gap: 8,
    justifyContent: "center",
  },
  albumContainer: {
    paddingHorizontal: 20,
    marginBottom: 12,
    gap: 4,
  },
  albumAssetsContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
  },
});
/* @end */
```

## Known limitations

### Empty albums

Due to system limitations on Android, it is impossible to create empty albums. It is necessary to either pass an existing asset to add to the album or a URI of a local resource, which will be used to create a new asset inside the album.

### Moving assets between albums

Android 11 introduced permission changes that make the operation of moving assets between albums require confirmation from the user every time.
Therefore, when creating a new asset, instead of creating the asset and then moving it to the album, it is recommended to pass the `album` parameter to the [`createAssetAsync`](#medialibrarycreateassetasynclocaluri-album) method, which will automatically add the asset to the album without the need for user confirmation.

### Wrong orientation of images

On Android, when using `getAssetsAsync` without `resolveWithFullInfo: true`, image orientation may be incorrect because EXIF data (which includes orientation) is only read when that option is enabled.

## API

```js
import * as MediaLibrary from "expo-media-library";
```

## API: expo-media-library

### Hooks

#### usePermissions (_Function_)

Check or request permissions to access the media library.
This uses both `requestPermissionsAsync` and `getPermissionsAsync` to interact with the permissions.

- `usePermissions(options?: PermissionHookOptions<{ granularPermissions: GranularPermission[]; writeOnly: boolean }>): [null | PermissionResponse, RequestPermissionMethod<PermissionResponse>, GetPermissionMethod<PermissionResponse>]`
  Check or request permissions to access the media library.
  This uses both `requestPermissionsAsync` and `getPermissionsAsync` to interact with the permissions.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `options` _(optional)_ | PermissionHookOptions<{ granularPermissions: GranularPermission[]; writeOnly: boolean }> | - |
  Example:
  ```ts
  const [permissionResponse, requestPermission] = MediaLibrary.usePermissions();
  ```

### MediaLibrary Methods

#### addAssetsToAlbumAsync (_Function_)

- `addAssetsToAlbumAsync(assets: AssetRef | AssetRef[], album: AlbumRef, copy: boolean): Promise<boolean>`
  Adds array of assets to the album.

  On Android, by default it copies assets from the current album to provided one, however it's also
  possible to move them by passing `false` as `copyAssets` argument. In case they're copied you
  should keep in mind that `getAssetsAsync` will return duplicated assets.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `assets` | AssetRef \| AssetRef[] | An array of [Asset](#asset) or their IDs. |
  | `album` | AlbumRef | An [Album](#album) or its ID. |
  | `copy` | boolean | **Android only.** Whether to copy assets to the new album instead of move them.<br>Defaults to `true`. |
  Returns: Returns promise which fulfils with `true` if the assets were successfully added to
  the album.

#### albumNeedsMigrationAsync (_Function_)

- `albumNeedsMigrationAsync(album: AlbumRef): Promise<boolean>`
  Checks if the album should be migrated to a different location. In other words, it checks if the
  application has the write permission to the album folder. If not, it returns `true`, otherwise `false`.
  > Note: For **Android below R**, **web** or **iOS**, this function always returns `false`.
  > | Parameter | Type | Description |
  > | --- | --- | --- |
  > | `album` | AlbumRef | An [Album](#album) or its ID. |
  > Returns: Returns a promise which fulfils with `true` if the album should be migrated.

#### createAlbumAsync (_Function_)

- `createAlbumAsync(albumName: string, asset?: AssetRef, copyAsset: boolean, initialAssetLocalUri?: string): Promise<Album>`
  Creates an album with given name and initial asset. The asset parameter is required on Android,
  since it's not possible to create empty album on this platform. On Android, by default it copies
  given asset from the current album to the new one, however it's also possible to move it by
  passing `false` as `copyAsset` argument.
  In case it's copied you should keep in mind that `getAssetsAsync` will return duplicated asset.
  > On Android, it's not possible to create an empty album. You must provide an existing asset to copy or move into the album or an uri of a local file, which will be used to create an initial asset for the album.
  > | Parameter | Type | Description |
  > | --- | --- | --- |
  > | `albumName` | string | Name of the album to create. |
  > | `asset` _(optional)_ | AssetRef | An [Asset](#asset) or its ID. On Android you either need to provide an asset or a localUri. |
  > | `copyAsset` | boolean | **Android Only.** Whether to copy asset to the new album instead of move it. This parameter is ignored if `asset` was not provided.<br>Defaults to `true`. |
  > | `initialAssetLocalUri` _(optional)_ | string | A URI to the local media file, which will be used to create the initial asset inside the album. It must contain an extension. On Android it<br>must be a local path, so it must start with `file:///`. If the `asset` was provided, this parameter will be ignored. |
  > Returns: Newly created [`Album`](#album).

#### createAssetAsync (_Function_)

- `createAssetAsync(localUri: string, album?: AlbumRef): Promise<Asset>`
  Creates an asset from existing file. The most common use case is to save a picture taken by [Camera](./camera).
  This method requires `CAMERA_ROLL` permission.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `localUri` | string | A URI to the image or video file. It must contain an extension. On Android it<br>must be a local path, so it must start with `file:///` |
  | `album` _(optional)_ | AlbumRef | An [Album](#album) or its ID. If provided, the asset will be added to this album upon creation, otherwise it will be added to the default album for the media type.<br>The album has exist. |
  Returns: A promise which fulfils with an object representing an [`Asset`](#asset).
  Example:
  ```js
  const { uri } = await Camera.takePictureAsync();
  const asset = await MediaLibrary.createAssetAsync(uri);
  ```

#### deleteAlbumsAsync (_Function_)

- `deleteAlbumsAsync(albums: AlbumRef | AlbumRef[], assetRemove: boolean): Promise<boolean>`
  Deletes given albums from the library. On Android by default it deletes assets belonging to given
  albums from the library. On iOS it doesn't delete these assets, however it's possible to do by
  passing `true` as `deleteAssets`.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `albums` | AlbumRef \| AlbumRef[] | An array of [`Album`](#asset)s or their IDs. |
  | `assetRemove` | boolean | **iOS Only.** Whether to also delete assets belonging to given albums.<br>Defaults to `false`. |
  Returns: Returns a promise which fulfils with `true` if the albums were successfully deleted from
  the library.

#### deleteAssetsAsync (_Function_)

- `deleteAssetsAsync(assets: AssetRef | AssetRef[]): Promise<boolean>`
  Deletes assets from the library. On iOS it deletes assets from all albums they belong to, while
  on Android it keeps all copies of them (album is strictly connected to the asset). Also, there is
  additional dialog on iOS that requires user to confirm this action.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `assets` | AssetRef \| AssetRef[] | An array of [Asset](#asset) or their IDs. |
  Returns: Returns promise which fulfils with `true` if the assets were successfully deleted.

#### getAlbumAsync (_Function_)

- `getAlbumAsync(title: string): Promise<Album>`
  Queries for an album with a specific name.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `title` | string | Name of the album to look for. |
  Returns: An object representing an [`Album`](#album), if album with given name exists, otherwise
  returns `null`.

#### getAlbumsAsync (_Function_)

- `getAlbumsAsync(__namedParameters: AlbumsOptions): Promise<Album[]>`
  Queries for user-created albums in media gallery.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `__namedParameters` | AlbumsOptions | - |
  Returns: A promise which fulfils with an array of [`Album`](#asset)s. Depending on Android version,
  root directory of your storage may be listed as album titled `"0"` or unlisted at all.

#### getAssetInfoAsync (_Function_)

- `getAssetInfoAsync(asset: AssetRef, options: MediaLibraryAssetInfoQueryOptions): Promise<AssetInfo>`
  Provides more information about an asset, including GPS location, local URI and EXIF metadata.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `asset` | AssetRef | An [Asset](#asset) or its ID. |
  | `options` | MediaLibraryAssetInfoQueryOptions | - |
  Returns: An [AssetInfo](#assetinfo) object, which is an `Asset` extended by an additional fields.

#### getAssetsAsync (_Function_)

- `getAssetsAsync(assetsOptions: AssetsOptions): Promise<PagedInfo<Asset>>`
  Fetches a page of assets matching the provided criteria.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `assetsOptions` | AssetsOptions | - |
  Returns: A promise that fulfils with to [`PagedInfo`](#pagedinfo) object with array of [`Asset`](#asset)s.

#### getMomentsAsync (_Function_)

- `getMomentsAsync(): Promise<any>`
  Fetches a list of moments, which is a group of assets taken around the same place
  and time.
  Available on platform: ios
  Returns: An array of [albums](#album) whose type is `moment`.

#### getPermissionsAsync (_Function_)

- `getPermissionsAsync(writeOnly: boolean, granularPermissions?: GranularPermission[]): Promise<PermissionResponse>`
  Checks user's permissions for accessing media library.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `writeOnly` | boolean | - |
  | `granularPermissions` _(optional)_ | GranularPermission[] | A list of [`GranularPermission`](#granularpermission) values. This parameter has<br>an effect only on Android 13 and newer. By default, `expo-media-library` will ask for all possible permissions. |
  Returns: A promise that fulfils with [`PermissionResponse`](#permissionresponse) object.

#### isAvailableAsync (_Function_)

- `isAvailableAsync(): Promise<boolean>`
  Returns whether the Media Library API is enabled on the current device.
  Returns: A promise which fulfils with a `boolean`, indicating whether the Media Library API is
  available on the current device.

#### migrateAlbumIfNeededAsync (_Function_)

- `migrateAlbumIfNeededAsync(album: AlbumRef): Promise<void>`
  Moves album content to the special media directories on **Android R** or **above** if needed.
  Those new locations are in line with the Android `scoped storage` - so your application won't
  lose write permission to those directories in the future.

  This method does nothing if:
  - app is running on **iOS**, **web** or **Android below R**
  - app has **write permission** to the album folder

  The migration is possible when the album contains only compatible files types.
  For instance, movies and pictures are compatible with each other, but music and pictures are not.
  If automatic migration isn't possible, the function rejects.
  In that case, you can use methods from the `expo-file-system` to migrate all your files manually.

  # Why do you need to migrate files?

  **Android R** introduced a lot of changes in the storage system. Now applications can't save
  anything to the root directory. The only available locations are from the `MediaStore` API.
  Unfortunately, the media library stored albums in folders for which, because of those changes,
  the application doesn't have permissions anymore. However, it doesn't mean you need to migrate
  all your albums. If your application doesn't add assets to albums, you don't have to migrate.
  Everything will work as it used to. You can read more about scoped storage in [the Android documentation](https://developer.android.com/about/versions/11/privacy/storage).
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `album` | AlbumRef | An [Album](#album) or its ID. |
  Returns: A promise which fulfils to `void`.

#### presentPermissionsPickerAsync (_Function_)

- `presentPermissionsPickerAsync(mediaTypes: MediaTypeFilter[]): Promise<void>`
  Allows the user to update the assets that your app has access to.
  The system modal is only displayed if the user originally allowed only `limited` access to their
  media library, otherwise this method is a no-op.
  Available on platforms: android 14+, ios
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `mediaTypes` | MediaTypeFilter[] | Limits the type(s) of media that the user will be granting access to. By default, a list that shows both photos and videos is presented. |
  Returns: A promise that either rejects if the method is unavailable, or resolves to `void`.
  > **Note:** This method doesn't inform you if the user changes which assets your app has access to.
  > That information is only exposed by iOS, and to obtain it, you need to subscribe for updates to the user's media library using [`addListener()`](#medialibraryaddlistenerlistener).
  > If `hasIncrementalChanges` is `false`, the user changed their permissions.

#### removeAssetsFromAlbumAsync (_Function_)

- `removeAssetsFromAlbumAsync(assets: AssetRef | AssetRef[], album: AlbumRef): Promise<boolean>`
  Removes given assets from album.

  On Android, album will be automatically deleted if there are no more assets inside.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `assets` | AssetRef \| AssetRef[] | An array of [Asset](#asset) or their IDs. |
  | `album` | AlbumRef | An [Album](#album) or its ID. |
  Returns: Returns promise which fulfils with `true` if the assets were successfully removed from
  the album.

#### removeSubscription (_Function_)

- `removeSubscription(subscription: EventSubscription)`
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `subscription` | EventSubscription | - |

#### requestPermissionsAsync (_Function_)

- `requestPermissionsAsync(writeOnly: boolean, granularPermissions?: GranularPermission[]): Promise<PermissionResponse>`
  Asks the user to grant permissions for accessing media in user's media library.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `writeOnly` | boolean | - |
  | `granularPermissions` _(optional)_ | GranularPermission[] | A list of [`GranularPermission`](#granularpermission) values. This parameter has an<br>effect only on Android 13 and newer. By default, `expo-media-library` will ask for all possible permissions.<br><br>> When using granular permissions with a custom config plugin configuration, make sure that all the requested permissions are included in the plugin. |
  Returns: A promise that fulfils with [`PermissionResponse`](#permissionresponse) object.

#### saveToLibraryAsync (_Function_)

- `saveToLibraryAsync(localUri: string): Promise<void>`
  Saves the file at given `localUri` to the user's media library. Unlike [`createAssetAsync()`](#medialibrarycreateassetasynclocaluri),
  This method doesn't return created asset.
  On **iOS 11+**, it's possible to use this method without asking for `CAMERA_ROLL` permission,
  however then yours `Info.plist` should have `NSPhotoLibraryAddUsageDescription` key.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `localUri` | string | A URI to the image or video file. It must contain an extension. On Android it<br>must be a local path, so it must start with `file:///`. |

### Event Subscriptions

#### addListener (_Function_)

- `addListener(listener: (event: MediaLibraryAssetsChangeEvent) => void): EventSubscription`
  Subscribes for updates in user's media library.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `listener` | (event: MediaLibraryAssetsChangeEvent) => void | A callback that is fired when any assets have been inserted or deleted from the<br>library. On Android it's invoked with an empty object. On iOS, it's invoked with [`MediaLibraryAssetsChangeEvent`](#medialibraryassetschangeevent)<br>object.<br><br>Additionally, only on iOS, the listener is also invoked when the user changes access to individual assets in the media library<br>using `presentPermissionsPickerAsync()`. |
  Returns: An [`Subscription`](#subscription) object that you can call `remove()` on when you would
  like to unsubscribe the listener.

#### removeAllListeners (_Function_)

- `removeAllListeners()`
  Removes all listeners.

### Interfaces

#### Subscription (_Interface_)

A subscription object that allows to conveniently remove an event listener from the emitter.

### Types

#### Album (_Type_)

| Property                           | Type      | Description                                                                                                                           |
| ---------------------------------- | --------- | ------------------------------------------------------------------------------------------------------------------------------------- |
| `approximateLocation` _(optional)_ | Location  | Apply only to albums whose type is `'moment'`. Approximated location of all<br>assets in the moment. Available on platform: ios       |
| `assetCount`                       | number    | Estimated number of assets in the album.                                                                                              |
| `endTime`                          | number    | Apply only to albums whose type is `'moment'`. Latest creation timestamp of all<br>assets in the moment. Available on platform: ios   |
| `id`                               | string    | Album ID.                                                                                                                             |
| `locationNames` _(optional)_       | string[]  | Apply only to albums whose type is `'moment'`. Names of locations grouped<br>in the moment. Available on platform: ios                |
| `startTime`                        | number    | Apply only to albums whose type is `'moment'`. Earliest creation timestamp of all<br>assets in the moment. Available on platform: ios |
| `title`                            | string    | Album title.                                                                                                                          |
| `type` _(optional)_                | AlbumType | The type of the assets album. Available on platform: ios                                                                              |

#### AlbumRef (_Type_)

Type: Album | string

#### AlbumsOptions (_Type_)

| Property                          | Type    | Description |
| --------------------------------- | ------- | ----------- |
| `includeSmartAlbums` _(optional)_ | boolean | -           |

#### AlbumType (_Type_)

Type: 'album' | 'moment' | 'smartAlbum'

#### Asset (_Type_)

| Property                     | Type           | Description                                                        |
| ---------------------------- | -------------- | ------------------------------------------------------------------ |
| `albumId` _(optional)_       | string         | Album ID that the asset belongs to. Available on platform: android |
| `creationTime`               | number         | File creation timestamp.                                           |
| `duration`                   | number         | Duration of the video or audio asset in seconds.                   |
| `filename`                   | string         | Filename of the asset.                                             |
| `height`                     | number         | Height of the image or video.                                      |
| `id`                         | string         | Internal ID that represents an asset.                              |
| `mediaSubtypes` _(optional)_ | MediaSubtype[] | An array of media subtypes. Available on platform: ios             |
| `mediaType`                  | MediaTypeValue | Media type.                                                        |
| `modificationTime`           | number         | Last modification timestamp.                                       |
| `uri`                        | string         | URI that points to the asset. `ph://*` (iOS), `file://*` (Android) |
| `width`                      | number         | Width of the image or video.                                       |

#### AssetInfo (_Type_)

| Property                        | Type          | Description                                                                                                                                                                                                                                                                                 |
| ------------------------------- | ------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `exif` _(optional)_             | object        | EXIF metadata associated with the image.                                                                                                                                                                                                                                                    |
| `isFavorite` _(optional)_       | boolean       | Whether the asset is marked as favorite. Available on platform: ios                                                                                                                                                                                                                         |
| `isNetworkAsset` _(optional)_   | boolean       | This field is available only if flag `shouldDownloadFromNetwork` is set to `false`.<br>Whether the asset is stored on the network (iCloud on iOS). Available on platform: ios                                                                                                               |
| `localUri` _(optional)_         | string        | Local URI for the asset.                                                                                                                                                                                                                                                                    |
| `location` _(optional)_         | Location      | GPS location if available.                                                                                                                                                                                                                                                                  |
| `orientation` _(optional)_      | number        | Display orientation of the image. Orientation is available only for assets whose<br>`mediaType` is `MediaType.photo`. Value will range from 1 to 8, see [EXIF orientation specification](http://sylvana.net/jpegcrop/exif_orientation.html)<br>for more details. Available on platform: ios |
| `pairedVideoAsset` _(optional)_ | Asset \| null | Contains information about the video paired with the image file.<br>This field is available if the `mediaType` is `"photo"`, and the `mediaSubtypes` includes `"livePhoto"`. Available on platform: ios                                                                                     |

#### AssetRef (_Type_)

Type: Asset | string

#### AssetsOptions (_Type_)

| Property                           | Type                               | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| ---------------------------------- | ---------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `after` _(optional)_               | AssetRef                           | Asset ID of the last item returned on the previous page. To get the ID of the next page,<br>pass [`endCursor`](#pagedinfo) as its value.                                                                                                                                                                                                                                                                                                                                                                                              |
| `album` _(optional)_               | AlbumRef                           | [Album](#album) or its ID to get assets from specific album.                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| `createdAfter` _(optional)_        | Date \| number                     | `Date` object or Unix timestamp in milliseconds limiting returned assets only to those that<br>were created after this date.                                                                                                                                                                                                                                                                                                                                                                                                          |
| `createdBefore` _(optional)_       | Date \| number                     | Similarly as `createdAfter`, but limits assets only to those that were created before specified<br>date.                                                                                                                                                                                                                                                                                                                                                                                                                              |
| `first` _(optional)_               | number                             | The maximum number of items on a single page. Default: `20`                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| `mediaSubtypes` _(optional)_       | MediaSubtype[] \| MediaSubtype     | An array of [MediaSubtype](#mediasubtype)s or a single `MediaSubtype`. Available on platform: ios                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| `mediaType` _(optional)_           | MediaTypeValue[] \| MediaTypeValue | An array of [MediaTypeValue](#mediatypevalue)s or a single `MediaTypeValue`. Default: `MediaType.photo`                                                                                                                                                                                                                                                                                                                                                                                                                               |
| `resolveWithFullInfo` _(optional)_ | boolean                            | Whether to resolve full info for the assets during the query.<br>This is useful to get the full EXIF data for images. It can fix the orientation of the image. Default: `false` Available on platform: android                                                                                                                                                                                                                                                                                                                        |
| `sortBy` _(optional)_              | SortByValue[] \| SortByValue       | An array of [`SortByValue`](#sortbyvalue)s or a single `SortByValue` value. By default, all<br>keys are sorted in descending order, however you can also pass a pair `[key, ascending]` where<br>the second item is a `boolean` value that means whether to use ascending order. Note that if<br>the `SortBy.default` key is used, then `ascending` argument will not matter. Earlier items have<br>higher priority when sorting out the results.<br>If empty, this method uses the default sorting that is provided by the platform. |

#### EXPermissionResponse (_Type_)

An object obtained by permissions get and request functions.
| Property | Type | Description |
| --- | --- | --- |
| `canAskAgain` | boolean | Indicates if user can be asked again for specific permission.<br>If not, one should be directed to the Settings app<br>in order to enable/disable the permission. |
| `expires` | PermissionExpiration | Determines time when the permission expires. |
| `granted` | boolean | A convenience boolean that indicates if the permission is granted. |
| `status` | PermissionStatus | Determines the status of the permission. |

#### GranularPermission (_Type_)

Determines the type of media that the app will ask the OS to get access to.
Available on platform: android 13+
Type: 'audio' | 'photo' | 'video'

#### Location (_Type_)

| Property    | Type   | Description |
| ----------- | ------ | ----------- |
| `latitude`  | number | -           |
| `longitude` | number | -           |

#### MediaLibraryAssetInfoQueryOptions (_Type_)

| Property                                 | Type    | Description                                                                                                      |
| ---------------------------------------- | ------- | ---------------------------------------------------------------------------------------------------------------- |
| `shouldDownloadFromNetwork` _(optional)_ | boolean | Whether allow the asset to be downloaded from network. Only available in iOS with iCloud assets. Default: `true` |

#### MediaLibraryAssetsChangeEvent (_Type_)

| Property                      | Type    | Description                                                                                                                                                                                                                                                                                                                                                                                  |
| ----------------------------- | ------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `deletedAssets` _(optional)_  | Asset[] | Available only if `hasIncrementalChanges` is `true`.<br>Array of [`Asset`](#asset)s that have been deleted from the library.                                                                                                                                                                                                                                                                 |
| `hasIncrementalChanges`       | boolean | Whether the media library's changes could be described as "incremental changes".<br>`true` indicates the changes are described by the `insertedAssets`, `deletedAssets` and<br>`updatedAssets` values. `false` indicates that the scope of changes is too large and you<br>should perform a full assets reload (eg. a user has changed access to individual assets in the<br>media library). |
| `insertedAssets` _(optional)_ | Asset[] | Available only if `hasIncrementalChanges` is `true`.<br>Array of [`Asset`](#asset)s that have been inserted to the library.                                                                                                                                                                                                                                                                  |
| `updatedAssets` _(optional)_  | Asset[] | Available only if `hasIncrementalChanges` is `true`.<br>Array of [`Asset`](#asset)s that have been updated or completed downloading from network<br>storage (iCloud on iOS).                                                                                                                                                                                                                 |

#### MediaSubtype (_Type_)

Constants identifying specific variations of asset media, such as panorama or screenshot photos,
and time-lapse or high-frame-rate video. Maps to [`PHAssetMediaSubtype`](https://developer.apple.com/documentation/photokit/phassetmediasubtype#1603888).
Available on platform: ios
Type: 'depthEffect' | 'hdr' | 'highFrameRate' | 'livePhoto' | 'panorama' | 'screenshot' | 'stream' | 'timelapse' | 'spatialMedia' | 'videoCinematic'

#### MediaTypeFilter (_Type_)

Represents the possible types of media that the app will ask the OS to get access to when calling [`presentPermissionsPickerAsync()`](#medialibrarypresentpermissionspickerasyncmediatypes).
Available on platform: android 14+
Type: 'photo' | 'video'

#### MediaTypeObject (_Type_)

| Property  | Type      | Description |
| --------- | --------- | ----------- |
| `audio`   | 'audio'   | -           |
| `photo`   | 'photo'   | -           |
| `unknown` | 'unknown' | -           |
| `video`   | 'video'   | -           |

#### MediaTypeValue (_Type_)

Type: 'audio' | 'photo' | 'video' | 'unknown' | 'pairedVideo'

#### PagedInfo (_Type_)

| Property      | Type    | Description                                                                                           |
| ------------- | ------- | ----------------------------------------------------------------------------------------------------- |
| `assets`      | T[]     | A page of [`Asset`](#asset)s fetched by the query.                                                    |
| `endCursor`   | string  | ID of the last fetched asset. It should be passed as `after` option in order to get the<br>next page. |
| `hasNextPage` | boolean | Whether there are more assets to fetch.                                                               |
| `totalCount`  | number  | Estimated total number of assets that match the query.                                                |

#### PermissionExpiration (_Type_)

Permission expiration time. Currently, all permissions are granted permanently.
Type: 'never' | number

#### PermissionHookOptions (_Type_)

Type: PermissionHookBehavior & Options

#### PermissionResponse (_Type_)

| Property                        | Type                         | Description                                                                                                                                                                                                                                                                                                                                                                        |
| ------------------------------- | ---------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `accessPrivileges` _(optional)_ | 'all' \| 'limited' \| 'none' | Indicates if your app has access to the whole or only part of the photo library. Possible values are:<br>- `'all'` if the user granted your app access to the whole photo library<br>- `'limited'` if the user granted your app access only to selected photos (only available on Android API 14+ and iOS 14.0+)<br>- `'none'` if user denied or hasn't yet granted the permission |

#### SortByKey (_Type_)

Type: 'default' | 'mediaType' | 'width' | 'height' | 'creationTime' | 'modificationTime' | 'duration'

#### SortByObject (_Type_)

| Property           | Type               | Description |
| ------------------ | ------------------ | ----------- |
| `creationTime`     | 'creationTime'     | -           |
| `default`          | 'default'          | -           |
| `duration`         | 'duration'         | -           |
| `height`           | 'height'           | -           |
| `mediaType`        | 'mediaType'        | -           |
| `modificationTime` | 'modificationTime' | -           |
| `width`            | 'width'            | -           |

#### SortByValue (_Type_)

Type: [SortByKey, boolean] | SortByKey

### Constants

#### MediaType (_Constant_)

Possible media types.

- `MediaType` (MediaTypeObject) — Possible media types. = MediaLibrary.MediaType

#### SortBy (_Constant_)

Supported keys that can be used to sort `getAssetsAsync` results.

- `SortBy` (SortByObject) — Supported keys that can be used to sort `getAssetsAsync` results. = MediaLibrary.SortBy

### Enums

#### PermissionStatus (_Enum_)

#### Members

- `DENIED` — User has denied the permission.
- `GRANTED` — User has granted the permission.
- `UNDETERMINED` — User hasn't granted or denied the permission yet.

## Permissions

### Android

The following permissions are added automatically through this library's **AndroidManifest.xml**:

<AndroidPermissions
permissions={[
'READ_EXTERNAL_STORAGE',
'WRITE_EXTERNAL_STORAGE',
'READ_MEDIA_IMAGES',
'READ_MEDIA_VIDEO',
'READ_MEDIA_AUDIO',
'READ_MEDIA_VISUAL_USER_SELECTED',
]}
/>

### iOS

The following usage description keys are used by this library:

<IOSPermissions
permissions={['NSPhotoLibraryUsageDescription', 'NSPhotoLibraryAddUsageDescription']}
/>
