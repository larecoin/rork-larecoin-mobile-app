# LinearGradient

_A universal React component that renders a gradient view._

Available on platforms android, ios, tvos, web

`expo-linear-gradient` provides a native React view that transitions between multiple colors in a linear direction.

## Installation

```bash
$ bunx expo install expo-linear-gradient
```

If you are installing this in an existing React Native app, make sure to install `expo` in your project.

## Usage

```tsx
import { StyleSheet, Text, View } from "react-native";
import { LinearGradient } from "expo-linear-gradient";

export default function App() {
  return (
    <View style={styles.container}>
      <LinearGradient
        // Background Linear Gradient
        colors={["rgba(0,0,0,0.8)", "transparent"]}
        style={styles.background}
      />
      <LinearGradient
        // Button Linear Gradient
        colors={["#4c669f", "#3b5998", "#192f6a"]}
        style={styles.button}
      >
        <Text style={styles.text}>Sign in with Facebook</Text>
      </LinearGradient>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "orange",
  },
  background: {
    position: "absolute",
    left: 0,
    right: 0,
    top: 0,
    height: 300,
  },
  button: {
    padding: 15,
    alignItems: "center",
    borderRadius: 5,
  },
  text: {
    backgroundColor: "transparent",
    fontSize: 15,
    color: "#fff",
  },
});
```

## API

```js
import { LinearGradient } from "expo-linear-gradient";
```

## API: expo-linear-gradient

### LinearGradient (_Class_)

Renders a native view that transitions between multiple colors in a linear direction.

#### Methods

- `render(): React.JSX.Element`

### Props

#### LinearGradientProps (_Type_)

| Property                 | Type                        | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| ------------------------ | --------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `colors`                 | typeOperator                | A readonly array of colors that represent stops in the gradient. At least two colors are required<br>(for a single-color background, use the `style.backgroundColor` prop on a `View` component).<br><br>For TypeScript to know the provided array has 2 or more values, it should be provided "inline" or typed `as const`.                                                                                                                                                                                                                                                                                                                                                                                                         |
| `dither` _(optional)_    | boolean                     | Enables or disables paint dithering. Dithering can reduce the gradient color banding issue.<br>Setting `false` may improve gradient rendering performance. Default: `true` Available on platform: android                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |
| `end` _(optional)_       | LinearGradientPoint \| null | For example, `{ x: 0.1, y: 0.2 }` means that the gradient will end `10%` from the left and `20%` from the bottom.<br><br>**On web**, this only changes the angle of the gradient because CSS gradients don't support changing the end position.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |
| `locations` _(optional)_ | typeOperator \| null        | A readonly array that contains `number`s ranging from `0` to `1`, inclusive, and is the same length as the `colors` property.<br>Each number indicates a color-stop location where each respective color should be located.<br>If not specified, the colors will be distributed evenly across the gradient.<br><br>For example, `[0.5, 0.8]` would render:<br>- the first color, solid, from the beginning of the gradient view to 50% through (the middle);<br>- a gradient from the first color to the second from the 50% point to the 80% point; and<br>- the second color, solid, from the 80% point to the end of the gradient view.<br><br>> The color-stop locations must be ascending from least to greatest. Default: `[]` |
| `start` _(optional)_     | LinearGradientPoint \| null | For example, `{ x: 0.1, y: 0.2 }` means that the gradient will start `10%` from the left and `20%` from the top.<br><br>**On web**, this only changes the angle of the gradient because CSS gradients don't support changing the starting position.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |

### Types

#### LinearGradientPoint (_Type_)

An object `{ x: number; y: number }` or array `[x, y]` that represents the point
at which the gradient starts or ends, as a fraction of the overall size of the gradient ranging
from `0` to `1`, inclusive.
| Property | Type | Description |
| --- | --- | --- |
| `x` | number | A number ranging from `0` to `1`, representing the position of gradient transformation. |
| `y` | number | A number ranging from `0` to `1`, representing the position of gradient transformation. |

#### NativeLinearGradientPoint (_Type_)

Type: [x, y]
