# MeshGradient

_A module that exposes MeshGradient view from SwiftUI to React Native._

Available on platforms ios, tvos

## Installation

```bash
$ bunx expo install expo-mesh-gradient
```

If you are installing this in an existing React Native app, make sure to install `expo` in your project.

## API

```tsx
import { MeshGradientView } from "expo-mesh-gradient";

function App() {
  return (
    <MeshGradientView
      style={{ flex: 1 }}
      columns={3}
      rows={3}
      colors={["red", "purple", "indigo", "orange", "white", "blue", "yellow", "green", "cyan"]}
      points={[
        [0.0, 0.0],
        [0.5, 0.0],
        [1.0, 0.0],
        [0.0, 0.5],
        [0.5, 0.5],
        [1.0, 0.5],
        [0.0, 1.0],
        [0.5, 1.0],
        [1.0, 1.0],
      ]}
    />
  );
}
```

## API: expo-mesh-gradient

### MeshGradient Methods

#### MeshGradientView (_Function_)

- `MeshGradientView(props: MeshGradientViewProps): React.JSX.Element`
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `props` | MeshGradientViewProps | - |

### Props

#### MeshGradientViewProps (_Interface_)

##### Properties

- `colors?` (ColorValue[])
  An array of colors. Must contain `columns * rows` elements.
- `columns?` (number)
  Width of the mesh, i.e. the number of vertices per row.
- `ignoresSafeArea?` (boolean)
  Whether to ignore safe areas when positioning the view.
  Available on platform: ios
- `mask?` (boolean)
  Masks the gradient using the alpha channel of the given children views.
  > **Note**: When this option is enabled, all user interactions (gestures) on children views are ignored.
  > Available on platform: ios
- `points?` (number[][])
  An array of two-dimensional points on the mesh. Must contain `columns * rows` elements.
- `resolution?` ({ x: number; y: number })
  Specifies how many points to sample on the path between points.
  Available on platform: android
- `rows?` (number)
  Height of the mesh, i.e. the number of vertices per column.
- `smoothsColors?` (boolean)
  Whether cubic (smooth) interpolation should be used for the colors in the mesh
  rather than only for the shape of the mesh.
