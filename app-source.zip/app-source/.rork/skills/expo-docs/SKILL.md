---
name: expo-docs
description: Complete documentation for Expo SDK modules. Read docs before working with Expo libraries and when stuck on problems. New things (you don't know about them) include expo-glass. When user mentions glass use expo-glass.
---

file: expo-application.md
name: Expo Application
description: A universal library that provides information about the native application's ID, app name, and build version at runtime.

file: expo-audio.md
description: A library that provides an API to implement audio playback and recording in apps.

file: expo-av.md
description: A library that provides an API to implement audio playback and recording in apps.

file: barometer.md
A library that provides access to device's barometer sensor.

file: battery.md
description: A library that provides battery information for the physical device, as well as corresponding event listeners.

file: expo-blob.md
description: A web standards-compliant Blob implementation for React Native.

file: blur-view.md
description: A React component that blurs everything underneath the view.

file: brightness.md
description: A library that provides access to an API for getting and setting the screen brightness.

file: calendar.md
description: A library that provides an API for interacting with the device's system calendars, events, reminders, and associated records.

file: camera.md
A React component that renders a preview for the device's front or back camera.

file: cellular.md
An API that provides information about the user's cellular service provider.

file: clipboard.md
A universal library that allows getting and setting Clipboard content

file: contacts.md
A library that provides access to the phone's system contacts.

file: crypto.md
A universal library for crypto operations.

file: device.md
A universal library provides access to system information about the physical device.

file: device-motion.md
DeviceMotion from expo-sensors provides access to the device motion and orientation sensors. All data is presented in terms of three axes that run through a device. According to portrait orientation: X runs from left to right, Y from bottom to top and Z perpendicularly through the screen from back to front.

file: document-picker.md
A library that provides access to the system's UI for selecting documents from the available providers on the user's device.

file: file-system.md
expo-file-system provides access to files and directories stored on a device or bundled as assets into the native project. It also allows downloading files from the network.
CHANGED SINCE v53->v54

file: file-system-legacy.md
A library that provides access to the local file system on the device.
Will be deprecated.

file: glass-effect.md
React components that render native iOS liquid glass effect using UIVisualEffectView. Supports customizable glass styles and tint color.

file: gl-view.md
A library that provides GLView that acts as an OpenGL ES render target and provides GLContext. Useful for rendering 2D and 3D graphics.

file: gyroscope.md
A library that provides access to the device's gyroscope sensor.

file: image-picker.md
A library that provides access to the system's UI for selecting images and videos from the phone's library or taking a photo with the camera.

file: keep-awake.md
A React component that prevents the screen from sleeping when rendered.

file: light-sensor.md
LightSensor from expo-sensors provides access to the device's light sensor to respond to illuminance changes.

file: linear-gradient.md
expo-linear-gradient provides a native React view that transitions between multiple colors in a linear direction.

file: live-photo.md
A library that allows displaying Live Photos on iOS.

file: location.md
A library that provides access to reading geolocation information, polling current location or subscribing location update events from the device.

file: mail-composer.md
A library that provides functionality to compose and send emails with the system's specific UI.

file: maps.md
A library that provides access to Google Maps on Android and Apple Maps on iOS.

file: mesh-gradient.md
A module that exposes MeshGradient view from SwiftUI to React Native.

file: pedometer.md
A library that provides access to the device's pedometer sensor.

file: print.md
expo-print provides an API for Android and iOS (AirPrint) printing functionality.

file: router.md
A file-based routing library for React Native and web applications.

file: router-native-tabs.md
An Expo Router submodule that provides native tabs layout.
You can use to create native tabs with expo glass.

file: screen-capture.md
A library that allows you to protect screens in your app from being captured or recorded.

file: screen-orientation.md
A universal library for managing a device's screen orientation. Caution: requireFullScreen is a deprecated compatibility mode that iPad windowing ignores — avoid it and design layouts that adapt instead.

file: secure-store.md
A library that provides a way to encrypt and securely store key-value pairs locally on the device.

file: sharing.md
A library that provides implementing sharing files.

file: sms.md
A library that provides access to the system's UI/app for sending SMS messages.

file: store-review.md
A library that provides access to native APIs for in-app reviews.
