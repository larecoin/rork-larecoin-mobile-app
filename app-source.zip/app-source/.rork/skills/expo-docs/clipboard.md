# Clipboard

_A universal library that allows getting and setting Clipboard content._

Available on platforms android, ios, web

`expo-clipboard` provides an interface for getting and setting Clipboard content on Android, iOS, and Web.

## Installation

```bash
$ bunx expo install expo-clipboard
```

If you are installing this in an existing React Native app, make sure to install `expo` in your project.

## Usage

```jsx
import { useState } from "react";
import { View, Text, Button, StyleSheet } from "react-native";
import * as Clipboard from "expo-clipboard";

export default function App() {
  const [copiedText, setCopiedText] = useState("");

  const copyToClipboard = async () => {
    /* @info Copy the text to the clipboard */
    await Clipboard.setStringAsync("hello world");
    /* @end */
  };

  const fetchCopiedText = async () => {
    const text = /* @info Paste the text from the clipboard */ await Clipboard.getStringAsync();
    /* @end */
    setCopiedText(text);
  };

  return (
    <View style={styles.container}>
      <Button title="Click here to copy to Clipboard" onPress={copyToClipboard} />
      <Button title="View copied text" onPress={fetchCopiedText} />
      <Text style={styles.copiedText}>{copiedText}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  copiedText: {
    marginTop: 10,
    color: "red",
  },
});
```

## API

```js
import * as Clipboard from "expo-clipboard";
```

> **warning** On Web, this module uses the [`AsyncClipboard` API](https://developer.mozilla.org/en-US/docs/Web/API/Clipboard_API),
> which might behave differently between browsers or not be fully supported.
> Especially on WebKit, there's an issue which makes this API unusable in asynchronous code.
> [Click here for more details](https://bugs.webkit.org/show_bug.cgi?id=222262).

## API: expo-clipboard

### Methods

#### ClipboardPasteButton (_Function_)

- `ClipboardPasteButton(__namedParameters: ClipboardPasteButtonProps): null | React.JSX.Element`
  This component displays the `UIPasteControl` button on your screen. This allows pasting from the clipboard without requesting permission from the user.

  You should only attempt to render this if [`Clipboard.isPasteButtonAvailable`](#ispastebuttonavailable)
  is `true`. This component will render nothing if it is not available, and you will get
  a warning in development mode (`__DEV__ === true`).

  The properties of this component extend from `View`; however, you should not attempt to set
  `backgroundColor`, `color` or `borderRadius` with the `style` property. Apple restricts customisation of this view.
  Instead, you should use the backgroundColor and foregroundColor properties to set the colors of the button, the cornerStyle property to change the border radius,
  and the displayMode property to change the appearance of the icon and label. The word "Paste" is not editable and neither is the icon.

  Make sure to attach height and width via the style props as without these styles, the button will
  not appear on the screen.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `__namedParameters` | ClipboardPasteButtonProps | - |

#### getImageAsync (_Function_)

- `getImageAsync(options: GetImageOptions): Promise<ClipboardImage | null>`
  Gets the image from the user's clipboard and returns it in the specified
  format. Calling this method on web will prompt the user to grant your app
  permission to "see text and images copied to the clipboard."
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `options` | GetImageOptions | A `GetImageOptions` object to specify the desired format of the image. |
  Returns: If there was an image in the clipboard, the promise resolves to
  a [`ClipboardImage`](#clipboardimage) object containing the base64 string and metadata of the image.
  Otherwise, it resolves to `null`.
  Example:
  ```tsx
  const img = await Clipboard.getImageAsync({ format: "png" });
  // ...
  <Image source={{ uri: img?.data }} style={{ width: 200, height: 200 }} />;
  ```

#### getStringAsync (_Function_)

- `getStringAsync(options: GetStringOptions): Promise<string>`
  Gets the content of the user's clipboard. Calling this method on web will prompt
  the user to grant your app permission to "see text and images copied to the clipboard."
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `options` | GetStringOptions | Options for the clipboard content to be retrieved. |
  Returns: A promise that resolves to the content of the clipboard.

#### getUrlAsync (_Function_)

- `getUrlAsync(): Promise<string | null>`
  Gets the URL from the user's clipboard.
  Available on platform: ios
  Returns: A promise that fulfills to the URL in the clipboard.

#### hasImageAsync (_Function_)

- `hasImageAsync(): Promise<boolean>`
  Returns whether the clipboard has an image content.

  On web, this requires the user to grant your app permission to _"see text and images copied to the clipboard"_.
  Returns: A promise that fulfills to `true` if clipboard has image content, resolves to `false` otherwise.

#### hasStringAsync (_Function_)

- `hasStringAsync(): Promise<boolean>`
  Returns whether the clipboard has text content. Returns true for both plain text and rich text (e.g. HTML).

  On web, this requires the user to grant your app permission to _"see text and images copied to the clipboard"_.
  Returns: A promise that fulfills to `true` if clipboard has text content, resolves to `false` otherwise.

#### hasUrlAsync (_Function_)

- `hasUrlAsync(): Promise<boolean>`
  Returns whether the clipboard has a URL content.
  Available on platform: ios
  Returns: A promise that fulfills to `true` if clipboard has URL content, resolves to `false` otherwise.

#### setImageAsync (_Function_)

- `setImageAsync(base64Image: string): Promise<void>`
  Sets an image in the user's clipboard.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `base64Image` | string | Image encoded as a base64 string, without MIME type. |
  Example:
  ```tsx
  const result = await ImagePicker.launchImageLibraryAsync({
    mediaTypes: ImagePicker.MediaTypeOptions.Images,
    base64: true,
  });
  await Clipboard.setImageAsync(result.base64);
  ```

#### setString (_Function_)

- `setString(text: string)`
  Sets the content of the user's clipboard.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `text` | string | - |
  Returns: On web, this returns a boolean value indicating whether or not the string was saved to
  the user's clipboard. On iOS and Android, nothing is returned.

#### setStringAsync (_Function_)

- `setStringAsync(text: string, options: SetStringOptions): Promise<boolean>`
  Sets the content of the user's clipboard.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `text` | string | The string to save to the clipboard. |
  | `options` | SetStringOptions | Options for the clipboard content to be set. |
  Returns: On web, this returns a promise that fulfills to a boolean value indicating whether or not
  the string was saved to the user's clipboard. On iOS and Android, the promise always resolves to `true`.

#### setUrlAsync (_Function_)

- `setUrlAsync(url: string): Promise<void>`
  Sets a URL in the user's clipboard.

  This function behaves the same as [`setStringAsync()`](#setstringasynctext-options), except that
  it sets the clipboard content type to be a URL. It lets your app or other apps know that the
  clipboard contains a URL and behave accordingly.
  Available on platform: ios
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `url` | string | The URL to save to the clipboard. |

### Event Subscriptions

#### addClipboardListener (_Function_)

- `addClipboardListener(listener: (event: ClipboardEvent) => void): EventSubscription`
  Adds a listener that will fire whenever the content of the user's clipboard changes. This method
  is a no-op on Web.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `listener` | (event: ClipboardEvent) => void | Callback to execute when listener is triggered. The callback is provided a<br>single argument that is an object containing information about clipboard contents. |
  Example:
  ```typescript
  Clipboard.addClipboardListener(({ contentTypes }: ClipboardEvent) => {
    if (contentTypes.includes(Clipboard.ContentType.PLAIN_TEXT)) {
      Clipboard.getStringAsync().then((content) => {
        alert("Copy pasta! Here's the string that was copied: " + content);
      });
    } else if (contentTypes.includes(Clipboard.ContentType.IMAGE)) {
      alert("Yay! Clipboard contains an image");
    }
  });
  ```

#### removeClipboardListener (_Function_)

- `removeClipboardListener(subscription: EventSubscription)`
  Removes the listener added by addClipboardListener. This method is a no-op on Web.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `subscription` | EventSubscription | The subscription to remove (created by addClipboardListener). |
  Example:
  ```typescript
  const subscription = addClipboardListener(() => {
    alert("Copy pasta!");
  });
  removeClipboardListener(subscription);
  ```

### Props

#### ClipboardPasteButtonProps (_Type_)

| Property                            | Type                                                                       | Description                                                                                                                                                                                                                     |
| ----------------------------------- | -------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `acceptedContentTypes` _(optional)_ | AcceptedContentType[]                                                      | An array of the content types that will cause the button to become active.<br>> Do not include `plain-text` and `html` at the same time as this will cause all text to be treated as `html`. Default: `['plain-text', 'image']` |
| `backgroundColor` _(optional)_      | string \| null                                                             | The backgroundColor of the button.<br>Leaving this as the default allows the color to adjust to the system theme settings.                                                                                                      |
| `cornerStyle` _(optional)_          | CornerStyleType \| null                                                    | The cornerStyle of the button. Default: `'capsule'`                                                                                                                                                                             |
| `displayMode` _(optional)_          | DisplayModeType \| null                                                    | The displayMode of the button. Default: `'iconAndLabel'`                                                                                                                                                                        |
| `foregroundColor` _(optional)_      | string \| null                                                             | The foregroundColor of the button. Default: `'white'`                                                                                                                                                                           |
| `imageOptions` _(optional)_         | GetImageOptions \| null                                                    | The options to use when pasting an image from the clipboard.                                                                                                                                                                    |
| `onPress`                           | (data: PasteEventPayload) => void                                          | A callback that is called with the result of the paste action.<br>Inspect the `type` property to determine the type of the pasted data.<br><br>Can be one of `text` or `image`.                                                 |
| `style` _(optional)_                | StyleProp<Omit<ViewStyle, 'backgroundColor' \| 'borderRadius' \| 'color'>> | The custom style to apply to the button. Should not include `backgroundColor`, `borderRadius` or `color`<br>properties.                                                                                                         |

### Interfaces

#### Subscription (_Interface_)

A subscription object that allows to conveniently remove an event listener from the emitter.

### Types

#### AcceptedContentType (_Type_)

Type: 'plain-text' | 'image' | 'url' | 'html'

#### ClipboardEvent (_Type_)

| Property       | Type          | Description                                                    |
| -------------- | ------------- | -------------------------------------------------------------- |
| `content`      | string        | -                                                              |
| `contentTypes` | ContentType[] | An array of content types that are available on the clipboard. |

#### ClipboardImage (_Type_)

| Property | Type                              | Description                                                                                                                                                                                                                                                                      |
| -------- | --------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `data`   | string                            | A Base64-encoded string of the image data. Its format is dependent on the `format` option.<br>You can use it directly as the source of an `Image` element.<br><br>> **NOTE:** The string is already prepended with `data:image/png;base64,` or `data:image/jpeg;base64,` prefix. |
| `size`   | { height: number; width: number } | Dimensions (`width` and `height`) of the image pasted from clipboard.                                                                                                                                                                                                            |

#### CornerStyleType (_Type_)

Type: 'dynamic' | 'fixed' | 'capsule' | 'large' | 'medium' | 'small'

#### DisplayModeType (_Type_)

Type: 'iconAndLabel' | 'iconOnly' | 'labelOnly'

#### GetImageOptions (_Type_)

| Property                   | Type            | Description                                                                                                                                                                           |
| -------------------------- | --------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `format`                   | 'png' \| 'jpeg' | The format of the clipboard image to be converted to.                                                                                                                                 |
| `jpegQuality` _(optional)_ | number          | Specify the quality of the returned image, between `0` and `1`. Defaults to `1` (highest quality).<br>Applicable only when `format` is set to `jpeg`, ignored otherwise. Default: `1` |

#### GetStringOptions (_Type_)

| Property                       | Type         | Description                                                                                                   |
| ------------------------------ | ------------ | ------------------------------------------------------------------------------------------------------------- |
| `preferredFormat` _(optional)_ | StringFormat | The target format of the clipboard string to be converted to, if possible. Default: `StringFormat.PLAIN_TEXT` |

#### ImagePasteEvent (_Type_)

| Property | Type    | Description |
| -------- | ------- | ----------- |
| `type`   | 'image' | -           |

#### PasteEventPayload (_Type_)

Type: TextPasteEvent | ImagePasteEvent

#### SetStringOptions (_Type_)

| Property                   | Type         | Description                                                                                                                                                        |
| -------------------------- | ------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `inputFormat` _(optional)_ | StringFormat | The input format of the provided string.<br>Adjusting this option can help other applications interpret copied string properly. Default: `StringFormat.PLAIN_TEXT` |

#### TextPasteEvent (_Type_)

| Property | Type   | Description |
| -------- | ------ | ----------- |
| `text`   | string | -           |
| `type`   | 'text' | -           |

### Constants

#### isPasteButtonAvailable (_Constant_)

Property that determines if the `ClipboardPasteButton` is available.

This requires the users device to be using at least iOS 16.

`true` if the component is available, and `false` otherwise.

- `isPasteButtonAvailable` (boolean) — Property that determines if the `ClipboardPasteButton` is available.

This requires the users device to be using at least iOS 16.

`true` if the component is available, and `false` otherwise. = ...

### Enums

#### ContentType (_Enum_)

Type used to define what type of data is stored in the clipboard.

#### Members

- `HTML`
- `IMAGE`
- `PLAIN_TEXT`
- `URL`

#### StringFormat (_Enum_)

Type used to determine string format stored in the clipboard.

#### Members

- `HTML`
- `PLAIN_TEXT`
