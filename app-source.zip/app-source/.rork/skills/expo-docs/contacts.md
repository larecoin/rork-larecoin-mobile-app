# Contacts

_A library that provides access to the phone's system contacts._

Available on platforms android, ios

`expo-contacts` provides access to the device's system contacts, allowing you to get contact information as well as adding, editing, or removing contacts.

On iOS, contacts have a multi-layered grouping system that you can also access through this API.

## Installation

```bash
$ bunx expo install expo-contacts
```

If you are installing this in an existing React Native app, make sure to install `expo` in your project.

## Configuration in app config

You can configure `expo-contacts` using its built-in [config plugin](https://docs.expo.dev/config-plugins/introduction/) if you use config plugins in your project ([Continuous Native Generation (CNG)](https://docs.expo.dev/workflow/continuous-native-generation/)). The plugin allows you to configure various properties that cannot be set at runtime and require building a new app binary to take effect. If your app does **not** use CNG, then you'll need to manually configure the library.

```json app.json
{
  "expo": {
    "plugins": [
      [
        "expo-contacts",
        {
          "contactsPermission": "Allow $(PRODUCT_NAME) to access your contacts."
        }
      ]
    ]
  }
}
```

### Configurable properties

| Name                 | Default                                           | Description                                                                                 |
| -------------------- | ------------------------------------------------- | ------------------------------------------------------------------------------------------- |
| `contactsPermission` | `"Allow $(PRODUCT_NAME) to access your contacts"` | Only for: ios. A string to set the [`NSContactsUsageDescription`](#ios) permission message. |

<ConfigReactNative>

If you're not using Continuous Native Generation ([CNG](https://docs.expo.dev/workflow/continuous-native-generation/)) (you're using native **android** and **ios** projects manually), then you need to configure following permissions in your native projects:

- For Android, add `android.permission.READ_CONTACTS` and `android.permission.WRITE_CONTACTS` permissions to your project's **android/app/src/main/AndroidManifest.xml**:

  ```xml
  <uses-permission android:name="android.permission.READ_CONTACTS" />
  <uses-permission android:name="android.permission.WRITE_CONTACTS" />
  ```

- For iOS, add the `NSContactsUsageDescription` key to your project's **ios/[app]/Info.plist**:

  ```xml
  <key>NSContactsUsageDescription</key>
  <string>Allow $(PRODUCT_NAME) to access your contacts</string>
  ```

</ConfigReactNative>

## Usage

```jsx
import { useEffect } from "react";
import { StyleSheet, View, Text } from "react-native";
import * as Contacts from "expo-contacts";

export default function App() {
  useEffect(() => {
    (async () => {
      const { status } = await Contacts.requestPermissionsAsync();
      if (status === "granted") {
        const { data } = await Contacts.getContactsAsync({
          fields: [Contacts.Fields.Emails],
        });

        if (data.length > 0) {
          const contact = data[0];
          console.log(contact);
        }
      }
    })();
  }, []);

  return (
    <View style={styles.container}>
      <Text>Contacts Module Example</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
});
```

## API

```js
import * as Contacts from "expo-contacts";
```

## API: expo-contacts

### ContactAccessButton (_Class_)

Creates a contact access button to quickly add contacts under limited-access authorization.

For more details, you can read the Apple docs about the underlying [`ContactAccessButton`](https://developer.apple.com/documentation/contactsui/contactaccessbutton) SwiftUI view.
Available on platform: ios 18.0+

#### Methods

- `render(): null | React.JSX.Element`

- `isAvailable(): boolean`
  Returns a boolean whether the `ContactAccessButton` is available on the platform.
  This is `true` only on iOS 18.0 and newer.

### Contacts Methods

#### addContactAsync (_Function_)

- `addContactAsync(contact: Contact, containerId?: string): Promise<string>`
  Creates a new contact and adds it to the system.
  > **Note**: For Android users, the Expo Go app does not have the required `WRITE_CONTACTS` permission to write to Contacts.
  > You will need to create a [development build](https://docs.expo.dev/develop/development-builds/create-a-build/) and add permission in there manually to use this method.
  > | Parameter | Type | Description |
  > | --- | --- | --- |
  > | `contact` | Contact | A contact with the changes you wish to persist. The `id` parameter will not be used. |
  > | `containerId` _(optional)_ | string | @tag-ios The container that will parent the contact. |
  > Returns: A promise that fulfills with ID of the new system contact.
  > Example:
  ```js
  const contact = {
    [Contacts.Fields.FirstName]: "Bird",
    [Contacts.Fields.LastName]: "Man",
    [Contacts.Fields.Company]: "Young Money",
  };
  const contactId = await Contacts.addContactAsync(contact);
  ```

#### addExistingContactToGroupAsync (_Function_)

- `addExistingContactToGroupAsync(contactId: string, groupId: string): Promise<any>`
  Add a contact as a member to a group. A contact can be a member of multiple groups.
  Available on platform: ios
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `contactId` | string | ID of the contact you want to edit. |
  | `groupId` | string | ID for the group you want to add membership to. |
  Example:
  ```js
  await Contacts.addExistingContactToGroupAsync(
    "665FDBCFAE55-D614-4A15-8DC6-161A368D",
    "161A368D-D614-4A15-8DC6-665FDBCFAE55",
  );
  ```

#### addExistingGroupToContainerAsync (_Function_)

- `addExistingGroupToContainerAsync(groupId: string, containerId: string): Promise<any>`
  Add a group to a container.
  Available on platform: ios
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `groupId` | string | The group you want to target. |
  | `containerId` | string | The container you want to add membership to. |
  Example:
  ```js
  await Contacts.addExistingGroupToContainerAsync(
    "161A368D-D614-4A15-8DC6-665FDBCFAE55",
    "665FDBCFAE55-D614-4A15-8DC6-161A368D",
  );
  ```

#### createGroupAsync (_Function_)

- `createGroupAsync(name?: string, containerId?: string): Promise<string>`
  Create a group with a name, and add it to a container. If the container is `undefined`, the default container will be targeted.
  Available on platform: ios
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `name` _(optional)_ | string | Name of the new group. |
  | `containerId` _(optional)_ | string | The container you to add membership to. |
  Returns: A promise that fulfills with ID of the new group.
  Example:
  ```js
  const groupId = await Contacts.createGroupAsync("Sailor Moon");
  ```

#### getContactByIdAsync (_Function_)

- `getContactByIdAsync(id: string, fields?: FieldType[]): Promise<Contact | undefined>`
  Used for gathering precise data about a contact. Returns a contact matching the given `id`.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `id` | string | The ID of a system contact. |
  | `fields` _(optional)_ | FieldType[] | If specified, the fields defined will be returned. When skipped, all fields will be returned. |
  Returns: A promise that fulfills with `Contact` object with ID matching the input ID, or `undefined` if there is no match.
  Example:
  ```js
  const contact = await Contacts.getContactByIdAsync("161A368D-D614-4A15-8DC6-665FDBCFAE55");
  if (contact) {
    console.log(contact);
  }
  ```

#### getContactsAsync (_Function_)

- `getContactsAsync(contactQuery: ContactQuery): Promise<ContactResponse>`
  Return a list of contacts that fit a given criteria. You can get all of the contacts by passing no criteria.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `contactQuery` | ContactQuery | Object used to query contacts. |
  Returns: A promise that fulfills with `ContactResponse` object returned from the query.
  Example:

  ```js
  const { data } = await Contacts.getContactsAsync({
    fields: [Contacts.Fields.Emails],
  });

  if (data.length > 0) {
    const contact = data[0];
    console.log(contact);
  }
  ```

#### getContainersAsync (_Function_)

- `getContainersAsync(containerQuery: ContainerQuery): Promise<Container[]>`
  Query a list of system containers.
  Available on platform: ios
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `containerQuery` | ContainerQuery | Information used to gather containers. |
  Returns: A promise that fulfills with array of containers that fit the query.
  Example:
  ```js
  const allContainers = await Contacts.getContainersAsync({
    contactId: "665FDBCFAE55-D614-4A15-8DC6-161A368D",
  });
  ```

#### getDefaultContainerIdAsync (_Function_)

- `getDefaultContainerIdAsync(): Promise<string>`
  Get the default container's ID.
  Available on platform: ios
  Returns: A promise that fulfills with default container ID.
  Example:
  ```js
  const containerId = await Contacts.getDefaultContainerIdAsync();
  ```

#### getGroupsAsync (_Function_)

- `getGroupsAsync(groupQuery: GroupQuery): Promise<Group[]>`
  Query and return a list of system groups.
  Available on platform: ios
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `groupQuery` | GroupQuery | Information regarding which groups you want to get. |
  Returns: A promise that fulfills with array of groups that fit the query.
  Example:
  ```js
  const groups = await Contacts.getGroupsAsync({ groupName: "sailor moon" });
  const allGroups = await Contacts.getGroupsAsync({});
  ```

#### getPagedContactsAsync (_Function_)

- `getPagedContactsAsync(contactQuery: ContactQuery): Promise<ContactResponse>`
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `contactQuery` | ContactQuery | - |

#### getPermissionsAsync (_Function_)

- `getPermissionsAsync(): Promise<ContactsPermissionResponse>`
  Checks user's permissions for accessing contacts data.
  Returns: A promise that resolves to a [ContactsPermissionResponse](#contactspermissionresponse) object.

#### isAvailableAsync (_Function_)

- `isAvailableAsync(): Promise<boolean>`
  Returns whether the Contacts API is enabled on the current device. This method does not check the app permissions.
  Returns: A promise that fulfills with a `boolean`, indicating whether the Contacts API is available on the current device. It always resolves to `false` on web.

#### presentAccessPickerAsync (_Function_)

- `presentAccessPickerAsync(): Promise<string[]>`
  Presents a modal which allows the user to select which contacts the app has access to.
  Using this function is reasonable only when the app has "limited" permissions.
  Available on platform: ios 18.0+
  Returns: A promise that resolves with an array of contact identifiers that were newly granted to the app.
  Contacts which the app lost access to are not listed. On platforms other than iOS and below 18.0, the promise rejects immediately.

#### presentContactPickerAsync (_Function_)

- `presentContactPickerAsync(): Promise<Contact | null>`
  Presents a native contact picker to select a single contact from the system. On Android, the `READ_CONTACTS` permission is required. You can
  obtain this permission by calling the [`Contacts.requestPermissionsAsync()`](#contactsrequestpermissionsasync) method. On iOS, no permissions are
  required to use this method.
  Returns: A promise that fulfills with a single `Contact` object if a contact is selected or `null` if no contact is selected (when selection is canceled).

#### presentFormAsync (_Function_)

- `presentFormAsync(contactId?: null | string, contact?: null | Contact, formOptions: FormOptions): Promise<any>`
  Present a native form for manipulating contacts.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `contactId` _(optional)_ | null \| string | The ID of a system contact. |
  | `contact` _(optional)_ | null \| Contact | A contact with the changes you want to persist. |
  | `formOptions` | FormOptions | Options for the native editor. |
  Example:
  ```js
  await Contacts.presentFormAsync("161A368D-D614-4A15-8DC6-665FDBCFAE55");
  ```

#### removeContactAsync (_Function_)

- `removeContactAsync(contactId: string): Promise<any>`
  Delete a contact from the system.
  Available on platform: ios
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `contactId` | string | ID of the contact you want to delete. |
  Example:
  ```js
  await Contacts.removeContactAsync("161A368D-D614-4A15-8DC6-665FDBCFAE55");
  ```

#### removeContactFromGroupAsync (_Function_)

- `removeContactFromGroupAsync(contactId: string, groupId: string): Promise<any>`
  Remove a contact's membership from a given group. This will not delete the contact.
  Available on platform: ios
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `contactId` | string | ID of the contact you want to remove. |
  | `groupId` | string | ID for the group you want to remove membership of. |
  Example:
  ```js
  await Contacts.removeContactFromGroupAsync(
    "665FDBCFAE55-D614-4A15-8DC6-161A368D",
    "161A368D-D614-4A15-8DC6-665FDBCFAE55",
  );
  ```

#### removeGroupAsync (_Function_)

- `removeGroupAsync(groupId: string): Promise<any>`
  Delete a group from the device.
  Available on platform: ios
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `groupId` | string | ID of the group you want to remove. |
  Example:
  ```js
  await Contacts.removeGroupAsync("161A368D-D614-4A15-8DC6-665FDBCFAE55");
  ```

#### requestPermissionsAsync (_Function_)

- `requestPermissionsAsync(): Promise<ContactsPermissionResponse>`
  Asks the user to grant permissions for accessing contacts data.
  Returns: A promise that resolves to a [ContactsPermissionResponse](#contactspermissionresponse) object.

#### shareContactAsync (_Function_)

- `shareContactAsync(contactId: string, message: string, shareOptions: ShareOptions): Promise<any>`
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `contactId` | string | - |
  | `message` | string | - |
  | `shareOptions` | ShareOptions | - |

#### updateContactAsync (_Function_)

- `updateContactAsync(contact: { id: string } & Partial<Omit<Contact, 'id'>>): Promise<string>`
  Mutate the information of an existing contact. Due to an iOS bug, `nonGregorianBirthday` field cannot be modified.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `contact` | { id: string } & Partial<Omit<Contact, 'id'>> | A contact object including the wanted changes. Contact `id` is required. |
  Returns: A promise that fulfills with ID of the updated system contact if mutation was successful.
  Example:
  ```js
  const contact = {
    id: "161A368D-D614-4A15-8DC6-665FDBCFAE55",
    [Contacts.Fields.FirstName]: "Drake",
    [Contacts.Fields.Company]: "Young Money",
  };
  await Contacts.updateContactAsync(contact);
  ```

#### updateGroupNameAsync (_Function_)

- `updateGroupNameAsync(groupName: string, groupId: string): Promise<any>`
  Change the name of an existing group.
  Available on platform: ios
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `groupName` | string | New name for an existing group. |
  | `groupId` | string | ID of the group you want to edit. |
  Example:
  ```js
  await Contacts.updateGroupName("Expo Friends", "161A368D-D614-4A15-8DC6-665FDBCFAE55");
  ```

#### writeContactToFileAsync (_Function_)

- `writeContactToFileAsync(contactQuery: ContactQuery): Promise<string | undefined>`
  Query a set of contacts and write them to a local URI that can be used for sharing.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `contactQuery` | ContactQuery | Used to query contact you want to write. |
  Returns: A promise that fulfills with shareable local URI, or `undefined` if there was no match.
  Example:
  ```js
  const localUri = await Contacts.writeContactToFileAsync({
    id: "161A368D-D614-4A15-8DC6-665FDBCFAE55",
  });
  Share.share({ url: localUri, message: "Call me!" });
  ```

### Props

#### ContactAccessButtonProps (_Type_)

| Property                           | Type                            | Description                                                                                                                                                                                                                                                                                   |
| ---------------------------------- | ------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `backgroundColor` _(optional)_     | ColorValue                      | A color of the button's background. Provided color should not be transparent,<br>otherwise it may not satisfy platform requirements for button legibility. Available on platform: ios 18.0+                                                                                                   |
| `caption` _(optional)_             | 'default' \| 'email' \| 'phone' | When the query produces a single result, the contact access button shows the caption under the matching contact name.<br>It can be nothing (default), email address or phone number. Available on platform: ios 18.0+                                                                         |
| `ignoredEmails` _(optional)_       | string[]                        | An array of email addresses. The search omits contacts matching query that also match any email address in this array. Available on platform: ios 18.0+                                                                                                                                       |
| `ignoredPhoneNumbers` _(optional)_ | string[]                        | An array of phone numbers. The search omits contacts matching query that also match any phone number in this set. Available on platform: ios 18.0+                                                                                                                                            |
| `query` _(optional)_               | string                          | A string to match against contacts not yet exposed to the app.<br>You typically get this value from a search UI that your app presents, like a text field. Available on platform: ios 18.0+                                                                                                   |
| `textColor` _(optional)_           | ColorValue                      | A color of the button's title. Slightly dimmed version of this color is used for the caption text.<br>Make sure there is a good contrast between the text and the background,<br>otherwise platform requirements for button legibility may not be satisfied. Available on platform: ios 18.0+ |
| `tintColor` _(optional)_           | ColorValue                      | A tint color of the button and the modal that is presented when there is more than one match. Available on platform: ios 18.0+                                                                                                                                                                |

### Types

#### Address (_Type_)

| Property                      | Type   | Description                                                               |
| ----------------------------- | ------ | ------------------------------------------------------------------------- |
| `city` _(optional)_           | string | City name.                                                                |
| `country` _(optional)_        | string | Country name                                                              |
| `id` _(optional)_             | string | Unique ID. This value will be generated by the OS.                        |
| `isoCountryCode` _(optional)_ | string | [Standard country code](https://www.iso.org/iso-3166-country-codes.html). |
| `label`                       | string | Localized display name.                                                   |
| `neighborhood` _(optional)_   | string | Neighborhood name.                                                        |
| `poBox` _(optional)_          | string | P.O. Box.                                                                 |
| `postalCode` _(optional)_     | string | Local post code.                                                          |
| `region` _(optional)_         | string | Region or state name.                                                     |
| `street` _(optional)_         | string | Street name.                                                              |

#### CalendarFormatType (_Type_)

Type: CalendarFormats | templateLiteral

#### Contact (_Type_)

A set of fields that define information about a single contact entity.
| Property | Type | Description |
| --- | --- | --- |
| `addresses` _(optional)_ | Address[] | Locations. |
| `birthday` _(optional)_ | Date | Birthday information in Gregorian format. |
| `company` _(optional)_ | string | Organization the entity belongs to. |
| `contactType` | ContactType | Denoting a person or company. |
| `dates` _(optional)_ | Date[] | A labeled list of other relevant user dates in Gregorian format. |
| `department` _(optional)_ | string | Job department. |
| `emails` _(optional)_ | Email[] | Email addresses. |
| `firstName` _(optional)_ | string | Given name. |
| `id` _(optional)_ | string | Immutable identifier used for querying and indexing. This value will be generated by the OS when the contact is created. |
| `image` _(optional)_ | Image | Thumbnail image. On iOS it size is set to 320×320px, on Android it may vary. |
| `imageAvailable` _(optional)_ | boolean | Used for efficient retrieval of images. |
| `instantMessageAddresses` _(optional)_ | InstantMessageAddress[] | Instant messaging connections. |
| `isFavorite` _(optional)_ | boolean | Whether the contact is starred. Available on platform: android |
| `jobTitle` _(optional)_ | string | Job description. |
| `lastName` _(optional)_ | string | Last name. |
| `maidenName` _(optional)_ | string | Maiden name. |
| `middleName` _(optional)_ | string | Middle name |
| `name` | string | Full name with proper format. |
| `namePrefix` _(optional)_ | string | Dr., Mr., Mrs., and so on. |
| `nameSuffix` _(optional)_ | string | Jr., Sr., and so on. |
| `nickname` _(optional)_ | string | An alias to the proper name. |
| `nonGregorianBirthday` _(optional)_ | Date | Birthday that doesn't conform to the Gregorian calendar format, interpreted based on the [calendar `format`](#date) setting. Available on platform: ios |
| `note` _(optional)_ | string | Additional information.<br>> The `note` field [requires your app to request additional entitlements](https://developer.apple.com/documentation/bundleresources/entitlements/com_apple_developer_contacts_notes).<br>> The Expo Go app does not contain those entitlements, so in order to test this feature you will need to [request the entitlement from Apple](https://developer.apple.com/contact/request/contact-note-field),<br>> set the [`ios.accessesContactNotes`](./../config/app/#accessescontactnotes) field in **app config** to `true`, and [create your development build](https://docs.expo.dev/develop/development-builds/create-a-build/). |
| `phoneNumbers` _(optional)_ | PhoneNumber[] | Phone numbers. |
| `phoneticFirstName` _(optional)_ | string | Pronunciation of the first name. |
| `phoneticLastName` _(optional)_ | string | Pronunciation of the last name. |
| `phoneticMiddleName` _(optional)_ | string | Pronunciation of the middle name. |
| `rawImage` _(optional)_ | Image | Raw image without cropping, usually large. |
| `relationships` _(optional)_ | Relationship[] | Names of other relevant user connections. |
| `socialProfiles` _(optional)_ | SocialProfile[] | Social networks. Available on platform: ios |
| `urlAddresses` _(optional)_ | UrlAddress[] | Associated web URLs. |

#### ContactQuery (_Type_)

Used to query contacts from the user's device.
| Property | Type | Description |
| --- | --- | --- |
| `containerId` _(optional)_ | string | Get all contacts that belong to the container matching this ID. Available on platform: ios |
| `fields` _(optional)_ | FieldType[] | If specified, the defined fields will be returned. If skipped, all fields will be returned. |
| `groupId` _(optional)_ | string | Get all contacts that belong to the group matching this ID. Available on platform: ios |
| `id` _(optional)_ | string \| string[] | Get contacts with a matching ID or array of IDs. |
| `name` _(optional)_ | string | Get all contacts whose name contains the provided string (not case-sensitive). |
| `pageOffset` _(optional)_ | number | The number of contacts to skip before gathering contacts. |
| `pageSize` _(optional)_ | number | The max number of contacts to return. If skipped or set to `0` all contacts will be returned. |
| `rawContacts` _(optional)_ | boolean | Prevent unification of contacts when gathering. Default: `false` Available on platform: ios |
| `sort` _(optional)_ | ContactSort | Sort method used when gathering contacts. |

#### ContactResponse (_Type_)

The return value for queried contact operations like `getContactsAsync`.
| Property | Type | Description |
| --- | --- | --- |
| `data` | Contact[] | An array of contacts that match a particular query. |
| `hasNextPage` | boolean | This will be `true` if there are more contacts to retrieve beyond what is returned. |
| `hasPreviousPage` | boolean | This will be `true` if there are previous contacts that weren't retrieved due to `pageOffset` limit. |

#### ContactSort (_Type_)

Type: templateLiteral

#### ContactsPermissionResponse (_Type_)

| Property                        | Type                         | Description                                                                                                                                                                                                                                                                                                    |
| ------------------------------- | ---------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `accessPrivileges` _(optional)_ | 'all' \| 'limited' \| 'none' | Indicates if your app has access to the whole or only part of the contact library. Possible values are:<br>- `'all'` if the user granted your app access to the whole contact library<br>- `'limited'` if the user granted your app access only to selected contacts (only available on iOS 18+)<br>- `'none'` |

#### ContactType (_Type_)

Type: ContactTypes | templateLiteral

#### Container (_Type_)

| Property | Type          | Description |
| -------- | ------------- | ----------- |
| `id`     | string        | -           |
| `name`   | string        | -           |
| `type`   | ContainerType | -           |

#### ContainerQuery (_Type_)

Used to query native contact containers.
Available on platform: ios
| Property | Type | Description |
| --- | --- | --- |
| `contactId` _(optional)_ | string | Query all the containers that parent a contact. |
| `containerId` _(optional)_ | string \| string[] | Query all the containers that matches ID or an array od IDs. |
| `groupId` _(optional)_ | string | Query all the containers that parent a group. |

#### ContainerType (_Type_)

Type: ContainerTypes | templateLiteral

#### Date (_Type_)

| Property              | Type               | Description                                                                |
| --------------------- | ------------------ | -------------------------------------------------------------------------- |
| `day`                 | number             | Day.                                                                       |
| `format` _(optional)_ | CalendarFormatType | Format for the date. This is provided by the OS, do not set this manually. |
| `id` _(optional)_     | string             | Unique ID. This value will be generated by the OS.                         |
| `label` _(optional)_  | string             | Localized display name.                                                    |
| `month`               | number             | Month - adjusted for JavaScript `Date` which starts at `0`.                |
| `year` _(optional)_   | number             | Year.                                                                      |

#### Email (_Type_)

| Property                 | Type    | Description                                        |
| ------------------------ | ------- | -------------------------------------------------- |
| `email` _(optional)_     | string  | Email address.                                     |
| `id` _(optional)_        | string  | Unique ID. This value will be generated by the OS. |
| `isPrimary` _(optional)_ | boolean | Flag signifying if it is a primary email address.  |
| `label`                  | string  | Localized display name.                            |

#### FieldType (_Type_)

Type: Fields | templateLiteral

#### FormOptions (_Type_)

Denotes the functionality of a native contact form.
| Property | Type | Description |
| --- | --- | --- |
| `allowsActions` _(optional)_ | boolean | Actions like share, add, create. |
| `allowsEditing` _(optional)_ | boolean | Allows for contact mutation. |
| `alternateName` _(optional)_ | string | Used if contact doesn't have a name defined. |
| `cancelButtonTitle` _(optional)_ | string | The name of the left bar button. |
| `displayedPropertyKeys` _(optional)_ | FieldType[] | The properties that will be displayed. On iOS those properties does nothing while in editing mode. |
| `groupId` _(optional)_ | string | The parent group for a new contact. |
| `isNew` _(optional)_ | boolean | Present the new contact controller. If set to `false` the unknown controller will be shown. |
| `message` _(optional)_ | string | Controller title. |
| `preventAnimation` _(optional)_ | boolean | Prevents the controller from animating in. |
| `shouldShowLinkedContacts` _(optional)_ | boolean | Show or hide the similar contacts. |

#### Group (_Type_)

A parent to contacts. A contact can belong to multiple groups. Here are some query operations you can perform:

- Child Contacts: `getContactsAsync({ groupId })`
- Groups From Container: `getGroupsAsync({ containerId })`
- Groups Named: `getContainersAsync({ groupName })`
  Available on platform: ios
  | Property | Type | Description |
  | --- | --- | --- |
  | `id` _(optional)_ | string | The editable name of a group. |
  | `name` _(optional)_ | string | Immutable id representing the group. |

#### GroupQuery (_Type_)

Used to query native contact groups.
Available on platform: ios
| Property | Type | Description |
| --- | --- | --- |
| `containerId` _(optional)_ | string | Query all groups that belong to a certain container. |
| `groupId` _(optional)_ | string | Query the group with a matching ID. |
| `groupName` _(optional)_ | string | Query all groups matching a name. |

#### Image (_Type_)

Information regarding thumbnail images.

> On Android you can get dimensions using [`Image.getSize`](https://reactnative.dev/docs/image#getsize) method.
> | Property | Type | Description |
> | --- | --- | --- |
> | `base64` _(optional)_ | string | Image as Base64 string. |
> | `height` _(optional)_ | number | Image height Available on platform: ios |
> | `uri` _(optional)_ | string | A local image URI.<br>> **Note**: If you have a remote URI, download it first using [`FileSystem.downloadAsync`](https://docs.expo.dev/versions/latest/sdk/filesystem/#filesystemdownloadasyncuri-fileuri-options). |
> | `width` _(optional)_ | number | Image width. Available on platform: ios |

#### InstantMessageAddress (_Type_)

| Property                        | Type   | Description                                        |
| ------------------------------- | ------ | -------------------------------------------------- |
| `id` _(optional)_               | string | Unique ID. This value will be generated by the OS. |
| `label`                         | string | Localized display name.                            |
| `localizedService` _(optional)_ | string | Localized name of app.                             |
| `service` _(optional)_          | string | Name of instant messaging app.                     |
| `username` _(optional)_         | string | Username in IM app.                                |

#### PermissionExpiration (_Type_)

Permission expiration time. Currently, all permissions are granted permanently.
Type: 'never' | number

#### PermissionResponse (_Type_)

An object obtained by permissions get and request functions.
| Property | Type | Description |
| --- | --- | --- |
| `canAskAgain` | boolean | Indicates if user can be asked again for specific permission.<br>If not, one should be directed to the Settings app<br>in order to enable/disable the permission. |
| `expires` | PermissionExpiration | Determines time when the permission expires. |
| `granted` | boolean | A convenience boolean that indicates if the permission is granted. |
| `status` | PermissionStatus | Determines the status of the permission. |

#### PhoneNumber (_Type_)

| Property                   | Type    | Description                                        |
| -------------------------- | ------- | -------------------------------------------------- |
| `countryCode` _(optional)_ | string  | Country code.                                      |
| `digits` _(optional)_      | string  | Phone number without format.                       |
| `id` _(optional)_          | string  | Unique ID. This value will be generated by the OS. |
| `isPrimary` _(optional)_   | boolean | Flag signifying if it is a primary phone number.   |
| `label`                    | string  | Localized display name.                            |
| `number` _(optional)_      | string  | Phone number.                                      |

#### Relationship (_Type_)

| Property            | Type   | Description                                        |
| ------------------- | ------ | -------------------------------------------------- |
| `id` _(optional)_   | string | Unique ID. This value will be generated by the OS. |
| `label`             | string | Localized display name.                            |
| `name` _(optional)_ | string | Name of related contact.                           |

#### SocialProfile (_Type_)

Available on platform: ios
| Property | Type | Description |
| --- | --- | --- |
| `id` _(optional)_ | string | Unique ID. This value will be generated by the OS. |
| `label` | string | Localized display name. |
| `localizedProfile` _(optional)_ | string | Localized profile name. |
| `service` _(optional)_ | string | Name of social app. |
| `url` _(optional)_ | string | Web URL. |
| `userId` _(optional)_ | string | Username ID in social app. |
| `username` _(optional)_ | string | Username in social app. |

#### UrlAddress (_Type_)

| Property           | Type   | Description                                        |
| ------------------ | ------ | -------------------------------------------------- |
| `id` _(optional)_  | string | Unique ID. This value will be generated by the OS. |
| `label`            | string | Localized display name.                            |
| `url` _(optional)_ | string | Web URL.                                           |

### Enums

#### CalendarFormats (_Enum_)

This format denotes the common calendar format used to specify how a date is calculated in `nonGregorianBirthday` fields.

#### Members

- `Buddhist`
- `Chinese`
- `Coptic`
- `EthiopicAmeteAlem`
- `EthiopicAmeteMihret`
- `Gregorian`
- `Hebrew`
- `Indian`
- `Islamic`
- `IslamicCivil`
- `IslamicTabular`
- `IslamicUmmAlQura`
- `ISO8601`
- `Japanese`
- `Persian`
- `RepublicOfChina`

#### ContactTypes (_Enum_)

#### Members

- `Company` — Contact is group or company.
- `Person` — Contact is a human.

#### ContainerTypes (_Enum_)

Available on platform: ios

#### Members

- `CardDAV` — With cardDAV protocol used for sharing.
- `Exchange` — In association with email server.
- `Local` — A local non-iCloud container.
- `Unassigned` — Unknown container.

#### Fields (_Enum_)

Possible fields to retrieve for a contact.

#### Members

- `Addresses`
- `Birthday`
- `Company`
- `ContactType`
- `Dates`
- `Department`
- `Emails`
- `ExtraNames`
- `FirstName`
- `ID`
- `Image`
- `ImageAvailable`
- `InstantMessageAddresses`
- `IsFavorite`
- `JobTitle`
- `LastName`
- `MaidenName`
- `MiddleName`
- `Name`
- `NamePrefix`
- `NameSuffix`
- `Nickname`
- `NonGregorianBirthday`
- `Note`
- `PhoneNumbers`
- `PhoneticFirstName`
- `PhoneticLastName`
- `PhoneticMiddleName`
- `RawImage`
- `Relationships`
- `SocialProfiles`
- `UrlAddresses`

#### PermissionStatus (_Enum_)

#### Members

- `DENIED` — User has denied the permission.
- `GRANTED` — User has granted the permission.
- `UNDETERMINED` — User hasn't granted or denied the permission yet.

#### SortTypes (_Enum_)

#### Members

- `FirstName` — Sort by first name in ascending order.
- `LastName` — Sort by last name in ascending order.
- `None` — No sorting should be applied.
- `UserDefault` — The user default method of sorting.

## Permissions

### Android

This library automatically adds `READ_CONTACTS` and `WRITE_CONTACTS` permissions to your app:

<AndroidPermissions permissions={['READ_CONTACTS', 'WRITE_CONTACTS']} />

### iOS

The following usage description keys are used by this library:

<IOSPermissions permissions={['NSContactsUsageDescription']} />
