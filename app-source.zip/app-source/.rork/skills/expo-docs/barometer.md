# Barometer

_A library that provides access to device's barometer sensor._

Available on platforms android, ios (device-only)

`Barometer` from `expo-sensors` provides access to the device barometer sensor to respond to changes in air pressure, which is measured in hectopascals (`hPa`).

## Installation

```bash
$ bunx expo install expo-sensors
```

If you are installing this in an existing React Native app, make sure to install `expo` in your project.

## Usage

```jsx
import { useState } from "react";
import { StyleSheet, Text, TouchableOpacity, View, Platform } from "react-native";
import { Barometer } from "expo-sensors";

export default function App() {
  const [{ pressure, relativeAltitude }, setData] = useState({ pressure: 0, relativeAltitude: 0 });
  const [subscription, setSubscription] = useState(null);

  const toggleListener = () => {
    subscription ? unsubscribe() : subscribe();
  };

  const subscribe = () => {
    setSubscription(Barometer.addListener(setData));
  };

  const unsubscribe = () => {
    subscription && subscription.remove();
    setSubscription(null);
  };

  return (
    <View style={styles.wrapper}>
      <Text>Barometer: Listener {subscription ? "ACTIVE" : "INACTIVE"}</Text>
      <Text>Pressure: {pressure} hPa</Text>
      <Text>Relative Altitude: {Platform.OS === "ios" ? `${relativeAltitude} m` : `Only available on iOS`}</Text>
      <TouchableOpacity onPress={toggleListener} style={styles.button}>
        <Text>Toggle listener</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  button: {
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#eee",
    padding: 10,
    marginTop: 15,
  },
  wrapper: {
    flex: 1,
    alignItems: "stretch",
    justifyContent: "center",
    paddingHorizontal: 20,
  },
});
```

## API

```js
import { Barometer } from "expo-sensors";
```

## API: expo-barometer

### BarometerSensor (_Class_)

Available on platforms: android, ios

#### Properties

- `_nativeEventName` (string)
- `_nativeModule` (any)

#### Methods

- `addListener(listener: Listener<BarometerMeasurement>): EventSubscription`
  Subscribe for updates to the barometer.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `listener` | Listener<BarometerMeasurement> | A callback that is invoked when a barometer update is available. When invoked, the listener is provided with a single argument that is `BarometerMeasurement`. |
  Returns: A subscription that you can call `remove()` on when you would like to unsubscribe the listener.
  Example:

  ```ts
  const subscription = Barometer.addListener(({ pressure, relativeAltitude }) => {
    console.log({ pressure, relativeAltitude });
  });
  ```

- `getListenerCount(): number`
  Returns the registered listeners count.

- `getPermissionsAsync(): Promise<PermissionResponse>`
  Checks user's permissions for accessing sensor.

- `hasListeners(): boolean`
  Returns boolean which signifies if sensor has any listeners registered.

- `isAvailableAsync(): Promise<boolean>`

  > **info** You should always check the sensor availability before attempting to use it.

  Check the availability of the device barometer. Requires at least Android 2.3 (API Level 9) and iOS 8.
  Returns: A promise that resolves to a `boolean` denoting the availability of the sensor.

- `removeAllListeners()`
  Removes all registered listeners.

- `removeSubscription(subscription: EventSubscription)`
  Removes the given subscription.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `subscription` | EventSubscription | A subscription to remove. |

- `requestPermissionsAsync(): Promise<PermissionResponse>`
  Asks the user to grant permissions for accessing sensor.

- `setUpdateInterval(intervalMs: number)`
  Set the sensor update interval.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `intervalMs` | number | Desired interval in milliseconds between sensor updates.<br>> Starting from Android 12 (API level 31), the system has a 200ms limit for each sensor updates.<br>><br>> If you need an update interval less than 200ms, you should:<br>> _ add `android.permission.HIGH_SAMPLING_RATE_SENSORS` to [**app.json** `permissions` field](https://docs.expo.dev/versions/latest/config/app/#permissions)<br>> _ or if you are using bare workflow, add `<uses-permission android:name="android.permission.HIGH_SAMPLING_RATE_SENSORS"/>` to **AndroidManifest.xml**. |

### Interfaces

#### Subscription (_Interface_)

A subscription object that allows to conveniently remove an event listener from the emitter.

### Types

#### BarometerMeasurement (_Type_)

The altitude data returned from the native sensors.
| Property | Type | Description |
| --- | --- | --- |
| `pressure` | number | Measurement in hectopascals (`hPa`). |
| `relativeAltitude` _(optional)_ | number | Measurement in meters (`m`). Available on platform: ios |
| `timestamp` | number | Timestamp of the measurement in seconds. |

#### PermissionExpiration (_Type_)

Permission expiration time. Currently, all permissions are granted permanently.
Type: 'never' | number

#### PermissionResponse (_Type_)

An object obtained by permissions get and request functions.
| Property | Type | Description |
| --- | --- | --- |
| `canAskAgain` | boolean | Indicates if user can be asked again for specific permission.<br>If not, one should be directed to the Settings app<br>in order to enable/disable the permission. |
| `expires` | PermissionExpiration | Determines time when the permission expires. |
| `granted` | boolean | A convenience boolean that indicates if the permission is granted. |
| `status` | PermissionStatus | Determines the status of the permission. |

### Enums

#### PermissionStatus (_Enum_)

#### Members

- `DENIED` — User has denied the permission.
- `GRANTED` — User has granted the permission.
- `UNDETERMINED` — User hasn't granted or denied the permission yet.

## Units and providers

| OS      | Units      | Provider                                                                                                | Description                                                                                                                         |
| ------- | ---------- | ------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------- |
| iOS     | _`hPa`_    | [`CMAltimeter`](https://developer.apple.com/documentation/coremotion/cmaltimeter)                       | Altitude events reflect the change in the current altitude, not the absolute altitude.                                              |
| Android | _`hPa`_    | [`Sensor.TYPE_PRESSURE`](https://developer.android.com/reference/android/hardware/Sensor#TYPE_PRESSURE) | Monitoring air pressure changes.                                                                                                    |
| Web     | <NoIcon /> | <NoIcon />                                                                                              | This sensor is not available on the web and cannot be accessed. An `UnavailabilityError` will be thrown if you attempt to get data. |
