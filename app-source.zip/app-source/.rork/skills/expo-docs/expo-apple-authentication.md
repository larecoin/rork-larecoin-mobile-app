You are not allowed to use expo-apple-authentication now.
