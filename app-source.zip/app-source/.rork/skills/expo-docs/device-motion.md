# DeviceMotion

_A library that provides access to a device's motion and orientation sensors._

Available on platforms android, ios, web

`DeviceMotion` from `expo-sensors` provides access to the device motion and orientation sensors. All data is presented in terms of three axes that run through a device. According to portrait orientation: X runs from left to right, Y from bottom to top and Z perpendicularly through the screen from back to front.

## Installation

```bash
$ bunx expo install expo-sensors
```

If you are installing this in an existing React Native app, make sure to install `expo` in your project.

## Configuration in app config

You can configure `DeviceMotion` from `expo-sensor` using its built-in [config plugin](https://docs.expo.dev/config-plugins/introduction/) if you use config plugins in your project ([Continuous Native Generation (CNG)](https://docs.expo.dev/workflow/continuous-native-generation/)). The plugin allows you to configure various properties that cannot be set at runtime and require building a new app binary to take effect. If your app does **not** use CNG, then you'll need to manually configure the library.

```json app.json
{
  "expo": {
    "plugins": [
      [
        "expo-sensors",
        {
          "motionPermission": "Allow $(PRODUCT_NAME) to access your device motion."
        }
      ]
    ]
  }
}
```

### Configurable properties

| Name               | Default                                                | Description                                                                               |
| ------------------ | ------------------------------------------------------ | ----------------------------------------------------------------------------------------- |
| `motionPermission` | `"Allow $(PRODUCT_NAME) to access your device motion"` | Only for: ios. A string to set the [`NSMotionUsageDescription`](#ios) permission message. |

<ConfigReactNative>

If you're not using Continuous Native Generation ([CNG](https://docs.expo.dev/workflow/continuous-native-generation/)) or you're using native **ios** project manually, then you need to configure `NSMotionUsageDescription` key in your native project to access `DeviceMotion` stats:

```xml ios/[app]/Info.plist
<key>NSMotionUsageDescription</key>
<string>Allow $(PRODUCT_NAME) to access your device motion</string>
```

</ConfigReactNative>

## API

```js
import { DeviceMotion } from "expo-sensors";
```

## API: expo-device-motion

### DeviceMotionSensor (_Class_)

A base class for subscribable sensors. The events emitted by this class are measurements
specified by the parameter type `Measurement`.

#### Properties

- `_nativeEventName` (string)
- `_nativeModule` (any)
- `Gravity` (number)
  Constant value representing standard gravitational acceleration for Earth (`9.80665` m/s^2).
  Default: `ExponentDeviceMotion.Gravity`

#### Methods

- `addListener(listener: Listener<DeviceMotionMeasurement>): EventSubscription`
  Subscribe for updates to the device motion sensor.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `listener` | Listener<DeviceMotionMeasurement> | A callback that is invoked when a device motion sensor update is available. When invoked,<br>the listener is provided a single argument that is a `DeviceMotionMeasurement` object. |
  Returns: A subscription that you can call `remove()` on when you would like to unsubscribe the listener.

- `getListenerCount(): number`
  Returns the registered listeners count.

- `getPermissionsAsync(): Promise<PermissionResponse>`
  Checks user's permissions for accessing sensor.

- `hasListeners(): boolean`
  Returns boolean which signifies if sensor has any listeners registered.

- `isAvailableAsync(): Promise<boolean>`

  > **info** You should always check the sensor availability before attempting to use it.

  Returns whether the accelerometer is enabled on the device.

  On mobile web, you must first invoke `DeviceMotion.requestPermissionsAsync()` in a user interaction (i.e. touch event) before you can use this module.
  If the `status` is not equal to `granted` then you should inform the end user that they may have to open settings.

  On **web** this starts a timer and waits to see if an event is fired. This should predict if the iOS device has the **device orientation** API disabled in
  **Settings > Safari > Motion & Orientation Access**. Some devices will also not fire if the site isn't hosted with **HTTPS** as `DeviceMotion` is now considered a secure API.
  There is no formal API for detecting the status of `DeviceMotion` so this API can sometimes be unreliable on web.
  Returns: A promise that resolves to a `boolean` denoting the availability of device motion sensor.

- `removeAllListeners()`
  Removes all registered listeners.

- `removeSubscription(subscription: EventSubscription)`
  Removes the given subscription.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `subscription` | EventSubscription | A subscription to remove. |

- `requestPermissionsAsync(): Promise<PermissionResponse>`
  Asks the user to grant permissions for accessing sensor.

- `setUpdateInterval(intervalMs: number)`
  Set the sensor update interval.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `intervalMs` | number | Desired interval in milliseconds between sensor updates.<br>> Starting from Android 12 (API level 31), the system has a 200ms limit for each sensor updates.<br>><br>> If you need an update interval less than 200ms, you should:<br>> _ add `android.permission.HIGH_SAMPLING_RATE_SENSORS` to [**app.json** `permissions` field](https://docs.expo.dev/versions/latest/config/app/#permissions)<br>> _ or if you are using bare workflow, add `<uses-permission android:name="android.permission.HIGH_SAMPLING_RATE_SENSORS"/>` to **AndroidManifest.xml**. |

### Interfaces

#### Subscription (_Interface_)

A subscription object that allows to conveniently remove an event listener from the emitter.

### Types

#### DeviceMotionMeasurement (_Type_)

| Property                       | Type                                                                      | Description                                                                                                                                                                |
| ------------------------------ | ------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `acceleration`                 | null \| { timestamp: number; x: number; y: number; z: number }            | Device acceleration on the three axis as an object with `x`, `y`, `z` keys. Expressed in meters per second squared (m/s^2).                                                |
| `accelerationIncludingGravity` | { timestamp: number; x: number; y: number; z: number }                    | Device acceleration with the effect of gravity on the three axis as an object with `x`, `y`, `z` keys. Expressed in meters per second squared (m/s^2).                     |
| `interval`                     | number                                                                    | Interval at which data is obtained from the native platform. Expressed in **milliseconds** (ms).                                                                           |
| `orientation`                  | DeviceMotionOrientation                                                   | Device orientation based on screen rotation. Value is one of:<br>- `0` (portrait),<br>- `90` (right landscape),<br>- `180` (upside down),<br>- `-90` (left landscape).     |
| `rotation`                     | { alpha: number; beta: number; gamma: number; timestamp: number }         | Device's orientation in space as an object with alpha, beta, gamma keys where alpha is for rotation around Z axis, beta for X axis rotation and gamma for Y axis rotation. |
| `rotationRate`                 | null \| { alpha: number; beta: number; gamma: number; timestamp: number } | Device's rate of rotation in space expressed in degrees per second (deg/s).                                                                                                |

#### PermissionExpiration (_Type_)

Permission expiration time. Currently, all permissions are granted permanently.
Type: 'never' | number

#### PermissionResponse (_Type_)

An object obtained by permissions get and request functions.
| Property | Type | Description |
| --- | --- | --- |
| `canAskAgain` | boolean | Indicates if user can be asked again for specific permission.<br>If not, one should be directed to the Settings app<br>in order to enable/disable the permission. |
| `expires` | PermissionExpiration | Determines time when the permission expires. |
| `granted` | boolean | A convenience boolean that indicates if the permission is granted. |
| `status` | PermissionStatus | Determines the status of the permission. |

### Constants

#### Gravity (_Constant_)

Constant value representing standard gravitational acceleration for Earth (`9.80665` m/s^2).

- `Gravity` (number) — Constant value representing standard gravitational acceleration for Earth (`9.80665` m/s^2). = ExponentDeviceMotion.Gravity

### Enums

#### DeviceMotionOrientation (_Enum_)

#### Members

- `LeftLandscape`
- `Portrait`
- `RightLandscape`
- `UpsideDown`

#### PermissionStatus (_Enum_)

#### Members

- `DENIED` — User has denied the permission.
- `GRANTED` — User has granted the permission.
- `UNDETERMINED` — User hasn't granted or denied the permission yet.

## Permissions

### iOS

The following usage description keys are used by this library:

<IOSPermissions permissions={['NSMotionUsageDescription']} />
