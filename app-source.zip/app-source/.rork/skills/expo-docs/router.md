# Router

_A file-based routing library for React Native and web applications._

Available on platforms android, ios, tvos, web

`expo-router` is a routing library for React Native and web apps. It enables navigation management using a file-based routing system and provides native navigation components and is built on top of [React Navigation](https://reactnavigation.org/).

[Expo Router guides](https://docs.expo.dev/router/introduction/)

## Installation

To use Expo Router in your project, you need to install. Follow the instructions from the Expo Router's installation guide:

[Install Expo Router](https://docs.expo.dev/router/installation/)

## Configuration in app config

If you are using the [default](https://docs.expo.dev/more/create-expo/#--template) template to create a new project, `expo-router`'s [config plugin](https://docs.expo.dev/config-plugins/introduction/) is already configured in your app config.

```json app.json
{
  "expo": {
    "plugins": ["expo-router"]
  }
}
```

## Usage

For information core concepts, notation patterns, navigation layouts, and common navigation patterns, start with Router 101 section:

[Router 101](https://docs.expo.dev/router/basics/core-concepts/)

## API

```js
import { Stack, Tabs, Link } from "expo-router";
```

## API: expo-router

### Hooks

#### useFocusEffect (_Function_)

- `useFocusEffect(effect: EffectCallback, do_not_pass_a_second_prop?: undefined)`
  Hook to run an effect whenever a route is **focused**. Similar to
  [`React.useEffect`](https://react.dev/reference/react/useEffect).

  This can be used to perform side-effects such as fetching data or subscribing to events.
  The passed callback should be wrapped in [`React.useCallback`](https://react.dev/reference/react/useCallback)
  to avoid running the effect too often.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `effect` | EffectCallback | Memoized callback containing the effect, should optionally return a cleanup function. |
  | `do_not_pass_a_second_prop` _(optional)_ | undefined | - |
  Example:

  ```tsx
  import { useFocusEffect } from 'expo-router';
  import { useCallback } from 'react';

  export default function Route() {
    useFocusEffect(
      // Callback should be wrapped in `React.useCallback` to avoid running the effect too often.
      useCallback(() => {
        // Invoked whenever the route is focused.
        console.log("Hello, I'm focused!");

        // Return function is invoked whenever the route gets out of focus.
        return () => {
          console.log('This route is now unfocused.');
        };
      }, []),
     );

   return </>;
  }
  ```

#### useGlobalSearchParams (_Function_)

- `useGlobalSearchParams(): RouteParams<TRoute> & TParams`
  Returns URL parameters for globally selected route, including dynamic path segments.
  This function updates even when the route is not focused. Useful for analytics or
  other background operations that don't draw to the screen.

  Route URL example: `acme://profile/baconbrix?extra=info`.

  When querying search params in a stack, opt-towards using
  [`useLocalSearchParams`](#uselocalsearchparams) because it will only update when the route is focused.

  > **Note:** For usage information, see
  > [Local versus global search parameters](https://docs.expo.dev/router/reference/url-parameters/#local-versus-global-url-parameters).
  > Example:

  ```tsx app/profile/[user].tsx
  import { Text } from "react-native";
  import { useGlobalSearchParams } from "expo-router";

  export default function Route() {
    // user=baconbrix & extra=info
    const { user, extra } = useGlobalSearchParams();

    return <Text>User: {user}</Text>;
  }
  ```

#### useIsPreview (_Function_)

- `useIsPreview(): boolean`
  Hook to determine if the current route is rendered inside a preview.
  Returns: - True if the current route is rendered inside a preview, false otherwise.

#### useLocalSearchParams (_Function_)

- `useLocalSearchParams(): RouteParams<TRoute> & TParams`
  Returns the URL parameters for the contextually focused route. Useful for stacks where you may push a new screen
  that changes the query parameters. For dynamic routes, both the route parameters and the search parameters are returned.

  Route URL example: `acme://profile/baconbrix?extra=info`.

  To observe updates even when the invoking route is not focused, use [`useGlobalSearchParams`](#useglobalsearchparams).

  > **Note:** For usage information, see
  > [Local versus global search parameters](https://docs.expo.dev/router/reference/url-parameters/#local-versus-global-url-parameters).
  > Example:

  ```tsx app/profile/[user].tsx
  import { Text } from "react-native";
  import { useLocalSearchParams } from "expo-router";

  export default function Route() {
    // user=baconbrix & extra=info
    const { user, extra } = useLocalSearchParams();

    return <Text>User: {user}</Text>;
  }
  ```

#### useNavigation (_Function_)

- `useNavigation(parent?: string | HrefObject): T`
  Returns the underlying React Navigation [`navigation` object](https://reactnavigation.org/docs/navigation-object)
  to imperatively access layout-specific functionality like `navigation.openDrawer()` in a
  [Drawer](https://docs.expo.dev/router/advanced/drawer/) layout.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `parent` _(optional)_ | string \| HrefObject | Provide an absolute path such as `/(root)` to the parent route or a relative path like `../../` to the parent route. |
  Returns: The navigation object for the current route.
  Example:

  ```tsx app/index.tsx
  import { useNavigation } from "expo-router";

  export default function Route() {
    // Access the current navigation object for the current route.
    const navigation = useNavigation();

    return (
      <View>
        <Text
          onPress={() => {
            // Open the drawer view.
            navigation.openDrawer();
          }}
        >
          Open Drawer
        </Text>
      </View>
    );
  }
  ```

  When using nested layouts, you can access higher-order layouts by passing a secondary argument denoting the layout route.
  For example, `/menu/_layout.tsx` is nested inside `/app/orders/`, you can use `useNavigation('/orders/menu/')`.

#### useNavigationContainerRef (_Function_)

- `useNavigationContainerRef(): NavigationContainerRefWithCurrent<__global.ReactNavigation.RootParamList>`
  Returns: The root `<NavigationContainer />` ref for the app. The `ref.current` may be `null`
  if the `<NavigationContainer />` hasn't mounted yet.

#### usePathname (_Function_)

- `usePathname(): string`
  Returns the currently selected route location without search parameters. For example, `/acme?foo=bar` returns `/acme`.
  Segments will be normalized. For example, `/[id]?id=normal` becomes `/normal`.
  Example:

  ```tsx app/profile/[user].tsx
  import { Text } from "react-native";
  import { usePathname } from "expo-router";

  export default function Route() {
    // pathname = "/profile/baconbrix"
    const pathname = usePathname();

    return <Text>Pathname: {pathname}</Text>;
  }
  ```

#### useRootNavigation (_Function_)

- `useRootNavigation(): null | NavigationContainerRef<__global.ReactNavigation.RootParamList>`

#### useRootNavigationState (_Function_)

- `useRootNavigationState(): Readonly<object>`
  Returns the [navigation state](https://reactnavigation.org/docs/navigation-state/)
  of the navigator which contains the current screen.
  Example:

  ```tsx
  import { useRootNavigationState } from "expo-router";

  export default function Route() {
    const { routes } = useRootNavigationState();

    return <Text>{routes[0].name}</Text>;
  }
  ```

#### useRouter (_Function_)

- `useRouter(): Router`
  Returns the [Router](#router) object for imperative navigation.
  Example:

  ```tsx
  import { useRouter } from "expo-router";
  import { Text } from "react-native";

  export default function Route() {
    const router = useRouter();

    return <Text onPress={() => router.push("/home")}>Go Home</Text>;
  }
  ```

#### useSegments (_Function_)

- `useSegments(): RouteSegments<TSegments>`
  Returns a list of selected file segments for the currently selected route. Segments are not normalized,
  so they will be the same as the file path. For example, `/[id]?id=normal` becomes `["[id]"]`.
  Example:

  ```tsx app/profile/[user].tsx
  import { Text } from "react-native";
  import { useSegments } from "expo-router";

  export default function Route() {
    // segments = ["profile", "[user]"]
    const segments = useSegments();

    return <Text>Hello</Text>;
  }
  ```

  `useSegments` can be typed using an abstract. Consider the following file structure:

  ```md
  - app
    - [user]
      - index.tsx
      - followers.tsx
    - settings.tsx
  ```

  This can be strictly typed using the following abstract with `useSegments` hook:

  ```tsx
  const [first, second] = useSegments<["settings"] | ["[user]"] | ["[user]", "followers"]>();
  ```

#### useSitemap (_Function_)

- `useSitemap(): SitemapType | null`

### Methods

#### ErrorBoundary (_Function_)

- `ErrorBoundary(__namedParameters: ErrorBoundaryProps): React.JSX.Element`
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `__namedParameters` | ErrorBoundaryProps | - |

#### Link (_Function_)

- `Link(props: LinkProps): React.JSX.Element`
  Component that renders a link using [`href`](#href) to another route.
  By default, it accepts children and wraps them in a `<Text>` component.

  Uses an anchor tag (`<a>`) on web and performs a client-side navigation to preserve
  the state of the website and navigate faster. The web-only attributes such as `target`,
  `rel`, and `download` are supported and passed to the anchor tag on web. See
  [`WebAnchorProps`](#webanchorprops) for more details.

  > **Note**: Client-side navigation works with both single-page apps,
  > and [static-rendering](https://docs.expo.dev/router/reference/static-rendering/).
  > | Parameter | Type | Description |
  > | --- | --- | --- |
  > | `props` | LinkProps | - |
  > Example:

  ```tsx
  import { Link } from "expo-router";
  import { View } from "react-native";

  export default function Route() {
    return (
      <View>
        <Link href="/about">About</Link>
      </View>
    );
  }
  ```

#### LinkMenu (_Function_)

Groups context menu actions for a link.

If multiple `Link.Menu` components are used within a single `Link`, only the first will be rendered.
Only `Link.MenuAction` and `LinkMenuAction` components are allowed as children.
Available on platform: ios

- `LinkMenu(props: LinkMenuProps): React.ReactNode | Promise<React.ReactNode>`
  Groups context menu actions for a link.

  If multiple `Link.Menu` components are used within a single `Link`, only the first will be rendered.
  Only `Link.MenuAction` and `LinkMenuAction` components are allowed as children.
  Available on platform: ios
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `props` | LinkMenuProps | - |
  Example:

  ```tsx
  <Link.Menu>
    <Link.MenuAction title="Action 1" onPress={() => {}} />
    <Link.MenuAction title="Action 2" onPress={() => {}} />
  </Link.Menu>
  ```

  > **Note**: You can use the alias `Link.Menu` for this component.

#### LinkMenuAction (_Function_)

- `LinkMenuAction(props: LinkMenuActionProps): null | React.JSX.Element`
  This component renders a context menu action for a link.
  It should only be used as a child of `Link.Menu` or `LinkMenu`.

  > **Note**: You can use the alias `Link.MenuAction` for this component.
  > Available on platform: ios
  > | Parameter | Type | Description |
  > | --- | --- | --- |
  > | `props` | LinkMenuActionProps | - |

#### LinkPreview (_Function_)

- `LinkPreview(props: LinkPreviewProps): null | React.JSX.Element`
  A component used to render and customize the link preview.

  If `Link.Preview` is used without any props, it will render a preview of the `href` passed to the `Link`.

  If multiple `Link.Preview` components are used within a single `Link`, only the first one will be rendered.

  To customize the preview, you can pass custom content as children.
  Available on platform: ios
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `props` | LinkPreviewProps | - |
  Example:

  ```tsx
  <Link href="/about">
    <Link.Preview>
      <Text>Custom Preview Content</Text>
    </Link.Preview>
  </Link>
  ```

#### LinkTrigger (_Function_)

- `LinkTrigger(props: object): undefined | null | string | number | bigint | boolean | Iterable<React.ReactNode> | Promise<AwaitedReactNode> | React.JSX.Element`
  Serves as the trigger for a link.
  The content inside this component will be rendered as part of the base link.

  If multiple `Link.Trigger` components are used within a single `Link`, only the first will be rendered.
  Available on platform: ios
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `props` | object | - |
  Example:

  ```tsx
  <Link href="/about">
    <Link.Trigger>Trigger</Link.Trigger>
  </Link>
  ```

  > **Note**: You can use the alias `Link.Trigger` for this component.

#### Redirect (_Function_)

- `Redirect(__namedParameters: RedirectProps): null`
  Redirects to the `href` as soon as the component is mounted.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `__namedParameters` | RedirectProps | - |
  Example:

  ```tsx
  import { View, Text } from "react-native";
  import { Redirect } from "expo-router";

  export default function Page() {
    const { user } = useAuth();

    if (!user) {
      return <Redirect href="/login" />;
    }

    return (
      <View>
        <Text>Welcome Back!</Text>
      </View>
    );
  }
  ```

#### Sitemap (_Function_)

- `Sitemap(): React.JSX.Element`

#### Slot (_Function_)

- `Slot(props: Omit<NavigatorProps<any>, 'children'>): React.JSX.Element`
  Renders the currently selected content.

  There are actually two different implementations of `<Slot/>`:
  - Used inside a `_layout` as the `Navigator`
  - Used inside a `Navigator` as the content

  Since a custom `Navigator` will set the `NavigatorContext.contextKey` to
  the current `_layout`, you can use this to determine if you are inside
  a custom navigator or not.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `props` | Omit<NavigatorProps<any>, 'children'> | - |

#### withLayoutContext (_Function_)

- `withLayoutContext(Nav: T, processor?: (options: ScreenProps[]) => ScreenProps[], useOnlyUserDefinedScreens: boolean): React.ForwardRefExoticComponent<React.PropsWithoutRef<PickPartial<React.ComponentProps<T>, 'children'>> & React.RefAttributes<unknown>> & { Protected: React.FunctionComponent<ProtectedProps>; Screen: (props: ScreenProps<TOptions, TState, TEventMap>) => null }`
  Returns a navigator that automatically injects matched routes and renders nothing when there are no children.
  Return type with `children` prop optional.

  Enables use of other built-in React Navigation navigators and other navigators built with the React Navigation custom navigator API.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `Nav` | T | The navigator component to wrap. |
  | `processor` _(optional)_ | (options: ScreenProps[]) => ScreenProps[] | A function that processes the screens before passing them to the navigator. |
  | `useOnlyUserDefinedScreens` | boolean | If true, all screens not specified as navigator's children will be ignored. |
  Example:

  ```tsx app/_layout.tsx
  import { ParamListBase, TabNavigationState } from "@react-navigation/native";
  import {
    createMaterialTopTabNavigator,
    MaterialTopTabNavigationOptions,
    MaterialTopTabNavigationEventMap,
  } from "@react-navigation/material-top-tabs";
  import { withLayoutContext } from "expo-router";

  const MaterialTopTabs = createMaterialTopTabNavigator();

  const ExpoRouterMaterialTopTabs = withLayoutContext<
    MaterialTopTabNavigationOptions,
    typeof MaterialTopTabs.Navigator,
    TabNavigationState<ParamListBase>,
    MaterialTopTabNavigationEventMap
  >(MaterialTopTabs.Navigator);

  export default function TabLayout() {
    return <ExpoRouterMaterialTopTabs />;
  }
  ```

### Props

#### LinkMenuActionProps (_Interface_)

##### Properties

- `destructive?` (boolean)
  If `true`, the menu item will be displayed as destructive.
- `disabled?` (boolean)
  If `true`, the menu item will be disabled and not selectable.
- `icon?` (SFSymbols6_0)
  Optional SF Symbol displayed alongside the menu item.
- `isOn?` (boolean)
  If `true`, the menu item will be displayed as selected.
- `onPress` (() => void)
- `title` (string)
  The title of the menu item.
- `unstable_keepPresented?` (boolean)
  If `true`, the menu will be kept presented after the action is selected.

  This is marked as unstable, because when action is selected it will recreate the menu,
  which will close all opened submenus and reset the scroll position.

#### LinkMenuProps (_Interface_)

##### Properties

- `children` (React.ReactElement<LinkMenuActionProps> | React.ReactElement<LinkMenuActionProps>[])
- `destructive?` (boolean)
  If `true`, the menu item will be displayed as destructive.
- `displayAsPalette?` (boolean)
  If `true`, the menu will be displayed as a palette.
  This means that the menu will be displayed as one row
- `displayInline?` (boolean)
  If `true`, the menu will be displayed inline.
  This means that the menu will not be collapsed
- `icon?` (string)
  Optional SF Symbol displayed alongside the menu item.
- `title?` (string)
  The title of the menu item

#### LinkPreviewProps (_Interface_)

##### Properties

- `children?` (React.ReactNode)
- `style?` (LinkPreviewStyle)
  Custom styles for the preview container.

  Note that some styles may not work, as they are limited or reset by the native view

#### LinkProps (_Interface_)

Available on platform: web

##### Properties

- `asChild?` (boolean)
  Used to customize the `Link` component. It will forward all props to the
  first child of the `Link`. Note that the child component must accept
  `onPress` or `onClick` props. The `href` and `role` are also
  passed to the child.
- `className?` (string)
  On native, this can be used with CSS interop tools like Nativewind.
  On web, this sets the HTML `class` directly.
- `dangerouslySingular?` (SingularOptions)
  When navigating in a Stack, if the target is valid then screens in the history that matches
  the uniqueness constraint will be removed.

  If used with `push`, the history will be filtered even if no navigation occurs.

- `dismissTo?` (boolean)
  While in a stack, this will dismiss screens until the provided `href` is reached. If the href is not found,
  it will instead replace the current screen with the provided `href`.
- `download?` (string)
  Specifies that the [`href`](#href) should be downloaded when the user clicks on the
  link, instead of navigating to it. It is typically used for links that point to
  files that the user should download, such as PDFs, images, documents, and more.

  The value of the `download` property, which represents the filename for the
  downloaded file. This property is passed to the underlying anchor (`<a>`) tag.

- `href` (string | HrefObject)
  The path of the route to navigate to. It can either be:
  - **string**: A full path like `/profile/settings` or a relative path like `../settings`.
  - **object**: An object with a `pathname` and optional `params`. The `pathname` can be
    a full path like `/profile/settings` or a relative path like `../settings`. The
    params can be an object of key-value pairs.
- `onPress?` ((event: React.MouseEvent<HTMLAnchorElement> | GestureResponderEvent) => void)
  This function is called on press.
  Text intrinsically supports press handling with a default highlight state (which can be disabled with suppressHighlighting).
- `prefetch?` (boolean)
  Prefetches the route when the component is rendered on a focused screen.
- `push?` (boolean)
  Always pushes a new route, and never pops or replaces to existing route.
  You can push the current route multiple times or with new parameters.
- `ref?` (React.Ref<Text>)
- `rel?` (string)
  Specifies the relationship between the [`href`](#href) and the current route.

  Common values:
  - **nofollow**: Indicates to search engines that they should not follow the `href`.
    This is often used for user-generated content or links that should not influence
    search engine rankings.
  - **noopener**: Suggests that the `href` should not have access to the opening
    window's `window.opener` object, which is a security measure to prevent potentially
    harmful behavior in cases of links that open new tabs or windows.
  - **noreferrer**: Requests that the browser does not send the `Referer` HTTP header
    when navigating to the `href`. This can enhance user privacy.

  The `rel` property is primarily used for informational and instructive purposes, helping browsers and web
  crawlers make better decisions about how to handle and interpret the links on a web
  page. It is important to use appropriate `rel` values to ensure that links behave as intended and adhere
  to best practices for web development and SEO (Search Engine Optimization).

  This property is passed to the underlying anchor (`<a>`) tag.

- `relativeToDirectory?` (boolean)
  Relative URL references are either relative to the directory or the document.
  By default, relative paths are relative to the document.
- `replace?` (boolean)
  Removes the current route from the history and replace it with the
  specified URL. This is useful for [redirects](https://docs.expo.dev/router/reference/redirects/).
- `target?` ('\_self' | '\_blank' | '\_parent' | '\_top')
  Specifies where to open the [`href`](#href).
  - **\_self**: the current tab.
  - **\_blank**: opens in a new tab or window.
  - **\_parent**: opens in the parent browsing context. If no parent, defaults to **\_self**.
  - **\_top**: opens in the highest browsing context ancestor. If no ancestors,
    defaults to **\_self**.

  This property is passed to the underlying anchor (`<a>`) tag.

- `withAnchor?` (boolean)
  Replaces the initial screen with the current route.

#### ErrorBoundaryProps (_Type_)

Props passed to a page's `ErrorBoundary` export.
| Property | Type | Description |
| --- | --- | --- |
| `error` | Error | The error that was thrown. |
| `retry` | () => Promise<void> | A function that will re-render the route component by clearing the `error` state. |

#### LinkTriggerProps (_Type_)

Type: React.PropsWithChildren

#### RedirectProps (_Type_)

| Property                           | Type    | Description                                                                                                                                                                                                                                                                                                                                                                      |
| ---------------------------------- | ------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `href`                             | Href    | The path of the route to navigate to. It can either be:<br>- **string**: A full path like `/profile/settings` or a relative path like `../settings`.<br>- **object**: An object with a `pathname` and optional `params`. The `pathname` can be<br>a full path like `/profile/settings` or a relative path like `../settings`. The<br>params can be an object of key-value pairs. |
| `relativeToDirectory` _(optional)_ | boolean | Relative URL references are either relative to the directory or the document.<br>By default, relative paths are relative to the document.                                                                                                                                                                                                                                        |
| `withAnchor` _(optional)_          | boolean | Replaces the initial screen with the current route.                                                                                                                                                                                                                                                                                                                              |

### Types

#### EffectCallback (_Type_)

Memoized callback containing the effect, should optionally return a cleanup function.
Type: () => undefined | void | () => void

#### ExternalPathString (_Type_)

Type: templateLiteral | templateLiteral

#### Href (_Type_)

The main routing type for Expo Router. It includes all available routes with strongly
typed parameters. It can either be:

- **string**: A full path like `/profile/settings` or a relative path like `../settings`.
- **object**: An object with a `pathname` and optional `params`. The `pathname` can be
  a full path like `/profile/settings` or a relative path like `../settings`.
  The params can be an object of key-value pairs.

An Href can either be a string or an object.
Type: T extends { href: any } ? indexedAccess : string | HrefObject

#### HrefObject (_Type_)

| Property              | Type               | Description                        |
| --------------------- | ------------------ | ---------------------------------- |
| `params` _(optional)_ | UnknownInputParams | Optional parameters for the route. |
| `pathname`            | string             | The path of the route.             |

#### LinkComponent (_Type_)

Type: query

#### LinkPreviewStyle (_Type_)

| Property              | Type   | Description                                                                                                                                                                   |
| --------------------- | ------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `height` _(optional)_ | number | Sets the preferred height of the preview.<br>If not set, full height of the screen will be used.<br><br>This is only **preferred** height, the actual height may be different |
| `width` _(optional)_  | number | Sets the preferred width of the preview.<br>If not set, full width of the screen will be used.<br><br>This is only **preferred** width, the actual width may be different     |

#### NativeIntent (_Type_)

Created by using a special file called `+native-intent.tsx` at the top-level of your
project's **app** directory. It exports `redirectSystemPath` or `legacy_subscribe` functions,
both methods designed to handle URL/path processing.

Useful for re-writing URLs to correctly target a route when unique/referred URLs
are incoming from third-party providers or stale URLs from previous versions.
| Property | Type | Description |
| --- | --- | --- |
| `legacy_subscribe` _(optional)_ | (listener: (url: string) => void) => undefined \| void \| () => void | > **warning** Experimentally available in SDK 52.<br><br>Useful as an alternative API when a third-party provider doesn't support Expo Router<br>but has support for React Navigation via `Linking.subscribe()` for existing projects.<br><br>Using this API is not recommended for newer projects or integrations since it is<br>incompatible with Server Side Routing and<br>[Static Rendering](https://docs.expo.dev/router/reference/static-rendering/), and can become challenging to manage while offline or in a low network environment. |
| `redirectSystemPath` _(optional)_ | (event: { initial: boolean; path: string }) => Promise<string> \| string | A special method used to process URLs in native apps. When invoked, it receives an<br>`options` object with the following properties:<br>- **path**: represents the URL or path undergoing processing.<br>- **initial**: a boolean indicating whether the path is the app's initial URL.<br><br>It's return value should either be a `string` or a `Promise<string>`.<br>Note that throwing errors within this method may result in app crashes. It's recommended to<br>wrap your code inside a `try/catch` block and utilize `.catch()` when appropriate. |

#### PickPartial (_Type_)

The list of input keys will become optional, everything else will remain the same.
Type: Omit<T, K> & Partial<Pick<T, K>>

#### RedirectConfig (_Type_)

| Property                 | Type     | Description |
| ------------------------ | -------- | ----------- |
| `destination`            | string   | -           |
| `destinationContextKey`  | string   | -           |
| `external` _(optional)_  | boolean  | -           |
| `methods` _(optional)_   | string[] | -           |
| `permanent` _(optional)_ | boolean  | -           |
| `source`                 | string   | -           |

#### RelativePathString (_Type_)

Type: templateLiteral | templateLiteral | '..'

#### ResultState (_Type_)

| Property             | Type        | Description |
| -------------------- | ----------- | ----------- |
| `state` _(optional)_ | ResultState | -           |

#### Route (_Type_)

Type: Exclude<indexedAccess, RelativePathString | ExternalPathString>

#### Router (_Type_)

Returns `router` object for imperative navigation API.
| Property | Type | Description |
| --- | --- | --- |
| `back` | () => void | Goes back in the navigation history. |
| `canDismiss` | () => boolean | Checks if it is possible to dismiss the current screen. Returns `true` if the<br>router is within the stack with more than one screen in stack's history. |
| `canGoBack` | () => boolean | Navigates to a route in the navigator's history if it supports invoking the `back` function. |
| `dismiss` | (count: number) => void | Navigates to the a stack lower than the current screen using the provided count if possible, otherwise 1.<br><br>If the current screen is the only route, it will dismiss the entire stack. |
| `dismissAll` | () => void | Returns to the first screen in the closest stack. This is similar to<br>[`popToTop`](https://reactnavigation.org/docs/stack-actions/#poptotop) stack action. |
| `dismissTo` | (href: Href, options: NavigationOptions) => void | Dismisses screens until the provided href is reached. If the href is not found, it will instead replace the current screen with the provided `href`. |
| `navigate` | (href: Href, options: NavigationOptions) => void | Navigates to the provided [`href`](#href). |
| `prefetch` | (name: Href) => void | Prefetch a screen in the background before navigating to it |
| `push` | (href: Href, options: NavigationOptions) => void | Navigates to the provided [`href`](#href) using a push operation if possible. |
| `replace` | (href: Href, options: NavigationOptions) => void | Navigates to route without appending to the history. Can be used with<br>[`useFocusEffect`](#usefocuseffecteffect-do_not_pass_a_second_prop)<br>to redirect imperatively to a new screen. |
| `setParams` | (params: Partial<RouteInputParams<T>>) => void | Updates the current route's query params. |

#### ScreenProps (_Type_)

| Property                           | Type                                                                                                                                             | Description                                                                                                                                        |
| ---------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------ | -------------------------------------------------------------------------------------------------------------------------------------------------- |
| `dangerouslySingular` _(optional)_ | SingularOptions                                                                                                                                  | -                                                                                                                                                  |
| `getId` _(optional)_               | ({ params }: { params: Record<string, any> }) => string \| undefined                                                                             | -                                                                                                                                                  |
| `initialParams` _(optional)_       | Record<string, any>                                                                                                                              | -                                                                                                                                                  |
| `listeners` _(optional)_           | ScreenListeners<TState, TEventMap> \| (prop: { navigation: any; route: RouteProp<ParamListBase, string> }) => ScreenListeners<TState, TEventMap> | -                                                                                                                                                  |
| `name` _(optional)_                | string                                                                                                                                           | Name is required when used inside a Layout component.                                                                                              |
| `options` _(optional)_             | TOptions \| (prop: { navigation: any; route: RouteProp<ParamListBase, string> }) => TOptions                                                     | -                                                                                                                                                  |
| `redirect` _(optional)_            | boolean                                                                                                                                          | Redirect to the nearest sibling route.<br>If all children are `redirect={true}`, the layout will render `null` as there are no children to render. |

#### SearchOrHash (_Type_)

Type: templateLiteral | templateLiteral

#### SingularOptions (_Type_)

Type: boolean | (name: string, params: UnknownOutputParams) => string | undefined

#### SitemapType (_Type_)

| Property      | Type           | Description |
| ------------- | -------------- | ----------- |
| `children`    | SitemapType[]  | -           |
| `contextKey`  | string         | -           |
| `filename`    | string         | -           |
| `href`        | string \| Href | -           |
| `isGenerated` | boolean        | -           |
| `isInitial`   | boolean        | -           |
| `isInternal`  | boolean        | -           |

#### WebAnchorProps (_Type_)

Available on platform: web
| Property | Type | Description |
| --- | --- | --- |
| `download` _(optional)_ | string | Specifies that the [`href`](#href) should be downloaded when the user clicks on the<br>link, instead of navigating to it. It is typically used for links that point to<br>files that the user should download, such as PDFs, images, documents, and more.<br><br>The value of the `download` property, which represents the filename for the<br>downloaded file. This property is passed to the underlying anchor (`<a>`) tag. |
| `rel` _(optional)_ | string | Specifies the relationship between the [`href`](#href) and the current route.<br><br>Common values:<br>- **nofollow**: Indicates to search engines that they should not follow the `href`.<br>This is often used for user-generated content or links that should not influence<br>search engine rankings.<br>- **noopener**: Suggests that the `href` should not have access to the opening<br>window's `window.opener` object, which is a security measure to prevent potentially<br>harmful behavior in cases of links that open new tabs or windows.<br>- **noreferrer**: Requests that the browser does not send the `Referer` HTTP header<br>when navigating to the `href`. This can enhance user privacy.<br><br>The `rel` property is primarily used for informational and instructive purposes, helping browsers and web<br>crawlers make better decisions about how to handle and interpret the links on a web<br>page. It is important to use appropriate `rel` values to ensure that links behave as intended and adhere<br>to best practices for web development and SEO (Search Engine Optimization).<br><br>This property is passed to the underlying anchor (`<a>`) tag. |
| `target` _(optional)_ | '\_self' \| '\_blank' \| '\_parent' \| '\_top' \| string & object | Specifies where to open the [`href`](#href).<br><br>- **\_self**: the current tab.<br>- **\_blank**: opens in a new tab or window.<br>- **\_parent**: opens in the parent browsing context. If no parent, defaults to **\_self**.<br>- **\_top**: opens in the highest browsing context ancestor. If no ancestors,<br>defaults to **\_self**.<br><br>This property is passed to the underlying anchor (`<a>`) tag. Default: `'_self'` |
