# StoreReview

_A library that provides access to native APIs for in-app reviews._

Available on platforms android, ios

`expo-store-review` is a library that provides access to `ReviewManager` API on Android 5+ and `SKStoreReviewController` API on iOS. It allows you to ask the user to rate your app without leaving the app itself.

<ContentSpotlight
  src="/static/images/store-review.png"
  alt="Screenshots of the store review API in action on iOS"
/>

## Installation

```bash
$ bunx expo install expo-store-review
```

If you are installing this in an existing React Native app, make sure to install `expo` in your project.

## Usage

It is important that you follow the [Human Interface Guidelines](https://developer.apple.com/design/human-interface-guidelines/ratings-and-reviews) for iOS and [Guidelines](https://developer.android.com/guide/playcore/in-app-review#when-to-request) for Android when using this API.

**Specifically:**

- Don't call `StoreReview.requestReview()` from a button - instead try calling it after the user has finished some signature interaction in the app.
- Don't spam the user.
- Don't request a review when the user is doing something time sensitive like navigating.
- Don't ask the user any questions before or while presenting the rating button or card.

### Write reviews

#### Android

There is no equivalent redirect on Android, you can still open the Play Store to the reviews sections using the query parameter `showAllReviews=true` like this:

```ts Android Play Store example
const androidPackageName = "host.exp.exponent";
// Open the Android Play Store in the browser -> redirects to Play Store on Android
Linking.openURL(`https://play.google.com/store/apps/details?id=${androidPackageName}&showAllReviews=true`);
// Open the Android Play Store directly
Linking.openURL(`market://details?id=${androidPackageName}&showAllReviews=true`);
```

#### iOS

You can redirect an app user to the **"Write a Review"** screen for an app in the iOS App Store by using the query parameter `action=write-review`. For example:

```ts iOS App Store example
const itunesItemId = 982107779;
// Open the iOS App Store in the browser -> redirects to App Store on iOS
Linking.openURL(`https://apps.apple.com/app/apple-store/id${itunesItemId}?action=write-review`);
// Open the iOS App Store directly
Linking.openURL(`itms-apps://itunes.apple.com/app/viewContentsUserReviews/id${itunesItemId}?action=write-review`);
```

## API

```js
import * as StoreReview from "expo-store-review";
```

## API: expo-store-review

### StoreReview Methods

#### hasAction (_Function_)

- `hasAction(): Promise<boolean>`
  Returns: This returns a promise that fulfills to `true` if `StoreReview.requestReview()` is capable
  directing the user to some kind of store review flow. If the app config (`app.json`) does not
  contain store URLs and native store review capabilities are not available then the promise
  will fulfill to `false`.
  Example:
  ```ts
  if (await StoreReview.hasAction()) {
    // you can call StoreReview.requestReview()
  }
  ```

#### isAvailableAsync (_Function_)

- `isAvailableAsync(): Promise<boolean>`
  Determines if the platform has the capabilities to use `StoreReview.requestReview()`.
  Returns: This returns a promise fulfills with `boolean`, depending on the platform:
  - On iOS, it will resolve to `true` unless the app is distributed through TestFlight.
  - On Android, it will resolve to `true` if the device is running Android 5.0+.
  - On Web, it will resolve to `false`.

#### requestReview (_Function_)

- `requestReview(): Promise<void>`
  In ideal circumstances this will open a native modal and allow the user to select a star rating
  that will then be applied to the App Store, without leaving the app. If the device is running
  a version of Android lower than 5.0, this will attempt to get the store URL and link the user to it.

#### storeUrl (_Function_)

- `storeUrl(): string | null`
  This uses the `Constants` API to get the `Constants.expoConfig.ios.appStoreUrl` on iOS, or the
  `Constants.expoConfig.android.playStoreUrl` on Android.

  On Web this will return `null`.

## Error codes

### `ERR_STORE_REVIEW_FAILED`

This error occurs when the store review request was not successful.
