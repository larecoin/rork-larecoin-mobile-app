# FileSystem (legacy)

_A library that provides access to the local file system on the device._

Available on platforms android, ios, tvos

> **important** The `legacy` version of the FileSystem API is included in the `expo-file-system` library. It can be used alongside the modern API for backward compatibility reasons.

`expo-file-system` provides access to a file system stored locally on the device. It is also capable of uploading and downloading files from network URLs.

#### Diagram explaining how expo-file-system interacts with different resources

[Diagram of the various pieces of expo-file-system and how they interact with different resources](https://docs.expo.dev/static/images/sdk/file-system/file-system-diagram.png)

#### How expo-file-system works differently inside of the Expo Go app

Within Expo Go, each project has a separate file system scope and has no access to the file system
of other projects.

## Installation

```bash
$ bunx expo install expo-file-system
```

If you are installing this in an existing React Native app, make sure to install `expo` in your project.

## Usage

### Downloading files

```js Component.js
const callback = (downloadProgress) => {
  const progress = downloadProgress.totalBytesWritten / downloadProgress.totalBytesExpectedToWrite;
  this.setState({
    downloadProgress: progress,
  });
};

const downloadResumable = FileSystem.createDownloadResumable(
  "http://techslides.com/demos/sample-videos/small.mp4",
  FileSystem.documentDirectory + "small.mp4",
  {},
  callback,
);

try {
  const { uri } = await downloadResumable.downloadAsync();
  console.log("Finished downloading to ", uri);
} catch (e) {
  console.error(e);
}

try {
  await downloadResumable.pauseAsync();
  console.log("Paused download operation, saving for future retrieval");
  AsyncStorage.setItem("pausedDownload", JSON.stringify(downloadResumable.savable()));
} catch (e) {
  console.error(e);
}

try {
  const { uri } = await downloadResumable.resumeAsync();
  console.log("Finished downloading to ", uri);
} catch (e) {
  console.error(e);
}

//To resume a download across app restarts, assuming the DownloadResumable.savable() object was stored:
const downloadSnapshotJson = await AsyncStorage.getItem("pausedDownload");
const downloadSnapshot = JSON.parse(downloadSnapshotJson);
const downloadResumable = new FileSystem.DownloadResumable(
  downloadSnapshot.url,
  downloadSnapshot.fileUri,
  downloadSnapshot.options,
  callback,
  downloadSnapshot.resumeData,
);

try {
  const { uri } = await downloadResumable.resumeAsync();
  console.log("Finished downloading to ", uri);
} catch (e) {
  console.error(e);
}
```

### Managing Giphy's

```js
import * as FileSystem from 'expo-file-system/legacy';

const gifDir = FileSystem.cacheDirectory + 'giphy/';
const gifFileUri = (gifId: string) => gifDir + `gif_${gifId}_200.gif`;
const gifUrl = (gifId: string) => `https://media1.giphy.com/media/${gifId}/200.gif`;

// Checks if gif directory exists. If not, creates it
async function ensureDirExists() {
  const dirInfo = await FileSystem.getInfoAsync(gifDir);
  if (!dirInfo.exists) {
    console.log("Gif directory doesn't exist, creating…");
    await FileSystem.makeDirectoryAsync(gifDir, { intermediates: true });
  }
}

// Downloads all gifs specified as array of IDs
export async function addMultipleGifs(gifIds: string[]) {
  try {
    await ensureDirExists();

    console.log('Downloading', gifIds.length, 'gif files…');
    await Promise.all(gifIds.map(id => FileSystem.downloadAsync(gifUrl(id), gifFileUri(id))));
  } catch (e) {
    console.error("Couldn't download gif files:", e);
  }
}

// Returns URI to our local gif file
// If our gif doesn't exist locally, it downloads it
export async function getSingleGif(gifId: string) {
  await ensureDirExists();

  const fileUri = gifFileUri(gifId);
  const fileInfo = await FileSystem.getInfoAsync(fileUri);

  if (!fileInfo.exists) {
    console.log("Gif isn't cached locally. Downloading…");
    await FileSystem.downloadAsync(gifUrl(gifId), fileUri);
  }

  return fileUri;
}

// Exports shareable URI - it can be shared outside your app
export async function getGifContentUri(gifId: string) {
  return FileSystem.getContentUriAsync(await getSingleGif(gifId));
}

// Deletes whole giphy directory with all its content
export async function deleteAllGifs() {
  console.log('Deleting all GIF files…');
  await FileSystem.deleteAsync(gifDir);
}
```

### Server: handling multipart requests

The simple server in Node.js, which can save uploaded images to disk:

```js index.js
const express = require("express");
const app = express();
const fs = require("fs");
const multer = require("multer");
const upload = multer({ dest: "uploads/" });

// This method will save the binary content of the request as a file.
app.patch("/binary-upload", (req, res) => {
  req.pipe(fs.createWriteStream("./uploads/image" + Date.now() + ".png"));
  res.end("OK");
});

// This method will save a "photo" field from the request as a file.
app.patch("/multipart-upload", upload.single("photo"), (req, res) => {
  // You can access other HTTP parameters. They are located in the body object.
  console.log(req.body);
  res.end("OK");
});

app.listen(3000, () => {
  console.log("Working on port 3000");
});
```

## API

```js
import * as FileSystem from "expo-file-system/legacy";
```

### Directories

The API takes `file://` URIs pointing to local files on the device to identify files. Each app only has read and write access to locations under the following directories:

- [`FileSystem.documentDirectory`](#filesystemdocumentdirectory)
- [`FileSystem.cacheDirectory`](#filesystemcachedirectory)

So, for example, the URI to a file named `'myFile'` under `'myDirectory'` in the app's user documents directory would be `FileSystem.documentDirectory + 'myDirectory/myFile'`.

Expo APIs that create files generally operate within these directories. This includes `Audio` recordings, `Camera` photos, `ImagePicker` results, `SQLite` databases and `takeSnapShotAsync()` results. This allows their use with the `FileSystem` API.

Some `FileSystem` functions are able to read from (but not write to) other locations.

### SAF URI

A SAF URI is a URI that is compatible with the Storage Access Framework. It should look like this `content://com.android.externalstorage.*`.
The easiest way to obtain such URI is by [`requestDirectoryPermissionsAsync`](#requestdirectorypermissionsasyncinitialfileurl) method.

## API: expo-file-system-legacy

### DownloadResumable (_Class_)

#### Methods

- `cancelAsync(): Promise<void>`

- `downloadAsync(): Promise<undefined | FileSystemDownloadResult>`
  Download the contents at a remote URI to a file in the app's file system.
  Returns: Returns a Promise that resolves to `FileSystemDownloadResult` object, or to `undefined` when task was cancelled.

- `pauseAsync(): Promise<DownloadPauseState>`
  Pause the current download operation. `resumeData` is added to the `DownloadResumable` object after a successful pause operation.
  Returns an object that can be saved with `AsyncStorage` for future retrieval (the same object that is returned from calling `FileSystem.DownloadResumable.savable()`).
  Returns: Returns a Promise that resolves to `DownloadPauseState` object.

- `resumeAsync(): Promise<undefined | FileSystemDownloadResult>`
  Resume a paused download operation.
  Returns: Returns a Promise that resolves to `FileSystemDownloadResult` object, or to `undefined` when task was cancelled.

- `savable(): DownloadPauseState`
  Method to get the object which can be saved with `AsyncStorage` for future retrieval.
  Returns: Returns object in shape of `DownloadPauseState` type.

### FileSystemCancellableNetworkTask (_Class_)

#### Methods

- `cancelAsync(): Promise<void>`

### UploadTask (_Class_)

#### Methods

- `cancelAsync(): Promise<void>`

- `uploadAsync(): Promise<undefined | null | FileSystemUploadResult>`

### FileSystem Legacy Methods

#### copyAsync (_Function_)

- `copyAsync(options: RelocatingOptions): Promise<void>`
  Create a copy of a file or directory. Directories are recursively copied with all of their contents.
  It can be also used to copy content shared by other apps to local filesystem.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `options` | RelocatingOptions | A map of move options represented by [`RelocatingOptions`](#relocatingoptions) type. |

#### createDownloadResumable (_Function_)

- `createDownloadResumable(uri: string, fileUri: string, options?: DownloadOptions, callback?: FileSystemNetworkTaskProgressCallback<DownloadProgressData>, resumeData?: string): DownloadResumable`
  Create a `DownloadResumable` object which can start, pause, and resume a download of contents at a remote URI to a file in the app's file system.
  > Note: You need to call `downloadAsync()`, on a `DownloadResumable` instance to initiate the download.
  > The `DownloadResumable` object has a callback that provides download progress updates.
  > Downloads can be resumed across app restarts by using `AsyncStorage` to store the `DownloadResumable.savable()` object for later retrieval.
  > The `savable` object contains the arguments required to initialize a new `DownloadResumable` object to resume the download after an app restart.
  > The directory for a local file uri must exist prior to calling this function.
  > | Parameter | Type | Description |
  > | --- | --- | --- |
  > | `uri` | string | The remote URI to download from. |
  > | `fileUri` | string | The local URI of the file to download to. If there is no file at this URI, a new one is created.<br>If there is a file at this URI, its contents are replaced. The directory for the file must exist. |
  > | `options` _(optional)_ | DownloadOptions | A map of download options represented by [`DownloadOptions`](#downloadoptions) type. |
  > | `callback` _(optional)_ | FileSystemNetworkTaskProgressCallback<DownloadProgressData> | This function is called on each data write to update the download progress.<br>> **Note**: When the app has been moved to the background, this callback won't be fired until it's moved to the foreground. |
  > | `resumeData` _(optional)_ | string | The string which allows the api to resume a paused download. This is set on the `DownloadResumable` object automatically when a download is paused.<br>When initializing a new `DownloadResumable` this should be `null`. |

#### createUploadTask (_Function_)

- `createUploadTask(url: string, fileUri: string, options?: FileSystemUploadOptions, callback?: FileSystemNetworkTaskProgressCallback<UploadProgressData>): UploadTask`
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `url` | string | - |
  | `fileUri` | string | - |
  | `options` _(optional)_ | FileSystemUploadOptions | - |
  | `callback` _(optional)_ | FileSystemNetworkTaskProgressCallback<UploadProgressData> | - |

#### deleteAsync (_Function_)

- `deleteAsync(fileUri: string, options: DeletingOptions): Promise<void>`
  Delete a file or directory. If the URI points to a directory, the directory and all its contents are recursively deleted.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `fileUri` | string | `file://` or [SAF](#saf-uri) URI to the file or directory. |
  | `options` | DeletingOptions | A map of write options represented by [`DeletingOptions`](#deletingoptions) type. |

#### deleteLegacyDocumentDirectoryAndroid (_Function_)

- `deleteLegacyDocumentDirectoryAndroid(): Promise<void>`

#### downloadAsync (_Function_)

- `downloadAsync(uri: string, fileUri: string, options: DownloadOptions): Promise<FileSystemDownloadResult>`
  Download the contents at a remote URI to a file in the app's file system. The directory for a local file uri must exist prior to calling this function.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `uri` | string | The remote URI to download from. |
  | `fileUri` | string | The local URI of the file to download to. If there is no file at this URI, a new one is created.<br>If there is a file at this URI, its contents are replaced. The directory for the file must exist. |
  | `options` | DownloadOptions | A map of download options represented by [`DownloadOptions`](#downloadoptions) type. |
  Returns: Returns a Promise that resolves to a `FileSystemDownloadResult` object.
  Example:
  ```js
  FileSystem.downloadAsync(
    "http://techslides.com/demos/sample-videos/small.mp4",
    FileSystem.documentDirectory + "small.mp4",
  )
    .then(({ uri }) => {
      console.log("Finished downloading to ", uri);
    })
    .catch((error) => {
      console.error(error);
    });
  ```

#### getContentUriAsync (_Function_)

- `getContentUriAsync(fileUri: string): Promise<string>`
  Takes a `file://` URI and converts it into content URI (`content://`) so that it can be accessed by other applications outside of Expo.
  Available on platform: android
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `fileUri` | string | The local URI of the file. If there is no file at this URI, an exception will be thrown. |
  Returns: Returns a Promise that resolves to a `string` containing a `content://` URI pointing to the file.
  The URI is the same as the `fileUri` input parameter but in a different format.
  Example:
  ```js
  FileSystem.getContentUriAsync(uri).then((cUri) => {
    console.log(cUri);
    IntentLauncher.startActivityAsync("android.intent.action.VIEW", {
      data: cUri,
      flags: 1,
    });
  });
  ```

#### getFreeDiskStorageAsync (_Function_)

- `getFreeDiskStorageAsync(): Promise<number>`
  Gets the available internal disk storage size, in bytes. This returns the free space on the data partition that hosts all of the internal storage for all apps on the device.
  Returns: Returns a Promise that resolves to the number of bytes available on the internal disk.

#### getInfoAsync (_Function_)

- `getInfoAsync(fileUri: string, options: InfoOptions): Promise<FileInfo>`
  Get metadata information about a file, directory or external content/asset.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `fileUri` | string | URI to the file or directory. See [supported URI schemes](#supported-uri-schemes). |
  | `options` | InfoOptions | A map of options represented by [`InfoOptions`](#infooptions) type. |
  Returns: A Promise that resolves to a `FileInfo` object. If no item exists at this URI,
  the returned Promise resolves to `FileInfo` object in form of `{ exists: false, isDirectory: false }`.

#### getTotalDiskCapacityAsync (_Function_)

- `getTotalDiskCapacityAsync(): Promise<number>`
  Gets total internal disk storage size, in bytes. This is the total capacity of the data partition that hosts all the internal storage for all apps on the device.
  Returns: Returns a Promise that resolves to a number that specifies the total internal disk storage capacity in bytes.

#### makeDirectoryAsync (_Function_)

- `makeDirectoryAsync(fileUri: string, options: MakeDirectoryOptions): Promise<void>`
  Create a new empty directory.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `fileUri` | string | `file://` URI to the new directory to create. |
  | `options` | MakeDirectoryOptions | A map of create directory options represented by [`MakeDirectoryOptions`](#makedirectoryoptions) type. |

#### moveAsync (_Function_)

- `moveAsync(options: RelocatingOptions): Promise<void>`
  Move a file or directory to a new location.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `options` | RelocatingOptions | A map of move options represented by [`RelocatingOptions`](#relocatingoptions) type. |

#### readAsStringAsync (_Function_)

- `readAsStringAsync(fileUri: string, options: ReadingOptions): Promise<string>`
  Read the entire contents of a file as a string. Binary will be returned in raw format, you will need to append `data:image/png;base64,` to use it as Base64.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `fileUri` | string | `file://` or [SAF](#saf-uri) URI to the file or directory. |
  | `options` | ReadingOptions | A map of read options represented by [`ReadingOptions`](#readingoptions) type. |
  Returns: A Promise that resolves to a string containing the entire contents of the file.

#### readDirectoryAsync (_Function_)

- `readDirectoryAsync(fileUri: string): Promise<string[]>`
  Enumerate the contents of a directory.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `fileUri` | string | `file://` URI to the directory. |
  Returns: A Promise that resolves to an array of strings, each containing the name of a file or directory contained in the directory at `fileUri`.

#### uploadAsync (_Function_)

- `uploadAsync(url: string, fileUri: string, options: FileSystemUploadOptions): Promise<FileSystemUploadResult>`
  Upload the contents of the file pointed by `fileUri` to the remote url.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `url` | string | The remote URL, where the file will be sent. |
  | `fileUri` | string | The local URI of the file to send. The file must exist. |
  | `options` | FileSystemUploadOptions | A map of download options represented by [`FileSystemUploadOptions`](#filesystemuploadoptions) type. |
  Returns: Returns a Promise that resolves to `FileSystemUploadResult` object.
  Example:
  **Client**

  ```js
  import * as FileSystem from "expo-file-system/legacy";

  try {
    const response = await FileSystem.uploadAsync(`http://192.168.0.1:1234/binary-upload`, fileUri, {
      fieldName: "file",
      httpMethod: "PATCH",
      uploadType: FileSystem.FileSystemUploadType.BINARY_CONTENT,
    });
    console.log(JSON.stringify(response, null, 4));
  } catch (error) {
    console.log(error);
  }
  ```

  **Server**

  Refer to the "[Server: Handling multipart requests](#server-handling-multipart-requests)" example - there is code for a simple Node.js server.

#### writeAsStringAsync (_Function_)

- `writeAsStringAsync(fileUri: string, contents: string, options: WritingOptions): Promise<void>`
  Write the entire contents of a file as a string.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `fileUri` | string | `file://` or [SAF](#saf-uri) URI to the file or directory.<br>> Note: when you're using SAF URI the file needs to exist. You can't create a new file. |
  | `contents` | string | The string to replace the contents of the file with. |
  | `options` | WritingOptions | A map of write options represented by [`WritingOptions`](#writingoptions) type. |

### Types

#### DeletingOptions (_Type_)

| Property                  | Type    | Description                                                                                    |
| ------------------------- | ------- | ---------------------------------------------------------------------------------------------- |
| `idempotent` _(optional)_ | boolean | If `true`, don't throw an error if there is no file or directory at this URI. Default: `false` |

#### DownloadOptions (_Type_)

| Property                   | Type                   | Description                                                                                                                                                                                                              |
| -------------------------- | ---------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `cache` _(optional)_       | boolean                | -                                                                                                                                                                                                                        |
| `headers` _(optional)_     | Record<string, string> | An object containing all the HTTP header fields and their values for the download network request. The keys and values of the object are the header names and values respectively.                                       |
| `md5` _(optional)_         | boolean                | If `true`, include the MD5 hash of the file in the returned object. Provided for convenience since it is common to check the integrity of a file immediately after downloading. Default: `false`                         |
| `sessionType` _(optional)_ | FileSystemSessionType  | A session type. Determines if tasks can be handled in the background. On Android, sessions always work in the background and you can't change it. Default: `FileSystemSessionType.BACKGROUND` Available on platform: ios |

#### DownloadPauseState (_Type_)

| Property                  | Type            | Description                                                                                                                                                 |
| ------------------------- | --------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `fileUri`                 | string          | The local URI of the file to download to. If there is no file at this URI, a new one is created. If there is a file at this URI, its contents are replaced. |
| `options`                 | DownloadOptions | Object representing the file download options.                                                                                                              |
| `resumeData` _(optional)_ | string          | The string which allows the API to resume a paused download.                                                                                                |
| `url`                     | string          | The remote URI to download from.                                                                                                                            |

#### DownloadProgressCallback (_Type_)

Type: FileSystemNetworkTaskProgressCallback<DownloadProgressData>

#### DownloadProgressData (_Type_)

| Property                    | Type   | Description                                                                                                                                                                                                                                                 |
| --------------------------- | ------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `totalBytesExpectedToWrite` | number | The total bytes expected to be written by the download operation. A value of `-1` means that the server did not return the `Content-Length` header<br>and the total size is unknown. Without this header, you won't be able to track the download progress. |
| `totalBytesWritten`         | number | The total bytes written by the download operation.                                                                                                                                                                                                          |

#### DownloadResult (_Type_)

Type: FileSystemDownloadResult

#### FileInfo (_Type_)

| Property           | Type    | Description                                                                              |
| ------------------ | ------- | ---------------------------------------------------------------------------------------- |
| `exists`           | true    | Signifies that the requested file exist.                                                 |
| `isDirectory`      | boolean | Boolean set to `true` if this is a directory and `false` if it is a file.                |
| `md5` _(optional)_ | string  | Present if the `md5` option was truthy. Contains the MD5 hash of the file.               |
| `modificationTime` | number  | The last modification time of the file expressed in seconds since epoch.                 |
| `size`             | number  | The size of the file in bytes.                                                           |
| `uri`              | string  | A `file://` URI pointing to the file. This is the same as the `fileUri` input parameter. |

#### FileSystemAcceptedUploadHttpMethod (_Type_)

Type: 'POST' | 'PUT' | 'PATCH'

#### FileSystemDownloadResult (_Type_)

| Property           | Type   | Description                                                                              |
| ------------------ | ------ | ---------------------------------------------------------------------------------------- |
| `md5` _(optional)_ | string | Present if the `md5` option was truthy. Contains the MD5 hash of the file.               |
| `uri`              | string | A `file://` URI pointing to the file. This is the same as the `fileUri` input parameter. |

#### FileSystemHttpResult (_Type_)

| Property   | Type                   | Description                                                                                                                                                                                    |
| ---------- | ---------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `headers`  | Record<string, string> | An object containing all the HTTP response header fields and their values for the download network request.<br>The keys and values of the object are the header names and values respectively. |
| `mimeType` | string \| null         | -                                                                                                                                                                                              |
| `status`   | number                 | The HTTP response status code for the download network request.                                                                                                                                |

#### FileSystemNetworkTaskProgressCallback (_Type_)

Type: (data: T) => void

#### FileSystemRequestDirectoryPermissionsResult (_Type_)

| Property       | Type   | Description                                                                                           |
| -------------- | ------ | ----------------------------------------------------------------------------------------------------- |
| `granted`      | false  | -                                                                                                     |
| `directoryUri` | string | The [SAF URI](#saf-uri) to the user's selected directory. Available only if permissions were granted. |

#### FileSystemUploadOptions (_Type_)

| Property                   | Type                               | Description                                                                                                                                                                                                              |
| -------------------------- | ---------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `headers` _(optional)_     | Record<string, string>             | An object containing all the HTTP header fields and their values for the upload network request.<br>The keys and values of the object are the header names and values respectively.                                      |
| `httpMethod` _(optional)_  | FileSystemAcceptedUploadHttpMethod | The request method. Default: `FileSystemAcceptedUploadHttpMethod.POST`                                                                                                                                                   |
| `sessionType` _(optional)_ | FileSystemSessionType              | A session type. Determines if tasks can be handled in the background. On Android, sessions always work in the background and you can't change it. Default: `FileSystemSessionType.BACKGROUND` Available on platform: ios |

#### FileSystemUploadResult (_Type_)

| Property | Type   | Description                      |
| -------- | ------ | -------------------------------- |
| `body`   | string | The body of the server response. |

#### InfoOptions (_Type_)

| Property           | Type    | Description                                                  |
| ------------------ | ------- | ------------------------------------------------------------ |
| `md5` _(optional)_ | boolean | Whether to return the MD5 hash of the file. Default: `false` |

#### MakeDirectoryOptions (_Type_)

| Property                     | Type    | Description                                                                                    |
| ---------------------------- | ------- | ---------------------------------------------------------------------------------------------- |
| `intermediates` _(optional)_ | boolean | If `true`, don't throw an error if there is no file or directory at this URI. Default: `false` |

#### ProgressEvent (_Type_)

| Property | Type   | Description |
| -------- | ------ | ----------- |
| `data`   | T      | -           |
| `uuid`   | string | -           |

#### ReadingOptions (_Type_)

| Property                | Type                               | Description                                                                                                                           |
| ----------------------- | ---------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------- |
| `encoding` _(optional)_ | EncodingType \| 'utf8' \| 'base64' | The encoding format to use when reading the file. Default: `EncodingType.UTF8`                                                        |
| `length` _(optional)_   | number                             | Optional number of bytes to read. This option is only used when `encoding: FileSystem.EncodingType.Base64` and `position` is defined. |
| `position` _(optional)_ | number                             | Optional number of bytes to skip. This option is only used when `encoding: FileSystem.EncodingType.Base64` and `length` is defined.   |

#### RelocatingOptions (_Type_)

| Property | Type   | Description                                                                                                       |
| -------- | ------ | ----------------------------------------------------------------------------------------------------------------- |
| `from`   | string | URI or [SAF](#saf-uri) URI to the asset, file, or directory. See [supported URI schemes](#supported-uri-schemes). |
| `to`     | string | `file://` URI to the file or directory which should be its new location.                                          |

#### UploadOptionsBinary (_Type_)

Upload options when upload type is set to binary.
| Property | Type | Description |
| --- | --- | --- |
| `uploadType` _(optional)_ | FileSystemUploadType | Upload type determines how the file will be sent to the server.<br>Value will be `FileSystemUploadType.BINARY_CONTENT`. |

#### UploadOptionsMultipart (_Type_)

Upload options when upload type is set to multipart.
| Property | Type | Description |
| --- | --- | --- |
| `fieldName` _(optional)_ | string | The name of the field which will hold uploaded file. Defaults to the file name without an extension. |
| `mimeType` _(optional)_ | string | The MIME type of the provided file. If not provided, the module will try to guess it based on the extension. |
| `parameters` _(optional)_ | Record<string, string> | Additional form properties. They will be located in the request body. |
| `uploadType` | FileSystemUploadType | Upload type determines how the file will be sent to the server.<br>Value will be `FileSystemUploadType.MULTIPART`. |

#### UploadProgressData (_Type_)

| Property                   | Type   | Description                                                  |
| -------------------------- | ------ | ------------------------------------------------------------ |
| `totalBytesExpectedToSend` | number | The total bytes expected to be sent by the upload operation. |
| `totalBytesSent`           | number | The total bytes sent by the upload operation.                |

#### WritingOptions (_Type_)

| Property                | Type                               | Description                                                                               |
| ----------------------- | ---------------------------------- | ----------------------------------------------------------------------------------------- |
| `encoding` _(optional)_ | EncodingType \| 'utf8' \| 'base64' | The encoding format to use when writing the file. Default: `FileSystem.EncodingType.UTF8` |

### Constants

#### bundleDirectory (_Constant_)

URI to the directory where assets bundled with the application are stored.

- `bundleDirectory` (null | string) — URI to the directory where assets bundled with the application are stored. = ...

#### cacheDirectory (_Constant_)

`file://` URI pointing to the directory where temporary files used by this app will be stored.
Files stored here may be automatically deleted by the system when low on storage.
Example uses are for downloaded or generated files that the app just needs for one-time usage.

- `cacheDirectory` (null | string) — `file://` URI pointing to the directory where temporary files used by this app will be stored.
  Files stored here may be automatically deleted by the system when low on storage.
  Example uses are for downloaded or generated files that the app just needs for one-time usage. = ...

#### documentDirectory (_Constant_)

`file://` URI pointing to the directory where user documents for this app will be stored.
Files stored here will remain until explicitly deleted by the app. Ends with a trailing `/`.
Example uses are for files the user saves that they expect to see again.

- `documentDirectory` (null | string) — `file://` URI pointing to the directory where user documents for this app will be stored.
  Files stored here will remain until explicitly deleted by the app. Ends with a trailing `/`.
  Example uses are for files the user saves that they expect to see again. = ...

### Enums

#### EncodingType (_Enum_)

These values can be used to define how file system data is read / written.

#### Members

- `Base64` — Binary, radix-64 representation.
- `UTF8` — Standard encoding format.

#### FileSystemSessionType (_Enum_)

These values can be used to define how sessions work on iOS.
Available on platform: ios

#### Members

- `BACKGROUND` — Using this mode means that the downloading/uploading session on the native side will work even if the application is moved to background.
  If the task completes while the application is in background, the Promise will be either resolved immediately or (if the application execution has already been stopped) once the app is moved to foreground again.
  > Note: The background session doesn't fail if the server or your connection is down. Rather, it continues retrying until the task succeeds or is canceled manually.
- `FOREGROUND` — Using this mode means that downloading/uploading session on the native side will be terminated once the application becomes inactive (e.g. when it goes to background).
  Bringing the application to foreground again would trigger Promise rejection.

#### FileSystemUploadType (_Enum_)

#### Members

- `BINARY_CONTENT` — The file will be sent as a request's body. The request can't contain additional data.
- `MULTIPART` — An [RFC 2387-compliant](https://www.ietf.org/rfc/rfc2387.txt) request body. The provided file will be encoded into HTTP request.
  This request can contain additional data represented by [`UploadOptionsMultipart`](#uploadoptionsmultipart) type.

### Namespaces

#### StorageAccessFramework (_Definition_)

The `StorageAccessFramework` is a namespace inside of the `expo-file-system` module, which encapsulates all functions which can be used with [SAF URIs](#saf-uri).
You can read more about SAF in the [Android documentation](https://developer.android.com/guide/topics/providers/document-provider).
Available on platform: Android

## Supported URI schemes

In this table, you can see what type of URI can be handled by each method. For example, if you have an URI, which begins with `content://`, you cannot use `FileSystem.readAsStringAsync()`, but you can use `FileSystem.copyAsync()` which supports this scheme.

| Method name               | Android                                                                                                                              | iOS                                                                                             |
| ------------------------- | ------------------------------------------------------------------------------------------------------------------------------------ | ----------------------------------------------------------------------------------------------- |
| `getInfoAsync`            | `file:///`,<br/>`content://`,<br/>`asset://`,<br/>no scheme                                                                          | `file://`,<br/>`ph://`,<br/>`assets-library://`                                                 |
| `readAsStringAsync`       | `file:///`,<br/>`asset://`,<br/>[SAF URI](#saf-uri)                                                                                  | `file://`                                                                                       |
| `writeAsStringAsync`      | `file:///`,<br/>[SAF URI](#saf-uri)                                                                                                  | `file://`                                                                                       |
| `deleteAsync`             | `file:///`,<br/>[SAF URI](#saf-uri)                                                                                                  | `file://`                                                                                       |
| `moveAsync`               | Source:<br/>`file:///`,<br/>[SAF URI](#saf-uri)<br/><br/>Destination:<br/>`file://`                                                  | Source:<br/>`file://`<br/><br/>Destination:<br/>`file://`                                       |
| `copyAsync`               | Source:<br/>`file:///`,<br/>`content://`,<br/>`asset://`,<br/>[SAF URI](#saf-uri),<br/>no scheme<br/><br/>Destination:<br/>`file://` | Source:<br/>`file://`,<br/>`ph://`,<br/>`assets-library://`<br/><br/>Destination:<br/>`file://` |
| `makeDirectoryAsync`      | `file:///`                                                                                                                           | `file://`                                                                                       |
| `readDirectoryAsync`      | `file:///`                                                                                                                           | `file://`                                                                                       |
| `downloadAsync`           | Source:<br/>`http://`,<br/>`https://`<br/><br/>Destination:<br/>`file:///`                                                           | Source:<br/>`http://`,<br/>`https://`<br/><br/>Destination:<br/>`file://`                       |
| `uploadAsync`             | Source:<br/>`file:///`<br/><br/>Destination:<br/>`http://`<br/>`https://`                                                            | Source:<br/>`file://`<br/><br/>Destination:<br/>`http://`<br/>`https://`                        |
| `createDownloadResumable` | Source:<br/>`http://`,<br/>`https://`<br/><br/>Destination:<br/>`file:///`                                                           | Source:<br/>`http://`,<br/>`https://`<br/><br/>Destination:<br/>`file://`                       |

> On Android **no scheme** defaults to a bundled resource.

## Permissions

### Android

The following permissions are added automatically through this library's **AndroidManifest.xml**.

<AndroidPermissions permissions={['READ_EXTERNAL_STORAGE', 'WRITE_EXTERNAL_STORAGE', 'INTERNET']} />

### iOS

_No permissions required_.
