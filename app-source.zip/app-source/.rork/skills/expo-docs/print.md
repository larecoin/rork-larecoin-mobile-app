# Print

_A library that provides printing functionality for Android and iOS (AirPrint)._

Available on platforms android, ios, web

`expo-print` provides an API for Android and iOS (AirPrint) printing functionality.

## Installation

```bash
$ bunx expo install expo-print
```

If you are installing this in an existing React Native app, make sure to install `expo` in your project.

## Usage

```jsx
import { useState } from "react";
import { View, StyleSheet, Button, Platform, Text } from "react-native";
import * as Print from "expo-print";
import { shareAsync } from "expo-sharing";

const html = `
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no" />
  </head>
  <body style="text-align: center;">
    <h1 style="font-size: 50px; font-family: Helvetica Neue; font-weight: normal;">
      Hello Expo!
    </h1>
    <img
      src="https://d30j33t1r58ioz.cloudfront.net/static/guides/sdk.png"
      style="width: 90vw;" />
  </body>
</html>
`;

export default function App() {
  const [selectedPrinter, setSelectedPrinter] = useState();

  const print = async () => {
    // On iOS/android prints the given html. On web prints the HTML from the current page.
    /* @info */ await Print.printAsync({
      html,
      printerUrl: selectedPrinter?.url, // iOS only
    }); /* @end */
  };

  const printToFile = async () => {
    // On iOS/android prints the given html. On web prints the HTML from the current page.
    /* @info */ const { uri } = await Print.printToFileAsync({ html }); /* @end */
    console.log("File has been saved to:", uri);
    await shareAsync(uri, { UTI: ".pdf", mimeType: "application/pdf" });
  };

  const selectPrinter = async () => {
    /* @info */ const printer = await Print.selectPrinterAsync(); // iOS only
    /* @end */
    setSelectedPrinter(printer);
  };

  return (
    <View style={styles.container}>
      <Button title="Print" onPress={print} />
      <View style={styles.spacer} />
      <Button title="Print to PDF file" onPress={printToFile} />
      {Platform.OS === "ios" && (
        <>
          <View style={styles.spacer} />
          <Button title="Select printer" onPress={selectPrinter} />
          <View style={styles.spacer} />
          {selectedPrinter ? (
            <Text style={styles.printer}>{`Selected printer: ${selectedPrinter.name}`}</Text>
          ) : undefined}
        </>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    backgroundColor: "#ecf0f1",
    flexDirection: "column",
    padding: 8,
  },
  spacer: {
    height: 8,
  },
  printer: {
    textAlign: "center",
  },
});
```

## API

```js
import * as Print from "expo-print";
```

## API: expo-print

### Print Methods

#### printAsync (_Function_)

- `printAsync(options: PrintOptions): Promise<void>`
  Prints a document or HTML, on web this prints the HTML from the page.

  > Note: On iOS, printing from HTML source doesn't support local asset URLs (due to `WKWebView`
  > limitations). As a workaround you can use inlined base64-encoded strings.
  > See [this comment](https://github.com/expo/expo/issues/7940#issuecomment-657111033) for more details.

  > Note: on iOS, when printing without providing a `PrintOptions.printerUrl` the `Promise` will be
  > resolved once printing is started in the native print window and rejected if the window is closed without
  > starting the print. On Android the `Promise` will be resolved immediately after displaying the native print window
  > and won't be rejected if the window is closed without starting the print.
  > | Parameter | Type | Description |
  > | --- | --- | --- |
  > | `options` | PrintOptions | A map defining what should be printed. |
  > Returns: Resolves to an empty `Promise` if printing started.

#### printToFileAsync (_Function_)

- `printToFileAsync(options: FilePrintOptions): Promise<FilePrintResult>`
  Prints HTML to PDF file and saves it to [app's cache directory](./filesystem/#filesystemcachedirectory).
  On Web this method opens the print dialog.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `options` | FilePrintOptions | A map of print options. |

#### selectPrinterAsync (_Function_)

- `selectPrinterAsync(): Promise<Printer>`
  Chooses a printer that can be later used in `printAsync`
  Available on platform: ios
  Returns: A promise which fulfils with an object containing `name` and `url` of the selected printer.

### Interfaces

#### OrientationType (_Interface_)

The possible values of orientation for the printed content.

##### Properties

- `landscape` (string)
- `portrait` (string)

### Types

#### FilePrintOptions (_Type_)

| Property                          | Type        | Description                                                                                                                                                                                                                       |
| --------------------------------- | ----------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `base64` _(optional)_             | boolean     | Whether to include base64 encoded string of the file in the returned object.                                                                                                                                                      |
| `height` _(optional)_             | number      | Height of the single page in pixels. Defaults to `792` which is a height of US Letter paper<br>format with 72 PPI.                                                                                                                |
| `html` _(optional)_               | string      | HTML string to print into PDF file.                                                                                                                                                                                               |
| `margins` _(optional)_            | PageMargins | Page margins for the printed document. Available on platform: ios                                                                                                                                                                 |
| `textZoom` _(optional)_           | number      | The text zoom of the page in percent. The default is 100. Available on platform: android                                                                                                                                          |
| `useMarkupFormatter` _(optional)_ | boolean     | Alternative to default option that uses [UIMarkupTextPrintFormatter](https://developer.apple.com/documentation/uikit/uimarkuptextprintformatter)<br>instead of WebView, but it doesn't display images. Available on platform: ios |
| `width` _(optional)_              | number      | Width of the single page in pixels. Defaults to `612` which is a width of US Letter paper<br>format with 72 PPI.                                                                                                                  |

#### FilePrintResult (_Type_)

| Property              | Type   | Description                                                                                                                                                                       |
| --------------------- | ------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `base64` _(optional)_ | string | Base64 encoded string containing the data of the PDF file. **Available only if `base64`<br>option is truthy**. It doesn't include data URI prefix `data:application/pdf;base64,`. |
| `numberOfPages`       | number | Number of pages that were needed to render given content.                                                                                                                         |
| `uri`                 | string | A URI to the printed PDF file.                                                                                                                                                    |

#### PageMargins (_Type_)

| Property | Type   | Description |
| -------- | ------ | ----------- |
| `bottom` | number | -           |
| `left`   | number | -           |
| `right`  | number | -           |
| `top`    | number | -           |

#### Printer (_Type_)

| Property | Type   | Description          |
| -------- | ------ | -------------------- |
| `name`   | string | Name of the printer. |
| `url`    | string | URL of the printer.  |

#### PrintOptions (_Type_)

| Property                          | Type                           | Description                                                                                                                                                                                                                                                  |
| --------------------------------- | ------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `height` _(optional)_             | number                         | Height of the single page in pixels. Defaults to `792` which is a height of US Letter paper<br>format with 72 PPI. **Available only with `html` option.**                                                                                                    |
| `html` _(optional)_               | string                         | HTML string to print. Available on platforms: android, ios                                                                                                                                                                                                   |
| `margins` _(optional)_            | PageMargins                    | Page margins for the printed document. Available on platform: ios                                                                                                                                                                                            |
| `markupFormatterIOS` _(optional)_ | string                         | Available on platform: ios                                                                                                                                                                                                                                   |
| `orientation` _(optional)_        | indexedAccess \| indexedAccess | The orientation of the printed content, `Print.Orientation.portrait`<br>or `Print.Orientation.landscape`. Available on platform: ios                                                                                                                         |
| `printerUrl` _(optional)_         | string                         | URL of the printer to use. Returned from `selectPrinterAsync`. Available on platform: ios                                                                                                                                                                    |
| `uri` _(optional)_                | string                         | URI of a PDF file to print. Remote, local (ex. selected via `DocumentPicker`) or base64 data URI<br>starting with `data:application/pdf;base64,`. This only supports PDF, not other types of<br>document (e.g. images). Available on platforms: android, ios |
| `useMarkupFormatter` _(optional)_ | boolean                        | Alternative to default option that uses [UIMarkupTextPrintFormatter](https://developer.apple.com/documentation/uikit/uimarkuptextprintformatter)<br>instead of WebView, but it doesn't display images. Available on platform: ios                            |
| `width` _(optional)_              | number                         | Width of the single page in pixels. Defaults to `612` which is a width of US Letter paper<br>format with 72 PPI. **Available only with `html` option.**                                                                                                      |

### Constants

#### Orientation (_Constant_)

The orientation of the printed content.

- `Orientation` (OrientationType) — The orientation of the printed content. = ExponentPrint.Orientation

## Local images

On iOS, printing from HTML source doesn't support local asset URLs (due to `WKWebView` limitations). Instead, images need to be converted to base64 and inlined into the HTML.

```tsx Example
import { Asset } from "expo-asset";
import { useImageManipulator } from "expo-image-manipulator";
import { printAsync } from "expo-print";
import { useEffect } from "react";

const IMAGE = Asset.fromModule(require("@/assets/images/icon.png"));

export function ImageManipulatorExample() {
  const context = useImageManipulator(IMAGE.uri);

  useEffect(() => {
    async function generateAndPrint() {
      try {
        await IMAGE.downloadAsync();
        const manipulatedImage = await context.renderAsync();
        const result = await manipulatedImage.saveAsync({ base64: true });

        const html = `
          <html>
            <img
              src="data:image/png;base64,${result.base64}"
              style="width: 90vw;" />
          </html>
        `;

        await printAsync({ html });
      } catch (error) {
        console.error("Error:", error);
      }
    }

    generateAndPrint();
  }, [context]);

  return <>{/* Render UI */}</>;
}
```

## Page margins

**On iOS** you can set the page margins using the `margins` option:

```js
const { uri } = await Print.printToFileAsync({
  html: "This page is printed with margins",
  margins: {
    left: 20,
    top: 50,
    right: 20,
    bottom: 100,
  },
});
```

If `useMarkupFormatter` is set to `true`, setting margins may cause a blank page to appear at the end of your printout. To prevent this, make sure your HTML string is a well-formed document, including `<!DOCTYPE html>` at the beginning of the string.

**On Android**, if you're using `html` option in `printAsync` or `printToFileAsync`, the resulting print might contain page margins (it depends on the WebView engine).
They are set by `@page` style block and you can override them in your HTML code:

```html
<style>
  @page {
    margin: 20px;
  }
</style>
```

See [`@page` documentation on MDN](https://developer.mozilla.org/en-US/docs/Web/CSS/@page) for more details.
