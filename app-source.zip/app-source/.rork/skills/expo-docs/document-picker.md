# DocumentPicker

_A library that provides access to the system's UI for selecting documents from the available providers on the user's device._

Available on platforms android, ios, web

`expo-document-picker` provides access to the system's UI for selecting documents from the available providers on the user's device.

<ContentSpotlight file="sdk/documentpicker.mp4" loop={false} />

## Installation

```bash
$ bunx expo install expo-document-picker
```

If you are installing this in an existing React Native app, make sure to install `expo` in your project.

## Configuration in app config

You can configure `expo-document-picker` using its built-in [config plugin](https://docs.expo.dev/config-plugins/introduction/) if you use config plugins in your project ([Continuous Native Generation (CNG)](https://docs.expo.dev/workflow/continuous-native-generation/)). The plugin allows you to configure various properties that cannot be set at runtime and require building a new app binary to take effect. If your app does **not** use CNG, then you'll need to manually configure the library.

If you want to enable [iCloud storage features][icloud-entitlement], set the `expo.ios.usesIcloudStorage` key to `true` in the [app config](https://docs.expo.dev/workflow/configuration/) file as specified [configuration properties](../config/app/#usesicloudstorage).

Running [EAS Build](https://docs.expo.dev/build/introduction) locally will use [iOS capabilities signing](https://docs.expo.dev/build-reference/ios-capabilities) to enable the required capabilities before building.

```json app.json
{
  "expo": {
    "plugins": [
      [
        "expo-document-picker",
        {
          "iCloudContainerEnvironment": "Production"
        }
      ]
    ]
  }
}
```

### Configurable properties

| Name                         | Default     | Description                                                                                                                                                                                                                                                      |
| ---------------------------- | ----------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `iCloudContainerEnvironment` | `undefined` | Only for: ios. Sets the iOS `com.apple.developer.icloud-container-environment` entitlement used for AdHoc iOS builds. Possible values: `Development`, `Production`. [Learn more](https://github.com/expo/eas-cli/issues/693).                                    |
| `kvStoreIdentifier`          | `undefined` | Only for: ios. Overrides the default iOS `com.apple.developer.ubiquity-kvstore-identifier` entitlement, which uses your Apple Team ID and bundle identifier. This may be needed if your app was transferred to another Apple Team after enabling iCloud storage. |

<ConfigReactNative>

Apps that don't use [EAS Build](https://docs.expo.dev/build/introduction) and want [iCloud storage features][icloud-entitlement] must [manually configure](https://docs.expo.dev/build-reference/ios-capabilities#manual-setup) the [**iCloud service with CloudKit support**](https://developer.apple.com/documentation/bundleresources/entitlements/com_apple_developer_icloud-container-environment) for their bundle identifier.

If you enable the **iCloud** capability through the [Apple Developer Console](https://docs.expo.dev/build-reference/ios-capabilities#apple-developer-console), then be sure to add the following entitlements in your `ios/[app]/[app].entitlements` file (where `dev.expo.my-app` if your bundle identifier):

```xml
<key>com.apple.developer.icloud-container-identifiers</key>
<array>
    <string>iCloud.dev.expo.my-app</string>
</array>
<key>com.apple.developer.icloud-services</key>
<array>
    <string>CloudDocuments</string>
</array>
<key>com.apple.developer.ubiquity-container-identifiers</key>
<array>
    <string>iCloud.dev.expo.my-app</string>
</array>
<key>com.apple.developer.ubiquity-kvstore-identifier</key>
<string>$(TeamIdentifierPrefix)dev.expo.my-app</string>
```

Apple Developer Console also requires an **iCloud Container** to be created. When registering the new container, you are asked to provide a description and identifier for the container. You may enter any name under the description. Under the identifier, add `iCloud.<your_bundle_identifier>` (same value used for `com.apple.developer.icloud-container-identifiers` and `com.apple.developer.ubiquity-container-identifiers` entitlements).

</ConfigReactNative>

## Using with `expo-file-system`

When using `expo-document-picker` with [`expo-file-system`](./filesystem/), it's not always possible for the file system to read the file immediately after the `expo-document-picker` picks it.

To allow the `expo-file-system` to read the file immediately after it is picked, you'll need to ensure that the [`copyToCacheDirectory`](#documentpickeroptions) option is set to `true`.

## API

```js
import * as DocumentPicker from "expo-document-picker";
```

## API: expo-document-picker

### DocumentPicker Methods

#### getDocumentAsync (_Function_)

- `getDocumentAsync(__namedParameters: DocumentPickerOptions): Promise<DocumentPickerResult>`
  Display the system UI for choosing a document. By default, the chosen file is copied to [the app's internal cache directory](filesystem/#filesystemcachedirectory).

  > **Notes for Web:** The system UI can only be shown after user activation (e.g. a `Button` press).
  > Therefore, calling `getDocumentAsync` in `componentDidMount`, for example, will **not** work as
  > intended. The `cancel` event will not be returned in the browser due to platform restrictions and
  > inconsistencies across browsers.
  > | Parameter | Type | Description |
  > | --- | --- | --- |
  > | `__namedParameters` | DocumentPickerOptions | - |
  > Returns: On success returns a promise that fulfils with [`DocumentPickerResult`](#documentpickerresult) object.

  If the user cancelled the document picking, the promise resolves to `{ type: 'cancel' }`.

### Types

#### DocumentPickerAsset (_Type_)

| Property                | Type   | Description                                                                                                                                                                                                                                                                                                                                            |
| ----------------------- | ------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `base64` _(optional)_   | string | Base64 string of the file. Available on platform: web                                                                                                                                                                                                                                                                                                  |
| `file` _(optional)_     | File   | `File` object for the parity with web File API. Available on platform: web                                                                                                                                                                                                                                                                             |
| `lastModified`          | number | Timestamp of last document modification. [Web API specs](https://developer.mozilla.org/en-US/docs/Web/API/File/lastModified)<br>The lastModified provides the last modified date of the file as the number<br>of milliseconds since the Unix epoch (January 1, 1970 at midnight). Files<br>without a known last modified date return the current date. |
| `mimeType` _(optional)_ | string | Document MIME type.                                                                                                                                                                                                                                                                                                                                    |
| `name`                  | string | Document original name.                                                                                                                                                                                                                                                                                                                                |
| `size` _(optional)_     | number | Document size in bytes.                                                                                                                                                                                                                                                                                                                                |
| `uri`                   | string | An URI to the local document file.                                                                                                                                                                                                                                                                                                                     |

#### DocumentPickerCanceledResult (_Type_)

Type representing canceled pick result.
| Property | Type | Description |
| --- | --- | --- |
| `assets` | null | Always `null` when the request was canceled. |
| `canceled` | true | Always `true` when the request was canceled. |
| `output` _(optional)_ | null | Always `null` when the request was canceled. Available on platform: web |

#### DocumentPickerOptions (_Type_)

| Property                            | Type               | Description                                                                                                                                                                                                                                                                                                                                                                                                                               |
| ----------------------------------- | ------------------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `base64` _(optional)_               | boolean            | If `true`, asset url is base64 from the file<br>If `false`, asset url is the file url parameter Default: `true` Available on platform: web                                                                                                                                                                                                                                                                                                |
| `copyToCacheDirectory` _(optional)_ | boolean            | If `true`, the picked file is copied to [`FileSystem.CacheDirectory`](./filesystem#filesystemcachedirectory),<br>which allows other Expo APIs to read the file immediately. This may impact performance for<br>large files, so you should consider setting this to `false` if you expect users to pick<br>particularly large files and your app does not need immediate read access. Default: `true` Available on platforms: ios, android |
| `multiple` _(optional)_             | boolean            | Allows multiple files to be selected from the system UI. Default: `false`                                                                                                                                                                                                                                                                                                                                                                 |
| `type` _(optional)_                 | string \| string[] | The [MIME type(s)](https://en.wikipedia.org/wiki/Media_type) of the documents that are available<br>to be picked. It also supports wildcards like `'image/*'` to choose any image. To allow any type<br>of document you can use `'&ast;/*'`. Default: `'&ast;/*'`                                                                                                                                                                         |

#### DocumentPickerResult (_Type_)

Type representing successful and canceled document pick result.
Type: DocumentPickerSuccessResult | DocumentPickerCanceledResult

#### DocumentPickerSuccessResult (_Type_)

Type representing successful pick result.
| Property | Type | Description |
| --- | --- | --- |
| `assets` | DocumentPickerAsset[] | An array of picked assets. |
| `canceled` | false | If asset data have been returned this should always be `false`. |
| `output` _(optional)_ | FileList | `FileList` object for the parity with web File API. Available on platform: web |

[icloud-entitlement]: https://developer.apple.com/documentation/bundleresources/entitlements/com_apple_developer_icloud-services
