# Cellular

_An API that provides information about the user's cellular service provider._

Available on platforms android, ios, web

`expo-cellular` provides information about the user's cellular service provider, such as its unique identifier, cellular connection type, and whether it allows VoIP calls on its network.

## Installation

```bash
$ bunx expo install expo-cellular
```

If you are installing this in an existing React Native app, make sure to install `expo` in your project.

## Configuration

<ConfigReactNative>

If you're not using Continuous Native Generation ([CNG](https://docs.expo.dev/workflow/continuous-native-generation/)) or you're using native a **android** project manually, then you need to add `android.permission.READ_PHONE_STATE` permission to your project's **AndroidManifest.xml**. This permission is used for `TelephonyManager`.

```xml android/app/src/main/AndroidManifest.xml
<uses-permission android:name="android.permission.READ_PHONE_STATE" />
```

This library does not require the more risky `READ_PRIVILEGED_PHONE_STATE` permission.

</ConfigReactNative>

## API

```js
import * as Cellular from "expo-cellular";
```

## API: expo-cellular

### Hooks

#### usePermissions (_Function_)

Check or request permissions to access the phone state.
This uses both `Cellular.requestPermissionsAsync` and `Cellular.getPermissionsAsync` to interact with the permissions.

- `usePermissions(options?: PermissionHookOptions<object>): [null | PermissionResponse, RequestPermissionMethod<PermissionResponse>, GetPermissionMethod<PermissionResponse>]`
  Check or request permissions to access the phone state.
  This uses both `Cellular.requestPermissionsAsync` and `Cellular.getPermissionsAsync` to interact with the permissions.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `options` _(optional)_ | PermissionHookOptions<object> | - |
  Example:
  ```ts
  const [status, requestPermission] = Cellular.usePermissions();
  ```

### Cellular Methods

#### allowsVoipAsync (_Function_)

- `allowsVoipAsync(): Promise<boolean | null>`
  Returns: Returns if the carrier allows making VoIP calls on its network. On Android, this checks whether
  the system supports SIP-based VoIP API. See [here](<https://developer.android.com/reference/android/net/sip/SipManager.html#isVoipSupported(android.content.Context)>)
  to view more information.

  On iOS, if you configure a device for a carrier and then remove the SIM card, this property
  retains the `boolean` value indicating the carrier’s policy regarding VoIP. If you then install
  a new SIM card, its VoIP policy `boolean` replaces the previous value of this property.

  On web, this returns `null`.
  Example:

  ```ts
  await Cellular.allowsVoipAsync(); // true or false
  ```

#### getCarrierNameAsync (_Function_)

- `getCarrierNameAsync(): Promise<string | null>`
  Returns: Returns name of the user’s home cellular service provider. If the device has dual SIM cards, only the
  carrier for the currently active SIM card will be returned.

  On Android, this value is only available when the SIM state is [`SIM_STATE_READY`](https://developer.android.com/reference/android/telephony/TelephonyManager.html#SIM_STATE_READY).
  Otherwise, this returns `null`.

  On iOS, if you configure a device for a carrier and then remove the SIM card, this property
  retains the name of the carrier. If you then install a new SIM card, its carrier name replaces
  the previous value of this property. The value for this property is `null` if the user never
  configured a carrier for the device.

  On web, this returns `null`.
  Example:

  ```ts
  await Cellular.getCarrierNameAsync(); // "T-Mobile" or "Verizon"
  ```

#### getCellularGenerationAsync (_Function_)

- `getCellularGenerationAsync(): Promise<CellularGeneration>`
  Returns: Returns a promise which fulfils with a [`Cellular.CellularGeneration`](#cellulargeneration)
  enum value that represents the current cellular-generation type.

  You will need to check if the native permission has been accepted to obtain generation.
  If the permission is denied `getCellularGenerationAsync` will resolve to `Cellular.Cellular Generation.UNKNOWN`.

  On web, this method uses [`navigator.connection.effectiveType`](https://developer.mozilla.org/en-US/docs/Web/API/NetworkInformation/effectiveType)
  to detect the effective type of the connection using a combination of recently observed
  round-trip time and downlink values. See [here](https://developer.mozilla.org/en-US/docs/Web/API/Network_Information_API)
  to view browser compatibility.
  Example:

  ```ts
  await Cellular.getCellularGenerationAsync();
  // CellularGeneration.CELLULAR_4G
  ```

#### getIsoCountryCodeAsync (_Function_)

- `getIsoCountryCodeAsync(): Promise<string | null>`
  Returns: Returns the ISO country code for the user’s cellular service provider.

  On iOS, the value is `null` if any of the following apply:
  - The device is in airplane mode.
  - There is no SIM card in the device.
  - The device is outside of cellular service range.

  On web, this returns `null`.
  Example:

  ```ts
  await Cellular.getIsoCountryCodeAsync(); // "us" or "au"
  ```

#### getMobileCountryCodeAsync (_Function_)

- `getMobileCountryCodeAsync(): Promise<string | null>`
  Returns: Returns mobile country code (MCC) for the user’s current registered cellular service provider.

  On Android, this value is only available when SIM state is [`SIM_STATE_READY`](https://developer.android.com/reference/android/telephony/TelephonyManager.html#SIM_STATE_READY). Otherwise, this
  returns `null`. On iOS, the value may be null on hardware prior to iPhone 4S when in airplane mode.
  Furthermore, the value for this property is `null` if any of the following apply:
  - There is no SIM card in the device.
  - The device is outside of cellular service range.

  On web, this returns `null`.
  Example:

  ```ts
  await Cellular.getMobileCountryCodeAsync(); // "310"
  ```

#### getMobileNetworkCodeAsync (_Function_)

- `getMobileNetworkCodeAsync(): Promise<string | null>`
  Returns: Returns the mobile network code (MNC) for the user’s current registered cellular service provider.

  On Android, this value is only available when SIM state is [`SIM_STATE_READY`](https://developer.android.com/reference/android/telephony/TelephonyManager.html#SIM_STATE_READY). Otherwise, this
  returns `null`. On iOS, the value may be null on hardware prior to iPhone 4S when in airplane mode.
  Furthermore, the value for this property is `null` if any of the following apply:
  - There is no SIM card in the device.
  - The device is outside of cellular service range.

  On web, this returns `null`.
  Example:

  ```ts
  await Cellular.getMobileNetworkCodeAsync(); // "310"
  ```

#### getPermissionsAsync (_Function_)

- `getPermissionsAsync(): Promise<PermissionResponse>`
  Checks user's permissions for accessing phone state.

#### requestPermissionsAsync (_Function_)

- `requestPermissionsAsync(): Promise<PermissionResponse>`
  Asks the user to grant permissions for accessing the phone state.

### Constants

#### allowsVoip (_Constant_)

Indicates if the carrier allows making VoIP calls on its network. On Android, this checks whether
the system supports SIP-based VoIP API. See the [Android documentation](<https://developer.android.com/reference/android/net/sip/SipManager.html#isVoipSupported(android.content.Context)>)
for more information.

On iOS, if you configure a device for a carrier and then remove the SIM card, this property
retains the `boolean` value indicating the carrier’s policy regarding VoIP. If you then install
a new SIM card, its VoIP policy `boolean` replaces the previous value of this property.

On web, this returns `null`.

- `allowsVoip` (boolean | null) — Indicates if the carrier allows making VoIP calls on its network. On Android, this checks whether
  the system supports SIP-based VoIP API. See the [Android documentation](<https://developer.android.com/reference/android/net/sip/SipManager.html#isVoipSupported(android.content.Context)>)
  for more information.

On iOS, if you configure a device for a carrier and then remove the SIM card, this property
retains the `boolean` value indicating the carrier’s policy regarding VoIP. If you then install
a new SIM card, its VoIP policy `boolean` replaces the previous value of this property.

On web, this returns `null`. = ...

#### carrier (_Constant_)

The name of the user’s home cellular service provider. If the device has dual SIM cards, only the
carrier for the currently active SIM card will be returned. On Android, this value is only
available when the SIM state is [`SIM_STATE_READY`](https://developer.android.com/reference/android/telephony/TelephonyManager.html#SIM_STATE_READY).
Otherwise, this returns `null`.

On iOS, if you configure a device for a carrier and then remove the SIM card, this property
retains the name of the carrier. If you then install a new SIM card, its carrier name replaces
the previous value of this property. The value for this property is `null` if the user never
configured a carrier for the device.

On web, this returns `null`.

- `carrier` (string | null) — The name of the user’s home cellular service provider. If the device has dual SIM cards, only the
  carrier for the currently active SIM card will be returned. On Android, this value is only
  available when the SIM state is [`SIM_STATE_READY`](https://developer.android.com/reference/android/telephony/TelephonyManager.html#SIM_STATE_READY).
  Otherwise, this returns `null`.

On iOS, if you configure a device for a carrier and then remove the SIM card, this property
retains the name of the carrier. If you then install a new SIM card, its carrier name replaces
the previous value of this property. The value for this property is `null` if the user never
configured a carrier for the device.

On web, this returns `null`. = ...

#### isoCountryCode (_Constant_)

The ISO country code for the user’s cellular service provider. On iOS, the value is `null` if any
of the following apply:

- The device is in airplane mode.
- There is no SIM card in the device.
- The device is outside of cellular service range.

On web, this returns `null`.

- `isoCountryCode` (string | null) — The ISO country code for the user’s cellular service provider. On iOS, the value is `null` if any
  of the following apply:
- The device is in airplane mode.
- There is no SIM card in the device.
- The device is outside of cellular service range.

On web, this returns `null`. = ...

#### mobileCountryCode (_Constant_)

The mobile country code (MCC) for the user’s current registered cellular service provider.
On Android, this value is only available when SIM state is [`SIM_STATE_READY`](https://developer.android.com/reference/android/telephony/TelephonyManager.html#SIM_STATE_READY). Otherwise, this
returns `null`. On iOS, the value may be null on hardware prior to iPhone 4S when in airplane mode.
Furthermore, the value for this property is `null` if any of the following apply:

- There is no SIM card in the device.
- The device is outside of cellular service range.

On web, this returns `null`.

- `mobileCountryCode` (string | null) — The mobile country code (MCC) for the user’s current registered cellular service provider.
  On Android, this value is only available when SIM state is [`SIM_STATE_READY`](https://developer.android.com/reference/android/telephony/TelephonyManager.html#SIM_STATE_READY). Otherwise, this
  returns `null`. On iOS, the value may be null on hardware prior to iPhone 4S when in airplane mode.
  Furthermore, the value for this property is `null` if any of the following apply:
- There is no SIM card in the device.
- The device is outside of cellular service range.

On web, this returns `null`. = ...

#### mobileNetworkCode (_Constant_)

The ISO country code for the user’s cellular service provider. On iOS, the value is `null` if
any of the following apply:

- The device is in airplane mode.
- There is no SIM card in the device.
- The device is outside of cellular service range.

On web, this returns `null`.

- `mobileNetworkCode` (string | null) — The ISO country code for the user’s cellular service provider. On iOS, the value is `null` if
  any of the following apply:
- The device is in airplane mode.
- There is no SIM card in the device.
- The device is outside of cellular service range.

On web, this returns `null`. = ...

### Enums

#### CellularGeneration (_Enum_)

Describes the current generation of the cellular connection. It is an enum with these possible
values:

#### Members

- `CELLULAR_2G` — Currently connected to a 2G cellular network. Includes CDMA, EDGE, GPRS, and IDEN type connections.
- `CELLULAR_3G` — Currently connected to a 3G cellular network. Includes EHRPD, EVDO, HSPA, HSUPA, HSDPA, HSPAP, and UTMS type connections.
- `CELLULAR_4G` — Currently connected to a 4G cellular network. Includes LTE type connections.
- `CELLULAR_5G` — Currently connected to a 5G cellular network. Includes NR and NRNSA type connections.
- `UNKNOWN` — Either we are not currently connected to a cellular network or type could not be determined.

## Error codes

| Code                                         | Description                                                          |
| -------------------------------------------- | -------------------------------------------------------------------- |
| ERR_CELLULAR_GENERATION_UNKNOWN_NETWORK_TYPE | Unable to access network type or not connected to a cellular network |

## Permissions

### Android

You must add the following permissions to your **app.json** inside the [`expo.android.permissions`](../config/app/#permissions) array.

<AndroidPermissions permissions={['READ_PHONE_STATE']} />

### iOS

_No permissions required_.
