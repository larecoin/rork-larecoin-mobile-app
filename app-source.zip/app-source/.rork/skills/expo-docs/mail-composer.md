# MailComposer

_A library that provides functionality to compose and send emails with the system's specific UI._

Available on platforms android, ios (device-only), web

`expo-mail-composer` allows you to compose and send emails quickly and easily using the OS UI. This module can't be used on iOS Simulators since you can't sign into a mail account on them.

<ContentSpotlight file="sdk/mailcomposer.mp4" loop={false} />

## Installation

```bash
$ bunx expo install expo-mail-composer
```

If you are installing this in an existing React Native app, make sure to install `expo` in your project.

## API

```js
import * as MailComposer from "expo-mail-composer";
```

## API: expo-mail-composer

### MailComposer Methods

#### composeAsync (_Function_)

- `composeAsync(options: MailComposerOptions): Promise<MailComposerResult>`
  Opens a mail modal for iOS and a mail app intent for Android and fills the fields with provided
  data. On iOS you will need to be signed into the Mail app.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `options` | MailComposerOptions | - |
  Returns: A promise fulfilled with an object containing a `status` field that specifies whether an
  email was sent, saved, or cancelled. Android does not provide this info, so the status is always
  set as if the email were sent.

#### getClients (_Function_)

- `getClients(): MailClient[]`
  Retrieves a list of available email clients installed on the device.
  This can be used to present options to the user for sending emails through their preferred email client,
  or to open an email client so the user can access their mailbox — for example, to open a confirmation email sent by your app.
  Returns: An array of available mail clients.

#### isAvailableAsync (_Function_)

- `isAvailableAsync(): Promise<boolean>`
  Determine if the `MailComposer` API can be used in this app.
  Returns: A promise resolves to `true` if the API can be used, and `false` otherwise.
  - Returns `true` when the device has a default email setup for sending mail.
  - Can return `false` on iOS if an MDM profile is setup to block outgoing mail. If this is the
    case, you may want to use the Linking API instead.
  - Always returns `true` in the browser.

### Types

#### MailClient (_Type_)

Represents a mail client available on the device.
| Property | Type | Description |
| --- | --- | --- |
| `label` | string | The display name of the mail client. |
| `packageName` _(optional)_ | string | The package name of the mail client application.<br>You can use this package name with the [`getApplicationIconAsync`](./intent-launcher/#intentlaunchergetapplicationiconasyncpackagename)<br>or [`openApplication`](./intent-launcher/#intentlauncheropenapplicationpackagename) functions from<br>[`expo-intent-launcher`](./intent-launcher/) to retrieve the app’s icon or open the mail client directly. Available on platform: android |
| `url` _(optional)_ | string | The URL scheme of the mail client.<br>You can use this URL with the [`openURL`](./linking/#linkingopenurlurl) function from [`expo-linking`](./linking/)<br>to open the mail client. Available on platform: ios |

#### MailComposerOptions (_Type_)

A map defining the data to fill the mail.
| Property | Type | Description |
| --- | --- | --- |
| `attachments` _(optional)_ | string[] | An array of app's internal file URIs to attach. |
| `bccRecipients` _(optional)_ | string[] | An array of e-mail addresses of the BCC recipients. |
| `body` _(optional)_ | string | Body of the e-mail. |
| `ccRecipients` _(optional)_ | string[] | An array of e-mail addresses of the CC recipients. |
| `isHtml` _(optional)_ | boolean | Whether the body contains HTML tags so it could be formatted properly.<br>Not working perfectly on Android. |
| `recipients` _(optional)_ | string[] | An array of e-mail addresses of the recipients. |
| `subject` _(optional)_ | string | Subject of the e-mail. |

#### MailComposerResult (_Type_)

| Property | Type               | Description |
| -------- | ------------------ | ----------- |
| `status` | MailComposerStatus | -           |

### Enums

#### MailComposerStatus (_Enum_)

#### Members

- `CANCELLED`
- `SAVED`
- `SENT`
- `UNDETERMINED`
