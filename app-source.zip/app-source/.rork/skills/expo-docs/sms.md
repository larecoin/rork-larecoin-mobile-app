# SMS

_A library that provides access to the system's UI/app for sending SMS messages._

Available on platforms android, ios

`expo-sms` provides access to the system's UI/app for sending SMS messages.

## Installation

```bash
$ bunx expo install expo-sms
```

If you are installing this in an existing React Native app, make sure to install `expo` in your project.

## API

```js
import * as SMS from "expo-sms";
```

## API: expo-sms

### SMS Methods

#### isAvailableAsync (_Function_)

- `isAvailableAsync(): Promise<boolean>`
  Determines whether SMS is available. Always returns `false` in the iOS simulator, and in browser.
  Returns: Returns a promise that fulfils with a `boolean`, indicating whether SMS is available on this device.
  Example:
  ```ts
  const isAvailable = await SMS.isAvailableAsync();
  if (isAvailable) {
    // do your SMS stuff here
  } else {
    // misfortune... there's no SMS available on this device
  }
  ```

#### sendSMSAsync (_Function_)

- `sendSMSAsync(addresses: string | string[], message: string, options?: SMSOptions): Promise<SMSResponse>`
  Opens the default UI/app for sending SMS messages with prefilled addresses and message.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `addresses` | string \| string[] | An array of addresses (phone numbers) or single address passed as strings. Those<br>would appear as recipients of the prepared message. |
  | `message` | string | Message to be sent. |
  | `options` _(optional)_ | SMSOptions | A `SMSOptions` object defining additional SMS configuration options. |
  Returns: Returns a Promise that fulfils with the SMS action is invoked by the user, with corresponding result:
  - If the user cancelled the SMS sending process: `{ result: 'cancelled' }`.
  - If the user has sent/scheduled message for sending: `{ result: 'sent' }`.
  - If the status of the SMS message cannot be determined: `{ result: 'unknown' }`.

  Android does not provide information about the status of the SMS message, so on Android devices
  the Promise will always resolve with `{ result: 'unknown' }`.

  > Note: The only feedback collected by this module is whether any message has been sent. That
  > means we do not check actual content of message nor recipients list.
  > Example:

  ```ts
  const { result } = await SMS.sendSMSAsync(["0123456789", "9876543210"], "My sample HelloWorld message", {
    attachments: {
      uri: "path/myfile.png",
      mimeType: "image/png",
      filename: "myfile.png",
    },
  });
  ```

### Types

#### SMSAttachment (_Type_)

An object that is used to describe an attachment that is included with a SMS message.
| Property | Type | Description |
| --- | --- | --- |
| `filename` | string | The filename of the attachment. |
| `mimeType` | string | The mime type of the attachment such as `image/png`. |
| `uri` | string | The content URI of the attachment. The URI needs be a content URI so that it can be accessed by<br>other applications outside of Expo. See [FileSystem.getContentUriAsync](./filesystem/#filesystemgetcontenturiasyncfileuri)). |

#### SMSOptions (_Type_)

| Property                   | Type                             | Description |
| -------------------------- | -------------------------------- | ----------- |
| `attachments` _(optional)_ | SMSAttachment \| SMSAttachment[] | -           |

#### SMSResponse (_Type_)

| Property | Type                               | Description                               |
| -------- | ---------------------------------- | ----------------------------------------- |
| `result` | 'unknown' \| 'sent' \| 'cancelled' | Status of SMS action invoked by the user. |
