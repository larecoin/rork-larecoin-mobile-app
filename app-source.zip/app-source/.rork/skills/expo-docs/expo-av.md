# Audio (expo-av)

_A library that provides an API to implement audio playback and recording in apps._

Available on platforms android, ios, tvos, web

> **warning** **Deprecated:** The `Audio` component from `expo-av`, which is documented on this page, has now been deprecated and replaced by an improved version in `expo-audio`. [Learn about `expo-audio`](./audio/).

`Audio` from `expo-av` allows you to implement audio playback and recording in your app.

Note that audio automatically stops if headphones/bluetooth audio devices are disconnected.

See the [playlist example app](https://github.com/expo/playlist-example) for an example on the media playback API, and the [recording example app](https://github.com/expo/audio-recording-example) for an example of the recording API.

## Installation

```bash
$ bunx expo install expo-av
```

If you are installing this in an existing React Native app, make sure to install `expo` in your project.

## Usage

### Playing sounds

```jsx
import { useEffect, useState } from "react";
import { View, StyleSheet, Button } from "react-native";
import { Audio } from "expo-av";

export default function App() {
  const [sound, setSound] = useState();

  async function playSound() {
    console.log("Loading Sound");
    /* @info */ const { sound } = await Audio.Sound.createAsync(/* @end */ require("./assets/Hello.mp3"));
    setSound(sound);

    console.log("Playing Sound");
    await /* @info */ sound.playAsync(); /* @end */
  }

  useEffect(() => {
    return sound
      ? () => {
          console.log("Unloading Sound");
          /* @info Always unload the Sound after using it to prevent memory leaks.*/ sound.unloadAsync(); /* @end */
        }
      : undefined;
  }, [sound]);

  return (
    <View style={styles.container}>
      <Button title="Play Sound" onPress={playSound} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    backgroundColor: "#ecf0f1",
    padding: 10,
  },
});
```

### Recording sounds

```jsx
import { useState } from "react";
import { View, StyleSheet, Button } from "react-native";
import { Audio } from "expo-av";

export default function App() {
  const [recording, setRecording] = useState();
  const [permissionResponse, requestPermission] = Audio.usePermissions();

  async function startRecording() {
    try {
      /* @info */ if (permissionResponse.status !== "granted") {
        console.log("Requesting permission..");
        await requestPermission();
      }
      await Audio.setAudioModeAsync({
        allowsRecordingIOS: true,
        playsInSilentModeIOS: true,
      }); /* @end */

      console.log("Starting recording..");
      /* @info */ const { recording } = await Audio.Recording.createAsync(
        /* @end */ Audio.RecordingOptionsPresets.HIGH_QUALITY,
      );
      setRecording(recording);
      console.log("Recording started");
    } catch (err) {
      console.error("Failed to start recording", err);
    }
  }

  async function stopRecording() {
    console.log("Stopping recording..");
    setRecording(undefined);
    /* @info */ await recording.stopAndUnloadAsync(); /* @end */
    /* @info iOS may reroute audio playback to the phone earpiece when recording is allowed, so disable once finished. */ await Audio.setAudioModeAsync(
      {
        allowsRecordingIOS: false,
      },
    ); /* @end */
    /* @info */ const uri = recording.getURI(); /* @end */
    console.log("Recording stopped and stored at", uri);
  }

  return (
    <View style={styles.container}>
      <Button
        title={recording ? "Stop Recording" : "Start Recording"}
        onPress={recording ? stopRecording : startRecording}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    backgroundColor: "#ecf0f1",
    padding: 10,
  },
});
```

### Playing or recording audio in background&ensp;<PlatformTags platforms={['ios']} />

On iOS, audio playback and recording in background is only available in standalone apps, and it requires some extra configuration.
On iOS, each background feature requires a special key in `UIBackgroundModes` array in your **Info.plist** file.
In standalone apps this array is empty by default, so to use background features you will need to add appropriate keys to your **app.json** configuration.

See an example of **app.json** that enables audio playback in background:

```json
{
  "expo": {
    ...
    "ios": {
      ...
      "infoPlist": {
        ...
        "UIBackgroundModes": [
          "audio"
        ]
      }
    }
  }
}
```

### Notes on web usage

- A MediaRecorder issue on Chrome produces WebM files missing the duration metadata. [See the open Chromium issue](https://bugs.chromium.org/p/chromium/issues/detail?id=642012).
- MediaRecorder encoding options and other configurations are inconsistent across browsers, utilizing a Polyfill such as [kbumsik/opus-media-recorder](https://github.com/kbumsik/opus-media-recorder) or [ai/audio-recorder-polyfill](https://github.com/ai/audio-recorder-polyfill) in your application will improve your experience. Any options passed to `prepareToRecordAsync` will be passed directly to the MediaRecorder API and as such the polyfill.
- Web browsers require sites to be served securely for them to listen to a mic. See [MediaDevices `getUserMedia()` security](https://developer.mozilla.org/en-US/docs/Web/API/MediaDevices/getUserMedia#security) for more details.

## API

```js
import { Audio } from "expo-av";
```

## API: expo-audio-av

### Recording (_Class_)

> **warning** **Warning**: Experimental for web.

This class represents an audio recording. After creating an instance of this class, `prepareToRecordAsync`
must be called in order to record audio. Once recording is finished, call `stopAndUnloadAsync`. Note that
only one recorder is allowed to exist in the state between `prepareToRecordAsync` and `stopAndUnloadAsync`
at any given time.

Note that your experience must request audio recording permissions in order for recording to function.
See the [`Permissions` module](https://docs.expo.dev/guides/permissions) for more details.

Additionally, audio recording is [not supported in the iOS Simulator](https://docs.expo.dev/workflow/ios-simulator/#limitations).
Available on platforms: android, ios

#### Properties

- `_canRecord` (boolean)
  Default: `false`
- `_finalDurationMillis` (number)
  Default: `0`
- `_isDoneRecording` (boolean)
  Default: `false`
- `_onRecordingStatusUpdate` (null | (status: RecordingStatus) => void)
  Default: `null`
- `_options` (null | RecordingOptions)
  Default: `null`
- `_progressUpdateIntervalMillis` (number)
  Default: `_DEFAULT_PROGRESS_UPDATE_INTERVAL_MILLIS`
- `_progressUpdateTimeoutVariable` (null | number)
  Default: `null`
- `_subscription` (null | EventSubscription)
  Default: `null`
- `_uri` (null | string)
  Default: `null`

#### Methods

- `_callOnRecordingStatusUpdateForNewStatus(status: RecordingStatus)`
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `status` | RecordingStatus | - |

- `_cleanupForUnloadedRecorder(finalStatus?: RecordingStatus): Promise<RecordingStatus>`
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `finalStatus` _(optional)_ | RecordingStatus | - |

- `_disablePolling()`

- `_enablePollingIfNecessaryAndPossible()`

- `_performOperationAndHandleStatusAsync(operation: () => Promise<RecordingStatus>): Promise<RecordingStatus>`
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `operation` | () => Promise<RecordingStatus> | - |

- `_pollingLoop(): Promise<void>`

- `createNewLoadedSound(initialStatus: AVPlaybackStatusToSet, onPlaybackStatusUpdate: null | (status: AVPlaybackStatus) => void): Promise<SoundObject>`
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `initialStatus` | AVPlaybackStatusToSet | - |
  | `onPlaybackStatusUpdate` | null \| (status: AVPlaybackStatus) => void | - |

- `createNewLoadedSoundAsync(initialStatus: AVPlaybackStatusToSet, onPlaybackStatusUpdate: null | (status: AVPlaybackStatus) => void): Promise<SoundObject>`
  Creates and loads a new `Sound` object to play back the `Recording`. Note that this will only succeed once the `Recording`
  is done recording and `stopAndUnloadAsync()` has been called.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `initialStatus` | AVPlaybackStatusToSet | The initial intended `PlaybackStatusToSet` of the sound, whose values will override the default initial playback status.<br>This value defaults to `{}` if no parameter is passed. See the [AV documentation](https://docs.expo.dev/versions/latest/sdk/av) for details on `PlaybackStatusToSet`<br>and the default initial playback status. |
  | `onPlaybackStatusUpdate` | null \| (status: AVPlaybackStatus) => void | A function taking a single parameter `PlaybackStatus`. This value defaults to `null` if no parameter is passed.<br>See the [AV documentation](https://docs.expo.dev/versions/latest/sdk/av) for details on the functionality provided by `onPlaybackStatusUpdate` |
  Returns: A `Promise` that is rejected if creation failed, or fulfilled with the `SoundObject`.

- `getAvailableInputs(): Promise<RecordingInput[]>`
  Returns a list of available recording inputs. This method can only be called if the `Recording` has been prepared.
  Returns: A `Promise` that is fulfilled with an array of `RecordingInput` objects.

- `getCurrentInput(): Promise<RecordingInput>`
  Returns the currently-selected recording input. This method can only be called if the `Recording` has been prepared.
  Returns: A `Promise` that is fulfilled with a `RecordingInput` object.

- `getStatusAsync(): Promise<RecordingStatus>`
  Gets the `status` of the `Recording`.
  Returns: A `Promise` that is resolved with the `RecordingStatus` object.

- `getURI(): null | string`
  Gets the local URI of the `Recording`. Note that this will only succeed once the `Recording` is prepared
  to record. On web, this will not return the URI until the recording is finished.
  Returns: A `string` with the local URI of the `Recording`, or `null` if the `Recording` is not prepared
  to record (or, on Web, if the recording has not finished).

- `pauseAsync(): Promise<RecordingStatus>`
  Pauses recording. This method can only be called if the `Recording` has been prepared.

  > This is only available on Android API version 24 and later.
  > Returns: A `Promise` that is fulfilled when recording has paused, or rejects if recording could not be paused.
  > If the Android API version is less than 24, the `Promise` will reject. The promise is resolved with the
  > `RecordingStatus` of the recording.

- `prepareToRecordAsync(options: RecordingOptions): Promise<RecordingStatus>`
  Loads the recorder into memory and prepares it for recording. This must be called before calling `startAsync()`.
  This method can only be called if the `Recording` instance has never yet been prepared.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `options` | RecordingOptions | `RecordingOptions` for the recording, including sample rate, bitrate, channels, format, encoder, and extension.<br>If no options are passed to `prepareToRecordAsync()`, the recorder will be created with options `Audio.RecordingOptionsPresets.LOW_QUALITY`. |
  Returns: A `Promise` that is fulfilled when the recorder is loaded and prepared, or rejects if this failed. If another `Recording` exists
  in your experience that is currently prepared to record, the `Promise` will reject. If the `RecordingOptions` provided are invalid,
  the `Promise` will also reject. The promise is resolved with the `RecordingStatus` of the recording.

- `setInput(inputUid: string): Promise<void>`
  Sets the current recording input.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `inputUid` | string | The uid of a `RecordingInput`. |
  Returns: A `Promise` that is resolved if successful or rejected if not.

- `setOnRecordingStatusUpdate(onRecordingStatusUpdate: null | (status: RecordingStatus) => void)`
  Sets a function to be called regularly with the `RecordingStatus` of the `Recording`.

  `onRecordingStatusUpdate` will be called when another call to the API for this recording completes (such as `prepareToRecordAsync()`,
  `startAsync()`, `getStatusAsync()`, or `stopAndUnloadAsync()`), and will also be called at regular intervals while the recording can record.
  Call `setProgressUpdateInterval()` to modify the interval with which `onRecordingStatusUpdate` is called while the recording can record.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `onRecordingStatusUpdate` | null \| (status: RecordingStatus) => void | A function taking a single parameter `RecordingStatus`. |

- `setProgressUpdateInterval(progressUpdateIntervalMillis: number)`
  Sets the interval with which `onRecordingStatusUpdate` is called while the recording can record.
  See `setOnRecordingStatusUpdate` for details. This value defaults to 500 milliseconds.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `progressUpdateIntervalMillis` | number | The new interval between calls of `onRecordingStatusUpdate`. |

- `startAsync(): Promise<RecordingStatus>`
  Begins recording. This method can only be called if the `Recording` has been prepared.
  Returns: A `Promise` that is fulfilled when recording has begun, or rejects if recording could not be started.
  The promise is resolved with the `RecordingStatus` of the recording.

- `stopAndUnloadAsync(): Promise<RecordingStatus>`
  Stops the recording and deallocates the recorder from memory. This reverts the `Recording` instance
  to an unprepared state, and another `Recording` instance must be created in order to record again.
  This method can only be called if the `Recording` has been prepared.

  > On Android this method may fail with `E_AUDIO_NODATA` when called too soon after `startAsync` and
  > no audio data has been recorded yet. In that case the recorded file will be invalid and should be discarded.
  > Returns: A `Promise` that is fulfilled when recording has stopped, or rejects if recording could not be stopped.
  > The promise is resolved with the `RecordingStatus` of the recording.

- `createAsync(options: RecordingOptions, onRecordingStatusUpdate: null | (status: RecordingStatus) => void, progressUpdateIntervalMillis: null | number): Promise<RecordingObject>`
  Creates and starts a recording using the given options, with optional `onRecordingStatusUpdate` and `progressUpdateIntervalMillis`.

  ```ts
  const { recording, status } = await Audio.Recording.createAsync(
    options,
    onRecordingStatusUpdate,
    progressUpdateIntervalMillis,
  );

  // Which is equivalent to the following:
  const recording = new Audio.Recording();
  await recording.prepareToRecordAsync(options);
  recording.setOnRecordingStatusUpdate(onRecordingStatusUpdate);
  await recording.startAsync();
  ```

  | Parameter                      | Type                                      | Description                                                                                                                                                                                                                                                              |
  | ------------------------------ | ----------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
  | `options`                      | RecordingOptions                          | Options for the recording, including sample rate, bitrate, channels, format, encoder, and extension. If no options are passed to,<br>the recorder will be created with options `Audio.RecordingOptionsPresets.LOW_QUALITY`. See below for details on `RecordingOptions`. |
  | `onRecordingStatusUpdate`      | null \| (status: RecordingStatus) => void | A function taking a single parameter `status` (a dictionary, described in `getStatusAsync`).                                                                                                                                                                             |
  | `progressUpdateIntervalMillis` | null \| number                            | The interval between calls of `onRecordingStatusUpdate`. This value defaults to 500 milliseconds.                                                                                                                                                                        |

  Returns: A `Promise` that is rejected if creation failed, or fulfilled with the following dictionary if creation succeeded.
  Example:

  ```ts
  try {
    const { recording: recordingObject, status } = await Audio.Recording.createAsync(
      Audio.RecordingOptionsPresets.HIGH_QUALITY,
    );
    // You are now recording!
  } catch (error) {
    // An error occurred!
  }
  ```

### Sound (_Class_)

This class represents a sound corresponding to an Asset or URL.

#### Properties

- `_coalesceStatusUpdatesInMillis` (number)
  Default: `100`
- `_eventEmitter` (LegacyEventEmitter)
  Default: `...`
- `_key` (AudioInstance)
  Default: `null`
- `_lastStatusUpdate` (null | string)
  Default: `null`
- `_lastStatusUpdateTime` (null | Date)
  Default: `null`
- `_loaded` (boolean)
  Default: `false`
- `_loading` (boolean)
  Default: `false`
- `_onAudioSampleReceived` (AudioSampleCallback)
  Default: `null`
- `_onMetadataUpdate` (null | (metadata: AVMetadata) => void)
  Default: `null`
- `_onPlaybackStatusUpdate` (null | (status: AVPlaybackStatus) => void)
  Default: `null`
- `_subscriptions` ({ remove: () => void }[])
  Default: `[]`
- `pauseAsync` (() => Promise<AVPlaybackStatus>)
  This is equivalent to `playbackObject.setStatusAsync({ shouldPlay: false })`.
- `playAsync` (() => Promise<AVPlaybackStatus>)
  This is equivalent to `playbackObject.setStatusAsync({ shouldPlay: true })`.

  Playback may not start immediately after calling this function for reasons such as buffering. Make sure to update your UI based
  on the `isPlaying` and `isBuffering` properties of the `AVPlaybackStatus`.

- `playFromPositionAsync` ((positionMillis: number, tolerances: AVPlaybackTolerance) => Promise<AVPlaybackStatus>)
  This is equivalent to `playbackObject.setStatusAsync({ shouldPlay: true, positionMillis, seekMillisToleranceAfter: tolerances.seekMillisToleranceAfter, seekMillisToleranceBefore: tolerances.seekMillisToleranceBefore })`.

  Playback may not start immediately after calling this function for reasons such as buffering. Make sure to update your UI based
  on the `isPlaying` and `isBuffering` properties of the `AVPlaybackStatus`.

- `setIsLoopingAsync` ((isLooping: boolean) => Promise<AVPlaybackStatus>)
  This is equivalent to `playbackObject.setStatusAsync({ isLooping })`.
- `setIsMutedAsync` ((isMuted: boolean) => Promise<AVPlaybackStatus>)
  This is equivalent to `playbackObject.setStatusAsync({ isMuted })`.
- `setPositionAsync` ((positionMillis: number, tolerances: AVPlaybackTolerance) => Promise<AVPlaybackStatus>)
  This is equivalent to `playbackObject.setStatusAsync({ positionMillis })`.
- `setProgressUpdateIntervalAsync` ((progressUpdateIntervalMillis: number) => Promise<AVPlaybackStatus>)
  This is equivalent to `playbackObject.setStatusAsync({ progressUpdateIntervalMillis })`.
- `setRateAsync` ((rate: number, shouldCorrectPitch: boolean, pitchCorrectionQuality: PitchCorrectionQuality) => Promise<AVPlaybackStatus>)
  This is equivalent to `playbackObject.setStatusAsync({ rate, shouldCorrectPitch, pitchCorrectionQuality })`.
- `setVolumeAsync` ((volume: number, audioPan: number) => Promise<AVPlaybackStatus>)
  This is equivalent to `playbackObject.setStatusAsync({ volume, audioPan })`.
  Note: `audioPan` is currently only supported on Android using `androidImplementation: 'MediaPlayer'`
- `stopAsync` (() => Promise<AVPlaybackStatus>)
  This is equivalent to `playbackObject.setStatusAsync({ shouldPlay: false, positionMillis: 0 })`.

#### Methods

- `_callOnPlaybackStatusUpdateForNewStatus(status: AVPlaybackStatus)`
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `status` | AVPlaybackStatus | - |

- `_clearSubscriptions()`

- `_errorCallback(error: string)`
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `error` | string | - |

- `_internalErrorCallback(__namedParameters: { error: string; key: AudioInstance })`
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `__namedParameters` | { error: string; key: AudioInstance } | - |

- `_internalMetadataUpdateCallback(__namedParameters: { key: AudioInstance; metadata: AVMetadata })`
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `__namedParameters` | { key: AudioInstance; metadata: AVMetadata } | - |

- `_internalStatusUpdateCallback(__namedParameters: { key: AudioInstance; status: AVPlaybackStatus })`
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `__namedParameters` | { key: AudioInstance; status: AVPlaybackStatus } | - |

- `_performOperationAndHandleStatusAsync(operation: () => Promise<AVPlaybackStatus>): Promise<AVPlaybackStatus>`
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `operation` | () => Promise<AVPlaybackStatus> | - |

- `_subscribeToNativeEvents()`

- `getStatusAsync(): Promise<AVPlaybackStatus>`

- `loadAsync(source: AVPlaybackSource, initialStatus: AVPlaybackStatusToSet, downloadFirst: boolean): Promise<AVPlaybackStatus>`
  Loads the media from `source` into memory and prepares it for playing. This must be called before calling `setStatusAsync()`
  or any of the convenience set status methods. This method can only be called if the `playbackObject` is in an unloaded state.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `source` | AVPlaybackSource | The source of the media. |
  | `initialStatus` | AVPlaybackStatusToSet | The initial intended `AVPlaybackStatusToSet` of the `playbackObject`, whose values will override the default initial playback status.<br>This value defaults to `{}` if no parameter is passed. For more information see the details on `AVPlaybackStatusToSet` type<br>and the default initial playback status. |
  | `downloadFirst` | boolean | - |
  Returns: A `Promise` that is fulfilled with the `AVPlaybackStatus` of the `playbackObject` once it is loaded, or rejects if loading failed.
  The `Promise` will also reject if the `playbackObject` was already loaded. See below for details on `AVPlaybackStatus`.

- `replayAsync(status: AVPlaybackStatusToSet): Promise<AVPlaybackStatus>`
  Replays the playback item. When using `playFromPositionAsync(0)` the item is seeked to the position at `0 ms`.
  On iOS this method uses internal implementation of the player and is able to play the item from the beginning immediately.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `status` | AVPlaybackStatusToSet | The new `AVPlaybackStatusToSet` of the `playbackObject`, whose values will override the current playback status.<br>`positionMillis` and `shouldPlay` properties will be overridden with respectively `0` and `true`. |
  Returns: A `Promise` that is fulfilled with the `AVPlaybackStatus` of the `playbackObject` once the new status has been set successfully,
  or rejects if setting the new status failed.

- `setOnAudioSampleReceived(callback: AudioSampleCallback)`
  Sets a function to be called during playback, receiving the audio sample as parameter.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `callback` | AudioSampleCallback | A function taking the `AudioSampleCallback` as parameter. |

- `setOnMetadataUpdate(onMetadataUpdate: (metadata: AVMetadata) => void)`
  Sets a function to be called whenever the metadata of the sound object changes, if one is set.
  Available on platform: ios
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `onMetadataUpdate` | (metadata: AVMetadata) => void | A function taking a single object of type `AVMetadata` as a parameter. |

- `setOnPlaybackStatusUpdate(onPlaybackStatusUpdate: null | (status: AVPlaybackStatus) => void)`
  Sets a function to be called regularly with the `AVPlaybackStatus` of the playback object.

  `onPlaybackStatusUpdate` will be called whenever a call to the API for this playback object completes
  (such as `setStatusAsync()`, `getStatusAsync()`, or `unloadAsync()`), nd will also be called at regular intervals
  while the media is in the loaded state.

  Set `progressUpdateIntervalMillis` via `setStatusAsync()` or `setProgressUpdateIntervalAsync()` to modify
  the interval with which `onPlaybackStatusUpdate` is called while loaded.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `onPlaybackStatusUpdate` | null \| (status: AVPlaybackStatus) => void | A function taking a single parameter `AVPlaybackStatus`. |

- `setStatusAsync(status: AVPlaybackStatusToSet): Promise<AVPlaybackStatus>`
  Sets a new `AVPlaybackStatusToSet` on the `playbackObject`. This method can only be called if the media has been loaded.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `status` | AVPlaybackStatusToSet | The new `AVPlaybackStatusToSet` of the `playbackObject`, whose values will override the current playback status. |
  Returns: A `Promise` that is fulfilled with the `AVPlaybackStatus` of the `playbackObject` once the new status has been set successfully,
  or rejects if setting the new status failed. See below for details on `AVPlaybackStatus`.

- `unloadAsync(): Promise<AVPlaybackStatus>`
  Unloads the media from memory. `loadAsync()` must be called again in order to be able to play the media.

  > This cleanup function will be automatically called in the `Video` component's `componentWillUnmount`.
  > Returns: A `Promise` that is fulfilled with the `AVPlaybackStatus` of the `playbackObject` once it is unloaded, or rejects if unloading failed.

- `create(source: AVPlaybackSource, initialStatus: AVPlaybackStatusToSet, onPlaybackStatusUpdate: null | (status: AVPlaybackStatus) => void, downloadFirst: boolean): Promise<SoundObject>`
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `source` | AVPlaybackSource | - |
  | `initialStatus` | AVPlaybackStatusToSet | - |
  | `onPlaybackStatusUpdate` | null \| (status: AVPlaybackStatus) => void | - |
  | `downloadFirst` | boolean | - |

- `createAsync(source: AVPlaybackSource, initialStatus: AVPlaybackStatusToSet, onPlaybackStatusUpdate: null | (status: AVPlaybackStatus) => void, downloadFirst: boolean): Promise<SoundObject>`
  Creates and loads a sound from source.

  ```ts
  const { sound } = await Audio.Sound.createAsync(source, initialStatus, onPlaybackStatusUpdate, downloadFirst);

  // Which is equivalent to the following:
  const sound = new Audio.Sound();
  sound.setOnPlaybackStatusUpdate(onPlaybackStatusUpdate);
  await sound.loadAsync(source, initialStatus, downloadFirst);
  ```

  | Parameter                | Type                                       | Description                                                                                                                                                                                                                                                                                                                                  |
  | ------------------------ | ------------------------------------------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
  | `source`                 | AVPlaybackSource                           | The source of the sound. See the [AV documentation](https://docs.expo.dev/versions/latest/sdk/av/#playback-api) for details on the possible `source` values.                                                                                                                                                                                 |
  | `initialStatus`          | AVPlaybackStatusToSet                      | The initial intended `PlaybackStatusToSet` of the sound, whose values will override the default initial playback status.<br>This value defaults to `{}` if no parameter is passed. See the [AV documentation](https://docs.expo.dev/versions/latest/sdk/av) for details on `PlaybackStatusToSet` and the default<br>initial playback status. |
  | `onPlaybackStatusUpdate` | null \| (status: AVPlaybackStatus) => void | A function taking a single parameter `PlaybackStatus`. This value defaults to `null` if no parameter is passed.<br>See the [AV documentation](https://docs.expo.dev/versions/latest/sdk/av) for details on the functionality provided by `onPlaybackStatusUpdate`                                                                            |
  | `downloadFirst`          | boolean                                    | If set to true, the system will attempt to download the resource to the device before loading. This value defaults to `true`.<br>Note that at the moment, this will only work for `source`s of the form `require('path/to/file')` or `Asset` objects.                                                                                        |

  Returns: A `Promise` that is rejected if creation failed, or fulfilled with the `SoundObject` if creation succeeded.
  Example:

  ```ts
  try {
    const { sound: soundObject, status } = await Audio.Sound.createAsync(require("./assets/sounds/hello.mp3"), {
      shouldPlay: true,
    });
    // Your sound is playing!
  } catch (error) {
    // An error occurred!
  }
  ```

### Hooks

#### usePermissions (_Function_)

Check or request permissions to record audio.
This uses both `requestPermissionAsync` and `getPermissionsAsync` to interact with the permissions.

- `usePermissions(options?: PermissionHookOptions<object>): [null | PermissionResponse, RequestPermissionMethod<PermissionResponse>, GetPermissionMethod<PermissionResponse>]`
  Check or request permissions to record audio.
  This uses both `requestPermissionAsync` and `getPermissionsAsync` to interact with the permissions.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `options` _(optional)_ | PermissionHookOptions<object> | - |
  Example:
  ```ts
  const [permissionResponse, requestPermission] = Audio.usePermissions();
  ```

### Audio Methods

#### getPermissionsAsync (_Function_)

- `getPermissionsAsync(): Promise<PermissionResponse>`
  Checks user's permissions for audio recording.
  Available on platforms: android, ios
  Returns: A promise that resolves to an object of type `PermissionResponse`.

#### requestPermissionsAsync (_Function_)

- `requestPermissionsAsync(): Promise<PermissionResponse>`
  Asks the user to grant permissions for audio recording.
  Available on platforms: android, ios
  Returns: A promise that resolves to an object of type `PermissionResponse`.

#### setAudioModeAsync (_Function_)

- `setAudioModeAsync(partialMode: Partial<AudioMode>): Promise<void>`
  We provide this API to customize the audio experience on iOS and Android.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `partialMode` | Partial<AudioMode> | - |
  Returns: A `Promise` that will reject if the audio mode could not be enabled for the device.

#### setIsEnabledAsync (_Function_)

- `setIsEnabledAsync(value: boolean): Promise<void>`
  Audio is enabled by default, but if you want to write your own Audio API in a bare workflow app, you might want to disable the Audio API.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `value` | boolean | `true` enables Audio, and `false` disables it. |
  Returns: A `Promise` that will reject if audio playback could not be enabled for the device.

### Types

#### AudioChannel (_Type_)

| Property | Type     | Description                                                                 |
| -------- | -------- | --------------------------------------------------------------------------- |
| `frames` | number[] | All samples for this specific Audio Channel in PCM Buffer format (-1 to 1). |

#### AudioMode (_Type_)

| Property                     | Type                    | Description                                                                                                                                                                                                                                                                                                                                                                                                    |
| ---------------------------- | ----------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `allowsRecordingIOS`         | boolean                 | A boolean selecting if recording is enabled on iOS.<br>> When this flag is set to `true`, playback may be routed to the phone earpiece instead of to the speaker. Set it back to `false` after stopping recording to reenable playback through the speaker. Default: `false`                                                                                                                                   |
| `interruptionModeAndroid`    | InterruptionModeAndroid | An enum selecting how your experience's audio should interact with the audio from other apps on Android.                                                                                                                                                                                                                                                                                                       |
| `interruptionModeIOS`        | InterruptionModeIOS     | An enum selecting how your experience's audio should interact with the audio from other apps on iOS.                                                                                                                                                                                                                                                                                                           |
| `playsInSilentModeIOS`       | boolean                 | A boolean selecting if your experience's audio should play in silent mode on iOS. Default: `false`                                                                                                                                                                                                                                                                                                             |
| `playThroughEarpieceAndroid` | boolean                 | A boolean selecting if the audio is routed to earpiece on Android. Default: `false`                                                                                                                                                                                                                                                                                                                            |
| `shouldDuckAndroid`          | boolean                 | A boolean selecting if your experience's audio should automatically be lowered in volume ("duck") if audio from another<br>app interrupts your experience. If `false`, audio from other apps will pause your audio. Default: `true`                                                                                                                                                                            |
| `staysActiveInBackground`    | boolean                 | A boolean selecting if the audio session (playback or recording) should stay active even when the app goes into background.<br>> This is not available in Expo Go for iOS, it will only work in standalone apps.<br>> To enable it for standalone apps, [follow the instructions below](#playing-or-recording-audio-in-background)<br>> to add `UIBackgroundModes` to your app configuration. Default: `false` |

#### AudioSample (_Type_)

Object passed to the `onAudioSampleReceived` function. Represents a single sample from an audio source.
The sample contains all frames (PCM Buffer values) for each channel of the audio, so if the audio is _stereo_ (interleaved),
there will be two channels, one for left and one for right audio.
| Property | Type | Description |
| --- | --- | --- |
| `channels` | AudioChannel[] | An array representing the data from each channel in PCM Buffer format. Array elements are objects in the following format: `{ frames: number[] }`,<br>where each frame is a number in PCM Buffer format (`-1` to `1` range). |
| `timestamp` | number | A number representing the timestamp of the current sample in seconds, relative to the audio track's timeline.<br>> **Known issue:** When using the `ExoPlayer` Android implementation, the timestamp is always `-1`. |

#### AudioSampleCallback (_Type_)

Type: (sample: AudioSample) => void | null

#### PermissionHookOptions (_Type_)

Type: PermissionHookBehavior & Options

#### PermissionResponse (_Type_)

An object obtained by permissions get and request functions.
| Property | Type | Description |
| --- | --- | --- |
| `canAskAgain` | boolean | Indicates if user can be asked again for specific permission.<br>If not, one should be directed to the Settings app<br>in order to enable/disable the permission. |
| `expires` | PermissionExpiration | Determines time when the permission expires. |
| `granted` | boolean | A convenience boolean that indicates if the permission is granted. |
| `status` | PermissionStatus | Determines the status of the permission. |

#### RecordingInput (_Type_)

Available on platforms: android, ios
| Property | Type | Description |
| --- | --- | --- |
| `name` | string | - |
| `type` | string | - |
| `uid` | string | - |

#### RecordingObject (_Type_)

Available on platforms: android, ios
| Property | Type | Description |
| --- | --- | --- |
| `recording` | Recording | The newly created and started `Recording` object. |
| `status` | RecordingStatus | The `RecordingStatus` of the `Recording` object. See the [AV documentation](https://docs.expo.dev/versions/latest/sdk/av) for further information. |

#### RecordingOptions (_Type_)

The recording extension, sample rate, bitrate, channels, format, encoder, etc. which can be customized by passing options to `prepareToRecordAsync()`.

We provide the following preset options for convenience, as used in the example above. See below for the definitions of these presets.

- `Audio.RecordingOptionsPresets.HIGH_QUALITY`
- `Audio.RecordingOptionsPresets.LOW_QUALITY`

We also provide the ability to define your own custom recording options, but **we recommend you use the presets,
as not all combinations of options will allow you to successfully `prepareToRecordAsync()`.**
You will have to test your custom options on iOS and Android to make sure it's working. In the future,
we will enumerate all possible valid combinations, but at this time, our goal is to make the basic use-case easy (with presets)
and the advanced use-case possible (by exposing all the functionality available on all supported platforms).
| Property | Type | Description |
| --- | --- | --- |
| `android` | RecordingOptionsAndroid | Recording options for the Android platform. |
| `ios` | RecordingOptionsIOS | Recording options for the iOS platform. |
| `isMeteringEnabled` _(optional)_ | boolean | A boolean that determines whether audio level information will be part of the status object under the "metering" key. |
| `keepAudioActiveHint` _(optional)_ | boolean | A boolean that hints to keep the audio active after `prepareToRecordAsync` completes.<br>Setting this value can improve the speed at which the recording starts. Only set this value to `true` when you call `startAsync`<br>immediately after `prepareToRecordAsync`. This value is automatically set when using `Audio.recording.createAsync()`. |
| `web` | RecordingOptionsWeb | Recording options for the Web platform. |

#### RecordingOptionsAndroid (_Type_)

Available on platform: android
| Property | Type | Description |
| --- | --- | --- |
| `audioEncoder` | AndroidAudioEncoder \| number | The desired audio encoder. See the [`AndroidAudioEncoder`](#androidaudioencoder) enum for all valid values. |
| `bitRate` _(optional)_ | number | The desired bit rate.<br><br>Note that `prepareToRecordAsync()` may perform additional checks on the parameter to make sure whether the specified<br>bit rate is applicable, and sometimes the passed bitRate will be clipped internally to ensure the audio recording<br>can proceed smoothly based on the capabilities of the platform. |
| `extension` | string | The desired file extension. Example valid values are `.3gp` and `.m4a`.<br>For more information, see the [Android docs](https://developer.android.com/guide/topics/media/media-formats)<br>for supported output formats. |
| `maxFileSize` _(optional)_ | number | The desired maximum file size in bytes, after which the recording will stop (but `stopAndUnloadAsync()` must still<br>be called after this point). |
| `numberOfChannels` _(optional)_ | number | The desired number of channels.<br><br>Note that `prepareToRecordAsync()` may perform additional checks on the parameter to make sure whether the specified<br>number of audio channels are applicable. |
| `outputFormat` | AndroidOutputFormat \| number | The desired file format. See the [`AndroidOutputFormat`](#androidoutputformat) enum for all valid values. |
| `sampleRate` _(optional)_ | number | The desired sample rate.<br><br>Note that the sampling rate depends on the format for the audio recording, as well as the capabilities of the platform.<br>For instance, the sampling rate supported by AAC audio coding standard ranges from 8 to 96 kHz,<br>the sampling rate supported by AMRNB is 8kHz, and the sampling rate supported by AMRWB is 16kHz.<br>Please consult with the related audio coding standard for the supported audio sampling rate. |

#### RecordingOptionsIOS (_Type_)

Available on platform: ios
| Property | Type | Description |
| --- | --- | --- |
| `audioQuality` | IOSAudioQuality \| number | The desired audio quality. See the [`IOSAudioQuality`](#iosaudioquality) enum for all valid values. |
| `bitDepthHint` _(optional)_ | number | The desired bit depth hint. |
| `bitRate` | number | The desired bit rate. |
| `bitRateStrategy` _(optional)_ | number | The desired bit rate strategy. See the next section for an enumeration of all valid values of `bitRateStrategy`. |
| `extension` | string | The desired file extension. |
| `linearPCMBitDepth` _(optional)_ | number | The desired PCM bit depth. |
| `linearPCMIsBigEndian` _(optional)_ | boolean | A boolean describing if the PCM data should be formatted in big endian. |
| `linearPCMIsFloat` _(optional)_ | boolean | A boolean describing if the PCM data should be encoded in floating point or integral values. |
| `numberOfChannels` | number | The desired number of channels. |
| `outputFormat` _(optional)_ | string \| IOSOutputFormat \| number | The desired file format. See the [`IOSOutputFormat`](#iosoutputformat) enum for all valid values. |
| `sampleRate` | number | The desired sample rate. |

#### RecordingOptionsWeb (_Type_)

| Property                     | Type   | Description |
| ---------------------------- | ------ | ----------- |
| `bitsPerSecond` _(optional)_ | number | -           |
| `mimeType` _(optional)_      | string | -           |

#### RecordingStatus (_Type_)

| Property                             | Type           | Description                                                                                                                                                                                                                                                                                        |
| ------------------------------------ | -------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `canRecord`                          | boolean        | A boolean describing if the `Recording` can initiate the recording. Available on platforms: android, ios                                                                                                                                                                                           |
| `durationMillis`                     | number         | The current duration of the recorded audio or the final duration is the recording has been stopped. Available on platforms: android, ios                                                                                                                                                           |
| `isDoneRecording`                    | boolean        | A boolean describing if the `Recording` has been stopped. Available on platforms: android, ios                                                                                                                                                                                                     |
| `isRecording`                        | boolean        | A boolean describing if the `Recording` is currently recording. Available on platforms: android, ios                                                                                                                                                                                               |
| `mediaServicesDidReset` _(optional)_ | boolean        | A boolean indicating whether media services were reset during recording. This may occur if the active input ceases to be available<br>during recording.<br><br>For example: airpods are the active input and they run out of batteries during recording. Available on platform: ios                |
| `metering` _(optional)_              | number         | A number that's the most recent reading of the loudness in dB. The value ranges from `–160` dBFS, indicating minimum power,<br>to `0` dBFS, indicating maximum power. Present or not based on Recording options. See `RecordingOptions` for more information. Available on platforms: android, ios |
| `uri` _(optional)_                   | string \| null | -                                                                                                                                                                                                                                                                                                  |

#### SoundObject (_Type_)

| Property | Type             | Description                                                                                                                                   |
| -------- | ---------------- | --------------------------------------------------------------------------------------------------------------------------------------------- |
| `sound`  | Sound            | The newly created and loaded `Sound` object.                                                                                                  |
| `status` | AVPlaybackStatus | The `PlaybackStatus` of the `Sound` object. See the [AV documentation](https://docs.expo.dev/versions/latest/sdk/av) for further information. |

### Constants

#### RecordingOptionsPresets (_Constant_)

Constant which contains definitions of the two preset examples of `RecordingOptions`, as implemented in the Audio SDK.

# `HIGH_QUALITY`

```ts
RecordingOptionsPresets.HIGH_QUALITY = {
  isMeteringEnabled: true,
  android: {
    extension: ".m4a",
    outputFormat: AndroidOutputFormat.MPEG_4,
    audioEncoder: AndroidAudioEncoder.AAC,
    sampleRate: 44100,
    numberOfChannels: 2,
    bitRate: 128000,
  },
  ios: {
    extension: ".m4a",
    outputFormat: IOSOutputFormat.MPEG4AAC,
    audioQuality: IOSAudioQuality.MAX,
    sampleRate: 44100,
    numberOfChannels: 2,
    bitRate: 128000,
    linearPCMBitDepth: 16,
    linearPCMIsBigEndian: false,
    linearPCMIsFloat: false,
  },
  web: {
    mimeType: "audio/webm",
    bitsPerSecond: 128000,
  },
};
```

# `LOW_QUALITY`

```ts
RecordingOptionsPresets.LOW_QUALITY = {
  isMeteringEnabled: true,
  android: {
    extension: ".3gp",
    outputFormat: AndroidOutputFormat.THREE_GPP,
    audioEncoder: AndroidAudioEncoder.AMR_NB,
    sampleRate: 44100,
    numberOfChannels: 2,
    bitRate: 128000,
  },
  ios: {
    extension: ".caf",
    audioQuality: IOSAudioQuality.MIN,
    sampleRate: 44100,
    numberOfChannels: 2,
    bitRate: 128000,
    linearPCMBitDepth: 16,
    linearPCMIsBigEndian: false,
    linearPCMIsFloat: false,
  },
  web: {
    mimeType: "audio/webm",
    bitsPerSecond: 128000,
  },
};
```

- `RecordingOptionsPresets` (Record<string, RecordingOptions>) — Constant which contains definitions of the two preset examples of `RecordingOptions`, as implemented in the Audio SDK.

# `HIGH_QUALITY`

```ts
RecordingOptionsPresets.HIGH_QUALITY = {
  isMeteringEnabled: true,
  android: {
    extension: ".m4a",
    outputFormat: AndroidOutputFormat.MPEG_4,
    audioEncoder: AndroidAudioEncoder.AAC,
    sampleRate: 44100,
    numberOfChannels: 2,
    bitRate: 128000,
  },
  ios: {
    extension: ".m4a",
    outputFormat: IOSOutputFormat.MPEG4AAC,
    audioQuality: IOSAudioQuality.MAX,
    sampleRate: 44100,
    numberOfChannels: 2,
    bitRate: 128000,
    linearPCMBitDepth: 16,
    linearPCMIsBigEndian: false,
    linearPCMIsFloat: false,
  },
  web: {
    mimeType: "audio/webm",
    bitsPerSecond: 128000,
  },
};
```

# `LOW_QUALITY`

````ts
RecordingOptionsPresets.LOW_QUALITY = {
  isMeteringEnabled: true,
  android: {
    extension: '.3gp',
    outputFormat: AndroidOutputFormat.THREE_GPP,
    audioEncoder: AndroidAudioEncoder.AMR_NB,
    sampleRate: 44100,
    numberOfChannels: 2,
    bitRate: 128000,
  },
  ios: {
    extension: '.caf',
    audioQuality: IOSAudioQuality.MIN,
    sampleRate: 44100,
    numberOfChannels: 2,
    bitRate: 128000,
    linearPCMBitDepth: 16,
    linearPCMIsBigEndian: false,
    linearPCMIsFloat: false,
  },
  web: {
    mimeType: 'audio/webm',
    bitsPerSecond: 128000,
  },
};
```  = ...

### Enums

#### AndroidAudioEncoder (*Enum*)
Defines the audio encoding.
Available on platform: android
#### Members
- `AAC` — AAC Low Complexity (AAC-LC) audio codec.
- `AAC_ELD` — Enhanced Low Delay AAC (AAC-ELD) audio codec.
- `AMR_NB` — AMR (Narrowband) audio codec.
- `AMR_WB` — AMR (Wideband) audio codec.
- `DEFAULT`
- `HE_AAC` — High Efficiency AAC (HE-AAC) audio codec.

#### AndroidOutputFormat (*Enum*)
Defines the output format.
Available on platform: android
#### Members
- `AAC_ADIF`
- `AAC_ADTS` — AAC ADTS file format.
- `AMR_NB` — AMR NB file format.
- `AMR_WB` — AMR WB file format.
- `DEFAULT`
- `MPEG_4` — MPEG4 media file format.
- `MPEG2TS` — H.264/AAC data encapsulated in MPEG2/TS.
- `RTP_AVP`
- `THREE_GPP` — 3GPP media file format.
- `WEBM` — VP8/VORBIS data in a WEBM container.

#### InterruptionModeAndroid (*Enum*)
Available on platform: android
#### Members
- `DoNotMix` — If this option is set, your experience's audio interrupts audio from other apps.
- `DuckOthers` — **This is the default option.** If this option is set, your experience's audio lowers the volume ("ducks") of audio from other apps while your audio plays.

#### InterruptionModeIOS (*Enum*)
Available on platform: ios
#### Members
- `DoNotMix` — If this option is set, your experience's audio interrupts audio from other apps.
- `DuckOthers` — If this option is set, your experience's audio lowers the volume ("ducks") of audio from other apps while your audio plays.
- `MixWithOthers` — **This is the default option.** If this option is set, your experience's audio is mixed with audio playing in background apps.

#### IOSAudioQuality (*Enum*)
Available on platform: ios
#### Members
- `HIGH`
- `LOW`
- `MAX`
- `MEDIUM`
- `MIN`

#### IOSBitRateStrategy (*Enum*)
Available on platform: ios
#### Members
- `CONSTANT`
- `LONG_TERM_AVERAGE`
- `VARIABLE`
- `VARIABLE_CONSTRAINED`

#### IOSOutputFormat (*Enum*)
> **Note:** Not all of the iOS formats included in this list of constants are currently supported by iOS,
> in spite of appearing in the Apple source code. For an accurate list of formats supported by iOS, see
> [Core Audio Codecs](https://developer.apple.com/library/content/documentation/MusicAudio/Conceptual/CoreAudioOverview/CoreAudioEssentials/CoreAudioEssentials.html)
> and [iPhone Audio File Formats](https://developer.apple.com/library/content/documentation/MusicAudio/Conceptual/CoreAudioOverview/CoreAudioEssentials/CoreAudioEssentials.html).
Available on platform: ios
#### Members
- `60958AC3`
- `AC3`
- `AES3`
- `ALAW`
- `AMR`
- `AMR_WB`
- `APPLEIMA4`
- `APPLELOSSLESS`
- `AUDIBLE`
- `DVIINTELIMA`
- `ENHANCEDAC3`
- `ILBC`
- `LINEARPCM`
- `MACE3`
- `MACE6`
- `MICROSOFTGSM`
- `MPEG4AAC`
- `MPEG4AAC_ELD`
- `MPEG4AAC_ELD_SBR`
- `MPEG4AAC_ELD_V2`
- `MPEG4AAC_HE`
- `MPEG4AAC_HE_V2`
- `MPEG4AAC_LD`
- `MPEG4AAC_SPATIAL`
- `MPEG4CELP`
- `MPEG4HVXC`
- `MPEG4TWINVQ`
- `MPEGLAYER1`
- `MPEGLAYER2`
- `MPEGLAYER3`
- `QDESIGN`
- `QDESIGN2`
- `QUALCOMM`
- `ULAW`

#### PermissionStatus (*Enum*)
#### Members
- `DENIED` — User has denied the permission.
- `GRANTED` — User has granted the permission.
- `UNDETERMINED` — User hasn't granted or denied the permission yet.

#### PitchCorrectionQuality (*Enum*)
Check [official Apple documentation](https://developer.apple.com/documentation/avfoundation/audio_settings/time_pitch_algorithm_settings) for more information.
#### Members
- `High` — Equivalent to `AVAudioTimePitchAlgorithmSpectral`.
- `Low` — Equivalent to `AVAudioTimePitchAlgorithmLowQualityZeroLatency`.
- `Medium` — Equivalent to `AVAudioTimePitchAlgorithmTimeDomain`.

## Unified API

The rest of the API on the `Sound.Audio` is the same as the API for `Video` component `ref`. See the [AV documentation](av/#playback) for more information.
````
