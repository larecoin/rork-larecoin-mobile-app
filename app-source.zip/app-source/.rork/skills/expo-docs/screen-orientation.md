# ScreenOrientation

_A universal library for managing a device's screen orientation._

Available on platforms android, ios, web

Screen Orientation is defined as the orientation in which graphics are painted on the device. For example, the figure below has a device in a vertical and horizontal physical orientation, but a portrait screen orientation. For physical device orientation, see the orientation section of [Device Motion](devicemotion.mdx).

[Portrait orientation in different physical orientations.](https://docs.expo.dev/static/images/screen-orientation-portrait.jpg)

On both Android and iOS platforms, changes to the screen orientation will override any system settings or user preferences. On Android, it is possible to change the screen orientation while taking the user's preferred orientation into account. On iOS, user and system settings are not accessible by the application and any changes to the screen orientation will override existing settings.

> Web has [limited support](https://caniuse.com/#feat=deviceorientation).

## Installation

```bash
$ bunx expo install expo-screen-orientation
```

If you are installing this in an existing React Native app, make sure to install `expo` in your project.

### Warning

Apple added support for _split view_ mode to iPads in iOS 9. This changed how the screen orientation is handled by the system. To put the matter shortly, for iOS, your iPad is always in landscape mode unless you open two applications side by side. To be able to lock screen orientation using this module you will need to disable support for this feature. For more information about the _split view_ mode, check out [the official Apple documentation](https://support.apple.com/en-us/HT207582).

## Configuration in app config

You can configure `expo-screen-orientation` using its built-in [config plugin](https://docs.expo.dev/config-plugins/introduction/) if you use config plugins in your project ([Continuous Native Generation (CNG)](https://docs.expo.dev/workflow/continuous-native-generation/)). The plugin allows you to configure various properties that cannot be set at runtime and require building a new app binary to take effect. If your app does **not** use CNG, then you'll need to manually configure the library.

```json app.json
{
  "expo": {
    "ios": {
      "requireFullScreen": true
    },
    "plugins": [
      [
        "expo-screen-orientation",
        {
          "initialOrientation": "DEFAULT"
        }
      ]
    ]
  }
}
```

### Configurable properties

| Name                 | Default     | Description                                                                                                                                                                             |
| -------------------- | ----------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `initialOrientation` | `undefined` | Only for: ios. Sets the iOS initial screen orientation. Possible values: `DEFAULT`, `ALL`, `PORTRAIT`, `PORTRAIT_UP`, `PORTRAIT_DOWN`, `LANDSCAPE`, `LANDSCAPE_LEFT`, `LANDSCAPE_RIGHT` |

<ConfigReactNative>

1. Open the **ios** directory in Xcode with `xed ios`. If you don't have the directory, run `bunx expo prebuild -p ios` to generate one.
2. Tick the `Requires Full Screen` checkbox in Xcode. It should be located under **Project Target** > **General** > **Deployment Info**.

</ConfigReactNative>

## API

```js
import * as ScreenOrientation from "expo-screen-orientation";
```

## API: expo-screen-orientation

### ScreenOrientation Methods

#### getOrientationAsync (_Function_)

- `getOrientationAsync(): Promise<Orientation>`
  Gets the current screen orientation.
  Returns: Returns a promise that fulfils with an [`Orientation`](#orientation)
  value that reflects the current screen orientation.

#### getOrientationLockAsync (_Function_)

- `getOrientationLockAsync(): Promise<OrientationLock>`
  Gets the current screen orientation lock type.
  Returns: Returns a promise which fulfils with an [`OrientationLock`](#orientationlock)
  value.

#### getPlatformOrientationLockAsync (_Function_)

- `getPlatformOrientationLockAsync(): Promise<PlatformOrientationInfo>`
  Gets the platform specific screen orientation lock type.
  Returns: Returns a promise which fulfils with a [`PlatformOrientationInfo`](#platformorientationinfo)
  value.

#### lockAsync (_Function_)

- `lockAsync(orientationLock: OrientationLock): Promise<void>`
  Lock the screen orientation to a particular `OrientationLock`.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `orientationLock` | OrientationLock | The orientation lock to apply. See the [`OrientationLock`](#orientationlock)<br>enum for possible values. |
  Returns: Returns a promise with `void` value, which fulfils when the orientation is set.
  Example:
  ```ts
  async function changeScreenOrientation() {
    await ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.LANDSCAPE_LEFT);
  }
  ```

#### lockPlatformAsync (_Function_)

- `lockPlatformAsync(options: PlatformOrientationInfo): Promise<void>`
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `options` | PlatformOrientationInfo | The platform specific lock to apply. See the [`PlatformOrientationInfo`](#platformorientationinfo)<br>object type for the different platform formats. |
  Returns: Returns a promise with `void` value, resolving when the orientation is set and rejecting
  if an invalid option or value is passed.

#### supportsOrientationLockAsync (_Function_)

- `supportsOrientationLockAsync(orientationLock: OrientationLock): Promise<boolean>`
  Returns whether the [`OrientationLock`](#orientationlock) policy is supported on
  the device.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `orientationLock` | OrientationLock | - |
  Returns: Returns a promise that resolves to a `boolean` value that reflects whether or not the
  orientationLock is supported.

#### unlockAsync (_Function_)

- `unlockAsync(): Promise<void>`
  Sets the screen orientation back to the `OrientationLock.DEFAULT` policy.
  Returns: Returns a promise with `void` value, which fulfils when the orientation is set.

### Event Subscriptions

#### addOrientationChangeListener (_Function_)

- `addOrientationChangeListener(listener: OrientationChangeListener): EventSubscription`
  Invokes the `listener` function when the screen orientation changes from `portrait` to `landscape`
  or from `landscape` to `portrait`. For example, it won't be invoked when screen orientation
  change from `portrait up` to `portrait down`, but it will be called when there was a change from
  `portrait up` to `landscape left`.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `listener` | OrientationChangeListener | Each orientation update will pass an object with the new [`OrientationChangeEvent`](#orientationchangeevent)<br>to the listener. |

#### removeOrientationChangeListener (_Function_)

- `removeOrientationChangeListener(subscription: EventSubscription)`
  Unsubscribes the listener associated with the `Subscription` object from all orientation change
  updates.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `subscription` | EventSubscription | A subscription object that manages the updates passed to a listener function<br>on an orientation change. |

#### removeOrientationChangeListeners (_Function_)

- `removeOrientationChangeListeners()`
  Removes all listeners subscribed to orientation change updates.

### Interfaces

#### Subscription (_Interface_)

A subscription object that allows to conveniently remove an event listener from the emitter.

### Types

#### OrientationChangeEvent (_Type_)

| Property          | Type                  | Description                                        |
| ----------------- | --------------------- | -------------------------------------------------- |
| `orientationInfo` | ScreenOrientationInfo | The current `ScreenOrientationInfo` of the device. |
| `orientationLock` | OrientationLock       | The current `OrientationLock` of the device.       |

#### OrientationChangeListener (_Type_)

Type: (event: OrientationChangeEvent) => void

#### PlatformOrientationInfo (_Type_)

| Property                                        | Type               | Description                                                                                                                                                                                                                                                                                                                                                            |
| ----------------------------------------------- | ------------------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `screenOrientationArrayIOS` _(optional)_        | Orientation[]      | An array of orientations to allow on the iOS platform. Available on platform: ios                                                                                                                                                                                                                                                                                      |
| `screenOrientationConstantAndroid` _(optional)_ | number             | A constant to set using the Android native [API](https://developer.android.com/reference/android/R.attr#screenOrientation).<br>For example, in order to set the lock policy to [unspecified](https://developer.android.com/reference/android/content/pm/ActivityInfo.html#SCREEN_ORIENTATION_UNSPECIFIED),<br>`-1` should be passed in. Available on platform: android |
| `screenOrientationLockWeb` _(optional)_         | WebOrientationLock | A web orientation lock to apply in the browser. Available on platform: web                                                                                                                                                                                                                                                                                             |

#### ScreenOrientationInfo (_Type_)

| Property                           | Type         | Description                                                                                                                                                             |
| ---------------------------------- | ------------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `horizontalSizeClass` _(optional)_ | SizeClassIOS | The [horizontal size class](https://developer.apple.com/documentation/uikit/uitraitcollection/1623508-horizontalsizeclass)<br>of the device. Available on platform: ios |
| `orientation`                      | Orientation  | The current orientation of the device.                                                                                                                                  |
| `verticalSizeClass` _(optional)_   | SizeClassIOS | The [vertical size class](https://developer.apple.com/documentation/uikit/uitraitcollection/1623513-verticalsizeclass)<br>of the device. Available on platform: ios     |

### Enums

#### Orientation (_Enum_)

#### Members

- `LANDSCAPE_LEFT` — Left landscape interface orientation.
- `LANDSCAPE_RIGHT` — Right landscape interface orientation.
- `PORTRAIT_DOWN` — Upside down portrait interface orientation.
- `PORTRAIT_UP` — Right-side up portrait interface orientation.
- `UNKNOWN` — An unknown screen orientation. For example, the device is flat, perhaps on a table.

#### OrientationLock (_Enum_)

An enum whose values can be passed to the [`lockAsync`](#screenorientationlockasyncorientationlock)
method.

> **Note:** `OrientationLock.ALL` and `OrientationLock.PORTRAIT` are invalid on devices which
> don't support `OrientationLock.PORTRAIT_DOWN`.

#### Members

- `ALL` — All four possible orientations
- `DEFAULT` — The default orientation. On iOS, this will allow all orientations except `Orientation.PORTRAIT_DOWN`.
  On Android, this lets the system decide the best orientation.
- `LANDSCAPE` — Any landscape orientation.
- `LANDSCAPE_LEFT` — Left landscape only.
- `LANDSCAPE_RIGHT` — Right landscape only.
- `OTHER` — A platform specific orientation. This is not a valid policy that can be applied in [`lockAsync`](#screenorientationlockasyncorientationlock).
- `PORTRAIT` — Any portrait orientation.
- `PORTRAIT_DOWN` — Upside down portrait only.
- `PORTRAIT_UP` — Right-side up portrait only.
- `UNKNOWN` — An unknown screen orientation lock. This is not a valid policy that can be applied in [`lockAsync`](#screenorientationlockasyncorientationlock).

#### SizeClassIOS (_Enum_)

Each iOS device has a default set of [size classes](https://developer.apple.com/documentation/uikit/uiuserinterfacesizeclass)
that you can use as a guide when designing your interface.

#### Members

- `COMPACT`
- `REGULAR`
- `UNKNOWN`

#### WebOrientation (_Enum_)

#### Members

- `LANDSCAPE_PRIMARY`
- `LANDSCAPE_SECONDARY`
- `PORTRAIT_PRIMARY`
- `PORTRAIT_SECONDARY`

#### WebOrientationLock (_Enum_)

An enum representing the lock policies that can be applied on the web platform, modelled after
the [W3C specification](https://w3c.github.io/screen-orientation/#dom-orientationlocktype).
These values can be applied through the [`lockPlatformAsync`](#screenorientationlockplatformasyncoptions)
method.

#### Members

- `ANY`
- `LANDSCAPE`
- `LANDSCAPE_PRIMARY`
- `LANDSCAPE_SECONDARY`
- `NATURAL`
- `PORTRAIT`
- `PORTRAIT_PRIMARY`
- `PORTRAIT_SECONDARY`
- `UNKNOWN`
