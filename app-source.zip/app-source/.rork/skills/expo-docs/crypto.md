# Crypto

_A universal library for crypto operations._

Available on platforms android, ios, tvos, web

`expo-crypto` enables you to hash data in an equivalent manner to the Node.js core `crypto` API.

## Installation

```bash
$ bunx expo install expo-crypto
```

If you are installing this in an existing React Native app, make sure to install `expo` in your project.

## Usage

```jsx
import { useEffect } from "react";
import { StyleSheet, View, Text } from "react-native";
import * as Crypto from "expo-crypto";

export default function App() {
  useEffect(() => {
    (async () => {
      const digest = await Crypto.digestStringAsync(Crypto.CryptoDigestAlgorithm.SHA256, "GitHub stars are neat 🌟");
      console.log("Digest: ", digest);
      /* Some crypto operation... */
    })();
  }, []);

  return (
    <View style={styles.container}>
      <Text>Crypto Module Example</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
});
```

## API

```js
import * as Crypto from "expo-crypto";
```

## API: expo-crypto

### Crypto Methods

#### digest (_Function_)

- `digest(algorithm: CryptoDigestAlgorithm, data: BufferSource): Promise<ArrayBuffer>`
  The `digest()` method of `Crypto` generates a digest of the supplied `TypedArray` of bytes `data` with the provided digest `algorithm`.
  A digest is a short fixed-length value derived from some variable-length input. **Cryptographic digests** should exhibit _collision-resistance_,
  meaning that it's very difficult to generate multiple inputs that have equal digest values.
  On web, this method can only be called from a secure origin (HTTPS) otherwise, an error will be thrown.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `algorithm` | CryptoDigestAlgorithm | The cryptographic hash function to use to transform a block of data into a fixed-size output. |
  | `data` | BufferSource | The value that will be used to generate a digest. |
  Returns: A Promise which fulfills with an ArrayBuffer representing the hashed input.
  Example:
  ```ts
  const array = new Uint8Array([1, 2, 3, 4, 5]);
  const digest = await Crypto.digest(Crypto.CryptoDigestAlgorithm.SHA512, array);
  console.log("Your digest: " + digest);
  ```

#### digestStringAsync (_Function_)

- `digestStringAsync(algorithm: CryptoDigestAlgorithm, data: string, options: CryptoDigestOptions): Promise<Digest>`
  The `digestStringAsync()` method of `Crypto` generates a digest of the supplied `data` string with the provided digest `algorithm`.
  A digest is a short fixed-length value derived from some variable-length input. **Cryptographic digests** should exhibit _collision-resistance_,
  meaning that it's very difficult to generate multiple inputs that have equal digest values.
  You can specify the returned string format as one of `CryptoEncoding`. By default, the resolved value will be formatted as a `HEX` string.
  On web, this method can only be called from a secure origin (HTTPS) otherwise, an error will be thrown.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `algorithm` | CryptoDigestAlgorithm | The cryptographic hash function to use to transform a block of data into a fixed-size output. |
  | `data` | string | The value that will be used to generate a digest. |
  | `options` | CryptoDigestOptions | Format of the digest string. Defaults to: `CryptoDigestOptions.HEX`. |
  Returns: Return a Promise which fulfills with a value representing the hashed input.
  Example:
  ```ts
  const digest = await Crypto.digestStringAsync(Crypto.CryptoDigestAlgorithm.SHA512, "🥓 Easy to Digest! 💙");
  ```

#### getRandomBytes (_Function_)

- `getRandomBytes(byteCount: number): Uint8Array`
  Generates completely random bytes using native implementations. The `byteCount` property
  is a `number` indicating the number of bytes to generate in the form of a `Uint8Array`.
  Falls back to `Math.random` during development to prevent issues with React Native Debugger.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `byteCount` | number | A number within the range from `0` to `1024`. Anything else will throw a `TypeError`. |
  Returns: An array of random bytes with the same length as the `byteCount`.

#### getRandomBytesAsync (_Function_)

- `getRandomBytesAsync(byteCount: number): Promise<Uint8Array>`
  Generates completely random bytes using native implementations. The `byteCount` property
  is a `number` indicating the number of bytes to generate in the form of a `Uint8Array`.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `byteCount` | number | A number within the range from `0` to `1024`. Anything else will throw a `TypeError`. |
  Returns: A promise that fulfills with an array of random bytes with the same length as the `byteCount`.

#### getRandomValues (_Function_)

- `getRandomValues(typedArray: T): T`
  The `getRandomValues()` method of `Crypto` fills a provided `TypedArray` with cryptographically secure random values.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `typedArray` | T | An integer based [`TypedArray`](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/TypedArray) to fill with cryptographically secure random values. It modifies the input array in place. |
  Returns: The input array filled with cryptographically secure random values.
  Example:
  ```ts
  const byteArray = new Uint8Array(16);
  Crypto.getRandomValues(byteArray);
  console.log("Your lucky bytes: " + byteArray);
  ```

#### randomUUID (_Function_)

- `randomUUID(): string`
  The `randomUUID()` method returns a unique identifier based on the V4 UUID spec (RFC4122).
  It uses cryptographically secure random values to generate the UUID.
  Returns: A string containing a newly generated UUIDv4 identifier
  Example:
  ```ts
  const UUID = Crypto.randomUUID();
  console.log("Your UUID: " + UUID);
  ```

### Types

#### CryptoDigestOptions (_Type_)

| Property   | Type           | Description                       |
| ---------- | -------------- | --------------------------------- |
| `encoding` | CryptoEncoding | Format the digest is returned in. |

#### Digest (_Type_)

Type: string

### Enums

#### CryptoDigestAlgorithm (_Enum_)

[`Cryptographic hash function`](https://developer.mozilla.org/en-US/docs/Glossary/Cryptographic_hash_function)

#### Members

- `MD2` — `128` bits.
- `MD4` — `128` bits.
- `MD5` — `128` bits.
- `SHA1` — `160` bits.
- `SHA256` — `256` bits. Collision Resistant.
- `SHA384` — `384` bits. Collision Resistant.
- `SHA512` — `512` bits. Collision Resistant.

#### CryptoEncoding (_Enum_)

#### Members

- `BASE64` — Has trailing padding. Does not wrap lines. Does not have a trailing newline.
- `HEX`

## Error codes

| Code                     | Description                                                                                  |
| ------------------------ | -------------------------------------------------------------------------------------------- |
| `ERR_CRYPTO_UNAVAILABLE` | **Web Only.** Access to the WebCrypto API is restricted to secure origins (localhost/https). |
| `ERR_CRYPTO_DIGEST`      | An invalid encoding type provided.                                                           |
