# Maps

_A library that provides access to Google Maps on Android and Apple Maps on iOS._

Available on platforms ios, android

> **important** **This library is currently in alpha and will frequently experience breaking changes.** It is not available in the Expo Go app &ndash; use [development builds](https://docs.expo.dev/develop/development-builds/introduction/) to try it out.

## Installation

```bash
$ bunx expo install expo-maps
```

If you are installing this in an existing React Native app, make sure to install `expo` in your project.

<br />

[Watch: Expo Maps Deep Dive](https://www.youtube.com/watch?v=jDCuaIQ9vd0)

## Configuration

Expo Maps provides access to the platform native map APIs on Android and iOS.

- **Apple Maps (available on <PlatformTag platform="ios" /> only)**. No additional configuration is required to use it after installing this package.
- **Google Maps (available on <PlatformTag platform="android" /> only)**. While Google provides a Google Maps SDK for iOS, Expo Maps supports it exclusively on Android. If you want to use Google Maps on iOS, you can look into using an [alternative library](https://reactnative.directory/) or [writing your own](https://docs.expo.dev/modules/overview/).

### Google Cloud API setup

**Before you can use Google Maps on Android**, you need to register a Google Cloud API project, enable the Maps SDK for Android, and add the associated configuration to your Expo project.

#### Set up Google Maps on Android

> If you have already registered a project for another Google service on Android, such as Google Sign In, you enable the **Maps SDK for Android** on your project and jump to step 4.

<Step label="1">
**Register a Google Cloud API project and enable the Maps SDK for Android**

- Open your browser to the [Google API Manager](https://console.developers.google.com/apis) and create a project.
- Once it's created, go to the project and enable the **Maps SDK for Android**.

</Step>

<Step label="2">
**Copy your app's SHA-1 certificate fingerprint**

<Tabs>
<Tab label="For Google Play Store">

- **If you are deploying your app to the Google Play Store**, you'll need to [upload your app binary to Google Play console](https://docs.expo.dev/submit/android/) at least once. This is required for Google to generate your app signing credentials.
- Go to the **[Google Play Console](https://play.google.com/console) > (your app) > Release > Setup > App integrity > App Signing**.
- Copy the value of **SHA-1 certificate fingerprint**.

</Tab>

<Tab label="For development builds">

- If you have already created a [development build](https://docs.expo.dev/develop/development-builds/introduction/), your project will be signed using a debug keystore.
- After the build is complete, go to your [project's dashboard](https://expo.dev/accounts/[username]/projects/[project-name]), then, under **Project settings** > click **Credentials**.
- Under **Application Identifiers**, click your project's package name and under **Android Keystore** copy the value of **SHA-1 Certificate Fingerprint**.

</Tab>

</Tabs>

</Step>

<Step label="3">
**Create an API key**

- Go to [Google Cloud Credential manager](https://console.cloud.google.com/apis/credentials) and click **Create Credentials**, then **API Key**.
- In the modal, click **Edit API key**.
- Under **Key restrictions** > **Application restrictions**, choose **Android apps**.
- Under **Restrict usage to your Android apps**, click **Add an item**.
- Add your `android.package` from **app.json** (for example: `com.company.myapp`) to the package name field.
- Then, add the **SHA-1 certificate fingerprint's** value from step 2.
- Click **Done** and then click **Save**.

</Step>

<Step label="4">
**Add the API key to your project**

- Copy your **API Key** into your **app.json** under the `android.config.googleMaps.apiKey` field.
- Create a new development build, and you can now use the Google Maps API on Android with `expo-maps`.

</Step>

## Permissions

To display the user's location on the map, you need to declare and request location permission beforehand. You can configure this using its built-in [config plugin](https://docs.expo.dev/config-plugins/introduction/) if you use config plugins in your project ([Continuous Native Generation (CNG)](https://docs.expo.dev/workflow/continuous-native-generation/)). The plugin allows you to configure various properties that cannot be set at runtime and require building a new app binary to take effect. If your app does **not** use CNG, then you'll need to manually configure the library.

```json app.json
{
  "expo": {
    "plugins": [
      [
        "expo-maps",
        {
          "requestLocationPermission": true,
          "locationPermission": "Allow $(PRODUCT_NAME) to use your location"
        }
      ]
    ]
  }
}
```

### Configurable properties

| Name                        | Default                                        | Description                                                                                                                                     |
| --------------------------- | ---------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------- |
| `requestLocationPermission` | `false`                                        | A boolean to add permissions to **AndroidManifest.xml** and **Info.plist**.                                                                     |
| `locationPermission`        | `"Allow $(PRODUCT_NAME) to use your location"` | Only for: ios. A string to set the [`NSLocationWhenInUseUsageDescription`](#permission-nslocationwheninuseusagedescription) permission message. |

## Usage

```tsx
import { AppleMaps, GoogleMaps } from "expo-maps";
import { Platform, Text } from "react-native";

export default function App() {
  if (Platform.OS === "ios") {
    return <AppleMaps.View style={{ flex: 1 }} />;
  } else if (Platform.OS === "android") {
    return <GoogleMaps.View style={{ flex: 1 }} />;
  } else {
    return <Text>Maps are only available on Android and iOS</Text>;
  }
}
```

## API

```js
import { AppleMaps, GoogleMaps } from "expo-maps";

// ApplesMaps.View and GoogleMaps.View are the React components
```

## API: expo-maps

### Hooks

#### useLocationPermissions (_Function_)

Check or request permissions to access the location.
This uses both `requestPermissionsAsync` and `getPermissionsAsync` to interact with the permissions.

- `useLocationPermissions(options?: PermissionHookOptions<object>): [null | PermissionResponse, RequestPermissionMethod<PermissionResponse>, GetPermissionMethod<PermissionResponse>]`
  Check or request permissions to access the location.
  This uses both `requestPermissionsAsync` and `getPermissionsAsync` to interact with the permissions.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `options` _(optional)_ | PermissionHookOptions<object> | - |
  Example:
  ```ts
  const [status, requestPermission] = useLocationPermissions();
  ```

### Maps Methods

#### AppleMapsView (_Function_)

Available on platform: ios

- `AppleMapsView(props: Omit<AppleMapsViewProps, 'ref'> & React.RefAttributes<AppleMapsViewType>): React.ReactNode`
  Available on platform: ios
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `props` | Omit<AppleMapsViewProps, 'ref'> & React.RefAttributes<AppleMapsViewType> | - |

#### getPermissionsAsync (_Function_)

- `getPermissionsAsync(): Promise<PermissionResponse>`
  Checks user's permissions for accessing location.
  Returns: A promise that fulfills with an object of type [`PermissionResponse`](#permissionresponse).

#### GoogleMapsView (_Function_)

Available on platform: android

- `GoogleMapsView(props: Omit<GoogleMapsViewProps, 'ref'> & React.RefAttributes<GoogleMapsViewType>): React.ReactNode`
  Available on platform: android
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `props` | Omit<GoogleMapsViewProps, 'ref'> & React.RefAttributes<GoogleMapsViewType> | - |

#### GoogleStreetView (_Function_)

- `GoogleStreetView(props: GoogleStreetViewProps): null | React.JSX.Element`
  Available on platform: android
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `props` | GoogleStreetViewProps | - |

#### requestPermissionsAsync (_Function_)

- `requestPermissionsAsync(): Promise<PermissionResponse>`
  Asks the user to grant permissions for location.
  Returns: A promise that fulfills with an object of type [`PermissionResponse`](#permissionresponse).

### Props

#### AppleMapsViewProps (_Type_)

Available on platform: ios
| Property | Type | Description |
| --- | --- | --- |
| `annotations` _(optional)_ | AppleMapsAnnotation[] | The array of annotations to display on the map. |
| `cameraPosition` _(optional)_ | CameraPosition | The initial camera position of the map. |
| `circles` _(optional)_ | AppleMapsCircle[] | The array of circles to display on the map. |
| `markers` _(optional)_ | AppleMapsMarker[] | The array of markers to display on the map. |
| `onCameraMove` _(optional)_ | (event: { bearing: number; coordinates: Coordinates; tilt: number; zoom: number }) => void | Lambda invoked when the map was moved by the user. |
| `onCircleClick` _(optional)_ | (event: AppleMapsCircle) => void | Lambda invoked when the circle is clicked Available on platform: ios 18.0+ |
| `onMapClick` _(optional)_ | (event: { coordinates: Coordinates }) => void | Lambda invoked when the user clicks on the map.<br>It won't be invoked if the user clicks on POI or a marker. |
| `onMarkerClick` _(optional)_ | (event: AppleMapsMarker) => void | Lambda invoked when the marker is clicked Available on platform: ios 18.0+ |
| `onPolygonClick` _(optional)_ | (event: AppleMapsPolygon) => void | Lambda invoked when the polygon is clicked Available on platform: ios 18.0+ |
| `onPolylineClick` _(optional)_ | (event: AppleMapsPolyline) => void | Lambda invoked when the polyline is clicked Available on platform: ios 18.0+ |
| `polygons` _(optional)_ | AppleMapsPolygon[] | The array of polygons to display on the map. |
| `polylines` _(optional)_ | AppleMapsPolyline[] | The array of polylines to display on the map. |
| `properties` _(optional)_ | AppleMapsProperties | The properties for the map. |
| `ref` _(optional)_ | React.Ref<AppleMapsViewType> | - |
| `style` _(optional)_ | StyleProp<ViewStyle> | - |
| `uiSettings` _(optional)_ | AppleMapsUISettings | The `MapUiSettings` to be used for UI-specific settings on the map. |

#### GoogleMapsViewProps (_Type_)

Available on platform: android
| Property | Type | Description |
| --- | --- | --- |
| `cameraPosition` _(optional)_ | CameraPosition | The initial camera position of the map. |
| `circles` _(optional)_ | GoogleMapsCircle[] | The array of circles to display on the map. |
| `colorScheme` _(optional)_ | GoogleMapsColorScheme | Defines the color scheme for the map. |
| `contentPadding` _(optional)_ | GoogleMapsContentPadding | The padding values used to signal that portions of the map around the edges may be obscured.<br>The map will move the Google logo, etc. to avoid overlapping the padding. |
| `mapOptions` _(optional)_ | GoogleMapsMapOptions | Defines configuration GoogleMapOptions for a GoogleMap |
| `markers` _(optional)_ | GoogleMapsMarker[] | The array of markers to display on the map. |
| `onCameraMove` _(optional)_ | (event: { bearing: number; coordinates: Coordinates; tilt: number; zoom: number }) => void | Lambda invoked when the map was moved by the user. |
| `onCircleClick` _(optional)_ | (event: GoogleMapsCircle) => void | Lambda invoked when the circle is clicked. |
| `onMapClick` _(optional)_ | (event: { coordinates: Coordinates }) => void | Lambda invoked when the user clicks on the map.<br>It won't be invoked if the user clicks on POI or a marker. |
| `onMapLoaded` _(optional)_ | () => void | Lambda invoked when the map is loaded. |
| `onMapLongClick` _(optional)_ | (event: { coordinates: Coordinates }) => void | Lambda invoked when the user long presses on the map. |
| `onMarkerClick` _(optional)_ | (event: GoogleMapsMarker) => void | Lambda invoked when the marker is clicked |
| `onPOIClick` _(optional)_ | (event: { coordinates: Coordinates; name: string }) => void | Lambda invoked when a POI is clicked. |
| `onPolygonClick` _(optional)_ | (event: GoogleMapsPolygon) => void | Lambda invoked when the polygon is clicked. |
| `onPolylineClick` _(optional)_ | (event: GoogleMapsPolyline) => void | Lambda invoked when the polyline is clicked. |
| `polygons` _(optional)_ | GoogleMapsPolygon[] | The array of polygons to display on the map. |
| `polylines` _(optional)_ | GoogleMapsPolyline[] | The array of polylines to display on the map. |
| `properties` _(optional)_ | GoogleMapsProperties | The properties for the map. |
| `ref` _(optional)_ | React.Ref<GoogleMapsViewType> | - |
| `style` _(optional)_ | StyleProp<ViewStyle> | - |
| `uiSettings` _(optional)_ | GoogleMapsUISettings | The `MapUiSettings` to be used for UI-specific settings on the map. |
| `userLocation` _(optional)_ | GoogleMapsUserLocation | User location, overrides default behavior. |

#### GoogleStreetViewProps (_Type_)

Available on platform: android
| Property | Type | Description |
| --- | --- | --- |
| `isPanningGesturesEnabled` _(optional)_ | boolean | - |
| `isStreetNamesEnabled` _(optional)_ | boolean | - |
| `isUserNavigationEnabled` _(optional)_ | boolean | - |
| `isZoomGesturesEnabled` _(optional)_ | boolean | - |
| `position` | StreetViewCameraPosition | - |
| `style` _(optional)_ | StyleProp<ViewStyle> | - |

### Types

#### AppleMapsAnnotation (_Type_)

Available on platform: ios
| Property | Type | Description |
| --- | --- | --- |
| `backgroundColor` _(optional)_ | string | The background color of the annotation. |
| `icon` _(optional)_ | SharedRef<'image'> | The custom icon to display in the annotation. |
| `text` _(optional)_ | string | The text to display in the annotation. |
| `textColor` _(optional)_ | string | The text color of the annotation. |

#### AppleMapsCircle (_Type_)

Available on platform: ios
| Property | Type | Description |
| --- | --- | --- |
| `center` | Coordinates | The coordinates of the circle. |
| `color` _(optional)_ | ProcessedColorValue \| string | The color of the circle. |
| `id` _(optional)_ | string | The unique identifier for the circle. This can be used to identify the clicked circle in the `onCircleClick` event. |
| `lineColor` _(optional)_ | ProcessedColorValue \| string | The color of the circle line. |
| `lineWidth` _(optional)_ | number | The width of the circle line. |
| `radius` | number | The radius of the circle (in meters). |
| `width` _(optional)_ | number | The width of the circle. |

#### AppleMapsMarker (_Type_)

Available on platform: ios
| Property | Type | Description |
| --- | --- | --- |
| `coordinates` _(optional)_ | Coordinates | The coordinates of the marker. |
| `id` _(optional)_ | string | The unique identifier for the marker. This can be used to identify the clicked marker in the `onMarkerClick` event. |
| `systemImage` _(optional)_ | string | The SF Symbol to display for the marker. |
| `tintColor` _(optional)_ | string | The tint color of the marker. |
| `title` _(optional)_ | string | The title of the marker, displayed in the callout when the marker is clicked. |

#### AppleMapsPointOfInterestCategories (_Type_)

Available on platform: ios
| Property | Type | Description |
| --- | --- | --- |
| `excluding` _(optional)_ | AppleMapPointOfInterestCategory[] | The POI categories to exclude.<br>To show all POIs, set this to an empty array. |
| `including` _(optional)_ | AppleMapPointOfInterestCategory[] | The POI categories to include.<br>To hide all POIs, set this to an empty array. |

#### AppleMapsPolygon (_Type_)

Available on platform: ios
| Property | Type | Description |
| --- | --- | --- |
| `color` _(optional)_ | ProcessedColorValue \| string | The color of the polygon. |
| `coordinates` | Coordinates[] | The coordinates of the circle. |
| `id` _(optional)_ | string | The unique identifier for the polygon. This can be used to identify the clicked polygon in the `onPolygonClick` event. |
| `lineColor` _(optional)_ | ProcessedColorValue \| string | The color of the polygon. |
| `lineWidth` _(optional)_ | number | The width of the polygon. |

#### AppleMapsPolyline (_Type_)

Available on platform: ios
| Property | Type | Description |
| --- | --- | --- |
| `color` _(optional)_ | ProcessedColorValue \| string | The color of the polyline. |
| `contourStyle` _(optional)_ | AppleMapsContourStyle | The style of the polyline. |
| `coordinates` | Coordinates[] | The coordinates of the polyline. |
| `id` _(optional)_ | string | The unique identifier for the polyline. This can be used to identify the clicked polyline in the `onPolylineClick` event. |
| `width` _(optional)_ | number | The width of the polyline. |

#### AppleMapsProperties (_Type_)

Available on platform: ios
| Property | Type | Description |
| --- | --- | --- |
| `elevation` _(optional)_ | AppleMapsMapStyleElevation | Values you use to determine whether a map renders elevation. |
| `emphasis` _(optional)_ | AppleMapsMapStyleEmphasis | Values that control how the framework emphasizes map features. |
| `isMyLocationEnabled` _(optional)_ | boolean | Whether the user location is shown on the map. Default: `false` |
| `isTrafficEnabled` _(optional)_ | boolean | Whether the traffic layer is enabled on the map. |
| `mapType` _(optional)_ | AppleMapsMapType | Defines which map type should be used. |
| `pointsOfInterest` _(optional)_ | AppleMapsPointOfInterestCategories | A structure you use to define points of interest to include or exclude on a map. |
| `polylineTapThreshold` _(optional)_ | number | The maximum distance in meters from a tap of a polyline for it to be considered a hit.<br>If the distance is greater than the threshold, the polyline is not considered a hit.<br>If a hit occurs, the `onPolylineClick` event will be triggered.<br>Defaults to 20 meters. |
| `selectionEnabled` _(optional)_ | boolean | If true, the user can select a location on the map to get more information. |

#### AppleMapsUISettings (_Type_)

Available on platform: ios
| Property | Type | Description |
| --- | --- | --- |
| `compassEnabled` _(optional)_ | boolean | Whether the compass is enabled on the map.<br>If enabled, the compass is only visible when the map is rotated. |
| `myLocationButtonEnabled` _(optional)_ | boolean | Whether the my location button is visible. |
| `scaleBarEnabled` _(optional)_ | boolean | Whether the scale bar is displayed when zooming. |
| `togglePitchEnabled` _(optional)_ | boolean | Whether the user is allowed to change the pitch type. |

#### AppleMapsViewType (_Type_)

Available on platform: ios
| Property | Type | Description |
| --- | --- | --- |
| `openLookAroundAsync` | (coordinates: Coordinates) => Promise<void> | Opens the look around view at specified coordinates. |
| `setCameraPosition` | (config: CameraPosition) => void | Update camera position.<br>Animation duration is not supported on iOS. |

#### CameraPosition (_Type_)

| Property                   | Type        | Description                                                                                     |
| -------------------------- | ----------- | ----------------------------------------------------------------------------------------------- |
| `coordinates` _(optional)_ | Coordinates | The middle point of the camera.                                                                 |
| `zoom` _(optional)_        | number      | The zoom level of the camera.<br>For some view sizes, lower zoom levels might not be available. |

#### Coordinates (_Type_)

| Property                 | Type   | Description                      |
| ------------------------ | ------ | -------------------------------- |
| `latitude` _(optional)_  | number | The latitude of the coordinate.  |
| `longitude` _(optional)_ | number | The longitude of the coordinate. |

#### GoogleMapsAnchor (_Type_)

Available on platform: android
| Property | Type | Description |
| --- | --- | --- |
| `x` | number | The normalized horizontal anchor point from 0.0 (left edge) to 1.0 (right edge). |
| `y` | number | The normalized vertical anchor point from 0.0 (top edge) to 1.0 (bottom edge). |

#### GoogleMapsCircle (_Type_)

Available on platform: android
| Property | Type | Description |
| --- | --- | --- |
| `center` | Coordinates | The coordinates of the circle. |
| `color` _(optional)_ | ProcessedColorValue \| string | The color of the circle. |
| `id` _(optional)_ | string | The unique identifier for the circle. This can be used to identify the clicked circle in the `onCircleClick` event. |
| `lineColor` _(optional)_ | ProcessedColorValue \| string | The color of the circle line. |
| `lineWidth` _(optional)_ | number | The width of the circle line. |
| `radius` | number | The radius of the circle. |

#### GoogleMapsContentPadding (_Type_)

Available on platform: android
| Property | Type | Description |
| --- | --- | --- |
| `bottom` _(optional)_ | number | The padding on the bottom side of the map. |
| `end` _(optional)_ | number | In LTR contexts, `end` will be applied along the right edge. In RTL contexts, `end` will correspond to the left edge. |
| `start` _(optional)_ | number | In LTR contexts, `start` will be applied along the left edge. In RTL contexts, `start` will correspond to the right edge. |
| `top` _(optional)_ | number | The padding on the top side of the map. |

#### GoogleMapsMapOptions (_Type_)

Available on platform: android
| Property | Type | Description |
| --- | --- | --- |
| `mapId` _(optional)_ | string | A map ID is a unique identifier that represents Google Map styling and configuration settings that are stored in Google Cloud. |

#### GoogleMapsMapStyleOptions (_Type_)

Available on platform: android
| Property | Type | Description |
| --- | --- | --- |
| `json` | string | The JSON string of the map style options. |

#### GoogleMapsMarker (_Type_)

Available on platform: android
| Property | Type | Description |
| --- | --- | --- |
| `anchor` _(optional)_ | GoogleMapsAnchor | The anchor used to position the anchor relative to its coordinates. Default: `bottom-center of the icon` |
| `coordinates` _(optional)_ | Coordinates | The coordinates of the marker. |
| `draggable` _(optional)_ | boolean | Whether the marker is draggable. |
| `icon` _(optional)_ | SharedRef<'image'> | The custom icon to display for the marker. |
| `id` _(optional)_ | string | The unique identifier for the marker. This can be used to identify the clicked marker in the `onMarkerClick` event. |
| `showCallout` _(optional)_ | boolean | Whether the callout should be shown when the marker is clicked. |
| `snippet` _(optional)_ | string | The snippet of the marker, displayed in the callout when the marker is clicked. |
| `title` _(optional)_ | string | The title of the marker, displayed in the callout when the marker is clicked. |
| `zIndex` _(optional)_ | number | The z-index to use for the marker. Default: `0` |

#### GoogleMapsPolygon (_Type_)

Available on platform: android
| Property | Type | Description |
| --- | --- | --- |
| `color` _(optional)_ | ProcessedColorValue \| string | The color of the polygon. |
| `coordinates` | Coordinates[] | The coordinates of the circle. |
| `id` _(optional)_ | string | The unique identifier for the polygon. This can be used to identify the clicked polygon in the `onPolygonClick` event. |
| `lineColor` _(optional)_ | ProcessedColorValue \| string | The color of the polygon. |
| `lineWidth` _(optional)_ | number | The width of the polygon. |

#### GoogleMapsPolyline (_Type_)

Available on platform: android
| Property | Type | Description |
| --- | --- | --- |
| `color` _(optional)_ | ProcessedColorValue \| string | The color of the polyline. |
| `coordinates` | Coordinates[] | The coordinates of the polyline. |
| `geodesic` _(optional)_ | boolean | Whether the polyline is geodesic. |
| `id` _(optional)_ | string | The unique identifier for the polyline. This can be used to identify the clicked polyline in the `onPolylineClick` event. |
| `width` _(optional)_ | number | The width of the polyline. |

#### GoogleMapsProperties (_Type_)

Available on platform: android
| Property | Type | Description |
| --- | --- | --- |
| `isBuildingEnabled` _(optional)_ | boolean | Whether the building layer is enabled on the map. |
| `isIndoorEnabled` _(optional)_ | boolean | Whether the indoor layer is enabled on the map. |
| `isMyLocationEnabled` _(optional)_ | boolean | Whether finding the user's location is enabled on the map. |
| `isTrafficEnabled` _(optional)_ | boolean | Whether the traffic layer is enabled on the map. |
| `mapStyleOptions` _(optional)_ | GoogleMapsMapStyleOptions | With style options you can customize the presentation of the standard Google map styles, changing the visual display of features like roads, parks, and other points of interest. |
| `mapType` _(optional)_ | GoogleMapsMapType | Defines which map type should be used. |
| `maxZoomPreference` _(optional)_ | number | The maximum zoom level for the map. |
| `minZoomPreference` _(optional)_ | number | The minimum zoom level for the map. |
| `selectionEnabled` _(optional)_ | boolean | If true, the user can select a location on the map to get more information. |

#### GoogleMapsUISettings (_Type_)

Available on platform: android
| Property | Type | Description |
| --- | --- | --- |
| `compassEnabled` _(optional)_ | boolean | Whether the compass is enabled on the map.<br>If enabled, the compass is only visible when the map is rotated. |
| `indoorLevelPickerEnabled` _(optional)_ | boolean | Whether the indoor level picker is enabled . |
| `mapToolbarEnabled` _(optional)_ | boolean | Whether the map toolbar is visible. |
| `myLocationButtonEnabled` _(optional)_ | boolean | Whether the my location button is visible. |
| `rotationGesturesEnabled` _(optional)_ | boolean | Whether rotate gestures are enabled. |
| `scaleBarEnabled` _(optional)_ | boolean | Whether the scale bar is displayed when zooming. |
| `scrollGesturesEnabled` _(optional)_ | boolean | Whether the scroll gestures are enabled. |
| `scrollGesturesEnabledDuringRotateOrZoom` _(optional)_ | boolean | Whether the scroll gestures are enabled during rotation or zoom. |
| `tiltGesturesEnabled` _(optional)_ | boolean | Whether the tilt gestures are enabled. |
| `togglePitchEnabled` _(optional)_ | boolean | Whether the user is allowed to change the pitch type. |
| `zoomControlsEnabled` _(optional)_ | boolean | Whether the zoom controls are visible. |
| `zoomGesturesEnabled` _(optional)_ | boolean | Whether the zoom gestures are enabled. |

#### GoogleMapsUserLocation (_Type_)

Available on platform: android
| Property | Type | Description |
| --- | --- | --- |
| `coordinates` | Coordinates | User location coordinates. |
| `followUserLocation` | boolean | Should the camera follow the users' location. |

#### GoogleMapsViewType (_Type_)

Available on platform: android
| Property | Type | Description |
| --- | --- | --- |
| `setCameraPosition` | (config: SetCameraPositionConfig) => void | Update camera position. |

#### SetCameraPositionConfig (_Type_)

Available on platform: android
| Property | Type | Description |
| --- | --- | --- |
| `duration` _(optional)_ | number | The duration of the animation in milliseconds. |

#### StreetViewCameraPosition (_Type_)

Available on platform: android
| Property | Type | Description |
| --- | --- | --- |
| `bearing` _(optional)_ | number | - |
| `coordinates` | Coordinates | - |
| `tilt` _(optional)_ | number | - |
| `zoom` _(optional)_ | number | - |

### Enums

#### AppleMapPointOfInterestCategory (_Enum_)

Available on platform: ios

#### Members

- `AIRPORT`
- `AMUSEMENT_PARK`
- `ANIMAL_SERVICE`
- `AQUARIUM`
- `ATM`
- `AUTOMOTIVE_REPAIR`
- `BAKERY`
- `BANK`
- `BASEBALL`
- `BASKETBALL`
- `BEACH`
- `BEAUTY`
- `BOWLING`
- `BREWERY`
- `CAFE`
- `CAMPGROUND`
- `CAR_RENTAL`
- `CASTLE`
- `CONVENTION_CENTER`
- `DISTILLERY`
- `EV_CHARGER`
- `FAIRGROUND`
- `FIRE_STATION`
- `FISHING`
- `FITNESS_CENTER`
- `FOOD_MARKET`
- `FORTRESS`
- `GAS_STATION`
- `GO_KART`
- `GOLF`
- `HIKING`
- `HOSPITAL`
- `HOTEL`
- `KAYAKING`
- `LANDMARK`
- `LAUNDRY`
- `LIBRARY`
- `MAILBOX`
- `MARINA`
- `MINI_GOLF`
- `MOVIE_THEATER`
- `MUSEUM`
- `MUSIC_VENUE`
- `NATIONAL_MONUMENT`
- `NATIONAL_PARK`
- `NIGHTLIFE`
- `PARK`
- `PARKING`
- `PHARMACY`
- `PLANETARIUM`
- `POLICE`
- `POST_OFFICE`
- `PUBLIC_TRANSPORT`
- `RESTAURANT`
- `RESTROOM`
- `ROCK_CLIMBING`
- `RV_PARK`
- `SCHOOL`
- `SKATE_PARK`
- `SKATING`
- `SKIING`
- `SOCCER`
- `SPA`
- `STADIUM`
- `STORE`
- `SURFING`
- `SWIMMING`
- `TENNIS`
- `THEATER`
- `UNIVERSITY`
- `VOLLEYBALL`
- `WINERY`
- `ZOO`

#### AppleMapsContourStyle (_Enum_)

The style of the polyline.
Available on platform: ios

#### Members

- `GEODESIC` — A geodesic line.
- `STRAIGHT` — A straight line.

#### AppleMapsMapStyleElevation (_Enum_)

Available on platform: ios

#### Members

- `AUTOMATIC` — The default elevation style, that renders a flat, 2D map.
- `FLAT` — A flat elevation style.
- `REALISTIC` — A value that renders a realistic, 3D map.

#### AppleMapsMapStyleEmphasis (_Enum_)

Available on platform: ios

#### Members

- `AUTOMATIC` — The default level of emphasis.
- `MUTED` — A muted emphasis style, that deemphasizes the map’s imagery.

#### AppleMapsMapType (_Enum_)

The type of map to display.
Available on platform: ios

#### Members

- `HYBRID` — A satellite image of the area with road and road name layers on top.
- `IMAGERY` — A satellite image of the area.
- `STANDARD` — A street map that shows the position of all roads and some road names.

#### GoogleMapsColorScheme (_Enum_)

Available on platform: android

#### Members

- `DARK`
- `FOLLOW_SYSTEM`
- `LIGHT`

#### GoogleMapsMapType (_Enum_)

The type of map to display.
Available on platform: android

#### Members

- `HYBRID` — Satellite imagery with roads and points of interest overlayed.
- `NORMAL` — Standard road map.
- `SATELLITE` — Satellite imagery.
- `TERRAIN` — Topographic data.

## Permissions

### Android

To show the user's location on the map, the `expo-maps` library requires the following permissions:

- `ACCESS_COARSE_LOCATION`: for approximate device location
- `ACCESS_FINE_LOCATION`: for precise device location

<AndroidPermissions
permissions={[
'ACCESS_COARSE_LOCATION',
'ACCESS_FINE_LOCATION',
'FOREGROUND_SERVICE',
'FOREGROUND_SERVICE_LOCATION',
'ACCESS_BACKGROUND_LOCATION',
]}
/>

### iOS

The following usage description keys are used by this library:

<IOSPermissions permissions={['NSLocationWhenInUseUsageDescription']} />
