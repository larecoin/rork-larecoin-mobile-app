# KeepAwake

_A React component that prevents the screen from sleeping when rendered._

Available on platforms android, ios, tvos, web

`expo-keep-awake` provides a React hook that prevents the screen from sleeping and a pair of functions to enable this behavior imperatively.

## Installation

```bash
$ bunx expo install expo-keep-awake
```

If you are installing this in an existing React Native app, make sure to install `expo` in your project.

## Usage

### Example: hook

```jsx
import { useKeepAwake } from "expo-keep-awake";
import React from "react";
import { Text, View } from "react-native";

export default function KeepAwakeExample() {
  /* @info As long as this component is mounted, the screen will not turn off from being idle. */
  useKeepAwake();
  /* @end */
  return (
    <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
      <Text>This screen will never sleep!</Text>
    </View>
  );
}
```

### Example: functions

```jsx
import { activateKeepAwake, deactivateKeepAwake } from "expo-keep-awake";
import React from "react";
import { Button, View } from "react-native";

export default class KeepAwakeExample extends React.Component {
  render() {
    return (
      <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
        <Button onPress={this._activate} title="Activate" />
        <Button onPress={this._deactivate} title="Deactivate" />
      </View>
    );
  }

  _activate = () => {
    /* @info Screen will remain on after called until <strong>deactivateKeepAwake()</strong> is called. */ activateKeepAwake(); /* @end */
    alert("Activated!");
  };

  _deactivate = () => {
    /* @info Deactivates KeepAwake, or does nothing if it was never activated. */ deactivateKeepAwake(); /* @end */
    alert("Deactivated!");
  };
}
```

## API

```js
import * as KeepAwake from "expo-keep-awake";
```

## API: expo-keep-awake

### Hooks

#### useKeepAwake (_Function_)

- `useKeepAwake(tag?: string, options?: KeepAwakeOptions)`
  A React hook to keep the screen awake for as long as the owner component is mounted.
  The optionally provided `tag` argument is used when activating and deactivating the keep-awake
  feature. If unspecified, an ID unique to the owner component is used. See the documentation for
  `activateKeepAwakeAsync` below to learn more about the `tag` argument.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `tag` _(optional)_ | string | Tag to lock screen sleep prevention. If not provided, an ID unique to the owner component is used. |
  | `options` _(optional)_ | KeepAwakeOptions | Additional options for the keep awake hook. |

### KeepAwake Methods

#### activateKeepAwake (_Function_)

- `activateKeepAwake(tag: string): Promise<void>`
  Prevents the screen from sleeping until `deactivateKeepAwake` is called with the same `tag` value.

  If the `tag` argument is specified, the screen will not sleep until you call `deactivateKeepAwake`
  with the same `tag` argument. When using multiple `tags` for activation you'll have to deactivate
  each one in order to re-enable screen sleep. If tag is unspecified, the default `tag` is used.

  Web support [is limited](https://caniuse.com/wake-lock).
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `tag` | string | Tag to lock screen sleep prevention. If not provided, the default tag is used. |

#### activateKeepAwakeAsync (_Function_)

- `activateKeepAwakeAsync(tag: string): Promise<void>`
  Prevents the screen from sleeping until `deactivateKeepAwake` is called with the same `tag` value.

  If the `tag` argument is specified, the screen will not sleep until you call `deactivateKeepAwake`
  with the same `tag` argument. When using multiple `tags` for activation you'll have to deactivate
  each one in order to re-enable screen sleep. If tag is unspecified, the default `tag` is used.

  Web support [is limited](https://caniuse.com/wake-lock).
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `tag` | string | Tag to lock screen sleep prevention. If not provided, the default tag is used. |

#### deactivateKeepAwake (_Function_)

- `deactivateKeepAwake(tag: string): Promise<void>`
  Releases the lock on screen-sleep prevention associated with the given `tag` value. If `tag`
  is unspecified, it defaults to the same default tag that `activateKeepAwake` uses.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `tag` | string | Tag to release the lock on screen sleep prevention. If not provided,<br>the default tag is used. |

#### isAvailableAsync (_Function_)

- `isAvailableAsync(): Promise<boolean>`
  Returns: `true` on all platforms except [unsupported web browsers](https://caniuse.com/wake-lock).

### Event Subscriptions

#### addListener (_Function_)

- `addListener(tagOrListener: string | KeepAwakeListener, listener?: KeepAwakeListener): EventSubscription`
  Observe changes to the keep awake timer.
  On web, this changes when navigating away from the active window/tab. No-op on native.
  Available on platform: web
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `tagOrListener` | string \| KeepAwakeListener | - |
  | `listener` _(optional)_ | KeepAwakeListener | - |
  Example:
  ```ts
  KeepAwake.addListener(({ state }) => {
    // ...
  });
  ```

### Types

#### KeepAwakeEvent (_Type_)

| Property | Type                | Description       |
| -------- | ------------------- | ----------------- |
| `state`  | KeepAwakeEventState | Keep awake state. |

#### KeepAwakeListener (_Type_)

Available on platform: web
Type: (event: KeepAwakeEvent) => void

#### KeepAwakeOptions (_Type_)

| Property                                  | Type              | Description                                                                                                                                                                         |
| ----------------------------------------- | ----------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `listener` _(optional)_                   | KeepAwakeListener | A callback that is invoked when the keep-awake state changes. Available on platform: web                                                                                            |
| `suppressDeactivateWarnings` _(optional)_ | boolean           | The call will throw an unhandled promise rejection on Android when the original Activity is dead or deactivated.<br>Set the value to `true` for suppressing the uncaught exception. |

### Constants

#### ExpoKeepAwakeTag (_Constant_)

Default tag, used when no tag has been specified in keep awake method calls.

- `ExpoKeepAwakeTag` ('ExpoKeepAwakeDefaultTag') — Default tag, used when no tag has been specified in keep awake method calls. = 'ExpoKeepAwakeDefaultTag'

### Enums

#### KeepAwakeEventState (_Enum_)

#### Members

- `RELEASE`
