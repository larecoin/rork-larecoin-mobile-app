# Battery

_A library that provides battery information for the physical device, as well as corresponding event listeners._

Available on platforms android, ios (device-only), web

`expo-battery` provides battery information for the physical device (such as battery level, whether or not the device is charging, and more) as well as corresponding event listeners.

## Installation

```bash
$ bunx expo install expo-battery
```

If you are installing this in an existing React Native app, make sure to install `expo` in your project.

## Usage

```jsx
import { useBatteryLevel } from "expo-battery";
import { StyleSheet, Text, View } from "react-native";

export default function App() {
  const batteryLevel = useBatteryLevel();

  return (
    <View style={styles.container}>
      <Text>Current Battery Level: {batteryLevel}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginTop: 15,
    alignItems: "center",
    justifyContent: "center",
  },
});
```

## API

```js
import * as Battery from "expo-battery";
```

## API: expo-battery

### Hooks

#### useBatteryLevel (_Function_)

- `useBatteryLevel(): number`
  Gets the device's battery level, as in [`getBatteryLevelAsync`](#getbatterylevelasync).
  Returns: The battery level of the device.
  Example:
  ```ts
  const batteryLevel = useBatteryLevel();
  ```

#### useBatteryState (_Function_)

- `useBatteryState(): BatteryState`
  Gets the device's battery state, as in [`getBatteryStateAsync`](#getbatterystateasync).
  Returns: The battery state of the device.
  Example:
  ```ts
  const batteryState = useBatteryState();
  ```

#### useLowPowerMode (_Function_)

- `useLowPowerMode(): boolean`
  Boolean that indicates if the device is in low power or power saver mode, as in [`isLowPowerModeEnabledAsync`](#islowpowermodeenabledasync).
  Returns: Returns a boolean indicating if the device is in low power mode.
  Example:
  ```ts
  const lowPowerMode = useLowPowerMode();
  ```

#### usePowerState (_Function_)

- `usePowerState(): PowerState`
  Gets the device's power state information, as in [`getPowerStateAsync`](#getpowerstateasync).
  Returns: Returns power state information.
  Example:
  ```ts
  const { lowPowerMode, batteryLevel, batteryState } = usePowerState();
  ```

### Methods

#### getBatteryLevelAsync (_Function_)

- `getBatteryLevelAsync(): Promise<number>`
  Gets the battery level of the device as a number between `0` and `1`, inclusive. If the device
  does not support retrieving the battery level, this method returns `-1`. On web, this method
  always returns `1`.
  Returns: A `Promise` that fulfils with a number between `0` and `1` representing the battery level,
  or `-1` if the device does not provide it.
  Example:
  ```ts
  await Battery.getBatteryLevelAsync();
  // 0.759999
  ```

#### getBatteryStateAsync (_Function_)

- `getBatteryStateAsync(): Promise<BatteryState>`
  Tells the battery's current state. On web, this always returns `BatteryState.UNKNOWN`.
  Returns: Returns a `Promise` which fulfills with a [`Battery.BatteryState`](#batterystate) enum
  value for whether the device is any of the four states.
  Example:
  ```ts
  await Battery.getBatteryStateAsync();
  // BatteryState.CHARGING
  ```

#### getPowerStateAsync (_Function_)

- `getPowerStateAsync(): Promise<PowerState>`
  Gets the power state of the device including the battery level, whether it is plugged in, and if
  the system is currently operating in Power Saver Mode (Android) or Low Power Mode (iOS). This
  method re-throws any errors that occur when retrieving any of the power-state information.
  Returns: Returns a `Promise` which fulfills with [`PowerState`](#powerstate) object.
  Example:
  ```ts
  await Battery.getPowerStateAsync();
  // {
  //   batteryLevel: 0.759999,
  //   batteryState: BatteryState.UNPLUGGED,
  //   lowPowerMode: true,
  // }
  ```

#### isAvailableAsync (_Function_)

- `isAvailableAsync(): Promise<boolean>`
  Resolves with whether the battery API is available on the current device. The value of this
  property is `true` on Android and physical iOS devices and `false` on iOS simulators. On web,
  it depends on whether the browser supports the web battery API.

#### isBatteryOptimizationEnabledAsync (_Function_)

- `isBatteryOptimizationEnabledAsync(): Promise<boolean>`
  Checks whether battery optimization is enabled for your application.
  If battery optimization is enabled for your app, background tasks might be affected
  when your app goes into doze mode state. (only on Android 6.0 or later)
  Returns: Returns a `Promise` which fulfills with a `boolean` value of either `true` or `false`,
  indicating whether the battery optimization is enabled or disabled, respectively. (Android only)
  Example:
  ```ts
  await Battery.isBatteryOptimizationEnabledAsync();
  // true
  ```

#### isLowPowerModeEnabledAsync (_Function_)

- `isLowPowerModeEnabledAsync(): Promise<boolean>`
  Gets the current status of Power Saver mode on Android and Low Power mode on iOS. If a platform
  doesn't support Low Power mode reporting (like web, older Android devices), the reported low-power
  state is always `false`, even if the device is actually in low-power mode.
  Returns: Returns a `Promise` which fulfills with a `boolean` value of either `true` or `false`,
  indicating whether low power mode is enabled or disabled.
  Example:
  Power Saver Mode (Android) or Low Power Mode (iOS) are enabled.
  ```ts
  await Battery.isLowPowerModeEnabledAsync();
  // true
  ```

### Event Subscriptions

#### addBatteryLevelListener (_Function_)

- `addBatteryLevelListener(listener: (event: BatteryLevelEvent) => void): EventSubscription`
  Subscribe to the battery level change updates.

  On Android devices, the event fires only when significant changes happens, which is when the
  battery level drops below [`android.intent.action.BATTERY_LOW`](https://developer.android.com/reference/android/content/Intent#ACTION_BATTERY_LOW)
  or rises above [`android.intent.action.BATTERY_OKAY`](https://developer.android.com/reference/android/content/Intent#ACTION_BATTERY_OKAY)
  from a low battery level. See [Monitor the Battery Level and Charging State](https://developer.android.com/training/monitoring-device-state/battery-monitoring)
  in Android documentation for more information.

  On iOS devices, the event fires when the battery level drops one percent or more, but is only
  fired once per minute at maximum.

  On web, the event never fires.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `listener` | (event: BatteryLevelEvent) => void | A callback that is invoked when battery level changes. The callback is provided a<br>single argument that is an object with a `batteryLevel` key. |
  Returns: A `Subscription` object on which you can call `remove()` to unsubscribe from the listener.

#### addBatteryStateListener (_Function_)

- `addBatteryStateListener(listener: (event: BatteryStateEvent) => void): EventSubscription`
  Subscribe to the battery state change updates to receive an object with a [`Battery.BatteryState`](#batterystate)
  enum value for whether the device is any of the four states.

  On web, the event never fires.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `listener` | (event: BatteryStateEvent) => void | A callback that is invoked when battery state changes. The callback is provided a<br>single argument that is an object with a `batteryState` key. |
  Returns: A `Subscription` object on which you can call `remove()` to unsubscribe from the listener.

#### addLowPowerModeListener (_Function_)

- `addLowPowerModeListener(listener: (event: PowerModeEvent) => void): EventSubscription`
  Subscribe to Power Saver Mode (Android) or Low Power Mode (iOS) updates. The event fires whenever
  the power mode is toggled.

  On web, the event never fires.
  | Parameter | Type | Description |
  | --- | --- | --- |
  | `listener` | (event: PowerModeEvent) => void | A callback that is invoked when Power Saver Mode (Android) or Low Power Mode (iOS)<br>changes. The callback is provided a single argument that is an object with a `lowPowerMode` key. |
  Returns: A `Subscription` object on which you can call `remove()` to unsubscribe from the listener.

### Interfaces

#### Subscription (_Interface_)

A subscription object that allows to conveniently remove an event listener from the emitter.

### Types

#### BatteryLevelEvent (_Type_)

| Property       | Type   | Description                                                                       |
| -------------- | ------ | --------------------------------------------------------------------------------- |
| `batteryLevel` | number | A number between `0` and `1`, inclusive, or `-1` if the battery level is unknown. |

#### BatteryStateEvent (_Type_)

| Property       | Type         | Description                                   |
| -------------- | ------------ | --------------------------------------------- |
| `batteryState` | BatteryState | An enum value representing the battery state. |

#### PowerModeEvent (_Type_)

| Property       | Type    | Description                                                                    |
| -------------- | ------- | ------------------------------------------------------------------------------ |
| `lowPowerMode` | boolean | A boolean value, `true` if lowPowerMode is on, `false` if lowPowerMode is off. |

#### PowerState (_Type_)

| Property       | Type         | Description                                                                       |
| -------------- | ------------ | --------------------------------------------------------------------------------- |
| `batteryLevel` | number       | A number between `0` and `1`, inclusive, or `-1` if the battery level is unknown. |
| `batteryState` | BatteryState | An enum value representing the battery state.                                     |
| `lowPowerMode` | boolean      | A boolean value, `true` if lowPowerMode is on, `false` if lowPowerMode is off.    |

### Enums

#### BatteryState (_Enum_)

#### Members

- `CHARGING` — If battery is charging.
- `FULL` — If the battery level is full.
- `UNKNOWN` — If the battery state is unknown or inaccessible.
- `UNPLUGGED` — If battery is not charging or discharging.
