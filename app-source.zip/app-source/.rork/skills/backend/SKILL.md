---
name: backend
description: Add server-side capabilities to a Rork project — including
  Supabase, Cloudflare Workers, Durable Objects, realtime/multiplayer, webhooks,
  scheduled tasks, and edge functions. Routes between Cloudflare-first and
  Supabase-first internally.
aliases:
  - server
  - api
  - webhook
  - realtime
  - multiplayer
  - database
  - persistence
  - durable object
  - worker
  - supabase
---

# Backend

Use this skill for backend work in Rork projects. There are two modern services and one legacy stack:

- **Cloudflare Workers + Durable Objects** — portable server-side code, realtime connection handling, and scoped durable SQLite storage. This is the default for APIs, webhooks, business logic, validation, third-party integrations, scheduled tasks, realtime, multiplayer, and per-room/per-project state. Read .rork/skills/backend/cloudflare/overview.md.
- **Supabase Postgres** — managed relational SQL storage with Row Level Security. Use it when the app needs global relational queries, RLS-protected client access, reporting, or data that should not be partitioned by Durable Object identity. Read .rork/skills/backend/supabase/overview.md.
- **Legacy Hono + tRPC** — only for projects that already have `backend/hono.ts`. Read .rork/skills/backend/legacy-hono/overview.md.


## Default to Cloudflare for Code

If you are adding any server-side code, prefer Cloudflare Workers. The Worker is vanilla Cloudflare (`export default { fetch }`) and can be lifted into a normal Cloudflare account with a `wrangler.jsonc` if the project ever needs to migrate off Rork. That portability also makes future bug fixes and backwards-compatible API evolution easier: the code owns the API boundary instead of spreading behavior across client calls and database policies.

Use Cloudflare for:

- API endpoints called by React Native, Swift, or web apps.
- Webhook handlers (Stripe, Resend, GitHub, etc.).
- Business logic, validation, permissions beyond simple row ownership, third-party API calls, and response shaping.
- Realtime, multiplayer, chat, presence, collaborative state, WebSockets, and scheduled tasks via Durable Objects.
- Durable Object storage when the data naturally belongs to one room, one match, one user session, one document, or one project-scoped actor.


## Choose the Data Layer

Cloudflare can be the database too. Durable Objects include per-object SQLite storage (`this.ctx.storage.sql`), so a Worker can own both the API and the durable state without adding Supabase.

Use **Durable Object storage** when:

- The app needs multiplayer rooms, presence, chat, matchmaking, collaborative documents, or any WebSocket fanout.
- State is naturally scoped to a stable id such as `roomId`, `matchId`, `documentId`, `userId`, or `projectId`.
- You want one colocated authority for connections plus data: the DO handles sockets, writes SQLite rows, runs periodic timers, and serves reads.
- The data is small to medium, local to that object, and does not need global SQL joins across every project/user.


Use **Supabase Postgres** when:

- The app needs global relational queries, cross-user reporting, search/filtering across many records, SQL joins, or admin analytics.
- The client should read/write directly with Row Level Security.
- The data should live in one central relational database instead of being partitioned across Durable Object instances.


Common patterns:

1. **Cloudflare Worker + Durable Object storage** (default for realtime and scoped state). The Worker/DO owns both API and data.
2. **Cloudflare Worker -> Supabase** (recommended for non-trivial logic over relational data). The Worker owns the public API and calls Supabase as the database.
3. **Client -> Supabase directly with RLS** (acceptable for thin CRUD like TODOs, profile editing, simple user-owned records). RLS guards rows, and there is little or no custom server-side behavior.


Move from direct client access to a Worker-owned API as soon as business logic grows. RLS is useful, but it is Supabase-specific; portable behavior belongs in Cloudflare code when possible.

## Edge Function Choice

Prefer Cloudflare Workers over Supabase Edge Functions. Use Supabase Edge Functions only when the function must run inside Supabase's environment with elevated database privileges or Supabase-specific auth context. For normal APIs and integrations, use Cloudflare.

## Existing Projects

Never migrate an existing Supabase-based project to Cloudflare just because Cloudflare is the default for new code. Continue the existing architecture unless the user explicitly asks for migration. The portability principle is for choosing where to put new behavior, not for creating churn.

For legacy `backend/hono.ts` projects, extend the existing stack unless the user explicitly asks to migrate.
