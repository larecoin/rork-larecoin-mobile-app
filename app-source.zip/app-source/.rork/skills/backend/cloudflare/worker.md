# Writing the Worker entrypoint

## File layout

```
functions/
├── index.ts          # export default { fetch }
├── chat-room.ts      # any Durable Object classes (optional)
├── _lib/             # internal helpers, organized however you want
└── package.json      # dependencies for the bundle
```

`functions/index.ts` is the Worker entrypoint. Everything else is plain TS modules that the entrypoint imports — `bun build` resolves all transitive imports into one bundle at deploy time.

## Entrypoint shape

```ts
export default {
  async fetch(request: Request): Promise<Response> {
    const url = new URL(request.url);

    switch (url.pathname) {
      case "/ping":
        return Response.json({ ok: true, now: new Date().toISOString() });

      default:
        return new Response("not found", { status: 404 });
    }
  },
};
```

The signature is the standard Cloudflare Worker `ExportedHandler<Env>`. State lives in Durable Objects (see `durable-objects.md`); the platform does not provide a DB or KV binding directly.

`env` carries two things:

- `env.DO` — service binding used to dispatch into your own Durable Object classes (see "Calling your own Durable Objects" below).
- Every entry from the project's envs store as a string — e.g. `env.STRIPE_SECRET_KEY`. See "Env vars and secrets" below.

```ts
type Env = {
  DO: Fetcher;
  STRIPE_SECRET_KEY: string;
  STRIPE_WEBHOOK_SECRET: string;
};

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    // ...
  },
} satisfies ExportedHandler<Env>;
```

## Env vars and secrets

The platform spreads the project's envs into `env` on every request. Read them like any other Cloudflare Worker binding:

```ts
type Env = { STRIPE_SECRET_KEY: string; DO: Fetcher };

export default {
  async fetch(_request: Request, env: Env): Promise<Response> {
    const stripe = await fetch("https://api.stripe.com/v1/charges", {
      headers: { Authorization: `Bearer ${env.STRIPE_SECRET_KEY}` },
    });
    return stripe;
  },
} satisfies ExportedHandler<Env>;
```

Rules of the road:

- **Same store as the rest of the project.** Values come from the project envs slice that already drives `EXPO_PUBLIC_*` for the React Native / web builds. Set them through the project settings UI; updates propagate to the running Worker automatically — no redeploy required.
- **Durable Objects see the same envs.** Inside a DO class, read them via `this.env.STRIPE_SECRET_KEY` (the second `super(ctx, env)` constructor argument). DO instances pick up env changes on the next dispatch.
- **No `wrangler secret` equivalent.** There's no separate "secrets" namespace; everything is one envs map.

## Routing

Routing inside the entrypoint is yours to choose. Vanilla switch is the smallest path:

```ts
const url = new URL(request.url);
const path = url.pathname;

if (path === "/users" && request.method === "GET") return listUsers(request);
if (path.startsWith("/users/") && request.method === "GET") return getUser(request, path);
if (path === "/webhooks/stripe" && request.method === "POST") return handleStripe(request);
return new Response("not found", { status: 404 });
```

Hono works too if you prefer:

```ts
import { Hono } from "hono";
const app = new Hono();
app.get("/users", listUsers);
app.post("/webhooks/stripe", handleStripe);
export default app;
```

## Outbound fetch — public Internet

`fetch(url)` from inside the loaded Worker goes through the platform's egress gateway and out to the public Internet exactly as a vanilla CF Worker would.

```ts
const quote = await fetch("https://api.quotable.io/random").then((r) => r.json());
```

Future versions of the gateway will add per-project rate limiting and audit logging at this single chokepoint, but for now it's straight passthrough.

## Runtime limitations

Your bundle runs under Cloudflare's Worker Loader (a dynamically-loaded Worker), not as a standalone deployed Worker. A few platform APIs that exist in a stock CF account are **not** available in this runtime:

- **Cache API (`caches.default`, `caches.open(...)`) is unsupported.** Any call throws `Cache API is not yet supported for dynamically-loaded workers.` Because that throw is uncaught, it aborts your `fetch` before it returns a Response, and the client sees an opaque `503 route unavailable` with an `x-rork-route-miss` header — the platform reporting that your Worker never produced a response. Do not reach for `caches`. To cache, keep state in your Durable Object (an in-memory field or its SQLite storage), or set `Cache-Control` response headers and let Cloudflare's edge cache the response for you.

> **Debugging a 503 `route unavailable` / `x-rork-route-miss`.** This is almost never a platform routing failure to escalate — it means your loaded Worker **threw** on that route. The tell is path-selective failure: a no-op route like `/ping` returns 200 while `/api/*` 503s, which means those handlers hit an exception (an unsupported API like `caches`, a `TypeError`, etc.), not that the route is "unregistered". Read the runtime logs (`getCloudflareLogs`) to see the verbatim error and stack before assuming anything platform-side.

## Calling your own Durable Objects (`env.DO`)

To dispatch from the entrypoint into a DO class **declared in the same bundle**, call `env.DO.fetch(request)` and stamp two headers that tell the platform which class and instance you want:

| Header            | Value                                                                                                  |
| ----------------- | ------------------------------------------------------------------------------------------------------ |
| `X-Rork-DO-Class` | The exported class name, exactly as it appears in `functions/index.ts` re-exports (e.g. `ChatRoom`).   |
| `X-Rork-DO-Id`    | The instance key — any string. Same key = same DO instance; inside it, `ctx.id.name` returns this key. |

There are two non-obvious requirements; both will silently break your DO if you skip them:

1. **Re-export the class from `functions/index.ts`.** A side-effect import (`import "./chat-room"`) is not enough — the bundler tree-shakes the class declaration and the platform fails to look it up. Use `export { ChatRoom } from "./chat-room";`.
2. **Wrap the request with the 2-arg `new Request(url, request)` form.** The 1-arg `new Request(request)` drops the `Upgrade: websocket` header on workerd, leaving the client stuck on `CONNECTING`. The 2-arg form preserves every header.

```ts
// Inside functions/index.ts
export { ChatRoom } from "./chat-room"; // [1] re-export so the bundler keeps the class

type Env = { DO: Fetcher };

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);

    if (url.pathname === "/chat" && request.headers.get("Upgrade") === "websocket") {
      const roomId = url.searchParams.get("room") ?? "lobby";
      const wrapped = new Request(request.url, request); // [2] 2-arg form
      wrapped.headers.set("X-Rork-DO-Class", "ChatRoom");
      wrapped.headers.set("X-Rork-DO-Id", roomId);
      return env.DO.fetch(wrapped);
    }
    return new Response("not found", { status: 404 });
  },
} satisfies ExportedHandler<Env>;
```

What `env.DO.fetch(...)` does:

- Looks up the user-declared class by `X-Rork-DO-Class` (must match a class re-exported from `functions/index.ts`). If the class isn't in the bundle's exports, the dispatcher returns 404 with `unknown DO class: <name>`.
- Materializes the instance keyed by `(className, id)` — same id always reaches the same DO, with its own SQLite storage and WebSocket peers. (Note: the native alarm API is replaced — schedule via `env.DO.setAlarm(...)` and handle in `onAlarm()`; see `durable-objects.md`.)
- Forwards the request unchanged. The DO's `fetch()` sees the original URL, method, headers, and body. WebSocket upgrade responses (`new Response(null, { status: 101, webSocket: client })`) flow back intact — this transport is WebSocket-aware.

> Why headers and not URL parameters: the dispatch goes over a service binding so that 101-upgrade responses with attached `WebSocket` pairs survive the round trip. Headers are the natural place to encode `(class, id)` without altering the URL the DO sees.

### DO → DO calls use the same binding

`env.DO` is also how DOs call each other — inside a DO class it's available as `this.env.DO`. Build a request with the two `X-Rork-DO-*` headers and any URL path the target should see:

```ts
const request = new Request("https://internal/init", {
  method: "POST",
  headers: {
    "X-Rork-DO-Class": "GameRoom",
    "X-Rork-DO-Id": "room-123",
  },
  body: JSON.stringify({ black: "alice", white: "bob" }),
});
await this.env.DO.fetch(request);
```

> NEVER use the legacy `fetch("do://internal/...")` scheme. Inside a DO it fails outright (`TypeError: Fetch API cannot load: do://...`), and it cannot carry WebSocket upgrades. `env.DO` is the only dispatch mechanism — from the entrypoint and from inside DOs alike. See `durable-objects.md` "DO → DO calls".

If you ever lift this code into a stock CF account, replace `env.DO.fetch(wrapped)` with the per-class binding:

```ts
return env.CHAT_ROOM.get(env.CHAT_ROOM.idFromName(roomId)).fetch(request);
```

…and remove the two headers. That's the entire portability delta.

See `durable-objects.md` for declaring the DO class and the full export / wrap-request rules.

## CORS

The hosting Worker doesn't intercept `OPTIONS` — your function handles its own CORS headers. A minimal CORS-allow snippet:

```ts
const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
};

if (request.method === "OPTIONS") {
  return new Response(null, { status: 204, headers: CORS });
}
// ... your handler ...
return new Response(JSON.stringify(payload), {
  headers: { ...CORS, "Content-Type": "application/json" },
});
```

## Examples

- `examples/example-stripe-webhook.ts` — full webhook with signature verification
- `examples/example-user-data.ts` — `/whoami` endpoint reading `X-Rork-User-Id`
- `examples/example-chat-room.ts` — WebSocket chat room via `env.DO.fetch(...)`
- `examples/example-presence.ts` — presence DO with hibernation + timer-driven heartbeat
- `examples/example-matchmaking-game.ts` — online game matchmaking with `env.DO` WebSocket routes and lazy room init
