# Calling the backend from the Next.js web app

The function is reachable at the URL written to `EXPO_PUBLIC_RORK_FUNCTIONS_URL` (e.g. `https://<projectSlug>-backend.rork.app/<path>` in production). If the user is signed in (Rork Auth), forward the bearer token and your function will receive `X-Rork-User-*` headers.

## Setup — derive the backend URL

The functions URL is exposed as `EXPO_PUBLIC_RORK_FUNCTIONS_URL` (set by the platform).

```ts
// lib/backend.ts
export const BACKEND_URL = process.env["EXPO_PUBLIC_RORK_FUNCTIONS_URL"]!;
```

## HTTP — fetch from a client component

```tsx
"use client";
import { useEffect, useState } from "react";
import { BACKEND_URL } from "@/lib/backend";

export function Ping() {
  const [data, setData] = useState<{ ok: boolean; now: string } | null>(null);

  useEffect(() => {
    fetch(`${BACKEND_URL}/ping`)
      .then((r) => r.json())
      .then(setData);
  }, []);

  return data ? <pre>{JSON.stringify(data, null, 2)}</pre> : null;
}
```

## HTTP — server-side fetch

To centralize backend calls or attach a bearer token, proxy through a Next.js route handler:

```ts
// app/api/backend/[...path]/route.ts
import { NextRequest } from "next/server";

const BACKEND = process.env["EXPO_PUBLIC_RORK_FUNCTIONS_URL"]!;

export async function GET(request: NextRequest, { params }: { params: Promise<{ path: string[] }> }) {
  const { path } = await params;
  const upstream = `${BACKEND}/${path.join("/")}${new URL(request.url).search}`;
  const auth = request.headers.get("Authorization");
  return fetch(upstream, {
    headers: {
      ...(auth ? { Authorization: auth } : {}),
    },
  });
}
```

The same pattern handles POST/PUT/DELETE — forward the method, body, and bearer token.

## WebSocket — connect to a chat / presence DO

Browser WebSocket can't set custom headers; pass the access token as a query param if needed:

```ts
"use client";

const BACKEND_URL = process.env["EXPO_PUBLIC_RORK_FUNCTIONS_URL"]!;

export function chatSocket(roomId: string, accessToken?: string): WebSocket {
  const params = new URLSearchParams({
    room: roomId,
  });
  if (accessToken) params.set("token", accessToken);
  return new WebSocket(`${BACKEND_URL.replace(/^http/, "ws")}/chat?${params.toString()}`);
}
```

## Common pitfalls

- **Client bundle exposure**: Next.js only inlines `NEXT_PUBLIC_*` env vars into the client bundle by default. To use `EXPO_PUBLIC_*` vars in client components, forward them in `next.config.mjs` under the `env` key, or read them server-side and pass through props.
- **Server components**: a server component running in a Cloudflare Pages / Vercel runtime can also reach the backend by reading `process.env["EXPO_PUBLIC_RORK_FUNCTIONS_URL"]` at runtime — don't rely on `"use client"` at module scope.
