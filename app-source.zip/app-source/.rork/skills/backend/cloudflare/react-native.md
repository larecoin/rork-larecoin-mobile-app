# Calling the backend from React Native

The function is reachable at the URL written to `EXPO_PUBLIC_RORK_FUNCTIONS_URL` (e.g. `https://<projectSlug>-backend.rork.app/<path>` in production). If the user is signed in (Rork Auth), forward the bearer token and your function will receive `X-Rork-User-*` headers.

## Setup — derive the backend URL

The functions URL is exposed as `EXPO_PUBLIC_RORK_FUNCTIONS_URL` (set by the platform).

```ts
// hooks/useBackendUrl.ts
export const BACKEND_URL = process.env.EXPO_PUBLIC_RORK_FUNCTIONS_URL!;
```

## HTTP — fetch from a screen

```tsx
import { useEffect, useState } from "react";
import { BACKEND_URL } from "../hooks/useBackendUrl";

export function PingButton() {
  const [data, setData] = useState<{ ok: boolean; now: string } | null>(null);

  async function ping() {
    const response = await fetch(`${BACKEND_URL}/ping`);
    setData(await response.json());
  }

  // ...render data, button calls ping
}
```

## HTTP — authenticated request

If you have Rork Auth set up (see the `auth` skill), pass the bearer token along:

```ts
async function fetchAuthed(path: string) {
  const accessToken = await SecureStore.getItemAsync("rork_access_token");
  return fetch(`${BACKEND_URL}${path}`, {
    headers: {
      ...(accessToken ? { Authorization: `Bearer ${accessToken}` } : {}),
    },
  });
}
```

The platform stamps `X-Rork-User-Id` on the request only when the token verifies. Your function reads `request.headers.get("X-Rork-User-Id")` to know who's calling.

## WebSocket — connect to a chat / presence DO

Browser / RN `WebSocket` doesn't let you set custom headers on the upgrade request. Pass the bearer token as a query param if needed:

```ts
function chatSocket(roomId: string, accessToken?: string): WebSocket {
  const params = new URLSearchParams({
    room: roomId,
  });
  if (accessToken) params.set("token", accessToken);
  return new WebSocket(`${BACKEND_URL.replace(/^http/, "ws")}/chat?${params.toString()}`);
}

const ws = chatSocket("lobby", accessToken);
ws.onmessage = (e) => console.log("from server:", e.data);
ws.onopen = () => ws.send("hello");
```

## Common pitfalls

- **Cold deploys**: a fresh project that has never been deployed returns 503 with `"no bundle deployed for this project"`. Edit `functions/index.ts` and run the build tool to deploy the seed bundle.
