# Calling the backend from Swift / iOS

The function is reachable at the URL written to `EXPO_PUBLIC_RORK_FUNCTIONS_URL` (e.g. `https://<projectSlug>-backend.rork.app/<path>` in production). If the user is signed in (Rork Auth), forward the bearer token and your function will receive `X-Rork-User-*` headers.

## Setup — derive the backend URL

The functions URL lands in the auto-generated `Config.swift` as `EXPO_PUBLIC_RORK_FUNCTIONS_URL`.

```swift
// Config.swift is auto-generated; the relevant constants are:
//   Config.EXPO_PUBLIC_RORK_FUNCTIONS_URL: String
import Foundation

enum Backend {
  static var baseURL: URL { URL(string: Config.EXPO_PUBLIC_RORK_FUNCTIONS_URL)! }
}
```

## HTTP — typed request helper

```swift
import Foundation

struct BackendError: Error { let status: Int; let body: String }

func backend<Decoded: Decodable>(
  _ path: String,
  method: String = "GET",
  body: Data? = nil,
  bearerToken: String? = nil,
  decode: Decoded.Type
) async throws -> Decoded {
  var request = URLRequest(url: Backend.baseURL.appendingPathComponent(path))
  request.httpMethod = method
  if let token = bearerToken {
    request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
  }
  if let body = body {
    request.httpBody = body
    request.setValue("application/json", forHTTPHeaderField: "Content-Type")
  }

  let (data, response) = try await URLSession.shared.data(for: request)
  let http = response as! HTTPURLResponse
  guard (200..<300).contains(http.statusCode) else {
    throw BackendError(status: http.statusCode, body: String(data: data, encoding: .utf8) ?? "")
  }
  return try JSONDecoder().decode(Decoded.self, from: data)
}
```

## HTTP — example call

```swift
struct PingResponse: Decodable { let ok: Bool; let now: String }

let ping = try await backend("/ping", decode: PingResponse.self)
print(ping.now)
```

For an authenticated call (Rork Auth set up — see the `auth` skill), pass the access token from the Keychain:

```swift
let token = try Keychain.read("rork_access_token")
let user = try await backend("/whoami", bearerToken: token, decode: WhoAmI.self)
```

## WebSocket — connect to a chat / presence DO

`URLSessionWebSocketTask` accepts custom headers on the upgrade, so pass the bearer token normally if needed.

```swift
import Foundation

func openChatSocket(room: String, accessToken: String?) -> URLSessionWebSocketTask {
  var components = URLComponents(url: Backend.baseURL, resolvingAgainstBaseURL: false)!
  components.scheme = "wss"
  components.path = "/chat"
  components.queryItems = [URLQueryItem(name: "room", value: room)]

  var request = URLRequest(url: components.url!)
  if let token = accessToken {
    request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
  }

  let task = URLSession.shared.webSocketTask(with: request)
  task.resume()
  return task
}

let socket = openChatSocket(room: "lobby", accessToken: token)
try await socket.send(.string("hello"))
let message = try await socket.receive()
```

Use `URLSessionWebSocketDelegate` to react to disconnects and re-open. `task.resume()` initiates the upgrade.

## Common pitfalls

- **Cold deploys**: a fresh project that has never been deployed returns 503 with `"no bundle deployed for this project"`. Edit `functions/index.ts` and run the build tool.
