---
name: cloudflare-workers
description: Default backend path for portable server-side logic, APIs,
  webhooks, realtime, Durable Objects, and scheduled tasks.
---

# Cloudflare Edge Functions

Each Rork project gets the equivalent of its own Cloudflare account, scoped to a single Worker bundle. The user writes a vanilla Cloudflare Worker (`export default { fetch }`) and any Durable Object classes they want to reach from it. Rork bundles the lot, hosts it on a per-project subdomain, and routes inbound traffic.

**No Rork-shaped programming model.** The source code is portable Cloudflare. Lifted into a normal CF account with a `wrangler.jsonc` it runs unchanged (the only Rork-specific bit is the `env.DO` service binding used to address user-declared DOs from the entrypoint — a few lines to rewrite into per-class `env.<CLASS>.get(idFromName(...))` calls).

Durable Objects are both a connection layer and a database layer. Use them to keep WebSocket peers, room/match/document state, and per-object SQLite rows together behind one strongly consistent actor. For many multiplayer or project-scoped backends, the Cloudflare Worker + DO is the whole backend; Supabase is optional, not mandatory.

## When to use

- Webhook handlers (Stripe, Resend, GitHub, ...).
- Server-side API endpoints called from the React Native / Swift / Web app.
- Real-time multiplayer (chat rooms, presence, collaborative state) via WebSockets + Durable Objects. For joining, default to a rooms list (server browser) or auto-matchmaking — not manual room-code exchange; see `durable-objects.md` → "Room discovery".
- Per-room, per-match, per-document, per-user, or per-project persistence via Durable Object SQLite storage.
- Background processing: in-object timers while a DO is active, and durable scheduling via DO alarms (`env.DO.setAlarm(...)` + an `onAlarm()` handler — works unattended, even with no inbound traffic; see `durable-objects.md`).


## When NOT to use

- Pure client-side data fetching (React Query, SWR) against public APIs.
- Static asset serving (use the project's existing storage).
- Anything that already has a vendor SDK with a managed client (Supabase, Firebase, etc.) — use the vendor SDK directly from the app instead.


## Project structure

```
<project root>/
├── rork.json                       # gains { "name": "Functions", "path": "functions", "framework": "cloudflare" }
├── .gitignore                      # gains a "# Cloudflare Functions" block
└── functions/
    ├── package.json                # deps for the bundle, scoped away from the parent app
    ├── index.ts                    # export default { fetch } — the entrypoint
    └── chat-room.ts                # optional — any DO classes the user declares

```

`functions/index.ts` is the Worker entrypoint. Everything else is just JS modules the entrypoint imports. Routing inside the entrypoint is your call — vanilla `URL.pathname` switch, Hono, anything you prefer.

Durable Object dispatch has exactly one mechanism: `env.DO.fetch(...)` with `X-Rork-DO-Class` and `X-Rork-DO-Id` headers. It serves public routes, **all WebSocket upgrades**, and DO-to-DO calls (inside a DO it's `this.env.DO`). The legacy `fetch("do://internal/...")` scheme must never be used — it fails inside DOs with `Fetch API cannot load`.

## Provisioning

Call `provisionFunctions` once per project to create the `functions/` folder and the `rork.json` entry.

After provisioning, `functions/index.ts` will contain the trivial seed:

```ts
export default {
  async fetch(request: Request): Promise<Response> {
    return Response.json({ ok: true, hello: "world" });
  },
};
```

## URL & deploy

- The function is reachable at the URL exposed via `EXPO_PUBLIC_RORK_FUNCTIONS_URL` (production form: `https://<projectId>-backend.rork.app/<path>`).
- Deploy by running the `runChecks` tool with the cloudflare app path; we bundle `functions/index.ts` (with all its imports) and ship it sub-second.
- One bundle per project. Adding a DO class is the same operation as editing the entrypoint: edit, redeploy.


## Env vars and secrets

The platform spreads the project's envs into the Worker's `env` as plain strings — read them as `env.STRIPE_SECRET_KEY`, `env.RESEND_API_KEY`, etc. Durable Object classes see the same values via `this.env.*`. Values come from the project envs UI (the same store that drives `EXPO_PUBLIC_*` for the RN/web builds); changes propagate to the running Worker without a redeploy. Do not hardcode secrets in `functions/` source. See `worker.md` for details.

## Inspecting runtime logs

Every invocation of the deployed Worker — entrypoint requests _and_ Durable Object dispatches — has its `console.log/warn/error/info/debug` output and any uncaught exception captured into a per-project ring buffer (most recent 10,000 entries). Read it with the `getCloudflareLogs` tool.

When to reach for it:

- The user says the backend is "broken", "returning 500", "not working", "stuck" — pull logs and read the stack instead of guessing from the source.
- You just deployed a new bundle and want to confirm the new code path is being hit.
- A webhook (Stripe, Resend, GitHub) silently isn't acting and you need to see what arrived.


What's captured per entry:

- `level` — `log`, `warn`, `error`, `info`, `debug`. Uncaught throws and rejected promises land as synthetic `level: "error"` rows with `stack` populated.
- `message` — the `console.*` arguments (preserved as the parsed value) or, for exception rows, the plain `Error.message` string.
- `requestUrl`, `requestMethod`, `responseStatus` — populated when the originating event was a fetch.
- `id`, `timestamp` — id is monotonic for stable cursor-style paging; timestamp is ms since epoch.


Tail Workers run asynchronously after the response, so expect ~1–2 s lag between hitting the URL and the log row showing up.

There is no `console` API or HTTP endpoint inside the user's Worker for fetching its own logs — `getCloudflareLogs` is the only path. Do not write code in `functions/` that tries to read logs.

**Known dev-environment gap.** When `EXPO_PUBLIC_RORK_FUNCTIONS_URL` points at a `*.rorkdev.link` tunnel (a Rork developer's local laptop running the hosting Worker under `wrangler dev`), `getCloudflareLogs` will always return an empty array — miniflare's Worker Loader plugin does not propagate the tail-Worker binding, so `console.*` output and uncaught exceptions are never captured into the ring buffer even though the user Worker is running and serving requests correctly. This affects only local dev tunnels; on the production `<projectId>-backend.rork.app` host, logs flow normally. If the user URL is a `rorkdev.link` tunnel and `getCloudflareLogs` is empty after a confirmed-successful curl, treat that as the environment limitation — do not loop, redeploy, or wait longer. Surface the gap to the user and either test against the production URL or fall back to reading the Worker's response body for debugging.

## Auth model — optional sugar, never gates

The platform routes requests by the backend hostname (for example, `<projectId>-backend.rork.app`). Your function does not need any Rork routing headers.

If the request additionally carries `Authorization: Bearer <rork-jwt>`, the platform verifies the token against Rork Auth's keys and stamps `X-Rork-User-Id`, `X-Rork-User-Email`, `X-Rork-User-Name` on the forwarded request. **On any failure** (missing, invalid signature, wrong audience, expired) the platform silently drops the token — never returns 401. Your function decides what to do with missing identity.

```ts
const userId = request.headers.get("X-Rork-User-Id"); // null = guest
```

There is no `requireAuth` flag. Your function decides per-route whether `userId` is required.

## Platform implementation guides

| File                 | When to use                                                                               |
| -------------------- | ----------------------------------------------------------------------------------------- |
| `worker.md`          | Writing the Worker — entrypoint shape, routing, outbound fetch, `env.DO`                  |
| `durable-objects.md` | Declaring a Durable Object class, WebSockets, SQLite storage, timers, alarms via `env.DO` |
| `auth.md`            | Optional Rork Auth headers, inline JWT-verify snippet                                     |
| `react-native.md`    | Client wiring from a React Native / Expo app                                              |
| `swift.md`           | Client wiring from a Swift / iOS app                                                      |
| `web.md`             | Client wiring from the Next.js web app                                                    |

## Examples

Runnable end-to-end examples in `examples/` — all five are referenced by the platform implementation guides:

- `example-stripe-webhook.ts` — webhook handler with signature verification
- `example-user-data.ts` — `/whoami`-style endpoint reading `X-Rork-User-Id`, with an inline JWT-verify alternative for projects that distrust platform headers
- `example-chat-room.ts` — chat DO + entrypoint dispatch via `env.DO.fetch(...)`
- `example-presence.ts` — presence DO with hibernation + timer-driven heartbeat + broadcast
- `example-matchmaking-game.ts` — FIFO matchmaking + one GameRoom DO per game, showing `env.DO` WebSocket routes and lazy room initialization


## Available tools

### provisionFunctions

Provision the per-project Cloudflare Worker backend. Idempotent — safe to call
multiple times.

Effects:
  - Adds a `cloudflare` app entry to rork.json (path: `functions`).
  - Creates `functions/package.json` and a starter `functions/index.ts`.
  - Adds a "Cloudflare Functions" block to .gitignore.

After provisioning, the function is reachable at the configured
`EXPO_PUBLIC_RORK_FUNCTIONS_URL`. Edit `functions/index.ts` and run the
build tool on the cloudflare app to deploy.

```json
{"type":"object","properties":{}}
```

### getCloudflareLogs

Read recent runtime logs from the deployed Cloudflare Worker (the project's
`functions/` bundle). Captures every `console.log/warn/error/info/debug`
call the user-Worker made plus any uncaught exceptions (`throw`, rejected
promises) — exceptions land as synthetic `level: "error"` rows with the
stack populated.

Default returns the 100 newest rows. Filters: `beforeId` for paging
further into history, `sinceTimestamp`/`untilTimestamp` (ms since
epoch) for a time window.

Use this tool when:
  - The user reports the backend "not working" / "broken" / "returning 500" — pull logs to see what actually happened in the Worker.
  - A request through the function failed and you need the stack.
  - You want to confirm a code path you just deployed is being hit.

Tail Workers run asynchronously after each request — expect a 1-2s lag
between hitting the URL and the log row appearing here.

```json
{"type":"object","properties":{"limit":{"description":"Max rows to return. Default 100, hard cap 500.","type":"integer","minimum":1,"maximum":500},"beforeId":{"description":"Newest-first cursor. Pass the `id` of the oldest row from the previous call to scroll into older history.","type":"integer","minimum":-9007199254740991,"maximum":9007199254740991},"sinceTimestamp":{"description":"Filter: only return rows with `timestamp >= this` (ms since epoch).","type":"integer","minimum":-9007199254740991,"maximum":9007199254740991},"untilTimestamp":{"description":"Filter: only return rows with `timestamp <= this` (ms since epoch).","type":"integer","minimum":-9007199254740991,"maximum":9007199254740991}}}
```
