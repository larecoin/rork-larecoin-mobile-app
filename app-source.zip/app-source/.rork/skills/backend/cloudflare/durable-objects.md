# Durable Objects

User-declared Durable Object classes live in the **same** bundle as your Worker entrypoint. The platform pulls them out at dispatch time and materializes per-`(className, id)` instances on demand.

Durable Objects are the Cloudflare-native state layer for Rork backends:

- **Multiplayer connection layer** — one object instance can own a chat room, match, presence channel, collaborative document, or lobby. It accepts WebSockets, keeps peer metadata through hibernation, broadcasts messages, and runs periodic timers while peers are connected. For how players find each other, see "Room discovery" below — default to a rooms list or auto-matchmaking, not manual code exchange.
- **Scoped database layer** — every object instance has durable SQLite storage via `this.ctx.storage.sql`. Use it for state that naturally belongs to that instance: room messages, match history, document edits, project-local queues, presence snapshots, or per-project settings.

This means the database does not always need to be Supabase. If the state is actor-scoped and the Worker/DO owns the API, Cloudflare can be the full backend. Reach for Supabase when you need global relational queries, RLS-protected direct client access, reporting, or joins across many objects/users/projects.

## Declaring a DO class

```ts
// functions/chat-room.ts
import { DurableObject } from "cloudflare:workers";

export class ChatRoom extends DurableObject {
  override async fetch(request: Request): Promise<Response> {
    if (request.headers.get("Upgrade") !== "websocket") {
      return new Response("expected websocket", { status: 426 });
    }
    const pair = new WebSocketPair();
    const [client, server] = Object.values(pair);

    this.ctx.acceptWebSocket(server);
    return new Response(null, { status: 101, webSocket: client });
  }

  override webSocketMessage(ws: WebSocket, message: string | ArrayBuffer): void {
    for (const peer of this.ctx.getWebSockets()) {
      if (peer === ws) continue;
      peer.send(typeof message === "string" ? message : new TextDecoder().decode(message));
    }
  }
}
```

This is plain Cloudflare. No Rork-specific imports, no required base class beyond `DurableObject`, no required method beyond what CF DOs already are.

## How instances are hosted: facets

On Rork, each `(className, id)` instance runs as a **facet** — an isolated child object materialized inside a platform-managed host Durable Object. Day to day this is mostly invisible: the facet has its own SQLite storage, its own WebSocket peers, hibernation works, and a crash or storage failure in one instance never touches another.

Identity works like native Cloudflare: `this.ctx.id.name` is the instance key you dispatched with (`X-Rork-DO-Id`), and `this.ctx.id.toString()` is a stable 64-hex id — see "Knowing your own instance key" below.

Two consequences are **not** invisible:

- **The native alarm API is replaced** — `ctx.storage.setAlarm` throws and `alarm()` never fires. Alarms work through `env.DO.setAlarm(...)` and an `onAlarm()` handler instead — see "Alarms: schedule via `env.DO`" below before designing anything around scheduled work.
- **`fetch("do://...")` does not work inside a DO** — global outbound fetch from a facet bypasses the platform's internal router. All DO→DO calls go through `this.env.DO`. See "DO → DO calls" below.

## You MUST re-export every DO class from `functions/index.ts`

The bundler (`bun build`) tree-shakes class declarations that aren't directly used or re-exported by the entrypoint. A side-effect import (`import "./chat-room"`) is **not enough** — the class will be dropped from the bundle, and the platform will fail to materialize it with `unknown DO class: ChatRoom` (HTTP 404 from the DO dispatcher).

Re-export every DO class from `functions/index.ts`:

```ts
// functions/index.ts
export { ChatRoom } from "./chat-room";
export { Presence } from "./presence";
// …your usual `export default { fetch }` below…
```

If you keep the DO class definition in the entrypoint itself, `export class ChatRoom extends DurableObject {}` is enough — it's already an export. The rule is that every DO class must reach the bundle's exports through `index.ts`.

## Dispatching to a DO: `env.DO` is the ONLY mechanism

```ts
// functions/index.ts
export { ChatRoom } from "./chat-room"; // re-export so the bundler keeps it

type Env = { DO: Fetcher };

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);

    if (url.pathname === "/chat" && request.headers.get("Upgrade") === "websocket") {
      const roomId = url.searchParams.get("room") ?? "lobby";
      // MUST use the 2-arg form. `new Request(request)` (1-arg) drops the
      // `Upgrade: websocket` header on workerd, leaving the client stuck on
      // CONNECTING. The 2-arg form copies headers (including Upgrade) intact.
      const wrapped = new Request(request.url, request);
      wrapped.headers.set("X-Rork-DO-Class", "ChatRoom");
      wrapped.headers.set("X-Rork-DO-Id", roomId);
      return env.DO.fetch(wrapped);
    }

    return new Response("not found", { status: 404 });
  },
} satisfies ExportedHandler<Env>;
```

Three things to know:

- `X-Rork-DO-Class` (`ChatRoom`) must match the **exported** class name in `functions/index.ts`. If you re-exported with a rename (`export { ChatRoom as Lobby }`), use the renamed name.
- `X-Rork-DO-Id` is whatever string keys your instances — a room slug, a user id, a document id, etc. Same id = same DO instance, with its own storage and WebSocket peers. Inside the instance it comes back as `this.ctx.id.name`, exactly like native `idFromName`. Project scope is implicit, so two different projects with the same id never collide.
- The DO sees the wrapped request unchanged: same URL, method, headers, body. WebSocket upgrade headers and 101-upgrade responses ride along (the `env.DO` transport preserves `Response.webSocket`, unlike the public-Internet outbound path).

## DO → DO calls: `this.env.DO`, same headers

The same `env.DO` binding is available **inside** DO classes via `this.env` — it is the one and only way to call another DO:

```ts
// Inside a DO class: report this room to a directory DO.
type Env = { DO: Fetcher };

export class GameRoom extends DurableObject<Env> {
  private reportToDirectory(players: number): void {
    const request = new Request("https://internal/report", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Rork-DO-Class": "RoomDirectory",
        "X-Rork-DO-Id": "global",
      },
      body: JSON.stringify({ roomId: this.ctx.id.name, players }),
    });
    this.ctx.waitUntil(
      this.env.DO.fetch(request).catch((err: unknown) => console.warn("directory report failed", err)),
    );
  }
}
```

The URL host is arbitrary (`https://internal/` is a readable convention) — routing is driven entirely by the two headers; the target DO sees the path (`/report` here).

### The `do://internal/...` scheme is legacy — NEVER use it

Older Rork bundles used `fetch("do://internal/<Class>/<id>/<path>")` for DO→DO calls. Do not emit it in new code:

- **Inside a DO it does not work at all.** A facet's global `fetch` bypasses the platform's internal router, so the call throws `TypeError: Fetch API cannot load: do://internal/...`.
- From the entrypoint it still resolves, but it cannot carry WebSocket upgrades and has no advantage over `env.DO`.

One mechanism everywhere: `env.DO.fetch` + `X-Rork-DO-Class` / `X-Rork-DO-Id`, from the entrypoint and from inside DOs alike.

### Never `await` a cross-DO call before returning a 101

A DO's `fetch()` handler that returns a 101 must complete promptly. Awaiting a cross-DO round trip first delays the upgrade and, if the call re-enters the same instance (or deadlocks on input gates), can wedge it entirely. If a successful upgrade needs to provision another DO, either:

- **Encode the setup data into the handshake / `matched` payload and lazily initialize on first hit.** Have the client carry the data on the next request (e.g. `/room/<id>?color=red&opponentId=…`) and let the target DO populate its state on first connect. First write wins, so a duplicated handshake can't overwrite a started game.
- **Defer the cross-DO call with `this.ctx.waitUntil(this.setup())`** so the 101 returns first and setup runs after.

```ts
// ❌ Holds the upgrade response until the cross-DO round-trip completes.
this.ctx.acceptWebSocket(server, ["waiting"]);
await this.env.DO.fetch(initRequest);
return new Response(null, { status: 101, webSocket: client });

// ✅ Return the 101 immediately; do the rest in the background or lazily.
this.ctx.acceptWebSocket(server, ["waiting"]);
this.ctx.waitUntil(this.tryMatch());
return new Response(null, { status: 101, webSocket: client });
```

See `examples/example-matchmaking-game.ts` for an end-to-end matchmaker + room pair that uses the lazy-init shape.

### Always use the 2-arg `new Request(url, request)` form

Cloning a Request via `new Request(request)` on workerd silently strips the `Upgrade: websocket` header (and a couple of other connection-managing headers). The result is that `env.DO.fetch(...)` no longer carries a WebSocket upgrade, the DO returns 426, and the client hangs on `CONNECTING`. Always use the 2-arg form `new Request(url, request)` — it preserves the headers you need:

```ts
// ❌ Drops Upgrade header on WS upgrades.
const wrapped = new Request(request);

// ✅ Preserves Upgrade and every other header.
const wrapped = new Request(request.url, request);
```

If you need to mutate the URL (e.g. add a query parameter), build the new URL first and pass it:

```ts
const url = new URL(request.url);
url.searchParams.set("userId", userId);
const wrapped = new Request(url.toString(), request);
```

Incoming `Request.headers` can also be immutable depending on where the request was minted. The 2-arg `new Request(url, request)` form gives you a fresh request with mutable headers; if you only have the original incoming `Request`, copy the headers into a `new Headers(request.headers)` before mutating instead of writing through `request.headers.set(...)` directly.

## Room discovery: default to a rooms list or auto-match, never code exchange alone

When building multiplayer, do NOT make "create a room and share the code" the only way to play together. Manually exchanged codes need an out-of-band channel, make the app feel empty, and are the most common thing users push back on. Default to one (or both) of:

- **Auto-matchmaking** — a queue DO pairs players and hands each one the room id. Full pattern in `examples/example-matchmaking-game.ts`.
- **Rooms list (server browser)** — a directory DO tracks open rooms; the join screen lists them and a tap joins. Pattern below.

A private "play with a friend" room with a shareable code or link is fine as a secondary option — just never the primary flow.

### Rooms directory pattern

One singleton `RoomDirectory` instance (id `"global"`) keeps a SQLite row per open room. Rooms self-report through `this.env.DO` (see "DO → DO calls" above — the `reportToDirectory` snippet is exactly this shape):

- on every player join/leave and on status changes (`open` → `live` when the match starts),
- plus a periodic refresh (~once a minute) while peers are connected — piggyback it on the re-armed `setTimeout` heartbeat from "Alarm vs in-memory timers" instead of adding a second timer.

Reports are fire-and-forget: `this.ctx.waitUntil(this.env.DO.fetch(...))`, never awaited in the upgrade path.

```ts
// functions/room-directory.ts
import { DurableObject } from "cloudflare:workers";

type RoomReport = {
  roomId: string;
  status: "open" | "live";
  playerNames: string[];
  playerCount: number;
  maxPlayers: number;
};

export class RoomDirectory extends DurableObject {
  constructor(ctx: DurableObjectState, env: unknown) {
    super(ctx, env);
    this.ctx.storage.sql.exec(`
      CREATE TABLE IF NOT EXISTS rooms (
        room_id TEXT PRIMARY KEY,
        status TEXT NOT NULL,
        player_names TEXT NOT NULL,
        player_count INTEGER NOT NULL,
        max_players INTEGER NOT NULL,
        last_seen_at INTEGER NOT NULL
      )
    `);
  }

  override async fetch(request: Request): Promise<Response> {
    const url = new URL(request.url);

    if (request.method === "POST" && url.pathname === "/report") {
      const report = (await request.json()) as RoomReport;
      if (report.playerCount === 0) {
        // An emptied room removes itself instead of waiting for the TTL.
        this.ctx.storage.sql.exec("DELETE FROM rooms WHERE room_id = ?", report.roomId);
      } else {
        this.ctx.storage.sql.exec(
          `INSERT INTO rooms (room_id, status, player_names, player_count, max_players, last_seen_at)
           VALUES (?, ?, ?, ?, ?, ?)
           ON CONFLICT(room_id) DO UPDATE SET
             status = excluded.status,
             player_names = excluded.player_names,
             player_count = excluded.player_count,
             max_players = excluded.max_players,
             last_seen_at = excluded.last_seen_at`,
          report.roomId,
          report.status,
          JSON.stringify(report.playerNames),
          report.playerCount,
          report.maxPlayers,
          Date.now(),
        );
      }
      return Response.json({ ok: true });
    }

    if (request.method === "GET" && url.pathname === "/rooms") {
      // Lazy TTL eviction on read — rooms that stopped reporting (crashed,
      // evicted, abandoned) disappear without any scheduled cleanup. See
      // "Deferred cleanup / TTL state" under "Alarm vs in-memory timers".
      this.ctx.storage.sql.exec("DELETE FROM rooms WHERE last_seen_at < ?", Date.now() - 2 * 60_000);
      const rooms = this.ctx.storage.sql
        .exec("SELECT room_id, status, player_names, player_count, max_players FROM rooms ORDER BY last_seen_at DESC")
        .toArray();
      return Response.json({ rooms });
    }

    return new Response("not found", { status: 404 });
  }
}
```

The entrypoint exposes `GET /rooms` as a plain HTTP route (no WebSocket) by dispatching to `RoomDirectory` / `"global"` with the usual `X-Rork-DO-Class` / `X-Rork-DO-Id` headers.

Client side:

- Poll `GET /rooms` every few seconds while the join screen is visible (a plain `setInterval` fetch is fine — no WebSocket needed for the list).
- Render each room with its name(s), `playerCount/maxPlayers`, and a derived status: `open`, `live` (match running), or `full` (`playerCount === maxPlayers`). Show `live`/`full` rooms but disable joining them.
- A tap joins directly: the listed `roomId` is the `X-Rork-DO-Id` for the room route — no code entry anywhere in the happy path.

## Hibernation API (recommended for WS)

```ts
this.ctx.acceptWebSocket(server);
// The DO can sleep with sockets attached. webSocketMessage / webSocketClose
// fire when traffic resumes — no need to keep the DO in memory.
```

Use `serializeAttachment` / `deserializeAttachment` to remember per-socket data across hibernation:

```ts
override async fetch(request: Request): Promise<Response> {
  // ...
  this.ctx.acceptWebSocket(server);
  const userId = new URL(request.url).searchParams.get("userId") ?? "guest";
  server.serializeAttachment({ userId });
  return new Response(null, { status: 101, webSocket: client });
}

override webSocketMessage(ws: WebSocket, message: string | ArrayBuffer): void {
  const { userId } = ws.deserializeAttachment() as { userId: string };
  // ...
}
```

### Inside `webSocketMessage`, the request is gone

The example above isn't optional plumbing — the `WebSocket` passed to `webSocketMessage` / `webSocketClose` / `webSocketError` has no `ws.url` (it's `null` on the server side of a `WebSocketPair`), no headers, and no query string. Any per-connection context the handler needs MUST be captured at upgrade time via `server.serializeAttachment(...)`.

```ts
// ❌ Throws: ws.url is null, `new URL(null)` is a TypeError that aborts
// webSocketMessage before any broadcast or storage write.
const userId = new URL(ws.url).searchParams.get("userId") ?? "guest";
```

### Knowing your own instance key: `this.ctx.id.name`

Same contract as native Cloudflare `idFromName`: inside a user DO, `this.ctx.id.name` is exactly the `X-Rork-DO-Id` string the instance was dispatched with, and `this.ctx.id.toString()` is a stable 64-hex id.

```ts
export class GameRoom extends DurableObject<Env> {
  override async fetch(request: Request): Promise<Response> {
    const roomId = this.ctx.id.name; // === the X-Rork-DO-Id used to reach this instance
    // ...
  }
}
```

It is available everywhere in the class — `fetch`, `webSocketMessage`, timers — with no plumbing, so it's the right way to know "which room am I" in handlers where the original request is long gone (e.g. when a hibernated WebSocket wakes up).

Per-**connection** context (userId, color, joinedAt) is different: that is not the DO's identity, and it must still be captured at upgrade time via `server.serializeAttachment(...)` — see "Inside `webSocketMessage`, the request is gone" above.

## Reading env vars and secrets

DOs see the same project envs as the entrypoint via `this.env`. Type the `env` argument on the constructor (or on the class generic) and read values directly:

```ts
type Env = { STRIPE_SECRET_KEY: string };

export class Billing extends DurableObject<Env> {
  override async fetch(_req: Request): Promise<Response> {
    const r = await fetch("https://api.stripe.com/v1/charges", {
      headers: { Authorization: `Bearer ${this.env.STRIPE_SECRET_KEY}` },
    });
    return r;
  }
}
```

Env changes propagate on the next dispatch — already-materialized DOs pick up the new values without code redeploy. See `worker.md` → "Env vars and secrets" for the full rules.

## Persistent SQLite storage

Every DO has its own SQLite database via `this.ctx.storage.sql`:

```ts
constructor(ctx: DurableObjectState, env: unknown) {
  super(ctx, env);
  this.ctx.storage.sql.exec(`
    CREATE TABLE IF NOT EXISTS messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT NOT NULL,
      text TEXT NOT NULL,
      ts INTEGER NOT NULL
    )
  `);
}

private appendMessage(userId: string, text: string): void {
  this.ctx.storage.sql.exec(
    "INSERT INTO messages (user_id, text, ts) VALUES (?, ?, ?)",
    userId, text, Date.now(),
  );
}

private recentMessages(limit = 50): { userId: string; text: string; ts: number }[] {
  return this.ctx.storage.sql
    .exec<{ user_id: string; text: string; ts: number }>(
      "SELECT user_id, text, ts FROM messages ORDER BY id DESC LIMIT ?",
      limit,
    )
    .toArray()
    .map((r) => ({ userId: r.user_id, text: r.text, ts: r.ts }));
}
```

Limits: 1 GB per DO storage, 2 MB per row.

Treat this as a per-object database, not a global Postgres replacement. Good fits:

- `ChatRoom:<roomId>` stores room messages and connected peer metadata.
- `GameRoom:<matchId>` stores moves, clocks, player assignments, and final results.
- `Document:<documentId>` stores edit history, snapshots, and current collaborators.
- `ProjectState:<projectId>` stores project-scoped queues, lightweight settings, and scheduled work.

Poor fits:

- Queries that need to join or aggregate across all rooms/users/projects.
- Admin reporting over large global datasets.
- Client-direct table access guarded by SQL RLS policies.

For those, use Supabase Postgres behind a Cloudflare Worker or direct RLS access for very thin CRUD.

## Alarms: schedule via `env.DO`, handle via `onAlarm()`

The native alarm API does not work inside user DO classes — they run as facets (see "How instances are hosted"), and a facet calling `ctx.storage.setAlarm(...)` fails at runtime (`Facets currently cannot set alarms`; the throw can escape the facet's own `try`/`catch` and fail the whole invocation as an opaque internal error). `getAlarm()` / `deleteAlarm()` are equally off-limits, and an `override async alarm()` handler will never be invoked. Do not write any of them.

Alarms ARE available through the platform instead. The `env.DO` binding carries three RPC methods alongside `fetch`:

```ts
type Env = {
  DO: Fetcher & {
    setAlarm(className: string, id: string, scheduledTime: number | Date): Promise<void>;
    getAlarm(className: string, id: string): Promise<number | null>;
    deleteAlarm(className: string, id: string): Promise<void>;
  };
};
```

Semantics match native Cloudflare alarms exactly: **one** pending alarm per `(className, id)` instance, a later `setAlarm` overwrites it, a past `scheduledTime` fires immediately, the alarm survives eviction, hibernation, and redeploys (it always runs the **current** code), and delivery is at-least-once with automatic retries — write the handler idempotently.

The handler is a method named `onAlarm` on the DO class (NOT `alarm` — that name is reserved by the runtime and cannot be reached on Rork):

```ts
// functions/reminder.ts
import { DurableObject } from "cloudflare:workers";

type Env = {
  DO: Fetcher & {
    setAlarm(className: string, id: string, scheduledTime: number | Date): Promise<void>;
    getAlarm(className: string, id: string): Promise<number | null>;
    deleteAlarm(className: string, id: string): Promise<void>;
  };
};

export class Reminder extends DurableObject<Env> {
  override async fetch(request: Request): Promise<Response> {
    const { text, delayMs } = (await request.json()) as { text: string; delayMs: number };
    await this.ctx.storage.put("text", text);
    // Schedule this instance's own alarm: the class name is this class,
    // the id is this instance's own key.
    await this.env.DO.setAlarm("Reminder", this.ctx.id.name ?? "", Date.now() + delayMs);
    return Response.json({ ok: true });
  }

  // Fires when the alarm comes due — even if nothing else ever talks to
  // this instance. May run more than once (retries); keep it idempotent.
  async onAlarm(info: { scheduledTime: number; retryCount: number; isRetry: boolean }): Promise<void> {
    const text = await this.ctx.storage.get<string>("text");
    if (info.isRetry) console.warn(`reminder retry #${info.retryCount}`);
    // ...deliver the reminder (push, outbound fetch, write a row)...
    console.log("reminder due:", text);
  }
}
```

Notes:

- **`onAlarm` is required for delivery.** Scheduling an alarm for a class that doesn't implement `onAlarm` consumes the alarm with a runtime-log error — it is not retried.
- **Schedule from anywhere.** The entrypoint Worker can arm an alarm for any instance (`env.DO.setAlarm("Reminder", userId, when)`) without that instance being awake — this is how "send a reminder in 2 hours even if nobody connects" works. Inside a DO, use `this.env.DO` and `this.ctx.id.name` for self-scheduling (see "Knowing your own instance key").
- **A throwing `onAlarm` is retried** by the native alarm machinery with backoff; a handler that returns normally consumes the alarm. Re-arm from inside `onAlarm` (`setAlarm` again) for recurring schedules.
- **Errors in `setAlarm` arguments throw back at the call site** (empty class/id, non-finite time) — they reject the RPC promise, not the request.

### Alarm vs in-memory timers

Alarms are for durable, low-frequency scheduling. For high-frequency periodic work **while clients are connected** (heartbeats every few seconds, stale-peer eviction, periodic broadcast), prefer `setTimeout` / `setInterval` — a pending timer keeps the DO resident (see "What keeps a DO alive"), fires with no RPC hop, and costs no DO invocation per tick:

```ts
private heartbeatHandle: ReturnType<typeof setTimeout> | null = null;

private ensureHeartbeat(): void {
  if (this.heartbeatHandle !== null || this.ctx.getWebSockets().length === 0) return;
  this.heartbeatHandle = setTimeout(() => {
    this.heartbeatHandle = null;
    this.tick(); // broadcast, evict stale peers, ...
    this.ensureHeartbeat(); // re-arm while peers remain
  }, 5_000);
}
```

Call `ensureHeartbeat()` from `fetch()` after `acceptWebSocket(...)` **and** from `webSocketMessage` (in-memory timers are gone after a hibernation wake — the message handler re-arms). Clear the handle in `webSocketClose` when the last peer leaves. A pending timer blocks hibernation, so only keep one armed while there is a live reason to stay awake (connected peers), and always stop it when the object goes idle — switch to an alarm (or nothing) once the room empties.

**Deferred cleanup / TTL state** ("evict entries older than N minutes") usually doesn't need a schedule at all — do it lazily on the next entry: store timestamps in SQLite and drop expired rows at the start of the next `fetch()` / `webSocketMessage`. Reach for an alarm only when the cleanup must happen even with zero inbound traffic.

## What keeps a DO alive

A DO stays resident (no hibernation, no eviction) while any of these are true:

- Active request in flight
- In-flight `fetch()` or `ctx.storage` I/O
- Outstanding `setTimeout` / `setInterval`
- A non-hibernated WebSocket (sockets attached via `acceptWebSocket` survive hibernation; bare WS do not)

Otherwise it hibernates or, after 70–140s of full inactivity, evicts entirely. On eviction all instance fields are lost — re-hydrate from storage on entry (constructor + `blockConcurrencyWhile` is the canonical pattern).

## Persistence performance: `ctx.storage` in the hot path

Storage writes (`put`, `sql.exec`) are durable but not free. Output gates make this worse: any outgoing I/O (`ws.send`, `fetch`, `Response`) is automatically held until in-flight writes are confirmed, so dropping `await` does **not** skip the wait — the broadcast still blocks behind the pending put.

Two ways to remove storage from the user-visible path:

**Option 1 — `{ allowUnconfirmed: true }`**

```ts
this.broadcast({ ... });
this.ctx.storage.put(STATE_KEY, state, { allowUnconfirmed: true });
```

- Advantage: every mutation still hits storage; only the output gate is skipped.
- Trade-off: if the DO crashes between broadcast and write, that write is lost — clients still have their copy. Use for high-frequency, non-critical state (multiplayer moves, presence). Never for billing/auth.

**Option 2 — coalescing `setTimeout` + `ctx.waitUntil`**

Schedule a flush once and merge subsequent mutations into the same pending flush — do **not** restart the timer on every mutation, or a busy stream would keep pushing the flush out and nothing would ever persist.

```ts
if (!this.flushHandle) {
  this.flushHandle = setTimeout(() => {
    this.flushHandle = undefined;
    this.ctx.waitUntil(this.ctx.storage.put(STATE_KEY, this.state));
  }, 150);
}
```

- Advantage: bounds writes to at most one per window; the pending timer itself keeps the DO resident, so the flush is guaranteed to fire (idle eviction cannot swallow it — eviction waits for the timer).
- Trade-off: up to one window's worth of state can be lost on a hard crash. If even that window is unacceptable, write synchronously with `{ allowUnconfirmed: true }` (Option 1) instead — an alarm can't recover state that never reached storage.

## Adding a DO class to an existing bundle

1. Create `functions/<class-name>.ts` and `export class FooBar extends DurableObject`.
2. Re-export it from `functions/index.ts`: `export { FooBar } from "./foo-bar";`. **Do not** use a side-effect import (`import "./foo-bar"`) — the bundler will tree-shake the class.
3. From the entrypoint, dispatch into it by stamping `X-Rork-DO-Class: FooBar` and `X-Rork-DO-Id: <instance-key>` on a wrapped request (using `new Request(request.url, request)`) and calling `env.DO.fetch(wrapped)`.
4. Run `runChecks` on the cloudflare app — the redeploy includes the new class automatically.

There's no `wrangler.jsonc` migration step because the user's bundle has no migrations of its own; class additions and removals are purely content-level.

## Examples

- `examples/example-chat-room.ts` — chat DO + entrypoint dispatch
- `examples/example-presence.ts` — presence DO with hibernation + timer-driven heartbeat + broadcast
- `examples/example-matchmaking-game.ts` — matchmaking queue + one game-room DO per match, using `ctx.waitUntil` to keep the upgrade path free of cross-DO calls and lazy room init on the first `/room/<id>` connect
