# Auth — optional Rork Auth

The platform handles optional Rork Auth before your function runs:

If the request has `Authorization: Bearer <jwt>`, the platform verifies the token against Rork Auth and stamps `X-Rork-User-Id`, `X-Rork-User-Email`, `X-Rork-User-Name` on the forwarded request. **On any failure** (missing, invalid, expired, wrong audience) the platform silently drops the token; the request still reaches your function with no user headers.

Your function's job is to read the headers and decide what to do.

## Reading user identity

```ts
export default {
  async fetch(request: Request): Promise<Response> {
    const userId = request.headers.get("X-Rork-User-Id");
    if (!userId) {
      return new Response("sign in first", { status: 401 });
    }

    const email = request.headers.get("X-Rork-User-Email") ?? null;
    const name = request.headers.get("X-Rork-User-Name") ?? null;

    return Response.json({ userId, email, name });
  },
};
```

Header smuggling is impossible — the platform strips inbound `X-Rork-User-*` headers from the client and only re-injects them when the JWT actually verifies.

## Public vs signed-in routes

There is no `requireAuth` flag. The function decides per-route:

```ts
const userId = request.headers.get("X-Rork-User-Id");

if (url.pathname === "/random-quote") {
  // Public — works for guests.
  return Response.json({ quote: pickRandomQuote() });
}

if (url.pathname === "/whoami") {
  if (!userId) return new Response("sign in first", { status: 401 });
  return Response.json({ userId });
}
```

## When to verify the JWT yourself

For most apps the platform headers are enough. Verify the JWT directly when:

- Your project switched to a different auth provider.
- You distrust the platform headers and want defense in depth.
- You're embedding identity claims (`role`, `tier`) into the token that the platform headers don't surface.

```ts
import { jwtVerify, createRemoteJWKSet } from "jose";

const JWKS = createRemoteJWKSet(new URL("https://api.rork.com/.well-known/jwks.json"));
const ISSUER = "https://api.rork.com";

async function verifyRorkToken(token: string, expectedAud: string) {
  const { payload } = await jwtVerify(token, JWKS, {
    issuer: ISSUER,
    audience: expectedAud,
    algorithms: ["RS256"],
  });
  return {
    userId: payload.sub,
    email: typeof payload["email"] === "string" ? payload["email"] : undefined,
    name: typeof payload["name"] === "string" ? payload["name"] : undefined,
  };
}

// in fetch(request, env):
const auth = request.headers.get("Authorization");
const token = auth?.startsWith("Bearer ") ? auth.slice(7) : null;
const projectId = env.EXPO_PUBLIC_PROJECT_ID;
if (!token) return new Response("sign in first", { status: 401 });
const claims = await verifyRorkToken(token, projectId).catch(() => null);
if (!claims?.userId) return new Response("invalid token", { status: 401 });
```

`jose` is small (~40 KB) and runs in Cloudflare Workers without extra config. Add it to `functions/package.json`:

```bash
cd functions && bun add jose
```

## Examples

- `examples/example-user-data.ts` — `/whoami` endpoint reading `X-Rork-User-Id`, with the inline-JWT-verify variant alongside.
