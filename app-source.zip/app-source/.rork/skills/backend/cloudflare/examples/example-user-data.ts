// functions/index.ts — /whoami endpoint.
//
// Reads the verified user identity that the platform stamps on the request
// when a valid Rork Auth bearer token was attached. Falls back to "guest"
// when there's no signed-in user — never returns 401 implicitly.

const ISSUER = "https://api.rork.com";

export default {
  async fetch(request: Request): Promise<Response> {
    const url = new URL(request.url);

    if (url.pathname === "/whoami" && request.method === "GET") {
      // Trusting platform headers is the simple path:
      const userId = request.headers.get("X-Rork-User-Id");
      if (!userId) {
        return Response.json({ signedIn: false }, { status: 200 });
      }
      return Response.json({
        signedIn: true,
        userId,
        email: request.headers.get("X-Rork-User-Email"),
        name: request.headers.get("X-Rork-User-Name"),
      });
    }

    if (url.pathname === "/whoami-verified" && request.method === "GET") {
      // Verifying the JWT yourself — see auth.md "When to verify the JWT yourself"
      // for when this is worth doing.
      const token = request.headers.get("Authorization")?.replace(/^Bearer\s+/, "");
      if (!token) return Response.json({ signedIn: false }, { status: 200 });

      const projectId = url.hostname.split("-backend.")[0]!.split(":")[0]!;

      try {
        const { jwtVerify, createRemoteJWKSet } = await import("jose");
        const jwks = createRemoteJWKSet(new URL(`${ISSUER}/.well-known/jwks.json`));
        const { payload } = await jwtVerify(token, jwks, {
          issuer: ISSUER,
          audience: projectId,
          algorithms: ["RS256"],
        });
        return Response.json({ signedIn: true, userId: payload.sub, claims: payload });
      } catch {
        return Response.json({ signedIn: false }, { status: 200 });
      }
    }

    return new Response("not found", { status: 404 });
  },
};
