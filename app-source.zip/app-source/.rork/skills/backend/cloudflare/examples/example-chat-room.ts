// functions/chat-room.ts — Durable Object that backs a chat room.
//
// Pair this with a /chat route in functions/index.ts that calls
// `env.DO.fetch(wrapped)` with X-Rork-DO-Class: "ChatRoom" and
// X-Rork-DO-Id: <roomId> headers to dispatch the WebSocket upgrade
// into the right room instance.

import { DurableObject } from "cloudflare:workers";

type AttachedClient = {
  userId: string;
  joinedAt: number;
};

type ChatMessage = {
  type: "message";
  roomId: string;
  userId: string;
  text: string;
  ts: number;
};

export class ChatRoom extends DurableObject {
  constructor(ctx: DurableObjectState, env: unknown) {
    super(ctx, env);
    this.ctx.storage.sql.exec(`
      CREATE TABLE IF NOT EXISTS messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT NOT NULL,
        text TEXT NOT NULL,
        ts INTEGER NOT NULL
      )
    `);
  }

  override async fetch(request: Request): Promise<Response> {
    const url = new URL(request.url);

    // History fetch: GET /chat/messages?room=<id>. The entrypoint stamps the
    // X-Rork-DO-Class / X-Rork-DO-Id headers but leaves the URL alone, so the
    // DO sees the public-facing pathname.
    if (url.pathname === "/chat/messages" && request.method === "GET") {
      const rows = this.ctx.storage.sql
        .exec<{ user_id: string; text: string; ts: number }>(
          "SELECT user_id, text, ts FROM messages ORDER BY id DESC LIMIT 50",
        )
        .toArray()
        .reverse();
      return Response.json(rows.map((r) => ({ userId: r.user_id, text: r.text, ts: r.ts })));
    }

    // Otherwise it's the WebSocket upgrade for /chat.
    if (request.headers.get("Upgrade") !== "websocket") {
      return new Response("expected websocket", { status: 426 });
    }

    const pair = new WebSocketPair();
    const [client, server] = Object.values(pair);

    this.ctx.acceptWebSocket(server);

    // Per-connection context must be attached at upgrade time: the URL is
    // gone by webSocketMessage (ws.url is null on the server side of a
    // WebSocketPair). The room id needs no plumbing — it's always available
    // as `this.ctx.id.name` (the X-Rork-DO-Id this instance was keyed by).
    const userId = url.searchParams.get("userId") ?? "guest";
    server.serializeAttachment({ userId, joinedAt: Date.now() } satisfies AttachedClient);

    return new Response(null, { status: 101, webSocket: client });
  }

  override webSocketMessage(ws: WebSocket, raw: string | ArrayBuffer): void {
    if (typeof raw !== "string") return;
    const { userId } = ws.deserializeAttachment() as AttachedClient;
    const roomId = this.ctx.id.name ?? "lobby";

    this.ctx.storage.sql.exec("INSERT INTO messages (user_id, text, ts) VALUES (?, ?, ?)", userId, raw, Date.now());

    const broadcast: ChatMessage = { type: "message", roomId, userId, text: raw, ts: Date.now() };
    const payload = JSON.stringify(broadcast);
    for (const peer of this.ctx.getWebSockets()) peer.send(payload);
  }

  override webSocketClose(_ws: WebSocket, _code: number, _reason: string, _wasClean: boolean): void {
    // Optional: emit a "user left" broadcast.
  }
}

// functions/index.ts — entrypoint dispatching /chat to the ChatRoom DO.
//
// Two requirements, both load-bearing:
//   1. Re-export the DO class. `import "./chat-room"` is not enough — the
//      bundler tree-shakes the class definition. Re-exporting ensures the
//      class survives into the bundle so the platform can look it up.
//   2. Always wrap with the 2-arg `new Request(url, request)` form. The
//      1-arg form drops the Upgrade header on workerd and the WS upgrade
//      silently fails (client hangs on CONNECTING).
//
// `env.DO` is the platform-wired service binding that materializes the
// user-declared DO class identified by the X-Rork-DO-Class header on a
// per-instance facet keyed by X-Rork-DO-Id. Service-binding transport is
// WebSocket-aware, so 101 upgrade responses survive the round trip.

export { ChatRoom } from "./chat-room";

type Env = { DO: Fetcher };

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);

    if (url.pathname === "/chat" && request.headers.get("Upgrade") === "websocket") {
      const roomId = url.searchParams.get("room") ?? "lobby";
      const userId = request.headers.get("X-Rork-User-Id") ?? "guest";
      url.searchParams.set("userId", userId);

      const wrapped = new Request(url.toString(), request);
      wrapped.headers.set("X-Rork-DO-Class", "ChatRoom");
      wrapped.headers.set("X-Rork-DO-Id", roomId);
      return env.DO.fetch(wrapped);
    }

    if (url.pathname === "/chat/messages" && request.method === "GET") {
      const roomId = url.searchParams.get("room") ?? "lobby";
      const wrapped = new Request(request.url, request);
      wrapped.headers.set("X-Rork-DO-Class", "ChatRoom");
      wrapped.headers.set("X-Rork-DO-Id", roomId);
      return env.DO.fetch(wrapped);
    }

    return new Response("not found", { status: 404 });
  },
} satisfies ExportedHandler<Env>;
