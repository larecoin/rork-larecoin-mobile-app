// functions/presence.ts — Durable Object that tracks who's currently online
// for a given resource (e.g. a document, a room, a project).
//
// Highlights:
//   - Hibernation API so the DO can sleep with sockets attached.
//   - Per-socket attachment for userId so reconnecting sockets show up
//     under the correct identity.
//   - Timer-based heartbeat that re-emits the active set every 5s and
//     evicts stale entries. A 5s tick is timer territory, not alarm
//     territory (see durable-objects.md → "Alarm vs in-memory timers"):
//     the pending setTimeout keeps the object resident while peers are
//     connected and is re-armed from webSocketMessage after a hibernation
//     wake.

import { DurableObject } from "cloudflare:workers";

const HEARTBEAT_INTERVAL_MS = 5_000;
const STALE_AFTER_MS = 30_000;

type Attachment = {
  userId: string;
  lastSeen: number;
};

type PresenceMessage =
  | { type: "presence"; resource: string; users: { userId: string; lastSeen: number }[] }
  | { type: "user-joined"; userId: string }
  | { type: "user-left"; userId: string };

export class Presence extends DurableObject {
  // In-memory on purpose: timers don't survive hibernation or eviction, so
  // the handle resets to null exactly when the timer itself is gone. Re-armed
  // from fetch() and webSocketMessage().
  private heartbeatHandle: ReturnType<typeof setTimeout> | null = null;

  override async fetch(request: Request): Promise<Response> {
    if (request.headers.get("Upgrade") !== "websocket") {
      return new Response("expected websocket", { status: 426 });
    }

    const pair = new WebSocketPair();
    const [client, server] = Object.values(pair);

    this.ctx.acceptWebSocket(server);

    const url = new URL(request.url);
    // Per-connection identity goes in the attachment. The resource id is the
    // DO's own identity and needs no plumbing: it's `this.ctx.id.name` (the
    // X-Rork-DO-Id this instance was dispatched with).
    const userId = url.searchParams.get("userId") ?? "guest";
    server.serializeAttachment({ userId, lastSeen: Date.now() } satisfies Attachment);

    this.broadcast({ type: "user-joined", userId });
    this.broadcastSnapshot();
    this.ensureHeartbeat();

    return new Response(null, { status: 101, webSocket: client });
  }

  override webSocketMessage(ws: WebSocket, _message: string | ArrayBuffer): void {
    const att = ws.deserializeAttachment() as Attachment | null;
    if (!att) return;
    ws.serializeAttachment({ ...att, lastSeen: Date.now() } satisfies Attachment);
    // After a hibernation wake the in-memory timer is gone; the first
    // message through re-arms it.
    this.ensureHeartbeat();
  }

  override webSocketClose(ws: WebSocket): void {
    const att = ws.deserializeAttachment() as Attachment | null;
    if (att) this.broadcast({ type: "user-left", userId: att.userId });
    if (this.ctx.getWebSockets().length === 0) {
      this.stopHeartbeat();
    }
  }

  // setTimeout, not an alarm: a frequent tick that only matters while peers
  // are connected is timer work (ctx.storage.setAlarm would throw here
  // anyway — alarms go through env.DO, see durable-objects.md). The pending
  // timer keeps the DO resident, so the tick is guaranteed to fire;
  // stopHeartbeat() lets the empty room hibernate.
  private ensureHeartbeat(): void {
    if (this.heartbeatHandle !== null || this.ctx.getWebSockets().length === 0) return;
    this.heartbeatHandle = setTimeout(() => {
      this.heartbeatHandle = null;
      this.heartbeat();
    }, HEARTBEAT_INTERVAL_MS);
  }

  private stopHeartbeat(): void {
    if (this.heartbeatHandle === null) return;
    clearTimeout(this.heartbeatHandle);
    this.heartbeatHandle = null;
  }

  private heartbeat(): void {
    const now = Date.now();
    for (const peer of this.ctx.getWebSockets()) {
      const att = peer.deserializeAttachment() as Attachment | null;
      if (att && now - att.lastSeen > STALE_AFTER_MS) {
        peer.close(1000, "idle");
      }
    }
    if (this.ctx.getWebSockets().length > 0) {
      this.broadcastSnapshot();
      this.ensureHeartbeat();
    }
  }

  private broadcast(msg: PresenceMessage): void {
    const text = JSON.stringify(msg);
    for (const peer of this.ctx.getWebSockets()) peer.send(text);
  }

  private broadcastSnapshot(): void {
    const attachments = this.ctx
      .getWebSockets()
      .map((peer) => peer.deserializeAttachment() as Attachment | null)
      .filter((a): a is Attachment => a !== null);
    const users = attachments.map((a) => ({ userId: a.userId, lastSeen: a.lastSeen }));
    // The instance key (= X-Rork-DO-Id) lets clients connected to multiple
    // resources disambiguate which presence set this snapshot belongs to.
    const resource = this.ctx.id.name ?? "default";
    this.broadcast({ type: "presence", resource, users });
  }
}

// functions/index.ts — entrypoint dispatching /presence to the Presence DO.
//
// Two requirements, both load-bearing:
//   1. Re-export the DO class (side-effect imports get tree-shaken).
//   2. Always use the 2-arg `new Request(url, request)` form (the 1-arg form
//      drops the Upgrade header and the WS handshake silently fails).
//
// `env.DO` is the platform-wired service binding that materializes the
// user-declared DO class identified by X-Rork-DO-Class on a per-instance
// facet keyed by X-Rork-DO-Id. Service-binding transport is WebSocket-aware,
// so the 101 upgrade response from the DO survives the round trip.

export { Presence } from "./presence";

type Env = { DO: Fetcher };

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);

    if (url.pathname === "/presence" && request.headers.get("Upgrade") === "websocket") {
      const resource = url.searchParams.get("resource") ?? "default";
      const userId = request.headers.get("X-Rork-User-Id") ?? "guest";
      url.searchParams.set("userId", userId);

      const wrapped = new Request(url.toString(), request);
      wrapped.headers.set("X-Rork-DO-Class", "Presence");
      wrapped.headers.set("X-Rork-DO-Id", resource);
      return env.DO.fetch(wrapped);
    }

    return new Response("not found", { status: 404 });
  },
} satisfies ExportedHandler<Env>;
