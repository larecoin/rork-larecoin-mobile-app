// functions/matchmaker.ts — FIFO matchmaking for online games.
//
// This example pairs two players, sends each one a `matched` message with the
// room id, their color, and their opponent's id, then closes the matchmaking
// socket. The client reconnects to /room/<roomId>?color=...&opponentId=...
// and the GameRoom lazily initializes from those query params on first hit.
//
// Rork protocol notes:
//   - ALL DO dispatch goes through `env.DO.fetch(wrapped)` with
//     X-Rork-DO-Class / X-Rork-DO-Id headers — public routes, WebSocket
//     upgrades, and DO-to-DO calls (`this.env.DO` inside a DO). The legacy
//     `do://internal/...` scheme must never be used: inside a DO it throws
//     `Fetch API cannot load`.
//   - This Matchmaker NEVER awaits a cross-DO call before returning the 101
//     upgrade response — see durable-objects.md "Never `await` a cross-DO
//     call before returning a 101" for the antipattern callout.

import { DurableObject } from "cloudflare:workers";

type QueuedPlayer = {
  playerId: string;
  queuedAt: number;
};

type Color = "black" | "white";

type MatchMessage = {
  type: "matched";
  roomId: string;
  color: Color;
  opponentId: string;
};

export class Matchmaker extends DurableObject {
  override async fetch(request: Request): Promise<Response> {
    if (request.headers.get("Upgrade") !== "websocket") {
      return new Response("expected websocket", { status: 426 });
    }

    const url = new URL(request.url);
    const playerId = url.searchParams.get("playerId") ?? crypto.randomUUID();

    const pair = new WebSocketPair();
    const [client, server] = Object.values(pair);

    this.ctx.acceptWebSocket(server, ["waiting"]);
    server.serializeAttachment({ playerId, queuedAt: Date.now() } satisfies QueuedPlayer);

    // Return the 101 immediately; pair players in the background. Awaiting
    // here would hold this DO's input gate while tryMatch makes any
    // cross-facet call, blocking the second client's upgrade.
    this.ctx.waitUntil(this.tryMatch());

    return new Response(null, { status: 101, webSocket: client });
  }

  private async tryMatch(): Promise<void> {
    const waiting = this.ctx.getWebSockets("waiting");

    for (let i = 0; i + 1 < waiting.length; i += 2) {
      const a = waiting[i];
      const b = waiting[i + 1];
      if (!a || !b) continue;

      const aMeta = a.deserializeAttachment() as QueuedPlayer | null;
      const bMeta = b.deserializeAttachment() as QueuedPlayer | null;
      if (!aMeta || !bMeta) continue;

      const roomId = crypto.randomUUID();

      // Send each player everything the GameRoom needs to initialize itself
      // (color + opponent id) and let the room populate state on the first
      // /room WS connect. We deliberately make NO preflight init call to the
      // room — lazy init keeps it a single DO with no cross-DO HTTP at all.
      // (If a cross-DO call were needed, it would be `this.env.DO.fetch` with
      // the X-Rork headers inside ctx.waitUntil — never `do://internal/...`,
      // which does not work inside a DO.)
      sendMatched(a, {
        type: "matched",
        roomId,
        color: "black",
        opponentId: bMeta.playerId,
      });
      sendMatched(b, {
        type: "matched",
        roomId,
        color: "white",
        opponentId: aMeta.playerId,
      });

      // Closing drops both sockets from getWebSockets("waiting") so the next
      // pairing pass doesn't see stale entries.
      safeClose(a, "matched");
      safeClose(b, "matched");
    }
  }

  override webSocketClose(_ws: WebSocket): void {
    // Dropped sockets automatically disappear from ctx.getWebSockets("waiting").
  }
}

function sendMatched(ws: WebSocket, msg: MatchMessage): void {
  ws.send(JSON.stringify(msg));
}

function safeClose(ws: WebSocket, reason: string): void {
  try {
    ws.close(1000, reason);
  } catch {
    // The socket may already be gone.
  }
}

// functions/game-room.ts — 15x15 Gomoku room, one DO instance per game.
//
// The matchmaker does NOT preinitialize this room (see matchmaker.ts).
// Instead, players arrive on /room/<roomId>?playerId=<id>&color=<color>&
// opponentId=<id> carrying the data the matchmaker stamped into their
// `matched` message, and the first player to connect populates state.black /
// state.white. First write wins, so a duplicated matched payload can't
// overwrite a started game.

const SIZE = 15;

type Cell = Color | null;

type GameState = {
  board: Cell[][];
  turn: Color;
  black: string | null;
  white: string | null;
  winner: Color | "draw" | null;
  moves: number;
};

type PlayerAttachment = {
  playerId: string;
  color: Color | "spectator";
};

export class GameRoom extends DurableObject {
  override async fetch(request: Request): Promise<Response> {
    const url = new URL(request.url);

    if (request.headers.get("Upgrade") !== "websocket") {
      return new Response("expected websocket", { status: 426 });
    }

    const playerId = url.searchParams.get("playerId");
    if (!playerId) {
      return new Response("missing playerId", { status: 400 });
    }

    const state = await this.getState();
    await this.lazyInitFromConnect(state, url, playerId);

    const color: PlayerAttachment["color"] =
      state.black === playerId ? "black" : state.white === playerId ? "white" : "spectator";

    const pair = new WebSocketPair();
    const [client, server] = Object.values(pair);

    this.ctx.acceptWebSocket(server, [`player:${playerId}`, `color:${color}`]);
    server.serializeAttachment({ playerId, color } satisfies PlayerAttachment);
    // `this.ctx.id.name` is the X-Rork-DO-Id this room was dispatched with —
    // same contract as native `idFromName`.
    const roomId = this.ctx.id.name ?? "unknown";
    server.send(JSON.stringify({ type: "state", roomId, state, you: color }));

    return new Response(null, { status: 101, webSocket: client });
  }

  override async webSocketMessage(ws: WebSocket, raw: string | ArrayBuffer): Promise<void> {
    if (typeof raw !== "string") return;

    const attachment = ws.deserializeAttachment() as PlayerAttachment | null;
    if (!attachment || attachment.color === "spectator") return;

    let msg: unknown;
    try {
      msg = JSON.parse(raw);
    } catch {
      return;
    }

    if (isMoveMessage(msg)) {
      await this.handleMove(attachment.color, msg.x, msg.y);
      return;
    }

    if (isResignMessage(msg)) {
      await this.handleResign(attachment.color);
    }
  }

  private async getState(): Promise<GameState> {
    return (
      (await this.ctx.storage.get<GameState>("state")) ?? {
        board: Array.from({ length: SIZE }, () => Array<Cell>(SIZE).fill(null)),
        turn: "black",
        black: null,
        white: null,
        winner: null,
        moves: 0,
      }
    );
  }

  // Populate state.black / state.white the first time a player connects.
  // The matchmaker stamped color + opponentId into the `matched` payload; the
  // client carries them on /room/<roomId>?color=...&opponentId=... and the
  // first player to arrive populates the assignment. First write wins — a
  // duplicated matched message can't overwrite a started game.
  private async lazyInitFromConnect(state: GameState, url: URL, playerId: string): Promise<void> {
    if (state.black || state.white) return;

    const color = url.searchParams.get("color");
    const opponentId = url.searchParams.get("opponentId");
    if (color !== "black" && color !== "white") return;
    if (!opponentId || opponentId === playerId) return;

    if (color === "black") {
      state.black = playerId;
      state.white = opponentId;
    } else {
      state.black = opponentId;
      state.white = playerId;
    }
    await this.ctx.storage.put("state", state);
  }

  private async handleMove(color: Color, x: number, y: number): Promise<void> {
    const state = await this.getState();

    if (state.winner) return;
    if (state.turn !== color) return;
    if (!Number.isInteger(x) || !Number.isInteger(y)) return;
    if (x < 0 || x >= SIZE || y < 0 || y >= SIZE) return;
    if (state.board[y]?.[x]) return;

    state.board[y]![x] = color;
    state.moves += 1;

    if (checkWin(state.board, x, y, color)) {
      state.winner = color;
    } else if (state.moves === SIZE * SIZE) {
      state.winner = "draw";
    } else {
      state.turn = color === "black" ? "white" : "black";
    }

    await this.ctx.storage.put("state", state);
    this.broadcast({ type: "move", x, y, color, state });
  }

  private async handleResign(color: Color): Promise<void> {
    const state = await this.getState();
    if (state.winner) return;

    state.winner = color === "black" ? "white" : "black";
    await this.ctx.storage.put("state", state);
    this.broadcast({ type: "resign", color, state });
  }

  private broadcast(msg: unknown): void {
    const data = JSON.stringify(msg);
    for (const ws of this.ctx.getWebSockets()) {
      try {
        ws.send(data);
      } catch {
        // The socket may be mid-close.
      }
    }
  }
}

function isMoveMessage(value: unknown): value is { type: "move"; x: number; y: number } {
  return (
    typeof value === "object" &&
    value !== null &&
    "type" in value &&
    value.type === "move" &&
    "x" in value &&
    typeof value.x === "number" &&
    "y" in value &&
    typeof value.y === "number"
  );
}

function isResignMessage(value: unknown): value is { type: "resign" } {
  return typeof value === "object" && value !== null && "type" in value && value.type === "resign";
}

function checkWin(board: Cell[][], x: number, y: number, color: Color): boolean {
  const dirs: Array<[number, number]> = [
    [1, 0],
    [0, 1],
    [1, 1],
    [1, -1],
  ];

  for (const [dx, dy] of dirs) {
    let count = 1;

    for (let step = 1; step < 5; step += 1) {
      const nx = x + dx * step;
      const ny = y + dy * step;
      if (nx < 0 || nx >= SIZE || ny < 0 || ny >= SIZE) break;
      if (board[ny]?.[nx] !== color) break;
      count += 1;
    }

    for (let step = 1; step < 5; step += 1) {
      const nx = x - dx * step;
      const ny = y - dy * step;
      if (nx < 0 || nx >= SIZE || ny < 0 || ny >= SIZE) break;
      if (board[ny]?.[nx] !== color) break;
      count += 1;
    }

    if (count >= 5) return true;
  }

  return false;
}

// functions/index.ts — public routes for matchmaking and game rooms.
//
// Load-bearing requirements:
//   1. Re-export every DO class from the root entrypoint. Side-effect imports
//      like `import "./game-room"` are tree-shaken.
//   2. ALL DO dispatch — public routes, WS upgrades, DO-to-DO — goes through
//      `env.DO.fetch(...)` with the X-Rork headers. Never use the legacy
//      `fetch("do://internal/...")` scheme: it fails inside DOs and is not
//      WebSocket-safe.
//   3. Always use the 2-arg `new Request(url, request)` form when forwarding
//      an incoming WS request; `new Request(request)` drops Upgrade headers.
//   4. Never await a cross-DO call inside a DO's `fetch()` before returning
//      the 101 — defer with `ctx.waitUntil(...)` or move setup out of the
//      upgrade path entirely (matchmaker.ts and game-room.ts in this example
//      do the latter).

export { GameRoom } from "./game-room";
export { Matchmaker } from "./matchmaker";

type Env = { DO: Fetcher };

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);

    if (url.pathname === "/matchmake" && request.headers.get("Upgrade") === "websocket") {
      const playerId = request.headers.get("X-Rork-User-Id") ?? url.searchParams.get("playerId") ?? crypto.randomUUID();
      url.searchParams.set("playerId", playerId);

      return dispatchToDo(env, "Matchmaker", "global", new Request(url.toString(), request));
    }

    const roomMatch = url.pathname.match(/^\/room\/([^/]+)$/);
    if (roomMatch && request.headers.get("Upgrade") === "websocket") {
      const playerId = request.headers.get("X-Rork-User-Id") ?? url.searchParams.get("playerId");
      if (!playerId) {
        return new Response("missing playerId", { status: 400 });
      }
      url.searchParams.set("playerId", playerId);

      return dispatchToDo(env, "GameRoom", roomMatch[1]!, new Request(url.toString(), request));
    }

    return new Response("not found", { status: 404 });
  },
} satisfies ExportedHandler<Env>;

function dispatchToDo(env: Env, className: string, id: string, request: Request): Promise<Response> {
  // Copy headers into a fresh Headers before stamping the routing tags.
  // Incoming Request.headers can be immutable depending on where the request
  // was minted; copying is always safe and lets the helper work regardless
  // of whether the caller already 2-arg-wrapped the request.
  const headers = new Headers(request.headers);
  headers.set("X-Rork-DO-Class", className);
  headers.set("X-Rork-DO-Id", id);
  return env.DO.fetch(
    new Request(request.url, {
      method: request.method,
      headers,
      body: request.body,
      redirect: request.redirect,
    }),
  );
}
