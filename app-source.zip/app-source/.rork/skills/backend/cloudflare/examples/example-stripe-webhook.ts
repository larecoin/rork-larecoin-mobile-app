// functions/index.ts — Stripe webhook with signature verification.
//
// Configure the endpoint in the Stripe dashboard as
//   https://<projectId>-backend.rork.app/webhooks/stripe
// and set the signing secret + API key in the project envs UI:
//   STRIPE_WEBHOOK_SECRET=whsec_...
//   STRIPE_API_KEY=sk_...
//
// The body MUST be read raw (not parsed) for signature verification. Do not
// `await request.json()` first — read the text once and verify it.

// Stripe webhooks must be verified within 5 minutes of the timestamp to prevent
// replay attacks. During secret rotation Stripe sends multiple v1 signatures —
// one per active secret — so accept any match.
const STRIPE_TIMESTAMP_TOLERANCE_SEC = 300;

type Env = {
  STRIPE_WEBHOOK_SECRET: string;
  // STRIPE_API_KEY: string;  // pull from env the same way when making outbound calls to Stripe
};

async function verifyStripeSignature(payload: string, header: string, secret: string): Promise<boolean> {
  // Stripe-Signature: t=<timestamp>,v1=<signature>[,v1=<signature>...]
  const entries = header.split(",").map((kv) => {
    const [k, ...rest] = kv.split("=");
    return [k, rest.join("=")] as const;
  });
  const timestamp = entries.find(([k]) => k === "t")?.[1];
  const signatures = entries.filter(([k, v]) => k === "v1" && v).map(([, v]) => v);
  if (!timestamp || signatures.length === 0) return false;

  const ageSec = Math.floor(Date.now() / 1000) - Number(timestamp);
  if (!Number.isFinite(ageSec) || Math.abs(ageSec) > STRIPE_TIMESTAMP_TOLERANCE_SEC) return false;

  const signedPayload = `${timestamp}.${payload}`;
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  const sig = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(signedPayload));
  const computed = Array.from(new Uint8Array(sig))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");

  // Constant-time compare against every active v1 signature; succeed on any match.
  return signatures.some((candidate) => {
    if (computed.length !== candidate.length) return false;
    let mismatch = 0;
    for (let i = 0; i < computed.length; i++) mismatch |= computed.charCodeAt(i) ^ candidate.charCodeAt(i);
    return mismatch === 0;
  });
}

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);

    if (url.pathname === "/webhooks/stripe" && request.method === "POST") {
      const signature = request.headers.get("Stripe-Signature");
      if (!signature) return new Response("missing signature", { status: 400 });

      const secret = env.STRIPE_WEBHOOK_SECRET;
      if (!secret) {
        // Surface the misconfiguration in logs (visible via `getCloudflareLogs`)
        // and fail closed — never accept unverified webhook bodies.
        console.error("STRIPE_WEBHOOK_SECRET is not set in project envs");
        return new Response("server misconfigured", { status: 500 });
      }

      const payload = await request.text();
      const ok = await verifyStripeSignature(payload, signature, secret);
      if (!ok) return new Response("invalid signature", { status: 400 });

      let event: { type: string; data: { object: unknown } };
      try {
        event = JSON.parse(payload) as { type: string; data: { object: unknown } };
      } catch {
        return new Response("invalid json payload", { status: 400 });
      }
      switch (event.type) {
        case "checkout.session.completed":
          // Persist into a DO, fan-out to clients via WebSocket, etc.
          console.log("checkout completed:", event.data.object);
          break;

        case "customer.subscription.deleted":
          console.log("subscription cancelled:", event.data.object);
          break;
      }

      return new Response(null, { status: 200 });
    }

    return new Response("not found", { status: 404 });
  },
} satisfies ExportedHandler<Env>;
