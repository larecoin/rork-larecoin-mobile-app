# Supabase Backend — Native Supabase Auth

Use this guide when the project's auth model is **native Supabase Auth** (`backendStatus` reports `Auth model: native Supabase Auth`, or `getContext` reports `rorkAuthEnabled: false`). This is the model for email/password, magic links, phone OTP, and any auth method Rork Auth does not provide.

**One identity model per project.** Native Supabase Auth and Rork Auth cannot be mixed in one app — they produce different user IDs (`auth.users` UUIDs vs Rork `usr_xxx` IDs) and different RLS conventions. If the backend currently has Rork Auth enabled and the user wants email/password, call `disableRorkAuth` first (confirm with the user if the app already has signed-in users — identities do not carry over), then follow this guide for everything.

## Client Setup (React Native)

No `accessToken` callback and no SecureStore token sharing — supabase-js owns the session:

```typescript
import { createClient } from "@supabase/supabase-js";
import AsyncStorage from "@react-native-async-storage/async-storage";

const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL!;
const supabaseAnonKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY!;

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    storage: AsyncStorage,
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false,
  },
});
```

Create exactly ONE client. Never create a second client to work around an `accessToken` restriction — if you see `supabase.auth.signUp is not possible` the project is in Rork Auth mode and you must switch models (`disableRorkAuth`), not bypass the client.

## Sign Up / Sign In

```typescript
// Sign up (sends a confirmation email by default)
const { data, error } = await supabase.auth.signUp({ email, password });

// Sign in
const { data, error } = await supabase.auth.signInWithPassword({ email, password });

// Sign out
await supabase.auth.signOut();

// React to session changes (wire into your auth context/provider)
supabase.auth.onAuthStateChange((_event, session) => {
  setSession(session);
});
```

**Email confirmation caveat:** confirmation emails come from Supabase's built-in SMTP — heavily rate-limited and sent from a generic supabase.co address. Fine for prototyping; for production, the user should configure custom SMTP in the Supabase dashboard, or you can suggest disabling email confirmation for development.

## RLS — use `auth.uid()`

`auth.uid()` returns the signed-in user's UUID from the Supabase session. (`user_id()` is the Rork Auth helper — it is NOT installed in this mode; calling it fails.)

## Profiles Table

`auth.users` is real and populated in this mode. Reference it with a UUID FK and auto-create profile rows with a trigger:

```sql
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text,
  name text,
  avatar_url text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read profiles"
  ON profiles FOR SELECT USING (true);

CREATE POLICY "Users can insert own profile"
  ON profiles FOR INSERT
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- Auto-create a profile row on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, email)
  VALUES (new.id, new.email)
  ON CONFLICT (id) DO NOTHING;
  RETURN new;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
```

Other tables reference `profiles.id` (uuid):

```sql
CREATE TABLE IF NOT EXISTS posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id),
  title text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE posts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read all posts"
  ON posts FOR SELECT USING (true);

CREATE POLICY "Users can insert own posts"
  ON posts FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own posts"
  ON posts FOR UPDATE
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);
```

## Edge Functions

In this mode Supabase's standard JWT flow applies — create the user-scoped client from the request's Authorization header exactly as in `database.md`, but verify tokens with `supabase.auth.getUser()` instead of Rork's JWKS:

```typescript
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

export async function requireAuth(req: Request) {
  const authHeader = req.headers.get("Authorization") ?? "";
  const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!, {
    global: { headers: { Authorization: authHeader } },
  });
  const {
    data: { user },
    error,
  } = await supabase.auth.getUser();
  if (error || !user) throw new Error("Unauthorized");
  return { user, supabase };
}
```

Everything else in `database.md` (CORS, migrations discipline, debugging, error handling) applies unchanged.
