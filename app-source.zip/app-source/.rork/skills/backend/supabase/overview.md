---
name: supabase-backend
description: Use Supabase Postgres as the managed data layer for persistence,
  SQL, RLS, and rare Supabase-specific Edge Functions.
---

# Supabase Backend

Supabase provides a Postgres database with auto-generated REST APIs, Row Level Security (RLS), and Edge Functions.

The Supabase backend runs on a per-app instance managed by Rork. **Migrations and edge function deploys hit the live production database immediately.** There is no preview branch and no automatic rollback — be conservative.

## Auth Model — exactly one per project

A project uses exactly ONE identity model. Call `backendStatus` to see which one is active (it reports the live ref/URL, auth model, deployed functions, and CLI guidance):

- **Rork Auth** (`rorkAuthEnabled: true`): Google/Apple sign-in via Rork. Supabase accepts Rork JWTs through a third-party-auth registration. RLS uses `user_id()`, `supabase.auth.*` is disabled, `auth.users` is empty. Covered by `database.md` + the **auth** skill.
- **Native Supabase Auth** (`rorkAuthEnabled: false`): email/password, magic links, phone OTP, or the user's own auth setup. Standard supabase-js sessions, RLS uses `auth.uid()`, `auth.users` is real. Covered by `native-auth.md`.


Routing rule: the user wants Google/Apple sign-in → Rork Auth (the **auth** skill enables it on the backend automatically via `getOrCreateAuthConfig`). The user wants email/password or anything Rork Auth doesn't offer → native Supabase Auth. **Never mix the two** — if the project is on the wrong model, switch it explicitly with `enableRorkAuth` / `disableRorkAuth` (confirm with the user when existing signed-in users would be affected; identities don't carry over).

`runMigration` enforces the active model: it rejects `auth.uid()` on Rork Auth projects and `user_id()` on native-auth projects.

## Provisioning Workflow

1. Call `provisionBackend`. This shows a confirmation widget; once the user confirms, creation continues in the background and the tool returns immediately. Continue writing code while it provisions.
2. After calling `provisionBackend`, install client deps, create the Supabase client, write UI.
3. Before any database operation (`runMigration`, `getSchema`, `deployEdgeFunction`), call `waitTask` with the `generationId` returned by `provisionBackend`.
4. If `provisionBackend` returns `status: "ready"` (already provisioned), skip the wait — proceed straight to migrations.


`provisionBackend` also registers `backend/` in `rork.json` and sets these environment variables once provisioning completes:

- `EXPO_PUBLIC_SUPABASE_URL`
- `EXPO_PUBLIC_SUPABASE_ANON_KEY`


The widget gives the user two paths: **Create Rork Cloud** (Rork-managed, the default) or **Connect my Supabase** (a project from their own Supabase organization, authorized via OAuth). From the skill's point of view both return the same `status: "ready"` prelude and the rest of the workflow — migrations, schema reads, edge functions, type-gen — is identical. The only BYO-specific failure mode is that the user can revoke the OAuth grant from their Supabase dashboard; if a subsequent tool call surfaces `SUPABASE_RECONNECT_REQUIRED` / a 401 UNAUTHORIZED, tell the user to reopen `provisionBackend` and re-grant access — don't keep retrying.

A user can also **claim** a Rork-managed project — transferring it into their own Supabase org. If the `transferBackendToUserSupabase` tool is available (it only appears on rork-owned backends) and the user asks to own / take over / move their Supabase project, call it: it returns a URL the user opens and confirms in Supabase. If you don't have that tool, this project has no Rork-managed backend to transfer — tell them rather than improvising. A claimed project is just an ordinary BYO project afterward (same ref, URL, keys), so it needs no claim-specific behavior. Two transfer-specific failure strings can surface, and both mean stop and tell the user, not retry:

- `SUPABASE_CLAIM_IN_PROGRESS` — the transfer is mid-flight (the user is confirming it in Supabase). Backend actions are paused; wait for the transfer to finish, then retry.
- `SUPABASE_CLAIM_ORPHANED` — the transfer completed but the project was never reconnected to Rork, so Rork's access is gone. Tell the user to reconnect their Supabase (Connect Supabase → pick the same project) to continue.


## Supabase CLI

The `supabase` CLI is installed in the sandbox but is not authenticated by default — `supabase login` won't work. Authentication goes through a credential tool, and exactly one is in your tool list depending on who owns the backend:

- `refreshSupabaseToken` (user-owned backend): sets `SUPABASE_ACCESS_TOKEN`, fully authenticating the CLI — `supabase link --project-ref <ref>`, `db push`, `db pull`, `gen types --linked`, `functions deploy` all work.
- `getSupabaseDbUrl` (Rork-managed backend): sets a short-lived `SUPABASE_DB_URL`. `supabase link` is NOT available in this mode — always pass `--db-url "$SUPABASE_DB_URL"` to db commands, e.g. `supabase db pull --db-url "$SUPABASE_DB_URL"`.


Call the matching tool once before your first CLI command. The credentials expire — if a CLI command later fails with an auth or connection error, call the tool again and retry the command.

**Do not use the CLI unless the user explicitly asks for it, or the managed backend tools genuinely cannot do the job.** The managed tools (`runMigration`, `getSchema`, `deployEdgeFunction`, `fetchProjectLogs`) are the default for all backend work — they enforce the active auth model, regenerate `types.ts` automatically, and are safer against the live database. Legitimate CLI cases are things they don't cover, e.g. schema diffs (`db pull`, `db diff`) or an explicit user request for a CLI workflow.

## Files in this skill

The implementation differs per platform — read the file(s) matching the app you're working in:

| File              | Contents                                                                                                                                                                          |
| ----------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `database.md`     | Platform-agnostic database content: project structure, `user_id()` / profiles convention (Rork Auth mode), migrations, RLS patterns, edge functions (Deno TS), debugging, errors. |
| `native-auth.md`  | Native Supabase Auth mode: email/password client setup, `auth.uid()` RLS, profiles keyed to `auth.users`, edge function auth. Read when `rorkAuthEnabled: false`.                 |
| `react-native.md` | React Native / TypeScript client setup (Rork Auth mode), query syntax, error handling patterns.                                                                                   |
| `swift.md`        | Swift client setup (`SupabaseClient`, `nonisolated`/`Sendable` rules), query syntax, `functions.invoke()` overloads.                                                              |

`database.md` is required reading on every platform — the SQL, RLS, and edge function patterns are the same. The platform file then covers how the client talks to that database. In native Supabase Auth mode, `native-auth.md` overrides the auth-specific parts (client setup, RLS function, profiles shape).

## Important Notes

- **Every migration and edge function deploy is live immediately.** There is no dev branch, no preview, no automatic rollback.
- **Default to additive-only schema changes.**`CREATE TABLE`, `ALTER TABLE ... ADD COLUMN` (nullable or with default), `CREATE INDEX`, new RLS policies are safe to run without confirmation.
- **Ask the user before running anything destructive.** That includes `DROP TABLE`, `DROP COLUMN`, `ALTER COLUMN ... NOT NULL` without a backfill, type changes that reinterpret existing data, `DELETE`, `TRUNCATE`, and cascading drops.
- Use `IF NOT EXISTS` / `IF EXISTS` so a retried migration is safe. Keep each `runMigration` call to **one logical change** — if it fails partway, surface the error and stop instead of compounding more migrations on top.
- Always enable RLS on every table. Without it, data is publicly accessible.
- RLS user reference depends on the auth model: `user_id()` on Rork Auth projects, `auth.uid()` on native Supabase Auth projects. `runMigration` rejects the wrong one — call `backendStatus` to confirm the active model before writing policies.
- Use `getSchema` to inspect the current database structure before writing migrations.
- Rork Auth (Google/Apple) depends on the **auth** skill — set it up first. Email/password and other native methods follow `native-auth.md` instead.


## Available tools

### backendStatus

Read-only summary of the project's live Supabase backend: production ref & URL, the active auth model (Rork Auth vs native Supabase Auth), deployed edge functions, any undeployed edge-function changes, and how to use the Supabase CLI. Returns a not-provisioned notice when no backend exists yet. Call this to learn which backend you're working against before migrations, schema reads, deploys, RLS policies, or CLI commands.

```json
{"type":"object","properties":{}}
```

### provisionBackend

Show a Rork Cloud creation widget and wait for the user's confirmation before provisioning a Supabase backend for this app. Returns immediately after creation starts — provisioning continues in the background. Continue writing code (client setup, UI, etc.) while it provisions. Call waitTask with the returned generationId before any database operations (runMigration, getSchema, deployEdgeFunction). Safe to call multiple times — will not create duplicates.

```json
{"type":"object","properties":{"runInBackground":{"default":true,"description":"If true (default), schedules in background and returns a generationId; pair with waitTask. Set to false only when the caller really needs to block.","type":"boolean"}}}
```

### runMigration

Run a SQL migration on the live Supabase database. There is no preview branch and no automatic rollback — write small, additive migrations and use IF NOT EXISTS / IF EXISTS so retries are safe. Ask the user before running anything destructive (DROP TABLE/COLUMN, ALTER COLUMN ... NOT NULL on existing data, type changes, DELETE/TRUNCATE). Returns updated TypeScript types. Backend must be provisioned first. If provisionBackend returned status 'creating', call waitTask with the returned generationId first.

```json
{"type":"object","properties":{"name":{"type":"string","description":"Migration name (e.g. 'create-posts', 'add-user-avatar'). Use kebab-case."},"sql":{"type":"string","description":"The SQL migration to run. Use IF NOT EXISTS where possible."}},"required":["name","sql"]}
```

### getSchema

Get the current database schema (tables, columns, RLS policies) from the live Supabase database. Backend must be provisioned first. If provisionBackend returned status 'creating', call waitTask with the returned generationId first.

```json
{"type":"object","properties":{}}
```

### deployEdgeFunction

Deploy a Supabase Edge Function to the live Supabase project. The function will be available at the returned URL. The function source and any _shared/ modules it imports must already exist on disk — use WriteFile or MultiEdit to create them first. JWT verification is OFF at the gateway — functions must handle their own auth using the _shared/auth.ts helper (requireAuth, createUserClient, createAdminClient). Backend must be provisioned first. If provisionBackend returned status 'creating', call waitTask with the returned generationId first.

```json
{"type":"object","properties":{"filePath":{"type":"string","description":"Path to the edge function entrypoint, e.g. 'backend/functions/send-email/index.ts'."}},"required":["filePath"]}
```

### fetchProjectLogs

Fetch logs from the Supabase project for debugging.
Queries the Supabase analytics engine. By default queries edge_logs (API gateway logs).

Available log sources (use the sql parameter to query):
- edge_logs: API gateway / Edge Function invocation logs (default)
- postgres_logs: Database query logs
- auth_logs: Authentication event logs
- realtime_logs: Realtime subscription logs

Example SQL queries:
- Edge function errors: select timestamp, event_message, metadata from edge_logs where response.status_code >= 400
- Postgres errors: select timestamp, event_message from postgres_logs where parsed.error_severity = 'ERROR'
- Auth events: select timestamp, event_message, metadata from auth_logs

The timestamp range must be no more than 24 hours. If not provided, queries the last 1 minute.
Backend must be provisioned first.

```json
{"type":"object","properties":{"sql":{"description":"Custom SQL query for logs. If omitted, queries edge_logs. See description for examples.","type":"string"},"isoTimestampStart":{"description":"ISO 8601 start timestamp (e.g. '2025-01-15T00:00:00Z')","type":"string"},"isoTimestampEnd":{"description":"ISO 8601 end timestamp (e.g. '2025-01-15T01:00:00Z')","type":"string"}}}
```

### listEdgeFunctions

List all deployed Edge Functions for this Supabase project. Returns function slugs, statuses, and versions. Backend must be provisioned first.

```json
{"type":"object","properties":{}}
```

### enableRorkAuth

Register Rork Auth as a third-party auth provider on the project's Supabase backend so Rork JWTs are accepted and user_id() works in RLS. Call when the app adopts Rork Auth (Google/Apple sign-in) and the backend was provisioned without it (getContext reports rorkAuthEnabled: false). Refuses if the Supabase project already uses native Supabase Auth (existing auth.users rows or auth.uid() policies) — one identity model per project, never both. Backend must be provisioned first.

```json
{"type":"object","properties":{}}
```

### disableRorkAuth

Remove the Rork Auth third-party registration from the project's Supabase backend, switching it to native Supabase Auth (auth.uid(), supabase.auth.*). Use when the user wants auth Rork Auth doesn't support (e.g. email/password) on a backend that currently has Rork Auth enabled. Confirm with the user first if the app already has Rork Auth users — their identities will not carry over. After disabling, rewrite existing RLS policies from user_id() to auth.uid() via runMigration and update the client/auth code to native Supabase Auth.

```json
{"type":"object","properties":{}}
```
