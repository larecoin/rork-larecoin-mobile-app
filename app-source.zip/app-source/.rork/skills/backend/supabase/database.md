# Supabase Backend — Database, RLS, Edge Functions

Platform-agnostic Supabase content. The SQL, RLS policies, edge function code (Deno TypeScript), and log queries here apply equally to React Native and Swift apps. The platform-specific guides (`react-native.md`, `swift.md`) cover only how the client talks to this backend.

The provisioning workflow lives in `SKILL.md`. Read it first. Run `provisionBackend` and wait for it to be ready before any of the database operations below.

## Project Structure

```
project/
├── backend/                  # Supabase backend artifacts
│   ├── types.ts              # Auto-generated DB types (do not edit)
│   └── functions/            # Edge function source
│       └── {slug}/
│           └── index.ts
├── <app folder>              # e.g. expo/, ios/, web/, android/
└── rork.json                 # Includes backend entry
```

For TypeScript apps (React Native, web), the auto-generated types are also copied to `<app>/src/integrations/supabase/types.ts`.

## User Profiles (`user_id()` instead of `auth.uid()`) — Rork Auth mode

**This section applies when the project's auth model is Rork Auth** (`backendStatus` reports `Auth model: Rork Auth`). When the model is native Supabase Auth, read `native-auth.md` instead — there `auth.uid()` is correct and `user_id()` does not exist. `runMigration` enforces whichever model is active.

In Rork Auth mode, Rork is registered as a third-party auth provider and Supabase's `auth.users` table is **empty** — there are no Supabase Auth sessions. The standard `auth.uid()` returns NULL for every Rork-signed-in user, so policies built on it silently reject everyone.

A custom `user_id()` function is installed when Rork Auth is enabled on the backend. It extracts the Rork user ID from the JWT's `sub` claim.

- Use `user_id()` in **all** RLS policies (returns the Rork user ID, e.g. `usr_xxx`)
- **Do NOT use `auth.uid()`** — it only works with native Supabase Auth
- **Never redefine `public.user_id()`** — overwriting it breaks the auth integration silently
- Create a `profiles` table as the canonical user table
- Upsert into `profiles` on app load so user data stays in sync

**First migration when the app has auth — create the `profiles` table:**

```sql
CREATE TABLE IF NOT EXISTS profiles (
  id text PRIMARY KEY,
  email text,
  name text,
  avatar_url text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read profiles"
  ON profiles FOR SELECT USING (true);

CREATE POLICY "Users can insert own profile"
  ON profiles FOR INSERT
  WITH CHECK (user_id() = id);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  USING (user_id() = id)
  WITH CHECK (user_id() = id);
```

Other tables reference `profiles.id`, **not** `auth.users.id`:

```sql
CREATE TABLE posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id text NOT NULL REFERENCES profiles(id),
  ...
);
```

After the user signs in, upsert into `profiles`. The platform file shows the client-side call.

## Migrations & RLS

Use the `runMigration` tool to create tables. Always include RLS policies in the same migration.

The `supabase` CLI is also available, but only use it when the user explicitly asks for it or when the managed tools can't do the job (e.g. schema diffs, `db pull`) — authenticate it first via the credential tool described in the "Supabase CLI" section of `overview.md`.

Example migration with RLS:

```sql
CREATE TABLE IF NOT EXISTS posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id text NOT NULL REFERENCES profiles(id),
  title text NOT NULL,
  content text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE posts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read all posts"
  ON posts FOR SELECT
  USING (true);

CREATE POLICY "Users can insert own posts"
  ON posts FOR INSERT
  WITH CHECK (user_id() = user_id);

CREATE POLICY "Users can update own posts"
  ON posts FOR UPDATE
  USING (user_id() = user_id)
  WITH CHECK (user_id() = user_id);

CREATE POLICY "Users can delete own posts"
  ON posts FOR DELETE
  USING (user_id() = user_id);
```

**Key RLS patterns (Rork Auth mode — see `native-auth.md` for the `auth.uid()` equivalents):**

- `user_id()` — the authenticated user's ID from Rork Auth (reads JWT `sub` claim). Installed when Rork Auth is enabled on the backend. **Do NOT use `auth.uid()`** — it only works with native Supabase Auth.
- `auth.jwt() ->> 'role'` — always `"authenticated"` for logged-in users
- Use `USING` for read/update/delete policies
- Use `WITH CHECK` for insert/update policies

## TypeScript Types

After running migrations, types are auto-generated and written to:

- `backend/types.ts`
- `<appPath>/src/integrations/supabase/types.ts` (copy in each TypeScript app folder)

These files are auto-generated — do not edit them manually. Run migrations to regenerate. Swift apps don't get a generated types file — define `Codable` models manually (see `swift.md`).

## Edge Functions

Use `deployEdgeFunction` for server-side logic. Edge functions run Deno. Source code is saved to `backend/functions/{slug}/index.ts` for version control.

Edge functions handle their own authentication — Supabase does not validate JWTs at the gateway. Use the shared `_shared/auth.ts` helper for consistent auth across functions.

**Secrets / environment variables:** Edge functions read secrets with `Deno.env.get("FOO")`. To supply a custom secret (Stripe key, etc.), set it as a project env var via the `requestEnvs` tool (or it may already be in the project env store), then call `syncEdgeFunctionSecrets` to push all project env vars into the edge function environment. Values are live immediately — no redeploy, no dashboard step. Never tell the user to add it in the Supabase dashboard; Rork-managed projects have no user dashboard access. `SUPABASE_URL`, `SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY`, and `SUPABASE_DB_URL` are auto-injected by Supabase — and any `SUPABASE_*` name is reserved — so don't request or set those. `deployEdgeFunction` scans the deployed code for `Deno.env.get(...)` names and warns when one has no Supabase secret yet — when you see such a warning, set the env var and run `syncEdgeFunctionSecrets`.

The helper below verifies **Rork Auth** JWTs against Rork's JWKS. In native Supabase Auth mode, use the `supabase.auth.getUser()` variant from `native-auth.md` instead.

**Shared auth helper** — deploy this first as `backend/functions/_shared/auth.ts`:

```typescript
import { jwtVerify, createRemoteJWKSet } from "https://deno.land/x/jose@v5.2.0/index.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const JWKS = createRemoteJWKSet(new URL("https://api.rork.com/.well-known/jwks.json"));

export class AuthError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "AuthError";
  }
}

export interface AuthUser {
  userId: string;
  email?: string;
  name?: string;
}

export async function requireAuth(req: Request): Promise<AuthUser> {
  try {
    const token = req.headers.get("Authorization")?.replace("Bearer ", "");
    if (!token) throw new Error("Missing token");

    const { payload } = await jwtVerify(token, JWKS, { issuer: "https://api.rork.com" });
    return {
      userId: payload.sub!,
      email: payload.email as string | undefined,
      name: payload.name as string | undefined,
    };
  } catch (err) {
    throw new AuthError(err instanceof Error ? err.message : "Authentication failed");
  }
}

export function createUserClient(req: Request) {
  return createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!, {
    global: { headers: { Authorization: req.headers.get("Authorization")! } },
  });
}

export function createAdminClient() {
  return createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
}
```

**CORS headers** — every edge function must include CORS headers and handle `OPTIONS` preflight requests, otherwise the app cannot call the function:

```typescript
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
};
```

**Authenticated edge function** (most common — requires a signed-in user):

```typescript
import { requireAuth, createUserClient, AuthError } from "../_shared/auth.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const user = await requireAuth(req);

    const supabase = createUserClient(req);
    const { data } = await supabase.from("posts").select("*");

    return new Response(JSON.stringify({ user: user.userId, data }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    if (err instanceof AuthError) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    console.error(err);
    return new Response(JSON.stringify({ error: "Internal server error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
```

**Auth-protected edge function with admin access** (e.g. user-triggered actions that need elevated privileges):

```typescript
import { requireAuth, createAdminClient, AuthError } from "../_shared/auth.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const user = await requireAuth(req);

    const supabaseAdmin = createAdminClient();
    const { data } = await supabaseAdmin.from("orders").update({ status: "paid" }).eq("user_id", user.userId);

    return new Response(JSON.stringify({ ok: true }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    if (err instanceof AuthError) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    console.error(err);
    return new Response(JSON.stringify({ error: "Internal server error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
```

**Key points:**

- Every edge function MUST include CORS headers and handle `OPTIONS` preflight — without this, the app cannot call the function.
- **Always auth-protect edge functions by default.** Only omit `requireAuth` for truly public endpoints like external webhooks with their own verification (e.g. Stripe signature checks).
- `requireAuth(req)` verifies the JWT signature against Rork's JWKS and returns user claims.
- `createUserClient(req)` creates a Supabase client scoped to the user (RLS applies).
- `createAdminClient()` uses the service role key — bypasses RLS, use only when RLS-scoped access is insufficient.
- The `_shared/` directory is bundled automatically by Supabase.

The platform file shows how to invoke an edge function from the client.

## Debugging

Use `fetchProjectLogs` to query Supabase logs when investigating issues. Available log sources:

- **edge_logs** (default): API gateway and Edge Function invocation logs
- **postgres_logs**: Database query and error logs
- **auth_logs**: Authentication event logs
- **realtime_logs**: Realtime subscription logs

Use the `sql` parameter for filtered queries:

```sql
-- Edge function errors
select timestamp, event_message, metadata from edge_logs where response.status_code >= 400

-- Postgres errors
select timestamp, event_message from postgres_logs where parsed.error_severity = 'ERROR'
```

Also available by running `rork-agent logs supabase` (optionally `--sql`, `--since`, `--until`) in the bash tool — see the debugging skill.

## Error Handling Principles

Every Supabase operation can fail (network issues, RLS denials, constraint violations). Handle errors explicitly:

- Always log Supabase operation failures so they are visible during development.
- Always show error UI (toast, alert, inline message) for all user-facing operations, not just auth flows.
- Never let a failed query silently swallow an error.

The exact pattern (return-tuple `{ data, error }` vs `do/catch`) is platform-specific — see the platform guide.
