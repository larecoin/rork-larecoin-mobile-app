# Supabase Backend — React Native / TypeScript

Read `database.md` first for the platform-agnostic database, RLS, and edge function content. This file covers only the client-side (`@supabase/supabase-js`) — how the React Native app talks to the backend documented there.

The client setup below is for **Rork Auth mode** (the `accessToken` callback feeds Rork JWTs to Supabase). In native Supabase Auth mode, use the session-based client from `native-auth.md` instead — never both.

## 1. Install Dependencies

```bash
bunx expo install @supabase/supabase-js
```

## 2. Create the Supabase Client

Create `lib/supabase.ts`:

```typescript
import { createClient } from "@supabase/supabase-js";
import * as SecureStore from "expo-secure-store";

const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL!;
const supabaseAnonKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY!;

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  global: {
    headers: {},
  },
  auth: {
    persistSession: false,
  },
  accessToken: async () => {
    const token = await SecureStore.getItemAsync("access_token");
    return token ?? undefined;
  },
});
```

The `accessToken` callback provides the Rork Auth JWT to Supabase. This token includes `role: "authenticated"` which Supabase uses for RLS.

**Important:** The auth skill's `useAuth` hook manages tokens in SecureStore. The Supabase client reads from the same store — no extra auth setup needed.

## 3. Sync the Profile Row

After the user signs in, upsert into `profiles` (table created in `database.md`):

```typescript
import { supabase } from "@/lib/supabase";

async function syncProfile(user: { id: string; email?: string; name?: string }) {
  await supabase.from("profiles").upsert({ id: user.id, email: user.email, name: user.name }, { onConflict: "id" });
}
```

## 4. Query Data

```typescript
import { supabase } from "@/lib/supabase";

// Select
const { data, error } = await supabase.from("posts").select("*").order("created_at", { ascending: false });

// Insert
const { data, error } = await supabase
  .from("posts")
  .insert({ title: "Hello", content: "World", user_id: user.id })
  .select()
  .single();

// Update
const { error } = await supabase.from("posts").update({ title: "Updated" }).eq("id", postId);

// Delete
const { error } = await supabase.from("posts").delete().eq("id", postId);
```

## 5. Use Generated Types

After running migrations, types are written to `<app>/src/integrations/supabase/types.ts`. Import them for type-safe queries:

```typescript
import { supabase } from "@/lib/supabase";
import type { Database } from "@/src/integrations/supabase/types";

type Post = Database["public"]["Tables"]["posts"]["Row"];
```

## 6. Invoke an Edge Function

The Supabase JS SDK's `functions.invoke()` returns `{ data, error }`. The edge function source lives in `backend/functions/{slug}/index.ts` (see `database.md` for how to write one):

```typescript
const { data, error } = await supabase.functions.invoke("process-data", {
  body: { input: "hello" },
});
if (error) {
  console.error("Edge function failed:", error);
  return;
}
```

## Error Handling Pattern

The JS SDK never throws on logical errors — it returns `{ data, error }`. Always check `error` before using `data`:

```typescript
const { data, error } = await supabase.from("posts").select("*");
if (error) {
  console.error("Failed to fetch posts:", error.message);
  // Show error to user
  return;
}
```

- Always add `onError` to `useMutation` hooks — never let Supabase errors be silently swallowed.
- Always `console.error` Supabase operation failures so they are visible during development.
- Always show error UI (toast, alert, inline message) for all user-facing operations, not just auth flows.
