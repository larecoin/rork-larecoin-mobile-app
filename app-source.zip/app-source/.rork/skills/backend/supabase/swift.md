# Supabase Backend — Swift

Read `database.md` first for the platform-agnostic database, RLS, and edge function content. This file covers only the Swift client (`supabase-swift`) — how the iOS app talks to the backend documented there.

## 1. Add the Swift Package

Add `supabase-swift` via SPM:

```
https://github.com/supabase/supabase-swift.git
```

## 2. Create the Supabase Client

```swift
import Foundation
import Supabase

let supabase = SupabaseClient(
    supabaseURL: URL(string: Config.EXPO_PUBLIC_SUPABASE_URL)!,
    supabaseKey: Config.EXPO_PUBLIC_SUPABASE_ANON_KEY,
    options: .init(
        auth: .init(
            accessToken: {
                // Return the Rork Auth JWT when signed in, nil when signed out.
                // With nil the SDK sends only the apikey header and the request
                // runs as the `anon` role. NEVER substitute another value:
                //   - "" → PostgREST rejects EVERY request with PGRST301 "Empty JWT"
                //   - the anon key → it is an sb_publishable_* key, not a JWT, so
                //     PostgREST rejects it too — public reads break for signed-out users
                return AuthManager.shared.getAccessToken()
            }
        )
    )
)
```

**Important notes:**

- Use `Config.EXPO_PUBLIC_*` to access environment variables, NOT `ProcessInfo.processInfo.environment`.
- The `accessToken` closure provides the Rork Auth JWT to Supabase. This token includes `role: "authenticated"` which Supabase uses for RLS.
- `getAccessToken()` is synchronous (reads from Keychain) and returns `String?`. The `accessToken` closure also returns `String?` — return the value as-is. `nil` (signed out) means the SDK sends only the `apikey` header and the request runs as the `anon` role, so public reads keep working. **Never coalesce to a fallback value**: `?? ""` makes PostgREST fail every request with PGRST301 "Empty JWT", and `?? Config.EXPO_PUBLIC_SUPABASE_ANON_KEY` is just as broken — the project key is an `sb_publishable_*` key, not a JWT, and PostgREST rejects it as a Bearer token.
- The `accessToken` closure is `async throws` in the SDK (`(@Sendable () async throws -> String?)?`), but write its body synchronously — `getAccessToken()` is a sync Keychain read, so there is nothing to `await`. Do NOT write `await AuthManager.shared.getAccessToken()` — awaiting a non-async call is a compile error.
- You MUST `import Foundation` alongside `import Supabase` — `URL(string:)` requires Foundation.

## 3. Define Swift Models

> **CRITICAL: All `Codable` / `Encodable` structs must be marked `nonisolated` and `Sendable`.**

This project uses `SWIFT_DEFAULT_ACTOR_ISOLATION = MainActor`, which means all types are implicitly `@MainActor` unless you opt out. `Codable` structs that are decoded on background threads (e.g. by Supabase's PostgREST client) will fail to compile without `nonisolated`.

```swift
nonisolated struct Post: Codable, Identifiable, Sendable {
    let id: UUID
    let userId: String
    let title: String
    let content: String?
    let createdAt: Date

    enum CodingKeys: String, CodingKey {
        case id
        case userId = "user_id"
        case title
        case content
        case createdAt = "created_at"
    }
}
```

For insert/upsert operations, create separate `Encodable` structs:

```swift
nonisolated struct PostInsert: Encodable, Sendable {
    let userId: String
    let title: String
    let content: String?

    enum CodingKeys: String, CodingKey {
        case userId = "user_id"
        case title
        case content
    }
}
```

## 4. Sync the Profile Row

After the user signs in, upsert into `profiles` (table created in `database.md`):

```swift
nonisolated struct ProfileUpsert: Encodable, Sendable {
    let id: String
    let email: String
    let name: String
}

try await supabase.from("profiles").upsert(
    ProfileUpsert(id: userId, email: userEmail, name: userName)
).execute()
```

## 5. Query Data

> **IMPORTANT: ALWAYS use `Encodable` structs for insert/upsert/update — NEVER use dictionaries.**

The Supabase Swift SDK's `insert()`, `upsert()`, and `update()` methods accept `Encodable` values. Dictionaries like `[String: String]` technically work for same-type values, but break with mixed types (String + Int + Date). The SDK does NOT have `AnyJSON.string()`, `AnyJSON.integer()`, or similar helpers — those do not exist and will cause compile errors.

**Always use typed `Encodable` structs. Never use dictionaries.**

```swift
// Select
let posts: [Post] = try await supabase
    .from("posts")
    .select()
    .order("created_at", ascending: false)
    .execute()
    .value

// Insert (use Encodable struct)
try await supabase
    .from("posts")
    .insert(PostInsert(userId: userId, title: "Hello", content: "World"))
    .execute()

// Insert and return the created record
let newPost: Post = try await supabase
    .from("posts")
    .insert(PostInsert(userId: userId, title: "Hello", content: "World"))
    .select()
    .single()
    .execute()
    .value

// Upsert (use Encodable struct — primary key must be included)
// PostgreSQL defaults to the primary key for conflict resolution,
// so you don't need to specify onConflict for PK-based upserts.
nonisolated struct CounterUpsert: Encodable, Sendable {
    let userId: String
    let count: Int

    enum CodingKeys: String, CodingKey {
        case userId = "user_id"
        case count
    }
}

try await supabase
    .from("counters")
    .upsert(CounterUpsert(userId: userId, count: newCount))
    .execute()

// Update (use Encodable struct)
nonisolated struct PostUpdate: Encodable, Sendable {
    let title: String
    let updatedAt: Date

    enum CodingKeys: String, CodingKey {
        case title
        case updatedAt = "updated_at"
    }
}

try await supabase
    .from("posts")
    .update(PostUpdate(title: "Updated", updatedAt: Date()))
    .eq("id", value: postId.uuidString)
    .execute()

// Delete
try await supabase
    .from("posts")
    .delete()
    .eq("id", value: postId.uuidString)
    .execute()
```

## 6. Invoke an Edge Function

The edge function source lives in `backend/functions/{slug}/index.ts` (see `database.md` for how to write one). The Supabase Swift SDK has multiple overloads of `functions.invoke()`. The key difference:

**Void overload** (no return value — fire-and-forget):

```swift
try await supabase.functions.invoke(
    "function-name",
    options: .init(body: someEncodableStruct)
)
```

**Generic decode overload** (returns decoded response — use when you need data back):

```swift
let result: MyResponseType = try await supabase.functions.invoke(
    "function-name",
    options: .init(method: .get)
)
```

The generic overload automatically decodes the response JSON into the specified `Decodable` type. The type annotation on the left side determines which overload is called.

**Important:** The response type struct must be `nonisolated` and conform to `Codable, Sendable`:

```swift
nonisolated struct QuoteResponse: Codable, Sendable {
    let text: String
    let author: String
}

let quote: QuoteResponse = try await supabase.functions.invoke(
    "random-quote",
    options: .init(method: .get)
)
```

**HTTP methods:**

- `.get` — for functions that only return data
- `.post` (default) — for functions that accept a request body
- Use `options: .init(method: .get)` or `options: .init(body: someEncodable)` accordingly

**Sending data to an edge function:**

```swift
nonisolated struct ProcessRequest: Encodable, Sendable {
    let input: String
}

nonisolated struct ProcessResponse: Codable, Sendable {
    let result: String
}

let response: ProcessResponse = try await supabase.functions.invoke(
    "process-data",
    options: .init(body: ProcessRequest(input: "hello"))
)
```

## Error Handling Pattern

The Swift SDK throws on errors — wrap calls in `do/catch`:

```swift
do {
    let posts: [Post] = try await supabase
        .from("posts")
        .select()
        .execute()
        .value
} catch {
    print("Failed to fetch posts: \(error)")
    // Show error to user
}
```

- Always `print` or log Supabase operation failures so they are visible during development.
- Always show error UI (alert, toast, inline message) for all user-facing operations, not just auth flows.

## Swift-Specific Gotchas (recap)

- Use `Config.EXPO_PUBLIC_*` for environment variables, NOT `ProcessInfo.processInfo.environment`.
- Mark ALL `Codable`/`Encodable` structs as `nonisolated` and `Sendable` — required by `SWIFT_DEFAULT_ACTOR_ISOLATION = MainActor`.
- **ALWAYS use `Encodable` structs for insert/upsert/update — NEVER use dictionaries or `AnyJSON`.**
- `import Foundation` is required in any file that uses `URL`, `Date`, `JSONDecoder`, etc. — don't assume `import Supabase` covers it.
- Write the `accessToken` closure body in `SupabaseClient` init synchronously — do NOT `await` the sync `getAccessToken()` helper (compile error).
- When calling `functions.invoke()`, use the **generic overload** (with type annotation) to get response data. The default overload returns `Void`.
