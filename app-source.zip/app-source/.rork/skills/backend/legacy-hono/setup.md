Enable backend for this project.

# IMPORTANT: Debugging backend

If the user is facing errors related to the backend (making requests to it,
failing requests, etc.) you have several tools that allow you to debug the
backend.

Please read the `.rork/skills/debugging/skill.md` to see them.

# ToDo list

## Setup backend

When importing, use `@/backend/...` to make the imports stable.

### Create backend/hono.ts file

backend/hono.ts is the most important file.
It is what gets deployed. If the project does not have backend/hono.ts
the backend would not be deployed.

We use what is returned from export default app

```ts
import { trpcServer } from "@hono/trpc-server";
import { Hono } from "hono";
import { cors } from "hono/cors";

import { appRouter } from "./trpc/app-router";
import { createContext } from "./trpc/create-context";

// app will be mounted at /api
const app = new Hono();

// Enable CORS for all routes
app.use("*", cors());

// Mount tRPC router at /trpc
app.use(
  "/trpc/*",
  trpcServer({
    endpoint: "/api/trpc",
    router: appRouter,
    createContext,
  }),
);

// Simple health check endpoint
app.get("/", (c) => {
  return c.json({ status: "ok", message: "API is running" });
});

export default app;
```

## Setting up TRPC

### Create create-context.ts file

You also need to create `/backend/trpc/create-context.ts` file that contains:

```ts
import { initTRPC } from "@trpc/server";
import { FetchCreateContextFnOptions } from "@trpc/server/adapters/fetch";
import superjson from "superjson";

// Context creation function
export const createContext = async (opts: FetchCreateContextFnOptions) => {
  return {
    req: opts.req,
    // You can add more context items here like database connections, auth, etc.
  };
};

export type Context = Awaited<ReturnType<typeof createContext>>;

// Initialize tRPC
const t = initTRPC.context<Context>().create({
  transformer: superjson,
});

export const createTRPCRouter = t.router;
export const publicProcedure = t.procedure;
```

### Create routes

Make a simple hi route that returns hi.
Store them per router (one file per router). For example:  
`/trpc/routes/example.ts`

This file should export a router with its routes:

```ts
import * as z from "zod";

import { createTRPCRouter, publicProcedure } from "../create-context";

export const exampleRouter = createTRPCRouter({
  hi: publicProcedure.input(z.object({ name: z.string() })).mutation(({ input }) => {
    return {
      hello: input.name,
      date: new Date(),
    };
  }),
});
```

### Create /backend/trpc/app-router.ts

Create app router including the nested ones and return:

```ts
import { createTRPCRouter } from "./create-context";
import { exampleRouter } from "./routes/example";

export const appRouter = createTRPCRouter({
  example: exampleRouter,
});

export type AppRouter = typeof appRouter;
```

### Setup client

1. Create trpc client for direct requests to TRPC, and for

```ts
import { httpLink } from "@trpc/client";
import { createTRPCReact } from "@trpc/react-query";
import superjson from "superjson";

import type { AppRouter } from "@/backend/trpc/app-router";

export const trpc = createTRPCReact<AppRouter>();

const getBaseUrl = () => {
  const url = process.env.EXPO_PUBLIC_RORK_API_BASE_URL;

  if (!url) {
    throw new Error("Rork did not set EXPO_PUBLIC_RORK_API_BASE_URL, please use support");
  }

  return url;
};

// for direct queries
export const trpcClient = trpc.createClient({
  links: [
    httpLink({
      url: `${getBaseUrl()}/api/trpc`,
      transformer: superjson,
    }),
  ],
});
```

2. Setup TRPC to be used with react-query (must)

In `/app/_layout.tsx` do all needed things to import and setup react query and trpc.

```tsx
<trpc.Provider client={trpcClient} queryClient={queryClient}>
  <QueryClientProvider client={queryClient}>{/* your app */}</QueryClientProvider>
</trpc.Provider>
```

## Required dependencies to install

DONT FORGET TO INSTALL ANY OF THEM. USE `bun add` to install them.

- @hono/trpc-server
- @trpc/server
- @trpc/client
- @trpc/react-query
- @tanstack/react-query
- hono
- superjson
- zod
