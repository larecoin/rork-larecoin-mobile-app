// lib/voice-call.ts — client side of a 1:1 voice call (web / React Native web).
//
// Pairs with ts/example-signaling-room.ts (the CallRoom Durable Object).
// Flow:
//   1. Fetch fresh ICE servers from the Rork toolkit (short-lived TURN creds).
//   2. getUserMedia (must be triggered by a user gesture, https only).
//   3. Open the signaling WebSocket to the project's own backend.
//   4. The peer that JOINS an occupied room receives `peer-joined` with
//      `initiator: true` and creates the offer; the other peer answers.
//   5. Trickle ICE: candidates are relayed through the room as they appear.
//
// For video calls, add `video: true` to getUserMedia and render the remote
// stream in a <video> element instead of <audio>.

type SignalMessage =
  | { type: "peer-joined"; peerId: string; initiator: boolean }
  | { type: "peer-left"; peerId: string }
  | { type: "offer"; payload: RTCSessionDescriptionInit; from: string }
  | { type: "answer"; payload: RTCSessionDescriptionInit; from: string }
  | { type: "ice-candidate"; payload: RTCIceCandidateInit; from: string };

export type VoiceCall = {
  /** Remote audio stream — attach to an <audio autoplay> element. */
  remoteStream: MediaStream;
  /** Mute/unmute the local microphone. */
  setMuted(muted: boolean): void;
  /** Hang up: closes the peer connection, signaling socket, and mic. */
  hangUp(): void;
};

export async function joinVoiceCall(options: {
  roomId: string;
  onRemoteStreamReady?: () => void;
  onPeerLeft?: () => void;
}): Promise<VoiceCall> {
  const toolkitUrl = process.env.EXPO_PUBLIC_TOOLKIT_URL!;
  const secretKey = process.env.EXPO_PUBLIC_RORK_TOOLKIT_SECRET_KEY!;
  const backendUrl = process.env.EXPO_PUBLIC_RORK_FUNCTIONS_URL!;

  // 1. Fresh ICE servers per call — credentials expire (ttlSeconds).
  const iceResponse = await fetch(`${toolkitUrl}/v2/webrtc/ice-servers`, {
    headers: { Authorization: `Bearer ${secretKey}` },
  });
  if (!iceResponse.ok) {
    throw new Error(`Failed to fetch ICE servers: ${iceResponse.status}`);
  }
  const { iceServers } = (await iceResponse.json()) as { iceServers: RTCIceServer[] };

  // 2. Microphone — call joinVoiceCall from a button press so the permission
  // prompt is tied to a user gesture.
  const localStream = await navigator.mediaDevices.getUserMedia({ audio: true });

  const pc = new RTCPeerConnection({ iceServers });
  const remoteStream = new MediaStream();

  for (const track of localStream.getTracks()) {
    pc.addTrack(track, localStream);
  }

  pc.ontrack = (event) => {
    for (const track of event.streams[0]?.getTracks() ?? [event.track]) {
      remoteStream.addTrack(track);
    }
    options.onRemoteStreamReady?.();
  };

  // 3. Signaling over the project's own Cloudflare backend.
  const wsUrl = new URL(`/call/${options.roomId}`, backendUrl);
  wsUrl.protocol = wsUrl.protocol === "http:" ? "ws:" : "wss:";
  const ws = new WebSocket(wsUrl.toString());

  const sendSignal = (msg: { type: string; payload: unknown }) => {
    if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(msg));
  };

  // 5. Trickle ICE — relay candidates as they are gathered.
  pc.onicecandidate = (event) => {
    if (event.candidate) {
      sendSignal({ type: "ice-candidate", payload: event.candidate.toJSON() });
    }
  };

  ws.onmessage = async (event) => {
    const msg = JSON.parse(String(event.data)) as SignalMessage;

    switch (msg.type) {
      case "peer-joined": {
        // 4. Deterministic caller: the joiner (initiator) creates the offer.
        if (msg.initiator) {
          const offer = await pc.createOffer();
          await pc.setLocalDescription(offer);
          sendSignal({ type: "offer", payload: offer });
        }
        break;
      }
      case "offer": {
        await pc.setRemoteDescription(msg.payload);
        const answer = await pc.createAnswer();
        await pc.setLocalDescription(answer);
        sendSignal({ type: "answer", payload: answer });
        break;
      }
      case "answer": {
        await pc.setRemoteDescription(msg.payload);
        break;
      }
      case "ice-candidate": {
        await pc.addIceCandidate(msg.payload);
        break;
      }
      case "peer-left": {
        options.onPeerLeft?.();
        break;
      }
    }
  };

  return {
    remoteStream,
    setMuted(muted: boolean) {
      for (const track of localStream.getAudioTracks()) {
        track.enabled = !muted;
      }
    },
    hangUp() {
      ws.close();
      pc.close();
      for (const track of localStream.getTracks()) {
        track.stop();
      }
    },
  };
}
