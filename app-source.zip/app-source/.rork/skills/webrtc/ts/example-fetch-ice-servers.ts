// Usage: bun example-fetch-ice-servers.ts <TOOLKIT_URL> <SECRET_KEY>
//
// Fetches short-lived ICE servers (Cloudflare STUN + per-project TURN
// credentials) from the Rork toolkit. The returned `iceServers` array is
// passed directly to `new RTCPeerConnection({ iceServers })`.
//
// In app code, TOOLKIT_URL comes from process.env.EXPO_PUBLIC_TOOLKIT_URL and
// SECRET_KEY from process.env.EXPO_PUBLIC_RORK_TOOLKIT_SECRET_KEY.

type IceServersResponse = {
  iceServers: {
    urls: string[];
    username?: string;
    credential?: string;
  }[];
  /** Credentials expire after this many seconds — fetch fresh ones per call. */
  ttlSeconds: number;
};

export async function fetchIceServers(toolkitUrl: string, secretKey: string): Promise<IceServersResponse> {
  const response = await fetch(`${toolkitUrl}/v2/webrtc/ice-servers`, {
    headers: { Authorization: `Bearer ${secretKey}` },
  });

  if (!response.ok) {
    throw new Error(`Failed to fetch ICE servers: ${response.status} ${await response.text()}`);
  }

  return (await response.json()) as IceServersResponse;
}

const [toolkitUrl, secretKey] = process.argv.slice(2);
if (!toolkitUrl || !secretKey) {
  console.error("Usage: bun example-fetch-ice-servers.ts <TOOLKIT_URL> <SECRET_KEY>");
  process.exit(1);
}

const { iceServers, ttlSeconds } = await fetchIceServers(toolkitUrl, secretKey);
console.log(`Got ${iceServers.length} ICE server entries, valid for ${ttlSeconds}s`);
for (const server of iceServers) {
  console.log(`- urls: ${server.urls.join(", ")} (credentials: ${server.username ? "yes" : "no"})`);
}
