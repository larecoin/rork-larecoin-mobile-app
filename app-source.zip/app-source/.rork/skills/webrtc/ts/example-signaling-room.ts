// functions/call-room.ts — WebRTC signaling room, one DO instance per call.
//
// The room only RELAYS signaling messages (SDP offers/answers, ICE
// candidates) between the peers in a call — media flows peer-to-peer (or via
// Cloudflare TURN), never through this DO.
//
// Rork protocol notes (see the backend skill's durable-objects.md):
//   - Public WebSocket routes dispatch through `env.DO.fetch(wrapped)` with
//     X-Rork-DO-Class / X-Rork-DO-Id headers — the WebSocket-safe path.
//   - Never await a `do://internal/...` call before returning the 101.
//   - Always use the 2-arg `new Request(url, request)` form when forwarding
//     an incoming WS request; `new Request(request)` drops Upgrade headers.

import { DurableObject } from "cloudflare:workers";

type PeerAttachment = {
  peerId: string;
};

/**
 * Signaling messages are relayed verbatim with a stamped `from` peer id.
 * Clients send: { type: "offer" | "answer" | "ice-candidate", payload }.
 * The room adds: { type: "peer-joined" | "peer-left", peerId }.
 */
type RelayMessage = {
  type: "offer" | "answer" | "ice-candidate";
  payload: unknown;
};

const MAX_PEERS = 2;

export class CallRoom extends DurableObject {
  override async fetch(request: Request): Promise<Response> {
    if (request.headers.get("Upgrade") !== "websocket") {
      return new Response("expected websocket", { status: 426 });
    }

    const url = new URL(request.url);
    const peerId = url.searchParams.get("peerId");
    if (!peerId) {
      return new Response("missing peerId", { status: 400 });
    }

    if (this.ctx.getWebSockets().length >= MAX_PEERS) {
      return new Response("room full", { status: 409 });
    }

    const pair = new WebSocketPair();
    const [client, server] = Object.values(pair);

    this.ctx.acceptWebSocket(server, [`peer:${peerId}`]);
    server.serializeAttachment({ peerId } satisfies PeerAttachment);

    // Tell the new peer who is already here with `initiator: true` (the
    // JOINER creates the offer — a deterministic caller/callee split with no
    // extra coordination), and tell existing peers someone arrived.
    for (const ws of this.ctx.getWebSockets()) {
      if (ws === server) continue;
      const other = ws.deserializeAttachment() as PeerAttachment | null;
      if (!other) continue;
      send(server, { type: "peer-joined", peerId: other.peerId, initiator: true });
      send(ws, { type: "peer-joined", peerId, initiator: false });
    }

    return new Response(null, { status: 101, webSocket: client });
  }

  override webSocketMessage(ws: WebSocket, raw: string | ArrayBuffer): void {
    if (typeof raw !== "string") return;

    const attachment = ws.deserializeAttachment() as PeerAttachment | null;
    if (!attachment) return;

    let msg: unknown;
    try {
      msg = JSON.parse(raw);
    } catch {
      return;
    }
    if (!isRelayMessage(msg)) return;

    // 1:1 room — relay to every other peer with the sender stamped on.
    const data = JSON.stringify({ ...msg, from: attachment.peerId });
    for (const other of this.ctx.getWebSockets()) {
      if (other === ws) continue;
      try {
        other.send(data);
      } catch {
        // The socket may be mid-close.
      }
    }
  }

  override webSocketClose(ws: WebSocket): void {
    const attachment = ws.deserializeAttachment() as PeerAttachment | null;
    if (!attachment) return;

    for (const other of this.ctx.getWebSockets()) {
      if (other === ws) continue;
      send(other, { type: "peer-left", peerId: attachment.peerId });
    }
  }
}

function send(ws: WebSocket, msg: unknown): void {
  try {
    ws.send(JSON.stringify(msg));
  } catch {
    // The socket may be mid-close.
  }
}

function isRelayMessage(value: unknown): value is RelayMessage {
  return (
    typeof value === "object" &&
    value !== null &&
    "type" in value &&
    (value.type === "offer" || value.type === "answer" || value.type === "ice-candidate")
  );
}

// functions/index.ts — public route for call signaling.
//
// Re-export every DO class from the root entrypoint (side-effect imports are
// tree-shaken) and dispatch WebSocket upgrades via env.DO.fetch.

export { CallRoom } from "./call-room";

type Env = { DO: Fetcher };

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);

    const callMatch = url.pathname.match(/^\/call\/([^/]+)$/);
    if (callMatch && request.headers.get("Upgrade") === "websocket") {
      // Prefer the Rork-authenticated user id; fall back to a client-supplied
      // peer id for anonymous calls.
      const peerId = request.headers.get("X-Rork-User-Id") ?? url.searchParams.get("peerId") ?? crypto.randomUUID();
      url.searchParams.set("peerId", peerId);

      const headers = new Headers(request.headers);
      headers.set("X-Rork-DO-Class", "CallRoom");
      headers.set("X-Rork-DO-Id", callMatch[1]!);
      return env.DO.fetch(
        new Request(url.toString(), {
          method: request.method,
          headers,
          body: request.body,
          redirect: request.redirect,
        }),
      );
    }

    return new Response("not found", { status: 404 });
  },
} satisfies ExportedHandler<Env>;
