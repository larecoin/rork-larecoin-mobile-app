---
name: webrtc
description: Real-time voice and video calls between users with WebRTC. Rork provides managed STUN/TURN (Cloudflare) via a free toolkit endpoint that mints short-lived ICE credentials per project. Use when the user asks for voice chat, video calls, audio rooms, walkie-talkie, or any live peer-to-peer audio/video feature.
aliases:
  - webrtc
  - voice chat
  - voice call
  - video call
  - video chat
  - video conferencing
  - audio call
  - calls
  - calling
  - walkie-talkie
  - audio room
  - peer-to-peer
  - p2p
  - TURN
  - STUN
  - ICE servers
  - RTCPeerConnection
---

# WebRTC voice & video calls

Use this skill for live user-to-user audio/video: voice chat, video calls, audio rooms, walkie-talkie features.

A call has three parts:

1. Media — WebRTC peer connection. Direct P2P when possible; Cloudflare TURN relays when NATs/firewalls block it.
2. ICE servers — fetched from the Rork toolkit endpoint below. Includes Cloudflare STUN plus short-lived TURN credentials minted for this project.
3. Signaling — the project's own Cloudflare backend: a Durable Object WebSocket room that relays SDP offers/answers and ICE candidates between peers. See the backend skill for DO patterns.

## GET /v2/webrtc/ice-servers

Fetch fresh ICE servers from the Rork toolkit before each call. Before using the endpoint, call `getOrCreateToolkitSecret` to provision the API key.

```http
GET <EXPO_PUBLIC_TOOLKIT_URL>/v2/webrtc/ice-servers
Authorization: Bearer <EXPO_PUBLIC_RORK_TOOLKIT_SECRET_KEY>
```

Response (200):

```json
{
  "iceServers": [
    { "urls": ["stun:stun.cloudflare.com:3478"] },
    {
      "urls": ["turn:turn.cloudflare.com:3478?transport=udp", "turns:turn.cloudflare.com:5349?transport=tcp"],
      "username": "<generated>",
      "credential": "<generated>"
    }
  ],
  "ttlSeconds": 7200
}
```

Pass `iceServers` directly to `new RTCPeerConnection({ iceServers })`.

- The endpoint is free (no toolkit balance charge) but rate limited per project.
- Credentials expire after `ttlSeconds` (2 hours). Fetch fresh credentials when a call starts; never persist them.
- Some returned urls use port 53, which browsers may block. Harmless with trickle ICE (the default) — do not filter them.

<important>
NEVER hardcode third-party public STUN/TURN servers (openrelay.metered.ca, Google STUN, expressturn, etc.) and NEVER embed static TURN credentials in app code. Always fetch ICE servers from the Rork endpoint above — it is the supported, monitored path.
</important>

## Platform support

- Web apps and the React Native web preview: built-in browser `RTCPeerConnection` + `navigator.mediaDevices.getUserMedia`. Works out of the box.
- React Native on native iOS/Android: WebRTC needs the `react-native-webrtc` native module, which is NOT available in the Rork native preview. Gate call features with `Platform.OS === "web"` and show a short "calls are available on web" notice on native instead of crashing.

## Implementation

Read these sample files for complete, working examples:

- ts/example-fetch-ice-servers.ts — fetch ICE servers from the toolkit (runnable: `bun example-fetch-ice-servers.ts <TOOLKIT_URL> <SECRET_KEY>`)
- ts/example-signaling-room.ts — Cloudflare backend: CallRoom Durable Object WebSocket signaling + entrypoint routes (follows the backend skill's DO dispatch rules)
- ts/example-voice-call-client.ts — client: connect signaling, getUserMedia, RTCPeerConnection wiring with trickle ICE for a 1:1 call

Microphone/camera access requires a secure context (https) and a user gesture; request `getUserMedia` from a button press, not on mount.
